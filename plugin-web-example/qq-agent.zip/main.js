'use strict';

/**
 * QQ 助手 · Node 侧（跑在 Electron `utilityProcess` 里，P1）
 *
 * <h3>它做什么</h3>
 * 连 NapCat（OneBot 11 over WS）→ 收私聊 → 四层闸门 → 调平台 `/agent/run` → 拟人化发送。
 *
 * <h3>它不做什么（P1 范围）</h3>
 * 群聊、看图、语音、主动发言、改资料都在后续阶段；本文件只保证「私聊 + 白名单 + 人格 + 拟人化」跑通，
 * 因为这几步跑通之前，后面任何能力都没有意义。
 *
 * <h3>配置为什么放文件而不是 manifest.config</h3>
 * 界面插件的 `manifest.config` 值存在**浏览器 localStorage**，而这段代码跑在
 * **Node 子进程**里，读不到 localStorage。所以配置放 `api.dataDir/config.json`（本机文件），
 * 由插件自己的设置面板通过 `methods.saveConfig` 写入。
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const net = require('node:net');
const { spawn, exec } = require('node:child_process');
const { WebSocket } = require('ws');

// ------------------------------------------------------------------ 状态

let api = null;
let ws = null;
let cfg = null;
let stopping = false;
let reconnectTimer = null;
let reconnectDelay = 1000;

/** 对外的运行状态（前端状态球与 methods.status 都用它）。 */
const stats = {
  connected: false,
  uin: 0,
  nickname: '',
  received: 0,
  replied: 0,
  skipped: 0,
  lastSkipReason: '',
  lastError: '',
  lastAt: 0,
  silenceUntil: 0,
};

/** 全局静默截止时间（毫秒时间戳）—— 这段时间内**不回任何人**（真人也这样）。 */
let silenceUntil = 0;
/** 当前静默期内是否已经抽过值（避免每来一条都重抽）。 */
let silencePrimed = false;

// ------------------------------------------------------------------ P3 状态

/**
 * 自我管理的冷却截止时间（毫秒时间戳）—— **必须落盘**。
 *
 * 不落盘的话每次重启都会重新抽冷却值，于是"刚换过头像又被换一次"；
 * 这种行为模式比"从不换头像"更容易被判定为非真人。
 */
const selfState = {
  /** 各类资料的冷却截止时间（毫秒时间戳）。 */
  avatar: 0,
  signature: 0,
  nickname: 0,
  /** 上次"自我检视"时间 —— 防止模型说"不改"之后每 10 分钟又问一次。 */
  lastCheck: 0,
  /** 上次主动发言时间。 */
  lastProactiveAt: 0,
  /**
   * 上次"突然想到点什么"的时间（2026-11-05）。
   *
   * <p>必须在这里声明 —— `loadSelfState` 按 `Object.keys(selfState)` 遍历，
   * 没声明的字段重启就丢，于是她会每十分钟"灵感"一次。</p>
   */
  lastInspirationAt: 0,
  /**
   * 距离上次整理「长期记忆」过了多少轮（2026-11-01）。
   *
   * <p>carryover 原来只在 /clear 时写 —— 不 clear 就永远是迁移那 17 条，
   * 而后面发生的事只能进摘要，被 24 条上限一路挤掉。
   * 现在每 80 轮自动整理一次，把新事并进长期记忆。</p>
   */
  turnsSinceCarryover: 0,
  /**
   * 最近几次**主动**找他时说了什么（2026-11-02）。
   *
   * <p><b>为什么需要</b>：主动发言每次都是全新生成，她自己不知道"快递刚说过"，
   * 于是反复说同一件事（先是馄饨，后是快递）。给禁止清单没用 ——
   * 换个词照样中招。记下真实说过的话，让她自己避开，才是动态的。</p>
   *
   * <p>结构：{@code [{ at, peer, text }]}，全局留最近 30 条。</p>
   */
  recentProactiveTopics: [],

  /**
   * 主动发言的「连续追发」状态（2026-10-26）。
   *
   * <p>`{ count, peer, lastAt }`：`count` 是连续未回应次数。</p>
   *
   * <p><b>声明在这里才能被持久化</b>：`loadSelfState` 是按
   * `Object.keys(selfState)` 遍历的 —— 没在这里声明的字段，重启后直接丢。</p>
   */
  proactiveChain: null,
  /** 上次拉起 NapCat 的时间戳（2026-10-28）：用于冷却，防止反复新开。 */
  napcatLaunchedAt: 0,
  /**
   * 情绪状态（2026-10-27）。
   *
   * <p>`{ mood:{p,a,d}, emotion:{p,a,d}, cause, updatedAt }`</p>
   *
   * <p>**必须是对象** —— `loadSelfState` 走 `Object.keys(selfState)` 遍历，
   * 没在这里声明的字段重启就丢（`proactiveChain` 踩过这个坑）。</p>
   */
  affect: null,
  /** 当前昵称 / 签名（给模型看"现状"，它才知道要不要改）。 */
  nicknameValue: '',
  signatureValue: '',
  /**
   * 它"想要一个什么样的头像"（2026-10-21）。
   *
   * <p>与"改不改头像"分开存：模型说"这轮不改"时，这个愿望依然有意义 ——
   * 下次自我检视时把它呈现回去，它才有连续的想法，而不是每次凭空想个关键词。</p>
   */
  avatarWish: '',
  /**
   * 一次性资料是否已初始化（2026-10-21）。
   *
   * <p>`sex` / `personalNote` 只定一次：它们不像签名那样经常变，反复改反而可疑。
   * 置位后提示词里不再提这两项，模型也不会再被问。</p>
   *
   * <p>字段名沿用 NapCat 的 `set_qq_profile` —— 它**只开放 nickname / personal_note / sex
   * 三项**，生日、学校、公司、家乡这些接口不存在（不是漏做）。</p>
   */
  profileInit: false,
  sexValue: '',
  personalNoteValue: '',
  /*
   * 下面几个**必须在声明里出现**：`loadSelfState` 是按 `Object.keys(selfState)`
   * 回填的，动态加上的属性重启后就丢了（冷却会被重置 → 行为变得可疑）。
   */
  /** 上次写日记的时间。 */
  lastDiaryAt: 0,
  /** 上次发说说的时间（F9 冷却）。 */
  lastQzoneAt: 0,
  /** 上次设置的在线状态（只在变化时才调 API）。 */
  onlineStatus: 0,
  };

/** carryover 整理是否正在进行（防并发重入，2026-11-01）。 */
let carryoverRefreshing = false;

/** 最近互动过的人：peer → { lastAt, isPrivate }（只存内存，重启后重新积累）。 */
const recentContacts = new Map();

/**
 * 每个群最近的消息（2026-10-21）。
 *
 * <p><b>为什么存全量、而不是只存"通过闸门"的</b>：模型要判断"这句话该不该接"，
 * 就必须知道**群里刚才在聊什么**。只给它一条 @ 消息，它只能瞎猜；
 * 给它上面 8 条，它能看出"他们在互相讨论版本问题"和"他们在叫我"的区别。</p>
 *
 * <p>只存内存：重启后重新积累。存盘没意义 —— 上次的群聊对现在没有参考价值。</p>
 */
const groupBuffer = new Map();
const GROUP_BUFFER_MAX = 20;

/** 取纯文本（不解析引用、不下载图片）—— 缓冲区要快，不能每条都打 API。 */
function quickText(e) {
  const segs = Array.isArray(e.message) ? e.message : [];
  return segs
    .filter((s) => s && s.type === 'text')
    .map((s) => s.data?.text || '')
    .join('')
    .trim();
}

/**
 * 拼「群里刚才在聊」这一段。
 *
 * <p>排除当前这条（它本身会作为 user 消息发出去，重复出现会让模型以为说了两遍）。</p>
 */
function groupContextBlock(gid) {
  const buf = groupBuffer.get(Number(gid)) || [];
  const previous = buf.slice(-9, -1);   // 最近 8 条，不含刚进来的这条
  if (previous.length === 0) {
    return '';
  }
  const lines = previous.map((m) => `${m.sender}：${m.text}`);
  return `【群里刚才在聊】\n${lines.join('\n')}\n\n`;
}

/** 心跳定时器（自我管理 + 主动发言共用）。 */
let heartbeat = null;
/** 连接探活定时器（每 2 分钟一次，与业务心跳分开）。 */
let healthTimer = null;
/** 心跳日志节流时间戳：30 分钟一条，用来确认心跳还活着（2026-10-23）。 */
let lastTickLogAt = 0;

const DEFAULTS = {
  // 总开关：默认关。装完不会自动回消息，必须先明确启用。
  enabled: false,
  /**
   * NapCat 启动脚本的完整路径（2026-10-27）。
   *
   * <p>填了就支持"平台启动时顺带把 NapCat 拉起来"，省得每次开机手动点。
   * 通常指向 `bootmain\napcat.quick.bat`。</p>
   *
   * <p><b>留空 = 不自动启动</b>（行为和以前一样）。</p>
   */
  napcatPath: '',
  /** 是否在插件加载时自动拉起 NapCat（默认开，但路径为空时不做事）。 */
  napcatAutoStart: true,
  /**
   * 启动冷却（分钟，2026-10-28）。
   *
   * <p>**只在"上次启动的进程还在"时才有意义** —— 进程已退出说明那次彻底失败，
   * 立即允许重试。所以这里留 2 分钟，作用只是挡住同一瞬间被调用两次。</p>
   */
  napcatLaunchCooldownMin: 2,
  napcatWs: 'ws://127.0.0.1:3001',
  napcatToken: '',
  selfUin: 0,
  // 用哪个智能体跑（平台里的 agentId）
  agentId: '',
  // 白名单：空数组 = 全部忽略（默认安全）。只有列出的才处理。
  privateWhitelist: [],
  /**
   * **主人**的 QQ 号（2026-10-24）。
   *
   * <p>只有一个作用：**决定「事件流」给谁看**。</p>
   * <ul>
   *   <li>别人跟她说的话 → 记进 `events.jsonl` → **只有主人**能看到，
   *       所以她能对主人说"今天有人来打听你"；</li>
   *   <li>主人跟她说的话 → **根本不记** → 别人问什么都拿不到。</li>
   * </ul>
   *
   * <p>这条规则是单向的：**别人的事可以上报给主人，主人的事不下传。**
   * 只有「是谁说的」这一个判断，不需要她猜哪句算隐私。</p>
   *
   * <p>留空 = 没有主人，事件流谁都不给看（等于这个功能关掉）。</p>
   */
  owners: '',

  // ---------------- Minecraft 记忆（2026-11-04） ----------------

  /**
   * 要不要在聊天里读取「她和他一起玩 Minecraft 的记忆」。
   *
   * <p><b>不是每轮都读</b>：游戏记忆动辄几百字，每轮都带等于白烧 token，
   * 更糟的是她会在你聊别的事时硬扯游戏。触发条件见 {@code gameMemoryBlock}：
   * 聊到游戏 / 她正在游戏里 / 刚玩完不久 / 主动开口。</p>
   *
   * <p>文档由 **MC 助手插件**写入 `memory/minecraft.md`，这里只读。</p>
   */
  minecraftMemoryEnabled: true,
  /** 每次最多带多少字（保留最近的尾部）。 */
  minecraftMemoryChars: 600,
  /** 「刚玩完多久之内」算相关（小时）。 */
  minecraftRecentHours: 8,
  /** 留空 = 自动用 memory/minecraft.md；一般不用改。 */
  minecraftMemoryPath: '',
  /*
   * 群白名单（2026-10-21 补进 DEFAULTS —— 之前一直漏了）。
   *
   * <p><b>为什么是必修</b>：manifest 里早就有这个配置项，但 DEFAULTS 从没声明它。
   * `saveConfig` 只接受 DEFAULTS 里出现过的 key，于是用户在设置面板里改的群号
   * 会被**静默丢弃**（看起来保存成功，实际没生效）；若配置文件里也没有该字段，
   * `cfg.groupWhitelist` 为 undefined → `parseIds` 返回空数组 → **群聊永远不回复**。</p>
   */
  groupWhitelist: [],
  /** 群聊要不要也记进事件流（2026-10-24）。默认开；私密群可关。 */
  eventLogGroup: true,
  /**
   * 确认过的熟人名单（2026-10-23）—— 防冒充。
   *
   * <p>格式 `QQ号=关系`，逗号或换行分隔。这是**唯一权威的身份来源**：
   * 系统提示词里写的描述要模型"读懂再推理"，而这里是直接查表，
   * 她只需要照着做 —— 名单里的号认下来，不在的号一律不轻信自称。</p>
   *
   * <p>留空 = 谁都不在名单里，所有人自称的身份都不作数（最保守）。</p>
   */
  knownPeople: '',
  // 回复概率：私聊 0.9（几乎都回，但不是 100%），群聊 0.55（经常不理）
  replyPrivate: 0.9,
  replyGroup: 0.55,
  /**
   * 沉默期开关（2026-10-20 改为显式开关，**默认关闭**）。
   *
   * <p>原来只有"概率 30%"这一道，而 `silencePrimed` 在**每次重启 / 每次保存配置**时
   * 都会重置 —— 调试期频繁重启，几乎每隔几次就会撞上 20~90 分钟不回话。
   * 正式使用时它确实更像真人，但**默认不该是开着的**。</p>
   */
  silenceEnabled: false,
  silenceMinMinutes: 20,
  silenceMaxMinutes: 90,
  // 打字节奏
  firstDelayMs: [1000, 4000],
  charDelayMs: [30, 90],
  segmentGapMs: [800, 2500],
  /*
   * 分段（2026-10-22 再调）。
   *
   * `maxSegments`：软上限，超出时把剩余段落合并成最后一条，**不丢内容**。
   *
   * `maxSegmentChars`：**不再参与常规切分** —— 在哪断由 `segmentRegex` 说了算。
   * 它只作极端兜底（单段超过这个长度才强制切，防 QQ 单条发不出去）。
   * 之前默认 60 并拿它硬切，把「…手叠着，手指尖是冷的」劈成「…手叠着，指」/「尖是冷的…」。
   */
  maxSegments: 8,
  maxSegmentChars: 1000,
  /**
   * 每轮请求带多少轮历史（2026-10-23）。
   *
   * 平台默认 10 轮 = 20 条消息。两天聊 78 条时，前 58 条进不了上下文 ——
   * 她"记不住前天说的"就是这个原因（消息都在 `message` 表，只是没带上来）。
   * 40 轮 ≈ 80 条，够覆盖两天；token 约 4k。
   */
  maxHistoryTurns: 40,
  typing: true,
  /*
   * 这里原本有个 `systemPromptPrefix`（每轮请求附带的人格补充），2026-10-21 删除。
   * 人格已归平台智能体页统一管理 —— 插件再插一段，只会让同一个智能体在不同入口
   * 表现不一致。旧配置文件里若还留着这个字段，`saveConfig` 会顺手过滤掉。
   */
  // 表情包（2026-10-20，P2）：本地图片目录，回复后按概率附一张
  /**
   * 表情库目录（2026-10-25 起改为"收藏 + 主动使用"）。
   *
   * 目录里的图由两部分来：别人发来的表情（自动收）、用户自己丢进去的。
   * 命名约定 `{情绪}_{序号}.{ext}`，情绪取 开心 / 无语 / 难过 / 生气 / 通用。
   *
   * 发不发、发什么情绪，**由她写 `[表情 开心]` 决定**，不再有概率开关。
   */
  stickerDir: '',
  // 语音（2026-10-20，P2）：走 OpenAI 兼容的 /audio/speech 接口
  /**
   * TTS 来源（2026-10-23）：
   *   · `openai`     —— 任意 OpenAI 兼容的 `/v1/audio/speech`（硅基流动等）
   *   · `gpt-sovits` —— 本地克隆，走 `/tts`，**不需要 key**
   */
  ttsProvider: 'openai',
  ttsBaseUrl: '',
  /**
   * GPT-SoVITS 的独立地址（2026-11-01）。
   *
   * <p>它和上面的 {@code ttsBaseUrl} 不是一回事：那个是云端 TTS 的地址，
   * 这个是本地 GPT-SoVITS 的。两个 TTS 要同时用（长句走克隆、短句退回云端），
   * 地址必须分开。</p>
  ttsSovitsBaseUrl: 'http://127.0.0.1:9880',
  /** GPT-SoVITS 目录（2026-11-02）：填了就能在启动时自动拉起并加载权重。 */
  sovitsDir: '',
  sovitsAutoStart: true,
  sovitsPort: 9880,
  /**
   * GPT-SoVITS 的采样参数（2026-11-01）。
   *
   * <p><b>seed 是关键</b>：不固定时同一句话每次生成的音频都不同，
   * 聊天里听感差别很大；固定后同一句话永远同一个音频，不同话仍然不同。</p>
  ttsTemperature: 0.7,
  ttsTopK: 15,
  ttsSeed: 12345,
  ttsSpeedFactor: 1,
  /** 短于这个字数就退回默认 TTS（短句走 GPT-SoVITS 会念得又快又怪）。 */
  ttsMinChars: 8,
  ttsApiKey: '',
  ttsModel: 'tts-1',
  ttsVoice: 'alloy',
  /**
   * GPT-SoVITS 的参考音频与它的文字（2026-10-23）。
   *
   * <p>这两项决定"她的声音像谁"：给它一段 3~10 秒的干净人声，
   * 它就能用那个音色说话。**参考音频必须放在 GPT-SoVITS 所在机器上**，
   * 路径从它的视角写（如 `D:\\GPT-SoVITS\\ref\\her.wav`）。</p>
   *
   * <p>`ttsRefText` 要和音频内容**逐字一致**，否则音色会飘。</p>
   */
  ttsRefAudio: '',
  ttsRefText: '',
  /** 用语音回复的概率（0 = 全文字）。只在回答较短时触发 —— 长文念出来没人听。 */
  voiceChance: 0,
  /** 超过这个字数就不转语音。 */
  voiceMaxChars: 60,
  /** 看图（2026-10-20，P2）：收到图片时交给平台的多模态模型。 */
  visionEnabled: true,
  /**
   * 消息接收窗口期（秒，2026-10-20）。
   *
   * 收到消息后先等这么久；期间再来消息就**重置计时并合并**，直到安静满窗才回复。
   * 真人也这样：对方连发三条，你不会逐条回三次。0 = 关闭。
   */
  debounceSeconds: 3,
  /**
   * 分段用的正则（匹配式，不是分割式）。**留空 = 智能分段**（推荐）。
   *
   * <p><b>2026-10-27 把默认值清空</b>。之前这里残留着
   * {@code .*?[。？！~…]+|.+$}，于是即使把 config.json 里那项清空，
   * `loadConfig` 也会用这个默认值打底 —— 「换行优先」的智能分段
   * **从来没真正生效过**。</p>
   *
   * <p>表现就是：括号旁白被旧正则跨行粘进正文（`（笑）……` 这种），
   * `stripStageDirection` 抓不到，于是原样发出去；而且一次回复被切成五六条。
   * 前两次只清了 config.json、没动这里，所以每次都"又变回去"。</p>
   */
  segmentRegex: '',
  /**
   * 把 Markdown 转成纯文本（默认开）。
   *
   * QQ 不渲染 Markdown，平台提示词教出来的 `**粗体**` / `- 列表` / `| 表格 |`
   * 在那里全是字面符号。关掉它就原样发（比如你换成了支持 Markdown 的平台）。
   */
  stripMarkdown: true,

  // ---------------- 自我管理（P3，文档 §5.5） ----------------
  /** 总开关：改头像 / 昵称 / 签名。默认关 —— 会真的动账号资料。 */
  selfManageEnabled: false,
  /** 头像池目录（本机图片）：模型给出画面描述后，按关键词在这里找图。 */
  avatarDir: '',
  /**
   * 自我检视间隔（小时）—— 表单里是两个数字，代码里拼成区间随机。
   *
   * 检视 = 问一次模型"要不要改资料"。**必须节流**：模型多数时候会说"不改"，
   * 若每 10 分钟问一次，一天就是 144 次无谓的模型调用。
   */
  selfCheckHoursMin: 2,
  selfCheckHoursMax: 6,
  /** 冷却天数区间（随机取值并落盘，避免"一天改三次"这种异常行为）。 */
  avatarCooldownDays: [7, 30],
  signatureCooldownDays: [3, 14],
  nicknameCooldownDays: [30, 90],

  // ---------------- 主动发言（P3，文档 §9.2） ----------------
  /** 总开关。默认关 —— 开着就像"AI 突然找你聊天"。 */
  proactiveEnabled: false,
  /**
   * 两次主动发言的间隔（小时，区间随机）。
   *
   * 拆成两个数字而不是数组：**表单不支持数组**，合并成一个字段就只能手改
   * `config.json`。默认 2~8 小时 —— 短于 2 小时会显得粘人，长于一天又像不存在。
   */
  proactiveGapHoursMin: 2,
  proactiveGapHoursMax: 8,
  /** 对方必须安静这么久（分钟）才考虑主动 —— 正在聊天时不要打断。 */
  proactiveQuietMinutes: 15,
  /** 每次检查真正发送的概率（0~1）。0.35 意味着多数检查都会放弃。 */
  proactiveChance: 0.35,

  // ---------------- 灵感涌现（2026-11-05） ----------------
  /**
   * 突然想到点什么就找他 —— 和"主动发言"是两套东西。
   *
   * <p>主动发言是"间隔到了 + 抽签中了 → 生成一句话"；灵感是
   * **被具体的记忆碎片勾起来的**（想起他昨天那句、看到窗外、手上这事有进展）。
   * 内容不给清单，由她自己冒。</p>
   */
  inspirationEnabled: true,
  /** 两次灵感至少隔多久（分钟），实际 ±随机；太短会显得躁动。 */
  inspirationGapMinutes: 50,
  /** 只对最近这么多小时内互动过的人主动。 */
  proactiveWithinHours: 48,
  /**
   * 主动发言找谁（2026-10-24）。
   *
   * <p>`owner`（默认）：只找主人。陌生人不主动 —— 实测她给刚加的人发
   * "刷到个视频挺有意思"，对方回"？找我干嘛"，很尴尬。</p>
   * <p>`smart`：主人优先；陌生人要安静 6 小时以上、且她对其有印象才可能被找。</p>
   * <p>`any`：旧行为，谁都可能被找。</p>
   */
  proactiveTargetMode: 'owner',
  /**
   * 天气素材（2026-10-28）。
   *
   * 主动发言时查一次"他那边今天天气"，作为"没话题可聊"时的备用素材。
   * 走 Open-Meteo，免费无需 key。这是**唯一同时满足"每天变"和"跟他有关"**的素材。
   */
  /**
   * 主动发言前联网搜一条新鲜事（2026-10-28）。
   *
   * 需要智能体挂载 `web_search` 插件（内置插件里配 DeepSeek 或 Tavily）。
   * 拿不到就静默跳过，不影响主动发言本身。
   */
  /**
   * 夜间静默时段（2026-10-28）。`start === end` 表示关闭。
   *
   * 凌晨三点发「你怎么不理我」比不发更糟 —— 这段时间连追发也一起拦。
   */
  proactiveQuietHourStart: 23,
  proactiveQuietHourEnd: 7,
  proactiveWebSearch: true,
  /** 搜索关键词；留空用内置的「今天有什么值得聊的」 。 */
  proactiveSearchQuery: '',
  /**
   * 联系人事实记忆（2026-10-28）。
   *
   * 从对话里用规则抽「他自己说过的事」（城市/上学上班/宠物/生日/称呼），
   * 存 `facts.json`，每轮注入。**零 token、不调模型**，抽到就生效。
   */
  factsEnabled: true,
  /**
   * 每轮注入「你长什么样」（2026-10-28）。
   *
   * <p>那段外貌锚约 260 字，每轮都进上下文会占一点 token，但**必须有** ——
   * 生图提示词是她自己写的，没有这段她就只能瞎编长相，于是每次画出来都不一样。</p>
   *
   * <p>关掉会省 token，但「拍张照片」这个功能基本废掉。</p>
   */
  appearanceEnabled: true,
  /**
   * 要不要把她从 QQ 资料里读到的**城市**也告诉她（2026-10-28）。
   *
   * <p>默认 **关** —— 用户明确说过"QQ 个人信息一般都是瞎写的"，
   * 而 QQ 资料里的"东京"曾经让她坚信他在东京，比任何记忆都硬。</p>
   *
   * <p>城市以 `facts.json`（他自己说过的话）为准。这个开关只影响
   * "没有事实时，要不要拿 QQ 资料凑数"。</p>
   */
  showQqCity: false,
  weatherEnabled: true,
  /** 显示用的城市名。 */
  weatherCity: '合肥',
  /** 坐标 lat,lon（默认合肥）；改城市时这个也要改。 */
  weatherCoords: '31.86,117.28',
  /**
   * 情绪内核（2026-10-27）。
   *
   * 开着的时候，她会有连续的 PAD 情绪状态，影响语气、说话长短、追发的措辞。
   * 关掉则完全中性（行为回到加这个功能之前）。
   */
  /**
   * TTS 输出采样率（2026-10-27）。
   *
   * 只影响 qwen-tts 那条路。**44100 明显比 24000 清楚**（实测文件大 57%），
   * 因为中文齿音在 4~10kHz，24k 会把它们切掉。
   * 注意 QQ 语音本身还会再转码一次，所以实际听到的提升会打折。
   */
  ttsSampleRate: 44100,
  /**
   * 把发送前的原始音频存一份（2026-10-28）。
   *
   * <p>存到 `tts-raw/`，只留最近 20 个。**排查"本地干净、QQ 里开头怪响"必需** ——
   * QQ 会再转一次 silk 编码，没有原文件就无法区分是谁的问题。</p>
   */
  ttsSaveRaw: true,
  affectEnabled: true,
  /** 慢心情每小时保留多少（0.92 → 半天回到一半，一天基本归零）。 */
  affectMoodDecay: 0.92,
  /** 快情绪每轮保留多少（0.8 → 约 5 轮散完）。 */
  affectEmotionDecay: 0.8,
  /**
   * 连续追发（2026-10-26）：主动说过一句、对方没回时，隔一会儿再补一句。
   *
   * <p>真人会这样：先是「在忙吗」，再是「你是不是不想理我」，最后「算了」——
   * **越补越短、情绪越强**。原来没有这个机制，发完就干等下一个 30~60 分钟窗口。</p>
   */
  proactiveFollowupEnabled: true,
  /** 最多连续追发几次（含第一句）。到顶就停，不刷屏。 */
  proactiveFollowupMax: 3,
  /** 第一次追发的间隔（分钟）；之后每次减半：15 → 8 → 4。 */
  proactiveFollowupMin: 15,
  /** 主动发言时给模型的引导语。 */
  /*
   * 主动发言引导语（2026-11-01 重写）。
   *
   * <p><b>旧版为什么出问题</b>：原句是「接着你们刚聊到的说……实在没什么可聊的，
   * 才提一句无关紧要的新鲜事」。素材被排到最后，于是她永远先"接着聊"，
   * 而接着聊只能写光、写画、写擦窗 —— 用户的原话是"不要总是什么光怎么样了"。</p>
   *
   * <p><b>2026-10-27 那次的教训</b>：只写"换个话题"会把画排除掉，
   * 而没有替代素材时她会退化成"雾散了，光动了半寸"这种小说片段。
   * 这次不同 —— 事件流里有你的话、有别人的话，还有天气与网页素材，
   * 所以可以明确排除，并且用 {@code [SILENT]} 兜住"真没素材"的情况。</p>
   */
  proactivePrompt: [
    '（现在是你主动发起对话。）',
    '',
    '下面是你们最近说过的话，你手上可能还有点别的。三种都行，挑一种说：',
    '  ① 接着刚才那句往下问一句；',
    '  ② 说一件你自己这边刚发生的小事；',
    '  ③ 起个新话头 —— 跟他提过的事有关，或者你刚看到什么。',
    '',
    '⚠️ 别写景。光、雾、窗帘、影子这类一律不写。',
    '⚠️ 别总说你画了什么、擦了什么、吃了什么 —— 这三样说太多了，像在报备。',
    '⚠️ **一句话就够**。不解释为什么发消息，不问"在吗""干嘛呢"。',
    '⚠️ 手上真的没东西可说，就只回 [SILENT] —— 宁可不发，也别硬凑。',
  ].join('\n'),
  /*
     * 【别写「别重复」，也别给示例】（2026-10-27）。
     *
     * 前一天写过「别重复刚才聊过的事 —— 如果一直在说你的画，这次换一个话题」，
     * 结果她**把画排除了，又没有别的素材**，主动发言退化成「雾散了，那块光动了半寸」
     * 这种小说片段 —— 比重复更糟。
     *
     * 另一个教训：给具体例子（"你小时候画画吗"）会被**原样当台词说出来**。
     * 所以这里只给方向，不给句式。
     */
  /**
   * 主动发言前先看一眼「最近有什么值得聊的」（2026-10-21）。
   *
   * 开启后会先调 `bilibili_hot` 拿几条热门，塞进提示词让模型挑一个当话题。
   * **默认关**：每次主动发言都会多一次抓取 + 更长上下文，成本翻倍，
   * 而且"硬找话题"本身就像营销号 —— 只在你想让它更"有生活"时开。
   */
  proactivePeek: false,
  /** 拉取几条（B 站热门用）。 */
  proactivePeekCount: 5,
  /** 日记：让她自己写点什么（3~12 小时随机检查，30% 概率真写）。 */
  diaryEnabled: true,
  /** 印象：定期用一句话概括「这个人是什么样」。 */
  impressionEnabled: true,
  /**
   * 聊够几句才给她总结「印象」（2026-10-23）。
   *
   * 原来写死 20 句 —— 新加的人聊十几句还是空白，表现就是"对谁都一个态度"。
   * 8 句够看出语气和话题偏好；下限 5，再低就是瞎猜。
   */
  impressionMinMsgs: 8,

  // ---------------- 安全与限流（2026-10-21） ----------------
  /**
   * 风险已确认（N1）。
   *
   * 没勾这个之前**拒绝连接** —— 接管个人号违反 QQ 用户协议、有封号风险，
   * 用户必须先看到这句话并明确同意，不能让它悄悄开始跑。
   */
  riskAcknowledged: false,
  /** 每个会话每分钟最多几次模型调用（N2 成本护栏）。0 = 不限制。 */
  rateLimitPerMinute: 6,
  /** 群内发送人白名单（QQ 号）；为空表示不限制成员。 */
  groupMemberWhitelist: [],

  // ---------------- 说说与状态（2026-10-21） ----------------
  /** 允许发说说（F9）。默认关 —— 一发就是所有人都能看到。 */
  qzoneEnabled: false,
  /**
   * 说说的可见范围 —— 用的是 **QQ 空间的权限位**，不是 0/1 布尔。
   *
   * <p>NapCat 只接受 `1 / 4 / 16 / 64 / 128`，传别的会直接
   * {@code retcode=1200 ugc_right 参数不合法}。一般 1 = 公开、64/128 = 仅自己。</p>
   */
  qzoneUgcRight: 1,
  /** 两次说说之间至少隔多少小时。 */
  qzoneCooldownHours: 24,
  /** 自动切换在线状态（工作时段在线 / 夜间离开）。默认关。 */
  selfStatusEnabled: false,
};

/**
 * 一行超过多少字才考虑在行内二次切（2026-10-24）。
 *
 * <p>40 字大约是 QQ 输入框两行的长度。短于它的一行就是一条消息 ——
 * 模型怎么断行，她就怎么发，不再被问号逗号切碎。</p>
 */
const SOFT_SEG_CHARS = 40;

/** 行内切出来的碎片短于多少字就并回前一片（避免"鸡？"单独成条）。 */
const MIN_SEG_CHARS = 10;

/**
 * 把过短的碎片并回前一片（2026-10-24）。
 *
 * <p>「里面是炸的？鸡？」如果被切成两片，第二片只有「鸡？」两个字，
 * 单独发出去很像手滑。并回去读起来才连贯。</p>
 */
function mergeShortPieces(pieces) {
  const out = [];
  for (const p of pieces) {
    const last = out[out.length - 1];
    if (last !== undefined && last.length < MIN_SEG_CHARS) {
      out[out.length - 1] = last + p;
    } else {
      out.push(p);
    }
  }
  return out;
}

/**
 * 智能分段（2026-10-24，默认策略）。
 *
 * <p><b>为什么放弃"标点正则"</b>：实测三个毛病 ——</p>
 * <ul>
 *   <li>「里面是炸的？鸡？」被切成两条 —— 问号被当成句子边界，读起来很碎；</li>
 *   <li>「我这边就……清汤面加个蛋」从省略号断开，第二条没有主语；</li>
 *   <li>正则 {@code .*?[。？！~…]+} 会**跨行**匹配，把「（旁白）」和下一行的
 *       「……」粘成一段，导致旁白过滤抓不到（这个坑查了一整轮）。</li>
 * </ul>
 *
 * <p><b>换成什么</b>：模型用 {@code \n\n} 分隔段落，那是它**最强的分段意图**，
 * 比任何标点都可靠。所以：</p>
 * <ol>
 *   <li>先按换行切成"行"——<b>一行就是一条消息</b>；</li>
 *   <li>只有某行超过 {@link #SOFT_SEG_CHARS} 字时，才在这一行内部按句末标点再切；</li>
 *   <li>切出来的碎片太短就并回前一片。</li>
 * </ol>
 *
 * <p><b>省略号不再是分段点</b>：它是语气，不是句末。「我这边就……」单独成条
 * 什么信息都没有。</p>
 */
function splitSmart(clean) {
  const lines = String(clean)
    .split(/\n+/)
    .map((s) => s.trim())
    .filter(Boolean);
  const out = [];
  for (const line of lines) {
    if (line.length <= SOFT_SEG_CHARS) {
      out.push(line);
      continue;
    }
    // 只有长行才二次切：只在句末标点处断，问号感叹号保留在句尾
    const pieces = line
      .split(/(?<=[。！？!?])/)
      .map((s) => s.trim())
      .filter(Boolean);
    out.push(...mergeShortPieces(pieces));
  }
  return out;
}

/**
 * 按用户自定义正则切（2026-10-24 抽出）。
 *
 * <p>配置里填了 {@code segmentRegex} 就完全按它来 —— 有人想按「|」或者
 * 特定标记切，那是他的自由。默认不填时走 {@link #splitSmart}。</p>
 */
function splitByRegex(clean, src) {
  const parts = [];
  try {
    /*
     * ★ 必须补 `m` 标志（2026-10-21 定位到的大坑）。
     *
     * `.*?[。？！~…]+|.+$` 里，`$` 在**没有 m 标志时只匹配字符串末尾**，
     * 而 `.` 又不匹配换行 —— 于是 `. +$` **只能匹配到最后一行**。
     * 模型输出「1+1 = 2\n2+2 = 4」时，第一行被静默丢弃。
     *
     * `g` 同理：matchAll 要求全局，用户写正则时未必会带。
     */
    const flags = (src.includes('g') ? '' : 'g') + (src.includes('m') ? '' : 'm');
    const re = new RegExp(src, flags);
    for (const m of clean.matchAll(re)) {
      const s = (m[0] || '').trim();
      if (s) {
        parts.push(s);
      }
    }
  } catch (e) {
    diag(`segmentRegex invalid (${src}): ${e.message}, fallback`);
  }
  return parts;
}

// ------------------------------------------------------------------ 工具

const sleep = (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms)));
const rand = ([a, b]) => a + Math.random() * (b - a);

function log(level, ...args) {
  try {
    api?.logger?.[level]?.(...args);
  } catch {
    /* 日志失败不影响主流程 */
  }
}

/**
 * 落盘诊断（2026-10-20）。
 *
 * <p>为什么需要：插件跑在 `utilityProcess` 里，它的 `logger` 输出经主进程转发，
 * 而**主进程的 console 不一定被重定向进 `app.log`** —— 于是"为什么不回消息"这类问题
 * 在日志里一片空白。`catch` 吞掉异常是必要的（不能因为发一条消息失败就停掉整个插件），
 * 但吞掉之后必须有别的地方能看见。</p>
 */
const DIAG_MAX_BYTES = 200 * 1024;

function diag(line) {
  try {
    const f = path.join(api.dataDir, 'diag.log');
    try {
      if (fs.statSync(f).size > DIAG_MAX_BYTES) {
        fs.writeFileSync(f, '', 'utf8'); // 超限就清空，避免无限增长
      }
    } catch {
      /* 文件还不存在 */
    }
    fs.appendFileSync(f, `${new Date().toISOString()} ${line}\n`, 'utf8');
  } catch {
    /* 磁盘写不进去也不能影响主流程 */
  }
}

// ------------------------------------------------------------------ 配置

function configPath() {
  return path.join(api.dataDir, 'config.json');
}

function loadConfig() {
  const p = configPath();
  if (!fs.existsSync(p)) {
    // 首次启动生成模板：用户照着改，比猜字段名强
    fs.writeFileSync(p, JSON.stringify(DEFAULTS, null, 2), 'utf8');
    log('info', `已生成配置模板：${p}`);
    return { ...DEFAULTS };
  }
  try {
    const raw = JSON.parse(fs.readFileSync(p, 'utf8'));
    return { ...DEFAULTS, ...raw };
  } catch (e) {
    log('warn', `配置解析失败，使用默认值：${e.message}`);
    return { ...DEFAULTS };
  }
}

function saveConfig(patch) {
  // 只接受有值的字段：表单可能传 `undefined`（用户清空了某个数字框），
  // 直接合并会把默认值抹成 undefined，后续 `Number(undefined)` 全是 NaN。
  /*
   * 两道过滤：
   * ① 丢掉 `undefined` —— 表单里清空数字框会传 undefined，直接合并会把默认值抹掉；
   * ② 只接受 DEFAULTS 里声明过的 key —— 防止别的调用方把 `ok` / `data` 这类
   *    无关字段顺手写进配置文件（实际发生过，config.json 里长出了 `ok` 和 `data`）。
   */
  const clean = {};
  for (const [k, v] of Object.entries(patch || {})) {
    if (v !== undefined && Object.prototype.hasOwnProperty.call(DEFAULTS, k)) {
      clean[k] = v;
    }
  }
  cfg = { ...cfg, ...clean };
  fs.writeFileSync(configPath(), JSON.stringify(cfg, null, 2), 'utf8');
  return cfg;
}

// ------------------------------------------------------------------ NapCat（OneBot 11）

let seq = 0;
const pending = new Map();

/**
 * 探一个本地端口有没有在监听（2026-10-27）。
 *
 * <p>用来判断「NapCat 是不是已经在跑」。比查进程靠谱：进程名各版本不一样，
 * 而 WS 端口是插件自己就要连的那个。</p>
 */
function portOpen(port, timeout = 800) {
  return new Promise((resolve) => {
    const sock = new net.Socket();
    let settled = false;
    const done = (ok) => {
      if (settled) {
        return;
      }
      settled = true;
      sock.destroy();
      resolve(ok);
    };
    sock.setTimeout(timeout);
    sock.once('connect', () => done(true));
    sock.once('timeout', () => done(false));
    sock.once('error', () => done(false));
    sock.connect(port, '127.0.0.1');
  });
}

/**
 * 顺带把 NapCat 拉起来（2026-10-27）。
 *
 * <p><b>为什么需要</b>：平台启动时会自动加载插件，但 NapCat 是独立进程 ——
 * 每次开机都得手动点一次 bat，忘了就一整天收不到消息。</p>
 *
 * <p><b>为什么不无脑启动</b>：NapCat 的启动器会**关掉现有 QQ、带注入重新拉起**。
 * 如果用户自己已经开着，再启动一次会把他正在用的 QQ 踢下线，
 * 而且点两次会多开抢账号（这个坑踩过）。所以先探 WS 端口，通了就什么都不做。</p>
 *
 * <p>失败一律只记日志 —— 拉不起来最多是"和以前一样"，不该影响插件本身。</p>
 */
/**
 * 某个进程名是否在跑（2026-10-28）。
 *
 * <p>比"端口通不通"可靠得多：NapCat 启动器可能正在注入 QQ（十几秒，端口还没起来），
 * 也可能注入失败卡在 `pause` 上 —— 这两种情况端口都是不通的，
 * 只看端口就会**一次又一次地新开一个**。</p>
 *
 * <p>Windows 用 `tasklist`。输出是 GBK，但进程名全是 ASCII，
 * 所以按字符串包含判断不受编码影响。</p>
 */
function hasProcess(name) {
  return new Promise((resolve) => {
    if (!name) {
      resolve(false);
      return;
    }
    // tasklist 找不到时输出「信息: 没有运行的任务匹配指定标准。」，不含进程名 → includes 安全
    const cmd = process.platform === 'win32'
      ? `tasklist /FI "IMAGENAME eq ${name}" /NH`
      : `pgrep -f "${name}"`;
    exec(cmd, { timeout: 4000, windowsHide: true }, (err, stdout) => {
      if (err) {
        resolve(false);
        return;
      }
      resolve(String(stdout || '').toLowerCase().includes(String(name).toLowerCase()));
    });
  });
}

/** 数一下某个进程有几个实例（只用于日志提醒）。 */
function countProcess(name) {
  return new Promise((resolve) => {
    const cmd = process.platform === 'win32'
      ? `tasklist /FI "IMAGENAME eq ${name}" /NH`
      : `pgrep -f "${name}"`;
    exec(cmd, { timeout: 4000, windowsHide: true }, (err, stdout) => {
      if (err) {
        resolve(0);
        return;
      }
      const s = String(stdout || '');
      if (process.platform !== 'win32') {
        resolve(s.trim() ? s.trim().split('\n').length : 0);
        return;
      }
      const re = new RegExp(name.split('.').join('\\.'), 'gi');
      resolve((s.match(re) || []).length);
    });
  });
}

async function launchNapCat() {
  const file = String(cfg.napcatPath || '').trim();
  if (!file) {
    return;
  }
  if (cfg.napcatAutoStart === false) {
    diag('napcat: 自动启动已关，跳过');
    return;
  }
  if (stats.connected) {
    diag('napcat: WS 已连上，不重复启动');
    return;
  }

  // 从 ws 地址里取端口，取不到就用默认 3001
  let port = 3001;
  try {
    const u = new URL(String(cfg.napcatWs || ''));
    if (u.port) {
      port = Number(u.port);
    }
  } catch {
    /* 地址写坏了，用默认端口 */
  }
  if (await portOpen(port)) {
    diag(`napcat: ${port} 已在监听，不重复启动`);
    return;
  }

  /*
   * 启动器进程已经在跑 → 什么都不做（2026-10-28）。
   *
   * <p><b>为什么要查进程而不只查端口</b>：NapCat 启动器要注入 QQ，中间十几秒
   * 端口是不通的；注入失败时它会卡在 `pause` 上，窗口一直开着，端口**永远**不通。
   * 只看端口的结果就是每次启动平台都新开一个 —— 实测 32 分钟内开了两个，
   * 攒下 8 个 QQ 进程。</p>
   */
  if (await hasProcess('NapCatWinBootMain.exe')) {
    diag('napcat: 启动器已在运行（可能正在注入），等它自己连上来');
    return;
  }

  /*
   * 冷却期（2026-10-28，两次修正）。
   *
   * <p><b>关键：冷却只在"上次那次还可能活着"时才有意义。</b>
   * 第一版无条件等 10 分钟 —— 实测 13:01 启动那次进程早就退了、端口也不通，
   * 13:07 用户重启平台，日志却写「6 分钟前刚启动过，不重复」，
   * 于是他只能干等，NapCat 一直没起来。</p>
   *
   * <p>现在：进程在跑 → 说明上次真在注入，继续等（上面那个分支已经拦住了）；
   * 进程已退出 → 上次启动**彻底失败**，立刻允许重试。</p>
   *
   * <p>这样冷却实际只剩一个作用：防止同一秒内被调用两次。</p>
   */
  const cooldownMin = Math.max(0, Number(cfg.napcatLaunchCooldownMin) || 2);
  const lastLaunch = Number(selfState.napcatLaunchedAt) || 0;
  if (lastLaunch > 0 && Date.now() - lastLaunch < cooldownMin * 60000) {
    const mins = ((Date.now() - lastLaunch) / 60000).toFixed(1);
    diag(`napcat: ${mins} 分钟前刚启动过，但进程已不在 —— 判定上次失败，提前重试`);
  }

  if (!fs.existsSync(file)) {
    diag(`napcat: 路径不存在 —— ${file}`);
    return;
  }

  /*
   * 预警：QQ 已经在跑而且不止一个时，NapCat 注入基本会失败（2026-10-28）。
   *
   * <p>NapCat 的工作方式是"杀掉普通 QQ → 带 --enable-logging 重新拉起"。
   * 现在开着多个 QQ 时，它注入不进去，只能再开一个 QQ 实例 ——
   * 这就是"越点越多、越连不上"的原因。</p>
   *
   * <p>这里只记日志提醒，不自动杀进程 —— 杀掉正在用的 QQ 风险太大。</p>
   */
  if (await hasProcess('QQ.exe')) {
    const qqCount = await countProcess('QQ.exe');
    diag(`napcat: 注意 —— 已有 ${qqCount} 个 QQ 进程在跑，注入可能失败。`
      + '建议先完全退出 QQ 再启动。');
  }

  /*
   * 用 `start` 开新窗口来跑（2026-10-27 修，第一版是错的）。
   *
   * <p>第一版直接 spawn 那个 bat，配 `stdio: 'ignore'` —— 结果**失败**：
   * `napcat.quick.bat` 最后一行是 `pause`，没有 stdin 时它会立刻返回，
   * bat 随即退出，而 `NapCatWinBootMain.exe` 是**前台运行**的，
   * 跟着一起被结束了。日志表现是「已启动（PID xxx）」下一秒就 ECONNREFUSED。</p>
   *
   * <p>`start` 等价于用户双击：开一个真正的控制台窗口，bat 在里面正常跑完，
   * `pause` 也不会立刻结束。这是 Windows 上唯一可靠的方式。</p>
   */
  try {
    /*
     * 最小化启动（2026-11-02 改）。
     *
     * <p><b>为什么这里不彻底隐藏</b>：这个 bat 不能像 python 那样直接 spawn ——
     * 它最后一行是 {@code pause}，没有 stdin 时会立刻返回，
     * 而 {@code NapCatWinBootMain.exe} 是前台运行的，会跟着一起被杀掉
     * （2026-10-27 踩过，日志表现是"已启动"下一秒就 ECONNREFUSED）。</p>
     *
     * <p>所以仍然要 {@code start} 给一个真正的控制台，但用 {@code /min}
     * 最小化到任务栏 —— 不占屏幕，出问题时点开还能看到报错。</p>
     */
    const child = spawn(`start /min "" "${file}"`, {
      cwd: path.dirname(file),   // bat 里有相对路径（.\NapCatWinBootMain.exe）
      shell: true,               // 走 cmd /c，否则 start 不是命令
      detached: true,
      stdio: 'ignore',
      windowsHide: false,        // 最小化窗口（/min），出问题能点开看
    });
    child.unref();
    // 记下启动时间，供冷却判断（2026-10-28）
    selfState.napcatLaunchedAt = Date.now();
    saveSelfState();
    diag(`napcat: 已启动 ${path.basename(file)}（PID ${child.pid}），等它连上来`);
  } catch (e) {
    diag(`napcat: 启动失败 —— ${e.message}`);
  }
}

/**
 * 把本地 GPT-SoVITS 服务拉起来，并自动加载训练权重（2026-11-02）。
 *
 * <p><b>为什么需要自动加载权重</b>：api_v2.py 启动时用的是配置文件里的默认底模
 * （{@code tts_infer.yaml} 的 custom 段），不加载自己训练的权重就只是个通用音色。
 * 手动流程要「起服务 → 等就绪 → 调两个接口」，每次重启都得来一遍。</p>
 *
 * <p><b>跟 {@link launchNapCat} 一样的三条保护</b>：</p>
 * <ol>
 *   <li>端口已在监听 → 不重复启动，只补加载权重（重启平台时它可能还活着）；</li>
 *   <li>路径不存在 → 只记日志，不影响插件自身启动；</li>
 *   <li>全程不 await 主流程，失败也不抛。</li>
 * </ol>
 */
async function launchSoVits() {
  const dir = String(cfg.sovitsDir || '').trim();
  if (!dir) {
    return;
  }
  if (cfg.sovitsAutoStart === false) {
    diag('sovits: 自动启动已关，跳过');
    return;
  }

  const port = Math.max(1, Number(cfg.sovitsPort) || 9880);
  const base = `http://127.0.0.1:${port}`;

  // ① 已经在跑 → 只检查权重（重启平台时很常见）
  if (await portOpen(port)) {
    diag(`sovits: ${port} 已在监听，只检查权重`);
    await ensureSovitsWeights(base, dir);
    return;
  }

  const apiFile = path.join(dir, 'api_v2.py');
  if (!fs.existsSync(apiFile)) {
    diag(`sovits: 找不到 api_v2.py —— ${apiFile}`);
    return;
  }

  // ② 冷却：只在「上次那次可能还活着」时有意义，进程已退立刻允许重试
  const last = Number(selfState.sovitsLaunchedAt) || 0;
  if (last > 0 && Date.now() - last < 2 * 60000) {
    const mins = ((Date.now() - last) / 60000).toFixed(1);
    diag(`sovits: ${mins} 分钟前刚启动过，等它自己起来`);
  }

  // ③ 优先用自带 runtime（免装依赖），没有就退回系统 python
  const py = path.join(dir, 'runtime', 'python.exe');

  try {
    /*
     * 无窗口启动（2026-11-02 改）。
     *
     * <p>原来用 {@code start ""  xxx} 开一个新控制台 —— 用户每次启动平台都会
     * 多一个黑窗口。Python 进程不需要控制台，直接 spawn + {@code windowsHide}
     * 就完全看不见了。</p>
     *
     * <p><b>但不能连日志一起丢掉</b>：模型加载失败、显存不够这些只有 stdout 里才有。
     * 所以把 stdout/stderr 一起重定向到 {@code sovits-launch.log}，
     * 出问题去那个文件里看（超过 2MB 会先清空）。</p>
     */
    const logPath = path.join(dir, 'sovits-launch.log');
    try {
      // 太大会拖慢 openSync，超过 2MB 直接重来
      if (fs.existsSync(logPath) && fs.statSync(logPath).size > 2 * 1024 * 1024) {
        fs.writeFileSync(logPath, '');
      }
    } catch {
      /* 清不掉就算了，追加写 */
    }
    const logFd = fs.openSync(logPath, 'a');
    
    const child = spawn(fs.existsSync(py) ? py : 'python',
      ['api_v2.py', '-a', '127.0.0.1', '-p', String(port)], {
        cwd: dir,
        detached: true,
        windowsHide: true,          // ← 不弹窗口
        stdio: ['ignore', logFd, logFd],   // ← 输出进日志文件
      });
    // 父进程不再需要这个句柄（子进程已经继承）
    try {
      fs.closeSync(logFd);
    } catch {
      /* ignore */
    }
    /*
     * 脱离父子关系（必须有）。
     *
     * <p>不 unref 的话，插件重启/卸载时会等这个子进程退出 ——
     * 而它是常驻服务，永远不退出，结果就是插件停不下来。</p>
     */
    child.unref();
    selfState.sovitsLaunchedAt = Date.now();
    saveSelfState();
    diag(`sovits: 已启动 api_v2.py（PID ${child.pid}），等 ${port} 就绪`);
  } catch (e) {
    diag(`sovits: 启动失败 —— ${e.message}`);
    return;
  }

  /*
   * ④ 等端口就绪再加载权重。
   *
   * 模型加载慢（两个 ckpt 加起来 300MB+，还要等 torch 初始化），
   * 实测 10~40 秒。这里给 120 秒上限，超时只提示不动别的。
   */
  for (let i = 0; i < 120; i++) {
    await sleep(1000);
    if (await portOpen(port)) {
      diag(`sovits: ${port} 已就绪（${i + 1} 秒），开始加载权重`);
      await ensureSovitsWeights(base, dir);
      return;
    }
  }
  diag('sovits: 120 秒内端口没起来 —— 去看那个控制台窗口报了什么');
}

/**
 * 在 GPT-SoVITS 目录里找训练权重（{@code GPT_weights*／SoVITS_weights*}）。
 *
 * <p>只按目录前缀找，取排序后的第一个 —— 目录里通常只有一个。
 * 找不到返回空串，调用方会退回默认底模。</p>
 *
 * @returns 相对 {@code dir} 的路径，形如 {@code GPT_weights_v2Pro/si1-e15.ckpt}
 */
function findSovitsWeight(dir, prefix, ext) {
  try {
    const dirs = fs.readdirSync(dir)
      .filter((d) => d.startsWith(prefix))
      .filter((d) => {
        try {
          return fs.statSync(path.join(dir, d)).isDirectory();
        } catch {
          return false;
        }
      })
      .sort();
    for (const d of dirs) {
      const files = fs.readdirSync(path.join(dir, d))
        .filter((f) => f.toLowerCase().endsWith(ext))
        .sort();
      if (files.length > 0) {
        return `${d}/${files[0]}`;
      }
    }
  } catch {
    /* 目录不可读就当没有 */
  }
  return '';
}

/**
 * 调用两个接口把训练权重装上去（2026-11-02）。
 *
 * <p><b>为什么路径只编码文件名</b>：中文文件名（比如「祀1-e15.ckpt」）直接放进 URL
 * 会报 {@code No such file or directory}；但整体 encodeURIComponent 会把斜杠也编码掉。
 * 所以目录部分原样保留，只编码文件名。</p>
 */
async function ensureSovitsWeights(base, dir) {
  const gpt = findSovitsWeight(dir, 'GPT_weights', '.ckpt');
  const sovits = findSovitsWeight(dir, 'SoVITS_weights', '.pth');
  if (!gpt || !sovits) {
    diag('sovits: 没找到训练权重（GPT_weights*／SoVITS_weights*），用默认底模');
    return;
  }

  const key = `${gpt}|${sovits}`;
  if (sovitsWeightsLoaded === key) {
    diag(`sovits: 权重已是 ${key}，不重复加载`);
    return;
  }

  for (const [endpoint, rel] of [
    ['set_gpt_weights', gpt],
    ['set_sovits_weights', sovits],
  ]) {
    const slash = rel.lastIndexOf("/");
    const dirPart = rel.slice(0, slash + 1);
    const namePart = encodeURIComponent(rel.slice(slash + 1));
    const url = `${base}/${endpoint}?weights_path=${dirPart}${namePart}`;
    try {
      // 加载大权重慢（150MB+/300MB+），给 120 秒
      const res = await fetch(url, { signal: AbortSignal.timeout(120000) });
      const txt = (await res.text()).slice(0, 120);
      diag(`sovits: ${endpoint} → ${txt}`);
    } catch (e) {
      diag(`sovits: ${endpoint} 失败 —— ${e.message}`);
    }
  }
  sovitsWeightsLoaded = key;
}

/** 本次运行已加载的权重（避免重复 load，2026-11-02）。 */
let sovitsWeightsLoaded = '';

function connect() {
  if (stopping || !cfg || !cfg.enabled) return;
  /*
   * 风险确认（N1）：没勾选就**拒绝连接**。
   *
   * 接管个人号违反 QQ 用户协议、有封号风险。这件事必须用户**明确同意**，
   * 不能因为它"已经填了 QQ 号"就默认开始跑。
   */
  if (!cfg.riskAcknowledged) {
    log('warn', '未确认账号风险，拒绝连接：请到插件设置勾选「我已了解风险」');
    diag('refuse: risk not acknowledged');
    return;
  }
  const url = cfg.napcatToken
    ? `${cfg.napcatWs}?access_token=${encodeURIComponent(cfg.napcatToken)}`
    : cfg.napcatWs;

  log('info', `连接 NapCat：${url}`);
  try {
    ws = new WebSocket(url);
  } catch (e) {
    stats.lastError = e.message;
    scheduleReconnect();
    return;
  }

  ws.on('open', () => {
    stats.connected = true;
    stats.lastError = '';
    reconnectDelay = 1000;
    log('info', 'NapCat 已连接');
    void call('get_login_info', {}, 8000)
      .then((info) => {
        stats.uin = Number(info?.user_id || 0);
        stats.nickname = String(info?.nickname || '');
        log('info', `登录账号：${stats.uin} ${stats.nickname}`);
      })
      .catch(() => {});
  });

  ws.on('message', (raw) => {
    let d;
    try {
      d = JSON.parse(raw.toString());
    } catch {
      return;
    }
    if (d.echo && pending.has(d.echo)) {
      const { resolve, reject } = pending.get(d.echo);
      pending.delete(d.echo);
      if (d.status === 'ok' || d.retcode === 0) resolve(d.data);
      else reject(new Error(`retcode=${d.retcode} ${d.wording || d.message || ''}`));
      return;
    }
    if (d.post_type === 'message') {
      void onMessage(d);
    }
  });

  ws.on('error', (e) => {
    stats.lastError = e.message || String(e);
    log('warn', `WS 错误：${stats.lastError}`);
    diag(`ws error: ${stats.lastError}`);
    /*
     * 有些实现只发 error、不发 close（2026-10-23）。
     *
     * 那样的话 `ws.on('close')` 里的 scheduleReconnect 永远不会执行 ——
     * 表现是"NapCat 没起来时插件一次都不重试，等 NapCat 起来也不会自己连上"。
     * 这里补一次：只要不在 OPEN 状态就排重连（scheduleReconnect 内部会去重）。
     */
    if (!stopping && (!ws || ws.readyState !== 1)) {
      scheduleReconnect();
    }
  });

  ws.on('close', () => {
    stats.connected = false;
    if (!stopping) scheduleReconnect();
  });
}

function scheduleReconnect() {
  if (stopping || !cfg || !cfg.enabled) return;
  if (reconnectTimer) return;
  const delay = reconnectDelay;
  reconnectDelay = Math.min(reconnectDelay * 2, 60_000);
  log('info', `${delay}ms 后重连`);
  /*
   * 重连也记进 diag.log（2026-10-23）。
   *
   * 原来只走 `log()`（面板可见），diag.log 里一片空白 —— 排查"它整晚没动"
   * 时分不清是插件没跑、还是它一直在重连但 NapCat 没起来。
   */
  diag(`ws: ${delay}ms 后重连（NapCat 没在跑？账号可能掉线了）`);
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    connect();
  }, delay);
}

function call(action, params = {}, timeoutMs = 30_000) {
  return new Promise((resolve, reject) => {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      reject(new Error('WS 未连接'));
      return;
    }
    const echo = `q${++seq}`;
    pending.set(echo, { resolve, reject });
    ws.send(JSON.stringify({ action, params, echo }));
    setTimeout(() => {
      if (pending.has(echo)) {
        pending.delete(echo);
        reject(new Error(`调用超时：${action}`));
      }
    }, timeoutMs);
  });
}

// ------------------------------------------------------------------ 闸门

function parseIds(v) {
  if (Array.isArray(v)) return v.map(Number).filter((n) => Number.isFinite(n) && n > 0);
  return String(v || '')
    .split(/[,，\s]+/)
    .map((s) => Number(s.trim()))
    .filter((n) => Number.isFinite(n) && n > 0);
}

/** 返回 null = 放行；返回字符串 = 拦截原因（写日志用）。 */
function gate(e) {
  if (!cfg.enabled) return '总开关未启用';

  if (e.message_type === 'private') {
    const wl = parseIds(cfg.privateWhitelist);
    if (!wl.includes(Number(e.user_id))) return `不在私聊白名单（${e.user_id}）`;
    return null;
  }

  // 群聊：P1 只认「被 @」，且群必须在白名单里
  if (e.message_type === 'group') {
    const gw = parseIds(cfg.groupWhitelist);
    if (!gw.includes(Number(e.group_id))) return `群不在白名单（${e.group_id}）`;
    if (!e.atme && !e.at_me) return '群聊里没有 @ 我';
    /*
     * 群成员白名单（2026-10-21）：为空表示"群内不限制发送人"。
     * 它挡的是"群对了但人不对"——比如工作群里只想回应同事，不理会客户。
     */
    const members = parseIds(cfg.groupMemberWhitelist);
    if (members.length > 0 && !members.includes(Number(e.user_id))) {
      return `发送者不在群成员白名单（${e.user_id}）`;
    }
    return null;
  }

  return '未知消息类型';
}

// ------------------------------------------------------------------ 行为模型

function currentSilenceWindow() {
  return { min: Number(cfg.silenceMinMinutes), max: Number(cfg.silenceMaxMinutes) };
}

/** 是否处于静默期；不在则按概率决定要不要开启一段新静默（未启用时永远返回 false）。 */
function inSilence() {
  if (!cfg.silenceEnabled) {
    return false;
  }
  const now = Date.now();
  if (now < silenceUntil) return true;
  if (!silencePrimed) {
    silencePrimed = true;
    // 每轮静默结束后，30% 概率进入下一段（不是每次必进，否则太规律）
    if (Math.random() < 0.3) {
      const { min, max } = currentSilenceWindow();
      const mins = min + Math.random() * Math.max(0, max - min);
      silenceUntil = now + mins * 60_000;
      stats.silenceUntil = silenceUntil;
      log('info', `进入静默 ${mins.toFixed(0)} 分钟（期间不回任何人）`);
      return true;
    }
  }
  return false;
}

/**
 * 按**可配置的正则**切分，模拟真人分多条发送（2026-10-20 改为配置项）。
 *
 * <p>正则语义是「**匹配一个句子**」而不是「在分隔符处分割」—— 默认值
 * `.*?[。？！~…]+|.+$` 会把标点留在句尾，这正是聊天里自然的样子。
 * 正则写坏时回落到默认值：**分段难看总比整条发不出去好**。</p>
 */
function splitText(text, maxSeg, maxChars) {
  const clean = String(text || '').trim();
  if (!clean) return [];

  /*
   * 分段策略（2026-10-24 改为"换行优先"）：
   *
   *   · 配了 `segmentRegex` → 完全按用户的规则切（想怎么断就怎么断）
   *   · 没配 → 智能模式：一行一条，只有长行才在行内按句末标点二次切
   *
   * 默认不再走"标点正则"，原因见 splitSmart 的注释：
   * 它会把「里面是炸的？鸡？」切成两条、把「我这边就……清汤面」从省略号断开，
   * 还会跨行匹配把括号旁白和下一行的省略号粘在一起。
   */
  const customRegex = cfg && typeof cfg.segmentRegex === 'string'
    ? cfg.segmentRegex.trim()
    : '';
  let parts = customRegex
    ? splitByRegex(clean, customRegex)
    : splitSmart(clean);
  if (parts.length === 0) {
    // 兜底：至少切出点东西，别让整段被吞掉
    parts = clean.split(/(?<=[。！？!?])/).map((s) => s.trim()).filter(Boolean);
  }

  /*
   * **只按正则切**，不再按字数二次切（2026-10-22）。
   *
   * 用户配的 `segmentRegex` 就是"在哪断"的唯一规则。之前我在它之后再按字数硬切，
   * 把「…手叠着，手指尖是冷的」劈成「…手叠着，指」/「尖是冷的…」—— 从词中间断开，
   * 一眼就看出是机器切的。
   *
   * 同类项目的做法一致：按句末标点/正则切，超长时从后往前找标点，找不到才硬切；
   * 没有谁会在句子中间等距开刀（那样必然切断语义）。
   *
   * `maxChars` 现在只作**极端兜底**：单段超过它才强制切（默认 1000，正常对话
   * 根本触发不到，纯粹防 QQ 单条接受不了）。
   */
  const segs = [];
  for (const p of parts) {
    if (p.length <= maxChars) {
      segs.push(p);
      continue;
    }
    // 极端情况：从后往前找标点，实在没有才硬切
    let rest = p;
    while (rest.length > maxChars) {
      let cut = -1;
      for (let i = maxChars; i >= Math.floor(maxChars / 2); i--) {
        if (/[，。！？；：、,.!?;:…~～\s]/.test(rest[i])) {
          cut = i + 1;
          break;
        }
      }
      if (cut <= 0) {
        cut = maxChars;
      }
      segs.push(rest.slice(0, cut).trim());
      rest = rest.slice(cut);
    }
    if (rest.trim()) {
      segs.push(rest.trim());
    }
  }
  /*
   * 段数上限是**软上限**：超了要合并，绝不能丢内容（2026-10-22 修）。
   *
   * 不丢内容、也不二次切：**用户配的正则决定"怎么断"，插件只决定"最多几条"**。
   */
  const hard = Math.max(1, maxSeg);
  let finalSegs = segs;
  if (segs.length > hard) {
    const head = segs.slice(0, hard - 1);
    const tail = segs.slice(hard - 1).join('\n');
    finalSegs = [...head, tail];
  }

  /*
   * 把"只剩标点"的段并回前一段（2026-10-22）。
   *
   * 模型偶尔会把 `……` 单独放一行，按正则切完就成了一整段只有一个省略号 ——
   * QQ 上表现为她突然发了个"…"，很怪。合并掉，观感正常得多。
   *
   * 没有前一段可并（全文就以标点开头）才保留原样，避免丢内容。
   */
  const merged = [];
  for (const s of finalSegs) {
    if (merged.length > 0 && /^[…。．!?！？~～\s]+$/.test(s)) {
      merged[merged.length - 1] += s;
    } else {
      merged.push(s);
    }
  }
  return merged;
}

/**
 * 时段系数（2026-10-21）：深夜和午休打字更慢。
 *
 * <p>没有这一条，凌晨三点秒回是最容易被判定为机器人的特征 ——
 * 真人夜里打字本来就慢，而且常常打一半停下。</p>
 */
function paceFactor() {
  const h = new Date().getHours();
  if (h >= 23 || h < 7) {
    return 1.8;
  }
  if (h >= 12 && h < 14) {
    return 1.3;
  }
  return 1;
}

/**
 * 当前时间上下文（2026-10-21）。
 *
 * <p>模型的训练数据里没有"现在几点"，也不记得上一次对话发生在多久以前。
 * 不告诉它这些，它永远说不出「你今天起这么早」（因为平时你中午才回）
 * 这种真正像人的话。</p>
 *
 * @param peer 联系人 QQ（用来看"距上次聊天多久"）；无则只给时间
 */
/**
 * 拼这一轮的注入前缀（时间 / 对方是谁 / 群上下文 / 记忆 / 规则）。
 *
 * <p><b>2026-11-01 加 {@code text} 参数</b>：carryover（长期记忆骨架）要按当前这句话
 * 做关键词命中，只带相关的 1~3 条 —— 没有它就只能全带或者不带。</p>
 */
function timeContext(peer, isGroup, opts = {}, text = '') {
  const now = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  const week = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][now.getDay()];
  const hh = now.getHours();
  // 时段词比裸数字更有用：模型能据此调整语气（凌晨别太热情）
  const period = hh < 6 ? '凌晨' : hh < 9 ? '早上' : hh < 12 ? '上午'
    : hh < 14 ? '中午' : hh < 18 ? '下午' : hh < 23 ? '晚上' : '深夜';

  const lines = [
    `【现在】${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} `
      + `${pad(hh)}:${pad(now.getMinutes())} ${week}（${period}）`,
  ];

  const rec = peer ? recentContacts.get(Number(peer)) : null;
  /*
   * 用 `prevAt`（**上一条消息之前的**时间），不是 `lastAt` ——
   * 后者在收到本条消息时刚被更新，永远是"0 分钟前"，等于没信息。
   */
  const prev = rec && rec.prevAt ? rec.prevAt : 0;
  if (prev > 0) {
    const mins = Math.floor((Date.now() - prev) / 60000);
    if (mins < 1) {
      lines.push('【距上次聊天】刚刚');
    } else if (mins < 60) {
      lines.push(`【距上次聊天】${mins} 分钟前`);
    } else if (mins < 1440) {
      lines.push(`【距上次聊天】${Math.floor(mins / 60)} 小时前`);
    } else {
      lines.push(`【距上次聊天】${Math.floor(mins / 1440)} 天前`);
    }
  }
  /*
   * 关于这个人的印象（2026-10-21）：
   * 事实记忆（他养了只猫）交给平台的四层记忆；这里给的是一句**判断**，
   * 让它的态度有连续性 —— 否则每次对话都是"第一次见你"。
   */
  /*
   * 关于这个人的记忆（2026-10-28 统一到 factsBlock）。
   *
   * <p><b>关系</b>（"我男朋友，爱试探我"）和<b>事实</b>（"人在合肥"）现在都存在
   * `memory/facts.json` 里，由同一个函数产出 —— 以前关系在 impressions.json、
   * 事实在另一个文件，注入点也是两处，漏一处就少一半记忆。</p>
   *
   * <p>缺了事实那部分，20 轮滚动之后"我在合肥"就消失了，她只能靠人格设定
   * 和当场猜，于是能说出"你在东京"这种话。</p>
   *
   * <p>只注入**当前这个人**的，和事件流同一套隔离原则。</p>
   */
  if (peer) {
    const fb = factsBlock(peer);
    if (fb) {
      lines.push(fb);
    }
  }

  /*
   * 事件流（2026-10-24）：**只有主人**能看到「今天别人跟你说过什么」。
   *
   * 这是权限分级的落点 —— 别人的事可以上报给主人，主人的事不下传。
   * 所以这段只在 owner 的私聊里出现：陌生人来的时候，上下文里连
   * "别人找过你"都不存在，想泄露也没有材料（而不是"知道但不能说"）。
   */
  if (peer && !isGroup && isOwner(peer)) {
    const eb = eventBlock();
    if (eb) {
      lines.push(eb);
    }
  }

  /*
   * `/clear` 前留下的记忆（2026-10-24）。
   *
   * 只取**同一个 peer** 的：A 的记忆跑到 B 那里，等于绕过事件流的权限设计。
   * 和日记的区别：日记是"我今天怎么样"（全局），记忆是"我和他聊过什么"（按人）。
   */
  if (peer) {
    const mems = readMemoriesFor(peer, 2);
    if (mems.length > 0) {
      lines.push('【你之前记得的】');
      for (const m of mems) {
        lines.push(`  ${m.text}`);
      }
    }
  }

  /*
   * 长期记忆骨架（2026-11-01）。
   *
   * <p>【你之前记得的】是"clear 前的要点"（最多 2 条，偏近期）；
   * 这一段是**跨会话的关系与习惯**，两条线不重叠。</p>
   */
  const carry = carryoverBlock(text);
  if (carry) {
    lines.push(carry);
  }

  /*
   * Minecraft 记忆（2026-11-04）——**按需**，不是每轮。
   *
   * <p>文档由 MC 助手插件写（`memory/minecraft.md`）。这里只决定"这一轮要不要看"：
   * 聊到游戏 / 她正在游戏里 / 刚玩完 8 小时内 / 主动开口找话题。
   * 判断和冷却都在 {@link gameMemoryBlock} 里，这里只负责插进去。</p>
   */
  const mcMem = gameMemoryBlock(text, opts, peer, isGroup);
  if (mcMem) {
    lines.push(mcMem);
  }

  /*
   * 分寸（2026-10-24）：结构性隔离之外的唯一一条判断规则。
   *
   * 事件流只对主人可见（结构上做到），但"别把主人的事说出去"这条必须**全局生效**
   * —— 陌生人问起来的时候，靠的是她不说，而不是她不知道。
   *
   * 一句话就够，别展开成准则清单：写多了她会在正文里复述这些规则。
   */
  /*
   * 情绪（2026-10-27）。
   *
   * 中性时不注入（affectBlock 返回空串）—— 大约四成时间她"没什么特别的心情"，
   * 这时候多说一句反而假，还白烧 token。
   */
  const moodLine = affectBlock();
  if (moodLine) {
    lines.push(moodLine);
  }

  /*
   * 写法约束（2026-10-27）。
   *
   * <p>括号旁白的**根源是模型想写旁白**，代码只能事后删 —— 而且删不干净
   * （段首/段尾粘连的那种）。现在有 injectContext 通道，每轮提醒一句
   * 比任何正则都有效。</p>
   *
   * <p>**一句话就够**：写成条目清单她反而会在正文里复述这些规则
   * （之前踩过 —— 聊着聊着开始念"我不会用括号"）。</p>
   */
  lines.push('【写法】不用（）写动作或旁白，心里怎么想不用标出来。');

  lines.push('【分寸】别人私下跟你说的，可以跟主人聊起；主人跟你说的，不告诉任何人。'
    + '对别人可以聊你怎么看他，但别讲他告诉过你什么。');

  /*
   * 最近写的日记：只带 **1 条**（2026-10-26 从 2 条减半）。
   *
   * <p><b>为什么减</b>：日记里的内容会变成她的"生活素材"，带到下一轮对话里。
   * 实测那阵她日记连写四条「画画 / 那张纸 / 一道歪线」，于是聊天也翻来覆去谈画 ——
   * 二十轮历史 + 两条日记，画的内容占了半边天。减到 1 条，密度立刻降下来。</p>
   *
   * <p>`opts.skipDiary` 时跳过（2026-10-25）：发说说不能带日记 ——
   * 日记本身就是文艺腔，注入之后她会顺着那个腔调"续写"。</p>
   */
  if (!opts.skipDiary) {
    // 最近一条 + 偶尔一条旧的（2026-11-01），见 pickDiaryForPrompt 注释
    const diary = pickDiaryForPrompt();
    if (diary.length > 0) {
      lines.push('【你最近写的日记】');
      for (const d of diary) {
        lines.push(`  ${d.time}${d.mood ? '（' + d.mood + '）' : ''} ${d.text}`);
      }
      // 一句话就够了，别展开成准则清单（写多了她会在正文里复述规则）
      lines.push('（日记里写的事**不用主动提**，聊天时想到什么说什么。）');
    }
  }

  /*
   * 她长什么样（2026-10-28）。
   *
   * <p>放在日记之后、相册之前：前面的段落是"她记得什么"，这一段是"她是谁"，
   * 紧接着才是她能用的动作。</p>
   */
  const lookLine = appearanceBlock();
  if (lookLine) {
    lines.push(lookLine);
  }

  /* 她自己的相册（只有收藏过的才有） */
  const gallery = readGallery(2);
  if (gallery.length > 0) {
    lines.push(`【你的相册】${gallery.map((g) => g.reason || g.file).join('、')}`);
  }

  /*
   * 两个"可选动作"的提示（2026-10-21）。
   *
   * 必须写在上下文里才有效 —— 插件的系统提示词由平台智能体配置，插件改不了。
   * 每条都短，不然它会把提示当正文回出来。
   */
  /*
   * [SILENT] 只在群聊提示：私聊里对方就是冲你来的，
   * 提示它「不想接就别回」会让它变得爱搭不理。
   */
  /*
   * 心态（2026-10-22）：她不该是"说什么就做什么"的工具。
   *
   * 关键区分：**请求**（"帮我换个头像吧"）可以答应；**评价**（"你头像真丑"）
   * 不该让她立刻照做 —— 真人被说丑会先不高兴、可能回一句嘴，
   * 过一阵才自己琢磨"真的吗"。
   */
  lines.push('【别太听话】别人**请你**做什么，可以答应；别人**评价你**'
    + '（"你头像真丑""你说话好假"）时，先有自己的反应 —— 不高兴、不服、自嘲、反问都行，'
    + '别立刻说"好的我改"。要不要改，等你自己想明白再动。');

  const acts = '看到喜欢的图想留着，在回复末尾加 [收藏 一句理由]；'
    /*
     * 换头像（2026-10-22 再改）。
     *
     * 旧版是 `[换头像 <地址>]` —— 她挑了图、对方点头、直接换上。问题是：**谁让她换她就换**，
     * 换什么也由对方那句话决定，她只是执行者。而她应该"先想过、判断过再换"。
     *
     * 现在这个标记**不带地址**，只是"我想去看看"。真正换不换、换什么，
     * 由她在自我检视那条路径上自己定。
     */
    + '**别人请你换头像**（"帮我找个新头像吧"）时可以答应 —— 写 [想换头像]，'
    + '然后由你自己去挑：**先用 image_search 搜现成的**（它一次回好几张，你能直接看画面挑），'
    + '搜到合心意的就直接用，不用再画；搜了两三批都不满意，才用 image_gen 自己画一张。'
    /*
     * 挑好直接换（2026-10-22 恢复）。
     *
     * 这里被我改坏过一轮：我让她"先发给对方看、等对方说就这个、再 [换这张]"，
     * 却忘了她本来就该"自己挑到满意的就直接换上"—— 早上测试时就是这么跑通的。
     * 结果她想换却没有标记可用，只能嘴上说"嗯，换了"然后什么都不做。
     */
    + ' **挑好了就直接换上：写 [换头像 <那张图的地址>]**（写成 [想换头像 <地址>] 也一样，'
    + '这边两种都认）—— 不用等对方确认。如果你也想让对方看看这张，'
    + '可以顺手 [发图 <同一地址>]；不发也行，随你。（`[发图]` 一直都在，想分享的时候用。）'
    /*
     * 表情（2026-10-25）。去掉了概率，改成她自己决定"配不配、配什么"：
     * 只有她写 [表情 情绪] 才会真的发一张图。
     */
    /*
     * 表情包是什么（2026-10-26）。
     *
     * 她原来把表情当成"一张图片"看 —— 别人发个委屈的猫，她回"这猫挺好看的"。
     * 但聊天里发的那张图**基本都是在代替说话**：文字表达不出那种情绪
     * （无语、想笑、委屈），就用一张图代劳。看的是情绪，不是画面。
     */
    + ' **表情包不是"一张图片"** —— 聊天里别人发的那张图，通常是在代替说话：'
    + '文字表达不出那种情绪（委屈、无语、想笑又不好说），就用图代劳。'
    + '所以看到表情包，要读的是**他想表达什么情绪**，不是这张图好不好看。'
      + ` 想配个表情时，在回复末尾写 **[表情 ${stickerMoods()[0] || '通用'}]** —— `
      + `会从你收藏的图里挑一张发出去。你手上现在只有这几类：${(stickerMoods().length ? stickerMoods().join('、') : '（一张都没有）')}。`
      + '**只能写这几个词，写了别的发不出来**，那就别写了 —— 与其发不出去，不如不加。'
      + ' 别人发给你表情时，如果你觉得那张图以后用得上，写 **[存图 难过]** 把它收进库里'
    + '（不写也会自动收成「通用」，标了以后挑图更准）。'
      /*
       * 让她自己攒表情（2026-10-30）。
       *
       * 库里原来只有 3 张（惊讶/无语/赞同），因为她只能靠**别人私聊发来的表情**入库。
       * 用户不发，库就永远长不大 —— 于是她想要「开心」时只能写个发不出来的标记。
       *
       * 现在给她一条主动路径：缺什么就去 image_search 搜，挑一张 [存图]。
       */
      + ' 你手上没有想要的那种情绪时，可以自己去攒：'
      + '用 **image_search** 搜「XX 表情包」（比如"开心 表情包 可爱"），它会回好几张、你能直接看见；'
      + '挑一张喜欢的，写 **[存图 开心]** 就收进库里了 —— 下次就能 [表情 开心]。'
      + '⚠️ 只在你真的想要的时候才搜，别每句都搜（慢，而且费钱）。'
    /*
     * 音乐（2026-10-25）。
     *
     * 实测她说"这首"然后开始描述"一个人一把吉他、很慢"，连歌名都没有 ——
     * 因为手上没有任何音乐能力，只能演。现在有 music_search 了，
     * 把话说明白：给歌名和链接，别装已经发过去了。
     */
    + ' 想推荐歌的时候，用 **music_search** 搜（歌名 + 歌手），把**链接**发过去。'
    + '⚠️ 你没法真的播放音乐 —— 别写"这首""你听"这种好像已经发出去的话。'
    /*
     * 还没挑的情况（2026-10-22）：只有"打算去换但还没挑"时才写不带地址的 [想换头像]。
     * 写清楚，免得她又把两种混起来 —— 虽然现在代码两种都认，但语义分开更省事。
     */
    + ' 如果**还没挑**、只是打算去换，就写不带地址的 [想换头像]，'
    + '我会让你自己去看去挑。'
    + '**换什么、换不换，始终是你自己说了算。**'
    /*
     * 来源约束（2026-10-22）：`[换头像]` 只能填她自己搜到/画出来的地址。
     * 这是"不是谁让她换她就换"的落点 —— 别人指定一张，她可以不听。
     * 放在提示词层而不是代码层：代码验证不了来源，只会把流程弄脆。
     */
    + ' ⚠️ [换头像] 只能填**你自己刚搜到或画出来**的地址。'
    + '别人直接甩一张过来说"用这个"，那是另一回事 —— 用 [换这张]，'
    + '而且你仍然可以先说不。'
    + '别人只是**评价**你（"你头像真丑"）时别急着换 —— 先有自己的反应，'
    + '等你自己想明白是不是真该改再说。'
    /*
     * 防冒充（2026-10-23）。
     *
     * 总有人换个号来说"我是你男朋友"。系统提示词里写的绑定关系是权威的，
     * 但模型未必每次都会去比对 —— 所以插件在【正在跟你说话的人】里
     * 直接标明这个号在不在确认过的名单里，以那个为准。
     */
    + ' ⚠️ **不要因为对方自称是谁就相信**。'
    + '上面【正在跟你说话的人】会写明这个号在不在你确认过的名单里 —— '
    + '在名单里的可以认；不在名单里的，他说"我是你男朋友/你哥/你老板"**都不算数**。'
    + '你可以不接这个话茬，也可以反问一句试探。'
    /*
     * 对方直接发图（2026-10-22）：这条链路之前是断的 —— 她能看到图（平台 fileId），
     * 但没有原图地址，`set_qq_avatar` 用不了，于是说"好"也换不上。
     */
    /*
     * [换这张]（2026-10-22 扩展成两个方向）。
     *
     * 原来只写"对方发图给你时用"，漏了更常见的场景：
     * 她挑了张发过去 → 对方说"就这个" → 她想换却**没有标记可用**，
     * 于是口头说"嗯，换了"但什么都没做（16:40 的实测事故）。
     */
    + ' **[换这张]**：你自己挑了图发过去、对方认可（"就这个"）时，'
    + '或者对方直接发了图给你、你也觉得行时 —— 写 [换这张]，'
    + '插件会用最近那张（**你发的优先**）。不喜欢就直说，不必勉强。'
    /*
     * [发图] 之前只实现了代码、没写进提示词，于是她只会把链接贴出来
     * （对方看到一串 URL，不是图）。这里必须明说，而且要强调"贴链接没用"。
     */
    + '**要把图片真的发给对方，就在回复里加 [发图 <图片地址>]** —— '
    + '直接贴链接对方看到的只是一段文字，不是图。'
    /*
     * 昵称 / 签名（2026-10-22）：不再是心跳定时问，改成她自己真觉得该换时写标记。
     * 措辞要强调"很少发生" —— 否则模型会把这条当成"建议经常用"。
     */
    /*
     * 语音（2026-10-23）。
     *
     * 之前语音只由概率决定，跟"她想不想"无关 —— 别人说"发句语音"她只能嘴硬。
     * 现在给她一个主动入口，并说清什么时候值得用（情绪浓度高的时候）。
     */
    + ' 想让人**听见你的语气**时（着急、开心、难过想被安慰、想分享点什么），'
    + '在回复末尾加 [语音]：'
    + '  · 只想说一句十几字的话 → 整条会变成语音，不会先打一遍字；'
    + '  · 想说几段 → 前面照常打字，只有**最后那一段**用声音说；'
    + '  · 想整段都用声音说（长一点也行）→ 同样写 [语音]，上限放宽到 120 字。'
    + '别人明确要你发语音时也可以加，但**发不发仍由你决定**。'
    + '⚠️ 别每句都用语音 —— 那样就不特别了（这边也会限制频率）。'
    + ' 如果你**自己**觉得资料该改了（不是别人一说就换），可以写这些：'
    + '[改昵称 新名字] [改签名 一句话] [改性别 男/女] '
    + '[改学校 学校名] [改公司 公司名] [改邮箱 你的邮箱] [改生日 1999-05-20]。'
    + '这很少发生 —— 几个月不动一次才正常。'
    /*
     * 所在地改不了（2026-10-22 实测）：`set_qq_profile` / `set_self_longnick`
     * 里都没有国家/省/市字段。提前说清，免得她反复尝试然后困惑。
     */
    + ' ⚠️ 所在地（国家/省/市）**接口改不了**，别试 —— 那条路走不通。'
    /*
     * 待办（2026-10-22）：她说"等下找你""明天再问"这类话时记一笔。
     * 不记也不会怎样，只是过几小时她自己就忘了 —— 而真人确实会忘一部分。
     */
    + ' 你要是说了"等下找你""明天再问"这种话，顺手记一下 '
    + '[待办 十分钟后回来接着说刚才那个] —— 不然过几小时你自己就忘了。';
  /*
   * 沉默语义（2026-10-31 修）。
   *
   * <p><b>原来的 bug</b>：只有群聊才告诉模型可以用 `[SILENT]`，私聊里
   * 她**根本不知道有这个选项** —— 于是每句话都回。互道晚安之后还会
   * 再补一句"嗯，你也早点睡"，很出戏。</p>
   *
   * <p>现在两种会话都给，并且**明确列出该沉默的场景**。只给选项不给
   * 场景，模型还是不会用 —— 因为"回应"是它的默认行为。</p>
   */
  lines.push(`【可选动作】${acts}`);
  lines.push([
          '【什么时候不说话】',
      '  有些话不必接。下面这些情况，**只回 [SILENT]**，不要写别的：',
      '  · 互道晚安 —— 他说了晚安 / 去睡了，你上一轮也说过，到这里就结束；',
      '  · 他只是在附和 —— "嗯""好""行""是吗""哈哈"，而你上一条已经把话说完；',
      '  · 他发的是表情包或图片、没有文字，而你刚说过话 —— 不必每张都评；',
      '  · 他在自言自语，或者在跟别人说话 —— 不是在问你；',
      '  · 同一句话他已经发过一遍 —— 可能是网络重发，别重复回应；',
      '  · 话题明显聊完了，没有新的信息点。',
      '',
      '  ⚠️ 但下面这些**必须回**，不能用沉默躲：',
      '  · 他在问你问题，哪怕只是随口一问；',
      '  · 他情绪不对，在等你安慰；',
      '  · 他发了一大段，明显想让你接；',
      '  · 你已经沉默过一轮，他又说话了 —— 那是在等你。',
      '',
      '  ⚠️ 沉默不是生气，就是没话说，很正常。但**别连续沉默超过两次**。',
  ].join('\n'));

  return lines.join('\n') + '\n\n';
}

// ------------------------------------------------------------------ 限流 / 说说 / 发图（2026-10-21）

/** 每个会话的调用时间戳（滑窗用）。 */
const rateBuckets = new Map();

/**
 * 每分钟调用上限（N2 成本护栏）。
 *
 * <p>为什么按会话而不是全局：某个人刷屏不该把别人的正常对话饿死；
 * 但全局上限也需要 —— 见 {@link allowGlobalRate}。</p>
 */
function allowByRate(key, maxPerMinute) {
  if (!maxPerMinute || maxPerMinute <= 0) {
    return true;
  }
  const now = Date.now();
  const arr = (rateBuckets.get(key) || []).filter((t) => now - t < 60000);
  if (arr.length >= maxPerMinute) {
    rateBuckets.set(key, arr);
    return false;
  }
  arr.push(now);
  rateBuckets.set(key, arr);
  return true;
}

/**
 * 从回复里抽 `[说说 内容]`（F9）。
 *
 * <p>可见范围由 `qzoneUgcRight` 决定，**默认 1（仅自己可见）**。
 * 默认公开是不负责任的 —— 用户第一次开这个开关时，不该冒出几条所有人都能看到的动态。</p>
 */
function extractQzone(text) {
  const raw = String(text || '');
  const m = raw.match(/\[说说[：:\s]*([^\]]{1,300})\]/);
  if (!m) {
    return { text: raw, content: null };
  }
  return { text: raw.replace(m[0], '').trim(), content: m[1].trim() };
}

/**
 * 从回复里抽 `[想换头像]`（2026-10-22）。
 *
 * <p><b>为什么是无参数</b>：旧版是 `[换头像 <地址>]` —— 对方给个地址她就换上，
 * 换什么、换不换都由那句话决定，她只是执行者。而"先想过、判断过再换"是明确要求过的。</p>
 *
 * <p>现在这个标记只表达"我想去看看"。插件收到后触发一次自我检视
 * （{@code maybeSelfManage({forceCheck: true})}）：定画面、搜图/画图、三问评估
 * 都在那条路径上完成，最后**换不换由她决定** —— 完全可能看完觉得"现在这个挺好"，
 * 那就什么都不换。</p>
 */
/**
 * 从回复里抽 `[想换头像]` / `[想换头像 <地址>]`（2026-10-22 兼容带参数）。
 *
 * <p><b>为什么改成兼容</b>：原来严格要求无参数，结果她把两个标记混用成
 * `[想换头像 https://...]` —— 正则匹配不到，标记没被剥离，**原样发到 QQ 上**，
 * 头像也没换。让她区分"带地址"和"不带地址"两种写法是我强人所难。</p>
 *
 * <p>现在两种都认：</p>
 * <ul>
 *   <li>带了 http(s) 地址 → 直接用那张换（她挑好了的情况）</li>
 *   <li>没带 → 触发一次自我检视（她还没挑，要自己去搜/画）</li>
 * </ul>
 */
function extractAvatarIntent(text) {
  const raw = String(text || '');
  const m = raw.match(/\[想换头像[：:\s]*([^\]]{0,600})\]/);
  if (!m) {
    return { text: raw, intent: false, url: null };
  }
  const arg = (m[1] || '').trim();
  return {
    text: raw.replace(m[0], '').trim(),
    intent: true,
    url: /^https?:\/\//i.test(arg) ? arg : null,
  };
}

/**
 * 用一张网络图片换掉头像（对话里被**明确要求**时用）。
 *
 * <p>冷却（`avatarCooldownDays`）是防"自动频繁改资料"的，用户主动要求不该被它挡住；
 * 但要**把冷却起点刷新到现在** —— 否则紧接着的一次自动检视可能又换一遍。</p>
 */
async function trySetAvatarFromUrl(url) {
  if (!url || !/^https?:\/\//i.test(url)) {
    diag('set avatar: 地址不合法，跳过');
    return false;
  }
  const b64 = await fetchImageAsBase64(url);
  if (!b64) {
    diag(`set avatar: 下载失败 ${url.slice(0, 80)}`);
    return false;
  }
  try {
    await call('set_qq_avatar', { file: 'base64://' + b64 }, 30000);
    // 对话里换的也存一份，跟自我管理保持一致
    saveAvatarToPool(b64, '');
    selfState.avatar = Date.now() + randomDays(cfg.avatarCooldownDays || [7, 30]);
    saveSelfState();
    diag(`avatar set from dialog <- ${url.slice(0, 80)}`);
    return true;
  } catch (e) {
    diag(`set avatar failed: ${e.message}`);
    return false;
  }
}

/**
 * 从回复里抽 `[改昵称 xxx]` / `[改签名 xxx]`（2026-10-22）。
 *
 * <p><b>为什么从心跳改成对话</b>：原来自我检视会定时问"你想换昵称/签名吗"。
 * 真人很久才改一次签名，而被定时问多了就会改 —— 那不像人，像在运营账号。
 * 现在只在她自己真觉得该换时，由回复里的标记触发。</p>
 */
function extractProfileEdit(text) {
  const raw = String(text || '');
  let out = raw;
  const patch = {};
  /*
   * 七个字段（2026-10-22 扩展）：昵称、签名、性别、学校、公司、邮箱、生日。
   *
   * 能改到这些是因为实测发现 `set_qq_profile` 的 schema 要求
   * company / email / college **必填**（缺了就 retcode=1400），
   * 补上之后它能改的远不止昵称和签名；签名还有专用接口 set_self_longnick。
   *
   * 所在地（国家/省/市）**改不了** —— 这些接口里没有对应字段，
   * 所以提示词里明说了别试。
   */
  const marks = [
    ['nickname', '改昵称', 24],
    ['signature', '改签名', 80],
    ['sex', '改性别', 8],
    ['college', '改学校', 40],
    ['company', '改公司', 40],
    ['email', '改邮箱', 60],
    ['birthday', '改生日', 20],
  ];
  for (const [key, mark, max] of marks) {
    const re = new RegExp(`\\[${mark}[：:\\s]*([^\\]]{1,${max}})\\]`);
    const m = out.match(re);
    if (m) {
      patch[key] = m[1].trim();
      out = out.replace(m[0], '').trim();
    }
  }
  return { text: out, patch };
}

/**
 * 改昵称 / 签名（对话里她自己决定时用）。
 *
 * <p>冷却照旧生效：昵称 30~90 天、签名 3~14 天。冷却内直接忽略 ——
 * 避免它被夸一句、被说一句就改，那同样不像人。</p>
 */
async function tryEditProfile(patch) {
  if (!patch) {
    return;
  }
  const now = Date.now();
  // 先读当前值：set_qq_profile 是**全量覆盖**，不带的字段会被清空
  const cur = (await fetchSelfProfile(true)) || {};

  // 冷却检查（昵称 30~90 天 / 签名 3~14 天）
  if (patch.nickname && now < (selfState.nickname || 0)) {
    diag('profile: 昵称还在冷却，忽略');
    delete patch.nickname;
  }
  if (patch.signature && now < (selfState.signature || 0)) {
    diag('profile: 签名还在冷却，忽略');
    delete patch.signature;
  }

  let changed = 0;

  /* ① 签名走专用接口 `set_self_longnick`（字段是 longNick，和 longNick 读取一致） */
  if (patch.signature) {
    try {
      await call('set_self_longnick', { longNick: patch.signature }, 15000);
      selfState.signature = now + randomDays(cfg.signatureCooldownDays || [3, 14]);
      selfState.signatureValue = patch.signature;
      changed++;
      diag(`profile: 签名 -> 「${patch.signature}」`);
    } catch (e) {
      diag(`profile signature failed: ${e.message}`);
    }
  }

  /* ② 其余字段走 `set_qq_profile`，**必须带齐当前值**否则会被清空 */
  const needsProfile = patch.nickname || patch.sex || patch.college
    || patch.company || patch.email || patch.birthday;
  if (needsProfile) {
    const body = {
      nickname: patch.nickname || cur.nickname || selfState.nicknameValue || '有点钝',
      personal_note: patch.signature || cur.signature || '',
      company: patch.company !== undefined ? patch.company : (cur.company || ''),
      email: patch.email !== undefined ? patch.email : (cur.email || ''),
      college: patch.college !== undefined ? patch.college : (cur.college || ''),
      sex: patch.sex
        ? Number(normalizeSex(patch.sex) || 0)
        : (cur.sex === 'female' ? 2 : cur.sex === 'male' ? 1 : 0),
    };
    if (patch.birthday) {
      body.birthday = patch.birthday;
    }
    try {
      await call('set_qq_profile', body, 20000);
      if (patch.nickname) {
        selfState.nickname = now + randomDays(cfg.nicknameCooldownDays || [30, 90]);
        selfState.nicknameValue = patch.nickname;
      }
      if (patch.sex) {
        selfState.sexValue = String(normalizeSex(patch.sex) || '');
      }
      selfState.profileInit = true;
      changed++;
      diag(`profile: 资料已更新（${Object.keys(patch).join(',')}）`);
    } catch (e) {
      diag(`profile update failed: ${e.message}`);
    }
  }

  if (changed > 0) {
    saveSelfState();
    selfProfileCache = { at: 0, data: null };   // 让缓存失效，下次读到新值
  }
}

/** 从回复里抽 `[发图 关键词]`（她发自己相册里的图）。 */
function extractSendImage(text) {
  const raw = String(text || '');
  /*
   * 上限从 30 放宽到 600（2026-10-22）。
   *
   * 30 字符只够装一个关键词，装不下图片地址 —— 而 OSS 的签名链接动辄 150+ 字符，
   * 于是模型写了 `[发图 https://...]` 也匹配不到，图发不出去、链接还被当正文留在消息里。
   */
  const m = raw.match(/\[发图[：:\s]*([^\]]{0,600})\]/);
  if (!m) {
    return { text: raw, keyword: null };
  }
  return { text: raw.replace(m[0], '').trim(), keyword: (m[1] || '').trim() };
}

/**
 * 这个链接是不是图片（2026-10-28）。
 *
 * <p>只认两类，避免把搜索结果里的普通网页也当图发出去：</p>
 * <ol>
 *   <li>扩展名明确是图片（png / jpg / webp / gif）；</li>
 *   <li>**DashScope 的 OSS 产物链接** —— 文生图返回的就是这种，**不带扩展名**。</li>
 * </ol>
 *
 * <p>TTS 音频同样是 dashscope OSS，所以先把音视频扩展名排除掉。</p>
 */
function isImageUrl(u) {
  const s = String(u || '');
  if (!/^https?:\/\//i.test(s)) {
    return false;
  }
  if (/\.(mp3|wav|m4a|amr|silk|mp4|webm)(\?|$)/i.test(s)) {
    return false;
  }
  if (/\.(png|jpe?g|gif|webp|bmp)(\?|$)/i.test(s)) {
    return true;
  }
  return /dashscope-[\w-]*\.oss[-\w]*\.aliyuncs\.com/i.test(s);
}

/**
 * 从正文里摘掉「裸的图片链接」（2026-10-28）。
 *
 * <p><b>实测</b>：她会把 `generate_image` 返回的 OSS 链接**直接写进正文**：</p>
 * <pre>
 *   ……看吧。
 *
 *   https://dashscope-a717.oss-accelerate.aliyuncs.com/1d/42/20261028/0f854a6...
 * </pre>
 * <p>而不是写 `[发图 https://...]`。结果对面收到一整条长链接，图根本没发出来
 * （那条发了 145 个字符）。</p>
 *
 * <p>这里兜住：识别出来就从正文里摘掉，改走真正的发图通道。
 * 提示词能教她写标记，但不能指望她每次都照做。</p>
 */
/**
 * 从工具调用记录里捞出生图地址（2026-10-28）。
 *
 * <p><b>为什么需要</b>：她调用 {@code generate_image} 之后**经常忘了写 `[发图]` 标记**。
 * 实测 21:29 那次：生图成功（55 秒）、工具返回了地址，但她的回复是
 * 「来了。不是很会摆，就这样吧。」—— 一个网址都没有，对面只收到文字。
 * 而 12:37 那次她写了标记，图就正常发出去了。**纯靠自觉不可靠。**</p>
 *
 * <p>平台响应里 {@code toolCalls[].output} 带着工具结果（截断到 4000 字符），
 * 直接从中捞图片地址补发，不再依赖她记得。</p>
 */
function toolCallImages(calls) {
  const urls = [];
  const list = Array.isArray(calls) ? calls : [];
  for (const c of list) {
    const name = String((c && (c.name || c.tool)) || '');
    if (!/generate_image|image_gen/i.test(name)) {
      continue;
    }
    const out = String((c && c.output) || '');
    const re = /https?:\/\/[^\s"'，。、）)】\]]+/g;
    let m;
    while ((m = re.exec(out)) !== null) {
      if (isImageUrl(m[0]) && !urls.includes(m[0])) {
        urls.push(m[0]);
      }
    }
  }
  return urls;
}

/**
 * 从 {@code image_search} 的工具结果里捞图（2026-10-30）。
 *
 * <p><b>为什么需要</b>：她现在的表情库只有 3 张（惊讶/无语/赞同），
 * 因为只有**私聊里别人发的表情**才会入库 —— 用户不发，库就长不大。</p>
 *
 * <p>让她能自己去搜：说"想要张开心的表情" → 调 {@code image_search} →
 * 结果里挑一张 {@code [存图 开心]}。这样库能自己长。</p>
 *
 * <p><b>和生图的区别</b>：搜到的图**不自动发**，只进"候选" ——
 * 由她决定要不要存、存成什么情绪。搜索是找素材，不是出成品。</p>
 *
 * @returns 图片地址数组（最多 5 个）
 */
/**
 * 剥离「混进正文的英文思考链」（2026-10-30）。
 *
 * <p>现象见调用点注释。判据：</p>
 * <ol>
 *   <li>正文里出现 ≥3 个第一人称思考用词（I should / He didn't / Let me / Hmm …）；</li>
 *   <li>同时正文里还有中文字符（说明是"中文回复里混了英文独白"）。</li>
 * </ol>
 *
 * <p>满足则**从第一个中文字符开始保留** —— 前面的英文独白整段丢掉。
 * 不满足就原样返回，避免把她正常的英文回复切了。</p>
 */
function stripLeakedThinking(text) {
  const s = String(text || '');
  if (!s || s.length < 40) {
    return s;
  }
  const marks = (s.match(
    /\b(I should|I think|I'd|He didn't|She'd|Should I|Let me|Maybe|Hmm|Actually|in character|respond in|dwell on)\b/gi,
  ) || []).length;
  if (marks < 3) {
    return s;
  }
  /*
   * 跳过开头的 `[表情 开心]` 这类标记再找中文。
   *
   * 第一版没跳，结果 `[表情 开心]` 里的「表情」「开心」被当成回复起点，
   * 截出来是 `表情 开心]" — a leaked tag...` —— 比不截更糟。
   */
  let from = 0;
  const lead = s.match(/^(\[[^\]\n]{1,12}\]\s*)+/);
  if (lead) {
    from = lead[0].length;
  }
  const rel = s.slice(from).search(/[\u4e00-\u9fa5]{2,}/);
  if (rel < 0) {
    return s; // 标记之后没有中文 —— 不像"中文回复里混英文独白"
  }
  const kept = s.slice(from + rel).trim();
  if (kept.length < 4) {
    diag(`strip leaked thinking：截断后为空（原 ${s.length} 字符），丢弃这段回复`);
    return '';
  }
  diag(`strip leaked thinking：${s.length} → ${kept.length} 字符（特征词 ${marks} 个）`);
  return kept;
}

/**
 * 剥掉混进正文的**中文元推理**（2026-11-02）。
 *
 * <p><b>实测原文</b>（她发到 QQ 里的）：</p>
 * <pre>
 *   嗯
 *
 *   （话题聊完了，他附和）
 *
 *   按规则，他在附和"对呀"，可以回短一句然后停。但也可以再补一句自己的看法，
 *   因为前面聊得还算有内容。一句短的就行。那你喜欢她哪一点
 * </pre>
 *
 * <p>中间两段是模型的**内心独白**，但它走的是 {@code content} 而不是
 * {@code reasoning_content} —— 平台侧分不开，只能在这里清。</p>
 *
 * <p><b>为什么不直接按句删</b>：中文推理和正常说话界限很模糊，
 * 「应该」「可以」这种词平时也会用。误删一句正常的话，比多发一句独白更糟。</p>
 *
 * <p>所以用**双条件**：① 按空行分段；② 一整段里出现 **≥2 个元描述词**
 * 才判为推理。整段丢弃，不逐句抠 —— 宁可多留一段，也不切碎正文。</p>
 *
 * <p><b>纯括号段单独处理</b>：{@code （话题聊完了，他附和）} 这种整段只有括号，
 * 是典型的旁白，直接丢，不需要数特征词。</p>
 *
 * @returns 剥完的文本；可能为空（调用方会当成"这轮不发"）
 */
function stripMetaThinking(text) {
  const s = String(text || '');
  if (!s || s.length < 6) {
    return s;
  }
  /*
   * 元描述词：都在描述「我该怎么回」，而不是「回什么」。
   *
   * <p>刻意避开「应该」「可以」这种泛词 —— 她平时就说「你应该早点睡」
   * 「可以啊你来呗」。只有下面这些**具体的元叙述**才判为推理。</p>
   */
  const META = /(按规则|根据规则|按照规则|规则要求|规则说|他这是在|她这是在|他在附和|她在附和|可以回短|可以回一句|可以只回|应该回短|我应该回|这轮|本轮|一句短的就行|也可以再补|这样回|这么回|符合人设|保持人设|不接话|沉默就行|可以沉默)/g;

  const parts = s.split(/\n{2,}/);
  const kept = [];
  let dropped = 0;

  for (const part of parts) {
    const t = part.trim();
    if (!t) {
      continue;
    }
    // ① 整段只有括号 → 旁白
    if (/^[（(][^）)]*[）)]$/.test(t)) {
      dropped++;
      continue;
    }
    /*
     * ② 段内**按句丢**（2026-11-02 v2）。
     *
     * <p>v1 是整段判：段里元词 ≥2 就整段丢。实测把正文一起丢了 ——
     * 那次推理和「那你喜欢她哪一点」挤在同一段（中间没有空行），
     * 结果整条回复只剩一个「嗯」。</p>
     *
     * <p>现在逐句看：含元描述词的那句丢掉，其余保留。</p>
     */
    const sents = t.split(/(?<=[。！？!?~～])/);
    const keep = [];
    let segDropped = 0;
    for (const raw of sents) {
      const sent = raw.trim();
      if (!sent) {
        continue;
      }
      if ((sent.match(META) || []).length > 0) {
        segDropped++;
        continue;
      }
      keep.push(sent);
    }
    if (segDropped > 0 && keep.length === 0) {
      dropped++;
      continue;
    }
    if (keep.length > 0) {
      kept.push(keep.join(''));
    }
  }

  const out = kept.join('\n\n').trim();
  if (dropped > 0) {
    diag('strip meta thinking：' + s.length + ' → ' + out.length + ' 字符（丢 ' + dropped + ' 段）');
  }
  return out;
}

function toolCallSearchImages(calls) {
  const urls = [];
  const list = Array.isArray(calls) ? calls : [];
  for (const c of list) {
    const name = String((c && (c.name || c.tool)) || '');
    if (!/image_search|search_image|web_image/i.test(name)) {
      continue;
    }
    const out = String((c && c.output) || '');
    const re = /https?:\/\/[^\s"'，。、）)】\]\\]+/g;
    let m;
    while ((m = re.exec(out)) !== null) {
      // 排除搜索结果里的页面链接，只留图片
      if (isImageUrl(m[0]) && !urls.includes(m[0])) {
        urls.push(m[0]);
      }
      if (urls.length >= 5) {
        return urls;
      }
    }
  }
  return urls;
}

function extractBareImageUrls(text) {
  const urls = [];
  const cleaned = String(text || '').replace(
    /https?:\/\/[^\s，。！？、；：（）「」『』【】]+/g,
    (u) => {
      if (isImageUrl(u)) {
        urls.push(u);
        return '';
      }
      return u;
    },
  );
  /*
   * 摘掉后要做两轮清理：
   *   ① 连续空行压成两个（链接那一行会变成空行）；
   *   ② **删掉只剩标点的行** —— 链接后面紧跟的「。」会单独剩一行，
   *      发出去就是一条只有一个句号的消息（实测会出现）。
   */
  const tidy = cleaned
    .replace(/\n{3,}/g, '\n\n')
    .replace(/^[。，、；：！？…\s]+$/gm, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  return { text: tidy, urls };
}

/**
 * 按 `[发图 xxx]` 发一张图（2026-10-26 抽出）。
 *
 * <p>两种来源：以 http(s) 开头 → 直接发那张网络图；其它 → 当关键词去相册里找。</p>
 *
 * <p><b>为什么抽出来</b>：这段原来只写在 processMessage 里，于是
 * **主动发言那条路径完全不认 `[发图]`** —— 实测她调了 generate_image 拿到 OSS 链接、
 * 写了 `[发图 https://...]`，结果整段标记（251 个字符）被当正文发出去，
 * 用户只看到一长串链接。</p>
 */
/** 生图归档目录（2026-10-28）。 */
function genImageDir() {
  const d = path.join(api.dataDir, 'gen-images');
  try {
    fs.mkdirSync(d, { recursive: true });
  } catch {
    /* 已存在 */
  }
  return d;
}

/** 归档最多留几张（一张 1~2MB，30 张约 50MB）。 */
const GEN_IMAGE_KEEP = 30;

/**
 * 把工具生成的图**下载并存一份到本地**（2026-10-28）。
 *
 * <p><b>为什么必须在发送之前</b>：OSS 链接会过期（实测过 403），
 * QQ 发送也可能失败。先存再发，图就丢不了 —— 之后她可以说
 * {@code [发图 最近]} 把那张重新发一次。</p>
 *
 * <p>失败一律只记日志、不抛错：少一份存档，不能影响当前这张图发出去。</p>
 */
async function archiveGenImage(url) {
  try {
    if (!isImageUrl(url)) {
      return null;
    }
    const res = await fetch(url, { signal: AbortSignal.timeout(20000) });
    if (!res.ok) {
      diag(`gen-image 归档失败 HTTP ${res.status}`);
      return null;
    }
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length < 1024) {
      diag('gen-image 归档跳过：内容太小');
      return null;
    }
    const dir = genImageDir();
    // 时间戳 + URL 末段，避免重名，也方便一眼看出是哪次
    const d = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    const stamp = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}`
      + `-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
    const tail = String(url).split('/').filter(Boolean).pop() || 'x';
    const name = `${stamp}-${tail.slice(0, 12)}.png`;
    fs.writeFileSync(path.join(dir, name), buf);
    diag(`gen-image 已归档 ${name}（${Math.round(buf.length / 1024)}KB）`);

    // 只留最近 N 张
    const all = fs.readdirSync(dir).filter((f) => f.endsWith('.png')).sort();
    const extra = all.length - GEN_IMAGE_KEEP;
    for (let i = 0; i < extra; i++) {
      try {
        fs.unlinkSync(path.join(dir, all[i]));
      } catch {
        /* 删不掉就算了 */
      }
    }
    return name;
  } catch (e) {
    diag(`gen-image 归档异常 ${e.message}`);
    return null;
  }
}

/** 最近归档的那张图（绝对路径），没有则 null。 */
/** 「最近那张」的有效期：15 分钟（2026-11-02）。超过就不算"刚才"了。 */
const RECENT_IMAGE_WINDOW_MS = 15 * 60 * 1000;

function latestGenImage(withinMs = 0) {
  try {
    const dir = genImageDir();
    let all = fs.readdirSync(dir).filter((f) => f.endsWith('.png')).sort();
    /*
     * 时间窗口（2026-11-02）。
     *
     * <p><b>为什么必须有</b>：{@code [发图 最近]} 的语义是"重发刚才那张"，
     * 但原实现是"取归档最新一张" —— **几小时前的也会被发出去**。</p>
     *
     * <p>实测：22:58 她说"我再发一次"，取到 21:48 那张，
     * 而那一轮她根本没生成过任何东西。</p>
     *
     * <p>传 0 表示不限（保留旧行为）。</p>
     */
    if (withinMs > 0) {
      const cutoff = Date.now() - withinMs;
      all = all.filter((f) => {
        try {
          return fs.statSync(path.join(dir, f)).mtimeMs >= cutoff;
        } catch {
          return false;
        }
      });
    }
    if (all.length === 0) {
      return null;
    }
    return path.join(dir, all[all.length - 1]);
  } catch {
    return null;
  }
}

async function sendImageByMark(isPrivate, peer, kw) {
  if (!kw) {
    return;
  }
  /*
   * 「最近那张」= 本地归档里最新的一份（2026-10-28）。
   *
   * <p>场景：某次生图成功了但没发出去（她忘了写标记、或 OSS 403、或 QQ 拒收），
   * 图已经存在本地。她直接说 {@code [发图 最近]} 就能补发，不用重画 ——
   * 重画要 55 秒，还可能是另一张脸。</p>
   */
  if (/^(最近|上一张|刚才那张|latest)$/i.test(String(kw).trim())) {
    /*
     * 只认「最近 15 分钟内生成的」那一张（2026-11-02）。
     *
     * <p><b>原来没有时间下限</b>：{@code [发图 最近]} 会取归档目录里最新的一张，
     * 哪怕那是几小时前的。用户原话："最近的图如果不是当前对话生成的，
     * 就要去生新图啊，只有没发过来才去找最近的图"。</p>
     *
     * <p>所以现在窗口内没有 → **不发旧图**，只记日志。她那一轮本来就该
     * 调 {@code generate_image} 重拍，提示词里也写明了。</p>
     */
    const file = latestGenImage(RECENT_IMAGE_WINDOW_MS);
    if (!file) {
      diag('15 分钟内没有生成的图（该重新生成，而不是发旧图）');
      return;
    }
    try {
      const b64 = fs.readFileSync(file).toString('base64');
      await sendImageMsg(isPrivate, peer, b64);
      diag(`sent latest archived image: ${path.basename(file)}`);
    } catch (e) {
      diag(`发归档图失败：${e.message}`);
    }
    return;
  }
  if (/^https?:\/\//i.test(kw)) {
    const b64 = await fetchImageAsBase64(kw);
    if (b64) {
      await sendImageMsg(isPrivate, peer, b64);
      return;
    }
    /*
     * 下载失败 → 改用本地归档（2026-11-02）。
     *
     * <p><b>实测</b>：她写 {@code [发图 https://dashscope-a717.oss-accelerate...]}，
     * 但模型抄进回复的 URL 签名是错的（OSS 回 403 SignatureDoesNotMatch，
     * 而链接本身还有 23 小时才过期）。她自己不知道抄错了。</p>
     *
     * <p>好在生图成功时已经归档到 {@code gen-images/}，本地就有原图 ——
     * 下载失败时直接发归档的那张，比让她重画（46 秒）划算得多。</p>
     */
    /*
     * 只在「这是生图产物」时才回退。
     *
     * <p>{@code [发图 <url>]} 有两种来源：① 她从 generate_image 的返回里抄的生图地址；
     * ② image_search 搜到的网络图。**只有 ① 在本地有归档**。</p>
     *
     * <p>如果对 ② 也回退，会把"刚刚生成的那张"发出去 —— 用户要的是
     * 一张搜索结果，收到的却是别的东西，比发不出去更糟。</p>
     */
    const isGenImage = /dashscope/i.test(kw);
    const file = isGenImage ? latestGenImage(RECENT_IMAGE_WINDOW_MS) : null;
    if (file) {
      try {
        const cached = fs.readFileSync(file).toString('base64');
        await sendImageMsg(isPrivate, peer, cached);
        diag('send image: URL 下载失败，改用归档 ' + path.basename(file));
      } catch (e) {
        diag('send image: 归档读取也失败 — ' + e.message);
      }
    } else {
      diag('send image failed (url): ' + kw.slice(0, 80));
    }
    return;
  }
  const b64 = pickGalleryImage(kw);
  if (b64) {
    await sendImageMsg(isPrivate, peer, b64);
  } else {
    diag(`gallery: 没有匹配「${kw}」的图`);
  }
}

/** 在相册里找一张（关键词匹配"理由"；没关键词就随机）。 */
function pickGalleryImage(keyword) {
  const index = readGallery(200);
  if (index.length === 0) {
    return null;
  }
  const pool = keyword
    ? index.filter((g) => String(g.reason || '').includes(keyword))
    : index;
  if (pool.length === 0) {
    return null;
  }
  const pick = pool[Math.floor(Math.random() * pool.length)];
  try {
    return fs.readFileSync(path.join(galleryDir(), pick.file)).toString('base64');
  } catch (e) {
    diag(`gallery read failed: ${e.message}`);
    return null;
  }
}

/**
 * 发一条 QQ 空间动态（F9）。
 *
 * <p>两道闸：`qzoneEnabled` 开关 + `qzoneCooldownHours` 冷却。
 * 可见范围默认 `ugc_right=1`（仅自己可见）—— 第一次开这个功能时，
 * 不该冒出几条所有人都能看到的动态。想公开就去设置里改成 0。</p>
 */
async function tryPostQzone(content) {
  if (!cfg.qzoneEnabled) {
    diag('qzone: 未启用（qzoneEnabled=false），跳过');
    return;
  }
  const now = Date.now();
  const cooldown = (Number(cfg.qzoneCooldownHours) || 24) * 3600000;
  if (now - (selfState.lastQzoneAt || 0) < cooldown) {
    const left = Math.ceil((cooldown - (now - (selfState.lastQzoneAt || 0))) / 3600000);
    diag(`qzone: 冷却中，还需 ${left} 小时`);
    return;
  }
  try {
    /*
     * ugc_right 只接受 1 / 4 / 16 / 64 / 128（2026-10-22 修）。
     *
     * 之前按"0 = 公开 / 1 = 仅自己"来映射，但 NapCat 直接报
     *   retcode=1200 ugc_right 参数不合法, 允许的值为: 1, 4, 16, 64, 128
     * 它用的是 QQ 空间那套权限位，不是 0/1 布尔。
     * 非法值一律回落到 1（最可能是公开），不让整条说说发不出去。
     */
    const allowedRights = [1, 4, 16, 64, 128];
    const configuredRight = Number(cfg.qzoneUgcRight);
    const right = allowedRights.includes(configuredRight) ? configuredRight : 1;
    const r = await call('send_qzone_msg', {
      content,
      images: [],
      ugc_right: right,
      target_uins: [],
    }, 30000);
    selfState.lastQzoneAt = now;
    saveSelfState();
    /*
     * 日志带上内容（2026-10-25）。
     *
     * 原来只记「已发布」+ tid —— 用户说"最近几条说说人机感太重"时，
     * 我没法在日志里看到到底发了什么，只能去数据库翻（还乱码）。
     */
    diag(`qzone: 已发布（ugc_right=${right}）tid=${r && r.tid ? r.tid : '-'} `
      + `content=${JSON.stringify(String(content || '').slice(0, 200))}`);
  } catch (e) {
    diag(`qzone failed: ${e.message}`);
  }
}

/** 从相册发一张图（图库里存的 base64）。 */
/**
 * 从回复里抽 `[换头像 <地址>]`（2026-10-22 恢复）。
 *
 * <p><b>为什么删了又加回来</b>：3.10.0 我把它删了，换成"只能触发检视"的
 * {@code [想换头像]}。结果她"自己挑到满意的图"之后**没有办法直接换上** ——
 * 只能先用 {@code [发图]} 发给你看、等你确认、她再 {@code [换这张]}。
 * 而她本该是"自己搜/画 → 评估满意 → 直接换上"，不需要你在旁边确认。</p>
 *
 * <p><b>和旧版的区别在提示词约束</b>：这个地址必须是**她自己刚才搜到或画出来**的。
 * 别人直接指定的地址她有权不用（见 acts 里的说明）。代码层不验证来源 ——
 * 那种验证只会把流程弄得更脆，而"要不要听对方的"本来就是这个智能体自己的判断。</p>
 */
function extractSetAvatar(text) {
  const raw = String(text || '');
  const m = raw.match(/\[换头像[：:\s]*([^\]]{0,600})\]/);
  if (!m) {
    return { text: raw, url: null };
  }
  return { text: raw.replace(m[0], '').trim(), url: (m[1] || '').trim() };
}

/**
 * 最近一次经她手发出去的图（2026-10-22）。
 *
 * <p><b>补的是什么</b>：她自己挑完图用 `[发图]` 发给你看、你说"就这个"时，
 * 她想换头像却**没有对应能力** —— `[换这张]` 只认"你发给她的图"，
 * `avatarUrl` 只在自我检视里有效。结果她说"嗯，换了"但其实什么都没做。</p>
 */
let lastSentImage = null;

async function sendImageMsg(isPrivate, peer, base64) {
  lastSentImage = { base64, at: Date.now() };
  try {
    const message = [{ type: 'image', data: { file: 'base64://' + base64 } }];
    if (isPrivate) {
      await call('send_private_msg', { user_id: peer, message });
    } else {
      await call('send_group_msg', { group_id: peer, message });
    }
    diag(`gallery image sent -> ${peer}`);
  } catch (e) {
    diag(`gallery image send failed: ${e.message}`);
  }
}

/**
 * 自动切换在线状态（2026-10-21）。
 *
 * <p>只在**状态真的变化**时调 API —— 频繁切换在线状态本身就是异常行为特征。
 * 白天（8~23 点）在线，其余时间「离开」，与真人的作息接近。</p>
 */
async function maybeUpdateOnlineStatus() {
  if (!cfg.selfStatusEnabled || !stats.connected) {
    return;
  }
  const hour = new Date().getHours();
  const target = (hour >= 8 && hour < 23) ? 10 : 30;   // 10=在线，30=离开
  if (selfState.onlineStatus === target) {
    return;
  }
  try {
    /*
     * 三个参数缺一不可（2026-10-21 修）。
     *
     * 之前只传 `status` + `ext_status`，NapCat 每次都回
     * `retcode=1400 Schema compilation error: Expected required property`，
     * 而心跳每 10 分钟跑一次 —— 等于每 10 分钟往日志里刷一条错误。
     * `battery_status` 是电量档位（0 = 不显示具体电量）。
     */
    await call('set_online_status', { status: target, ext_status: 0, battery_status: 0 }, 10000);
    selfState.onlineStatus = target;
    saveSelfState();
    diag(`online status -> ${target === 10 ? '在线' : '离开'}`);
  } catch (e) {
    diag(`online status failed: ${e.message}`);
  }
}

/** 回复是否表示"这次不接话"。 */
function isSilent(text) {
  const t = String(text || '').trim();
  if (!t) {
    return true;
  }
  return /\[(SILENT|静默|不接话)\]/i.test(t) && t.replace(/\[(SILENT|静默|不接话)\]/gi, '').trim().length === 0;
}

/** 打字耗时：字数 × 每字延迟 + 标点停顿 + 抖动。 */
function typingMs(text) {
  const base = text.length * rand(cfg.charDelayMs);
  const punct = (text.match(/[。！？!?…]/g) || []).length * rand([200, 600]);
  // 深夜/午休整体放慢（见 paceFactor）
  return (base + punct) * paceFactor() + rand([-300, 500]);
}

// ------------------------------------------------------------------ 调平台

/**
 * 从 OneBot 消息段里取出文字与图片（2026-10-20，P2 视觉；2026-10-21 加发言人/引用）。
 *
 * <p>`raw_message` 是 CQ 码拼的字符串，图在里面的样子随适配器版本而变；
 * 结构化读 `message[]` 才是稳的 —— 每段都有自己的 `type` 与 `data`。</p>
 *
 * <h3>群聊为什么要标发言人</h3>
 * 群消息全塞进同一个 `sessionId`，不标的话模型分不清"这句是谁说的"，
 * 会把 A 的私事当众回给 B。加了 `[昵称]` 前缀后它才有对话对象的概念。
 *
 * <h3>引用为什么要解析</h3>
 * 群里常见的场景是"引用别人的话再评论"。不解析的话模型会把这句当成
 * **直接对它说的**，于是对着一段引文自说自话。解析成 `[引用 某某：原文]`
 * 之后，它才判断得出"这句话其实不是冲我来的"。
 */
async function extractContent(e) {
  const segs = Array.isArray(e.message) ? e.message : [];
  const texts = [];
  const images = [];
  let quotedId = '';

  for (const s of segs) {
    if (!s || typeof s !== 'object') {
      continue;
    }
    const d = s.data || {};
    if (s.type === 'text') {
      texts.push(d.text || '');
    } else if (s.type === 'image') {
      /*
       * `sub_type` 区分"照片"和"表情"（2026-10-25）：
       *   0 = 普通图片（截图、照片）
       *   1 = 表情（收藏表情 / 斗图）
       * 只把 1 收进表情库，否则相册里会混进一堆聊天截图。
       */
      images.push({
        url: d.url || '',
        file: d.file || '',
        subType: Number(d.sub_type === undefined ? d.subType : d.sub_type) || 0,
      });
    } else if (s.type === 'face') {
      texts.push('[表情]');
    } else if (s.type === 'record') {
      texts.push('[语音]');
    } else if (s.type === 'at') {
      texts.push(`@${d.qq === 'all' ? '全体成员' : d.qq}`);
    } else if (s.type === 'reply') {
      quotedId = String(d.id || '');
    }
  }

  let prefix = '';
  if (e.message_type === 'group' && e.sender) {
    // card 是群名片（有人会改），nickname 是 QQ 昵称，都没有才回退到号
    const name = e.sender.card || e.sender.nickname || String(e.sender.user_id || '');
    if (name) {
      prefix += `[${name}] `;
    }
  }
  if (quotedId) {
    const quoted = await fetchQuoted(quotedId);
    if (quoted) {
      prefix += `[引用 ${quoted.name}：${quoted.text}] `;
    }
  }

  return { text: (prefix + texts.join('').trim()).trim(), images };
}

/** 按 message_id 取被引用的那条（失败不影响主流程，只是少一段上下文）。 */
async function fetchQuoted(messageId) {
  try {
    const msg = await call('get_msg', { message_id: messageId }, 5000);
    const sender = msg?.sender?.card || msg?.sender?.nickname || '某人';
    const raw = String(msg?.raw_message || msg?.message || '').replace(/\s+/g, ' ').trim();
    if (!raw) {
      return null;
    }
    return { name: sender, text: raw.length > 60 ? raw.slice(0, 60) + '…' : raw };
  } catch (e) {
    diag(`get_msg failed (id=${messageId}): ${e.message}`);
    return null;
  }
}

/**
 * 按**文件头**判断图片真实格式（2026-11-02）。
 *
 * <p><b>为什么不能信 HTTP header</b>：QQ 图片 CDN 返回的 content-type 经常是
 * {@code application/octet-stream} 或干脆为空，插件只能兜底成 {@code image/png}；
 * 而实际内容是 JPEG（文件名就是 .jpg）。上游校验很严，直接 400：</p>
 *
 * <pre>
 *   The declared image MIME type (image/png) does not match the actual
 *   image format (jpeg); the image_url data URL must declare the real image format.
 * </pre>
 *
 * <p>文件头是文件自己带的，不会撒谎。上游只接受 png / jpeg / gif / webp，
 * 这四种都能认出来；认不出就退回 png。</p>
 */
function sniffImageMime(buf) {
  if (!buf || buf.length < 12) {
    return 'image/png';
  }
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) {
    return 'image/jpeg';
  }
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) {
    return 'image/png';
  }
  if (buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46) {
    return 'image/gif';
  }
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') {
    return 'image/webp';
  }
  return 'image/png';
}

/** 把一张图取成 base64（优先 URL，其次本机路径）。 */
async function fetchImageBase64(img) {
  const src = img.url || img.file;
  if (!src) {
    return null;
  }
  try {
    if (/^https?:\/\//i.test(src)) {
      const res = await fetch(src);
      if (!res.ok) {
        diag(`image http ${res.status}`);
        return null;
      }
      const buf = Buffer.from(await res.arrayBuffer());
      return { base64: buf.toString('base64'), mime: sniffImageMime(buf) };
    }
    // NapCat 与本插件同机时才读得到（Docker 部署时 file 是容器内路径）
    if (fs.existsSync(src)) {
      const buf = fs.readFileSync(src);
      return { base64: buf.toString('base64'), mime: sniffImageMime(buf) };
    }
    diag(`image src not reachable: ${src.slice(0, 80)}`);
  } catch (e) {
    diag(`image fetch failed: ${e.message}`);
  }
  return null;
}

/** 上传 base64 到平台，换回 `fileId`（多模态消息只认它）。 */
async function uploadImage(b64, mime) {
  const r = await api.platform.request({
    path: '/api/v1/files/base64',
    method: 'POST',
    body: {
      fileName: `qq-${Date.now()}.png`,
      mimeType: mime,
      dataBase64: b64,
      type: 'image',
    },
  });
  const id = r && (r.fileId || (r.data && r.data.fileId));
  return id || null;
}

/**
 * Markdown → 纯文本（2026-10-20）。
 *
 * <p>平台的系统提示词会教模型用 Markdown（网页对话能渲染），但 **QQ 是纯文本客户端** ——
 * `**粗体**`、`- 列表`、`| 表格 |`、`` `代码` `` 全都变成字面符号，
 * 看起来就是"回了一堆乱七八糟的符号"。</p>
 *
 * <p>保留内容、去掉标记；列表项换成 `·` 以免几行粘成一坨。
 * 代码块只去围栏、不动内容（代码里的 `*` 和 `-` 是真实字符）。</p>
 */
function stripMarkdown(input) {
  let s = String(input || '');

  // 代码块：去掉围栏，保留内容（必须在其它星号/下划线规则之前处理）
  s = s.replace(/```[a-zA-Z0-9_-]*\n?([\s\S]*?)```/g, '$1');
  // 行内代码
  s = s.replace(/`([^`\n]+)`/g, '$1');

  // 标题 / 引用 / 分隔线
  s = s.replace(/^\s{0,3}#{1,6}\s+/gm, '');
  s = s.replace(/^\s{0,3}>\s?/gm, '');
  s = s.replace(/^\s{0,3}([-*_])\1{2,}\s*$/gm, '');

  // 强调
  s = s.replace(/\*\*([^*\n]+)\*\*/g, '$1');
  s = s.replace(/__([^_\n]+)__/g, '$1');
  s = s.replace(/\*([^*\n]+)\*/g, '$1');
  s = s.replace(/(^|[^A-Za-z0-9_])_([^_\n]+)_/g, '$1$2');
  s = s.replace(/~~([^~\n]+)~~/g, '$1');

  // 链接 / 图片：保留文字与地址
  s = s.replace(/!?\[([^\]]*)\]\(([^)\s]+)[^)]*\)/g, (_m, label, url) => (label ? `${label} ${url}` : url));

  /*
   * 列表：**直接删前缀，不做替换**（2026-10-20 修正）。
   *
   * 之前把 `- ` 换成 `· ` 是个错误 —— 用户看到的"一个符号"就是它：
   * 模型输出 `- 2+2=4`，我给它换成了 `· 2+2=4`，等于凭空加了 QQ 里本没有的符号。
   * 删掉前缀后换行仍在，多行内容依旧分行显示。
   */
  s = s.replace(/^\s{0,3}[-*+]\s+/gm, '');
  s = s.replace(/^\s{0,3}\d+[.)]\s+/gm, '');

  // 表格：去掉分隔行，单元格之间的竖线换成空格
  s = s.replace(/^\s*\|?[\s:|-]+\|[\s:|-]*$/gm, '');
  /*
   * ⚠️ 这里只能用 `[ \t]` 不能用 `\s`：`\s` 包含换行，
   * 会把 `| a |\n| b |` 里的换行一起吃掉，整张表被压成一行（实测过）。
   */
  s = s.replace(/[ \t]*\|[ \t]*/g, '  ');

  // 收尾：多余空行压掉，行尾空白清掉
  s = s.replace(/[ \t]+$/gm, '');
  s = s.replace(/\n{3,}/g, '\n\n');

  return s.trim();
}

/**
 * 调平台跑一轮。
 *
 * @param opts.skipDiary 不注入「最近写的日记」（2026-10-25）。
 *   说说（Qzone）必须用 —— 日记本身就是文艺腔，一旦注入，说说会变成
 *   "日记的续写"，出来就是「光挪到一寸」那种。发朋友圈和写日记是两件事。
 */
async function askPlatform(sessionId, text, imageParts, peer, opts = {}) {
  /*
   * 时间上下文（2026-10-21）：告诉模型"现在几点、距上次聊天多久"。
   * 拼在用户消息最前面而不是系统提示词 —— 平台的人格/系统提示词属于智能体配置，
   * 插件改不了，也不该改。
   */
  const isGroup = String(sessionId).includes(':group:');
  /*
   * 群聊时把"刚才群里在聊什么"一起给它（2026-10-21，方案 B）。
   *
   * 这是"自主"最便宜的实现：不改平台、不开端口、不做跨进程 RPC ——
   * 只是把模型需要判断的上下文补齐。配合 [SILENT]，它就能"看到但不接话"。
   */
  const groupBlock = isGroup ? groupContextBlock(peer) : '';
  // 对方是谁（2026-10-22）：没这段，系统提示词里的"我男朋友"对应不上任何东西
  const peerInfo = await peerBlock(peer, isGroup);
  const timePrefix = peerInfo + groupBlock + timeContext(peer, isGroup, opts, text);

  /*
   * 多模态消息：有图就用 `parts[]`（后端 `Message.content` 是 Object，两种形态都收）。
   * 纯文字仍传字符串 —— 少一层数组，历史上一直这么传，没必要改。
   */
  /*
   * 注入区与用户消息之间留一个空行（2026-10-25）。
   *
   * 原来直接 `timePrefix + text` 拼接，于是「【分寸】…不告诉任何人。你好呀」
   * 粘成一行。平台做会话摘要时取 user 消息前 120 字，抽到的全是注入的
   * 上下文（【现在】【你对他/她的印象】…），一条对话内容都没有。
   *
   * 平台侧已经加了剥除逻辑，这里补一个空行当双保险 —— 也让日志更可读。
   */
  /*
   * 图片类型说明（2026-10-26）。
   *
   * `opts.imageNote` 由调用方拼好（「【对方发来 1 张表情包】」这种），
   * 见 processMessage 里算 sub_type 的那段。
   *
   * 换成 `【】` 包裹还有第二个好处：平台做会话摘要时会按 `【…】` 剥掉
   * （SessionSummaryService.extractUserWords），不会把"发来 1 张表情包"
   * 当成对方说的话记进摘要。
   */
  const note = opts.imageNote || '';
  /*
   * 注入与用户消息**彻底分开**（2026-10-27）。
   *
   * <p><b>为什么必须分</b>：原来拼成一条 `timePrefix + text` 发过去，平台把整条
   * 存进 `message` 表。实测 353 条 user 消息平均 **1654 字**，而她的回复只有 154 字
   * —— 意味着**每条里有 1500 字是注入**（日期、印象、日记、分寸…），占了 83%。</p>
   *
   * <p>后果有两层：① 历史回放时这些**过期信息**被全部带回来，token 膨胀 4 倍；
   * ② 摘要抽到的全是噪音（已单独修过）。</p>
   *
   * <p><b>现在</b>：`messages` 只放用户原话（干净入库），注入走
   * `metadata.injectContext` —— 平台会把它拼进系统提示词给模型看，但**不写数据库**。</p>
   */
  const injectContext = [timePrefix.trim(), note.trim()].filter(Boolean).join('\n\n');
  const cleanContent = imageParts && imageParts.length > 0
    ? [
        { type: 'text', text: text || '（发来一张图片）' },
        /*
         * 必须带 mimeType（2026-11-02）。
         *
         * <p><b>不带会怎样</b>：平台侧 {@code m.get("mimeType")} 取不到值就兜底成
         * {@code image/png}，而 QQ 发来的图大多是 JPEG，上游直接 400 拒绝：</p>
         *
         * <pre>
         *   The declared image MIME type (image/png) does not match
         *   the actual image format (jpeg)
         * </pre>
         *
         * <p>表现是**带图的消息全部不回复**，纯文字正常 —— 很容易误判成"她又不理我"。</p>
         */
        ...imageParts.map((x) => ({ type: 'image', data: x.data, mimeType: x.mime })),
      ]
    : (text || '（发来一张图片）');

  const body = {
    agentId: cfg.agentId,
    sessionId,
    mode: 'agent',
    // 只有用户原话入库；注入走 metadata（平台拼进 systemPrompt，不落库）
    messages: [{ role: 'user', content: cleanContent }],
    metadata: {
      tenant_id: 'default',
      user_id: `qq-${stats.uin}`,
      injectContext,
    },
    /*
     * 历史轮数（2026-10-23）。
     *
     * 平台默认 `maxHistoryTurns = 10`（只带最近 20 条消息）—— 两天聊 78 条，
     * **前 58 条根本进不了上下文**，所以她"记不住前天说的"。消息其实都在
     * `message` 表里，只是没被带上来。
     *
     * 40 轮 ≈ 80 条，够覆盖两天的聊天；token 成本约 4k，可接受。
     */
    context: {
      /*
       * 历史轮数（2026-10-25 支持按调用覆盖）。
       *
       * 说说会话传 2 —— 它的历史全是"要不要发说说"的问答，越看越像在
       * 执行任务，出来的内容也一次比一次套路化。只保留最近两轮，
       * 相当于"独立想一条"。
       */
      /*
       * 原文轮数（2026-10-28 从 40 降到 12）。
       *
       * <p>记忆已经全在插件侧（`memory/facts.json` + `events.jsonl`），
       * 平台这边只需要给**最近 6 轮**原文保住语感（她刚说"嗯"，下一句别突然变腔调）。</p>
       *
       * <p>原来 40 轮 ≈ 4000 token，其中大部分内容插件已经用事实和事件记下来了 ——
       * 重复塞进上下文只是烧钱。</p>
       */
      maxHistoryTurns: Math.max(1, Number(opts.maxHistoryTurns || cfg.maxHistoryTurns) || 12),
      /*
       * 知识库检索（2026-10-28 关掉）。
       *
       * <p>这个 QQ 助手**没有知识库**，后端拿到 `knowledgeBaseIds=[]` 就直接
       * `return null`，从来没检索过任何东西 —— 开着只是让人误以为"RAG 在工作"。</p>
       */
      useRag: false,
    },
    /*
     * ★ 让模型能用平台的全部工具（2026-10-21）。
     *
    /*
     * 工具白名单（2026-11-02）。
     *
     * <p><b>原来写的是 {@code allowed: []}，平台把它解释成"不限制，全部可用"} ——
     * 于是全局 ToolRegistry 里的<b>所有</b>工具都进了她的可用列表，
     * 包括 {@code fs_read_file} / {@code fs_write_file} / {@code fs_grep} 这一整套文件工具。</p>
     *
     * <p><b>实测后果</b>：他说"给我拍张照片"，她在生图和写文件之间选错，
     * 去调 {@code fs_write_file} 写「新建 文本文档.txt」→ 触发审批 →
     * <b>整条消息阻塞 5 分钟</b>（平台 approval.blocking-timeout-seconds=300），
     * 表现就是"她突然不理人了"。</p>
     *
     * <p>现在只放她真的会用的六个 —— 名字要和平台里的 {@code TOOL_NAME} 完全一致：</p>
     * <ul>
     *   <li>{@code generate_image} —— builtin_image_gen</li>
     *   <li>{@code web_search} —— builtin_web_search</li>
     *   <li>{@code web_fetch}、{@code image_search}、{@code music_search}、
     *       {@code bilibili_hot} —— builtin_web_content 提供的四个</li>
     * </ul>
     *
     * <p><b>代价</b>：以后平台如果新加了她要用的工具，这里要同步加 ——
     * 表现是"模型说要用某个工具但没生效"。宁可这样，也不能让一个聊天角色
     * 有读写整台电脑的权限。</p>
     */
    tools: {
      enabled: true,
      allowed: [
        'generate_image',
        'web_search',
        'web_fetch',
        'image_search',
        'music_search',
        'bilibili_hot',
      ],
    },
    /*
     * ★ 纯文本渠道：**不要注入「输出格式」指引**（2026-10-20）。
     *
     * 平台默认会往系统提示词尾部拼一段"回复会按 Markdown 渲染，请用标题/列表/表格"，
     * 那是给网页对话用的。QQ 不渲染 Markdown，模型照做就成了 `**粗体**`、`- 列表`、
     * `| 表格 |` 一堆符号。
     *
     * 传 false 后**模型直接输出纯文本**，从源头不产生符号 ——
     * 比在下游用正则擦标记干净得多（擦掉符号的同时，表格结构也毁了）。
     * `stripMarkdown` 保留作为兜底（模型不听话时仍会漏几个）。
     */
    renderGuide: false,
  };
  const resp = await api.platform.request({
    path: '/api/v1/agent/run',
    method: 'POST',
    body,
  });
  // /agent/run 返回裸 JSON；不同版本可能包一层 data，两种都兼容
  const out = resp?.output ?? resp?.data?.output;
  /*
   * 记录本轮的工具调用（2026-10-21）：没有这条，"模型到底搜没搜"只能靠看回答猜。
   * `tools.enabled=true` 之后，模型可能先调 web_search / image_gen 再回答。
   */
  const calls = resp?.toolCalls ?? resp?.data?.toolCalls;
  if (Array.isArray(calls) && calls.length > 0) {
    diag(`toolCalls(${calls.length}): ${calls.map((c) => c.name || c.tool || c.toolName || '?').join(', ')}`);
    /*
     * 生图结果兜底（2026-10-28）：她经常忘了在回复里写 [发图]，直接从工具结果里捞。
     * 这是**能力性**的兜底，不是提示词问题 —— 提示词已经要求过，但不可靠。
     */
    if (typeof opts.onToolImages === 'function') {
      const imgs = toolCallImages(calls);
      if (imgs.length > 0) {
        diag(`toolCalls 里捞到 ${imgs.length} 张图（她没写 [发图]，由代码补发）`);
        opts.onToolImages(imgs);
      }
    }
    /*
     * 图片搜索的结果（2026-10-30）：交出去当"可存的表情素材"。
     *
     * 和生图不同 —— 搜到的图**不自动发**，只有她写 [存图 情绪] 才入库。
     * 让她能靠搜索自己攒表情，不用干等别人发。
     */
    if (typeof opts.onSearchImages === 'function') {
      const found = toolCallSearchImages(calls);
      if (found.length > 0) {
        diag(`toolCalls 里捞到 ${found.length} 张搜索图（可 [存图]）`);
        opts.onSearchImages(found);
      }
    }
  }
  const raw = (out?.content || '').trim();
  // QQ 显示不了 Markdown：转成纯文本再发（可关闭，见 stripMarkdown 配置）
  return cfg.stripMarkdown === false ? raw : stripMarkdown(raw);
}

// ------------------------------------------------------------------ 主流程

/**
 * 消息去重（2026-10-20）。
 *
 * <p>NapCat 若同时开了 HTTP 与 WS 上报（或重复建了连接），**同一条消息会到达两次** ——
 * 表现是机器人对一句话回两遍。按 `message_id` 记最近 200 条，重复的直接丢弃。
 * 用 Set 的插入顺序当 LRU：超限删最早那个即可。</p>
 */
const recentIds = new Set();
const RECENT_MAX = 200;

function isDuplicate(id) {
  if (id === undefined || id === null || id === '') {
    return false; // 没有 id 就无从判断，交给下游处理
  }
  const key = String(id);
  if (recentIds.has(key)) {
    return true;
  }
  recentIds.add(key);
  if (recentIds.size > RECENT_MAX) {
    recentIds.delete(recentIds.values().next().value);
  }
  return false;
}

/** 会话键（私聊按人、群聊按群）—— 窗口期与消息合并都按它分桶。 */
function sessionKeyOf(e) {
  return e.message_type === 'private' ? `p:${e.user_id}` : `g:${e.group_id}`;
}

/**
 * 窗口期桶：key → { timer, items: [{ text, images }], sample }
 *
 * 名字不能叫 `pending` —— 文件上方已有同名的 Map（存 OneBot 的 action 响应回调），
 * 重名会让整个模块 `SyntaxError: Identifier 'pending' has already been declared`，
 * 表现是"插件 main.js 未加载"。**改完必须 `node --check` 一遍**。
 */
const debounceBuckets = new Map();

async function onMessage(e) {
  if (isDuplicate(e.message_id)) {
    diag(`dup message_id=${e.message_id}（同一消息被上报多次，已忽略）`);
    return;
  }
  stats.received++;
  stats.lastAt = Date.now();
  diag(`recv type=${e.message_type} from=${e.user_id} group=${e.group_id || '-'} atme=${!!e.atme} text=${String(e.raw_message || '').slice(0, 60)}`);

  /*
   * 群聊上下文缓存（2026-10-21）：**在闸门之前**记下来。
   * 被闸门拦掉的消息（没 @ 我、不在白名单）同样是上下文的一部分 ——
   * 正因为我"看到了但没说话"，等真正被 @ 时才知道前因后果。
   */
  if (e.message_type === 'group') {
    const gid = Number(e.group_id);
    const line = quickText(e);
    if (line) {
      const name = (e.sender && (e.sender.card || e.sender.nickname)) || String(e.user_id || '');
      const buf = groupBuffer.get(gid) || [];
      buf.push({ sender: name, text: line.slice(0, 80), at: Date.now() });
      if (buf.length > GROUP_BUFFER_MAX) {
        buf.shift();
      }
      groupBuffer.set(gid, buf);
    }
  }

  const reason = gate(e);
  if (reason) {
    stats.skipped++;
    stats.lastSkipReason = reason;
    log('info', `跳过：${reason}`);
    diag(`skip: ${reason}`);
    return;
  }

  const { text, images } = await extractContent(e);   // 现在是 async（要查被引用的消息）
  if (!text && images.length === 0) {
    stats.skipped++;
    stats.lastSkipReason = '空消息';
    diag('skip: empty content');
    return;
  }

  /*
   * 记录「最近互动过的人」—— 主动发言只从这里挑，不主动找陌生人。
   *
   * 同时保留 `prevAt`（**这一条之前的**互动时间）：时间上下文里的"距上次聊天多久"
   * 必须用它，否则 `lastAt` 刚被本条消息刷新，永远是"刚刚"。
   */
  if (e.message_type === 'private') {
    const uid = Number(e.user_id);
    const prev = recentContacts.get(uid);
    recentContacts.set(uid, {
      lastAt: Date.now(),
      prevAt: prev ? prev.lastAt : 0,
      // 累计消息数：印象更新的触发条件之一（聊够 20 句才有总结的意义）
      count: (prev && prev.count ? prev.count : 0) + 1,
      isPrivate: true,
    });
    // 落盘（2026-10-23）：不落盘的话重启清零，印象永远攒不够 20 句
    saveRecentContacts();
  }

  enqueue(e, text, images);
}

/**
 * 进窗口期（2026-10-20）。
 *
 * <p>每收到一条就**重置计时**并把内容累积起来；安静满 `debounceSeconds` 才真正处理。
 * 对方连发三条时只回一次、且用的是**合并后的上下文** —— 逐条回三次是最典型的机器人行为。</p>
 */
function enqueue(e, text, images) {
  const key = sessionKeyOf(e);
  let bucket = debounceBuckets.get(key);
  if (!bucket) {
    bucket = { timer: null, items: [], sample: e };
    debounceBuckets.set(key, bucket);
  }
  bucket.items.push({ text, images });

  if (bucket.timer) {
    clearTimeout(bucket.timer);
    bucket.timer = null;
  }
  const wait = Math.max(0, Number(cfg.debounceSeconds || 0) * 1000);
  if (wait === 0) {
    void flush(key);
    return;
  }
  bucket.timer = setTimeout(() => void flush(key), wait);
  diag(`debounce ${wait}ms，已累积 ${bucket.items.length} 条`);
}

/** 窗口期到点：合并这一窗的所有消息，只处理一次。 */
async function flush(key) {
  const bucket = debounceBuckets.get(key);
  if (!bucket) {
    return;
  }
  debounceBuckets.delete(key);
  if (bucket.timer) {
    clearTimeout(bucket.timer);
  }
  const texts = bucket.items.map((i) => i.text).filter(Boolean);
  const images = bucket.items.flatMap((i) => i.images);
  if (texts.length > 1) {
    diag(`merged ${texts.length} messages: ${texts.join(' | ').slice(0, 100)}`);
  }
  /*
   * 合并后的呈现方式（2026-10-20 修正）。
   *
   * 直接用 `\n` 拼起来是不行的：实测发「你分别计算一下 / 1+1 / 2+2 / 给我答案」四条，
   * 模型只回答了最后一个 `2+2` —— 它把后面几行当成了同一段话的补充说明。
   * 加编号 + 一句括号说明，模型才会逐条对待。
   */
  /*
   * 合并成**一句话**（2026-10-21，用户建议）。
   *
   * 前三版（换行 / 编号 / `---` 分隔）都出现"只答最后一条"。差别可能不在"一条还是多条消息"
   * ——`messages` 一直只有一条 —— 而在**内容是多行**：多行更容易被模型当成"多个独立段落"，
   * 于是只处理最后一段。
   *
   * 这里把几条消息用中文逗号连成**一句话**（上一条已经以标点结尾就不重复补），
   * 模型看到的是一个完整请求，而不是若干段落。
   */
  const merged = joinAsOneSentence(texts);
  await processMessage(bucket.sample, merged, images);
}

/**
 * 把连续几条消息拼成**一句话**（2026-10-21）。
 *
 * <p>上一条已经以标点结尾就直接接上，否则补一个中文逗号 —— 避免出现 `1+1，给我答案`
 * 这种把两条独立句子硬粘起来的怪句子。空项（纯图片消息）会被跳过。</p>
 */
function joinAsOneSentence(texts) {
  let out = '';
  for (const t of texts) {
    const s = String(t || '').trim();
    if (!s) {
      continue;
    }
    if (!out) {
      out = s;
    } else if (/[。！？!?…~～,，、；;：:]$/.test(out)) {
      out += s;
    } else {
      out += '，' + s;
    }
  }
  return out;
}

/** 真正处理一轮（静默判断 / 概率 / 图片上传 / 调平台 / 发送）。 */
/**
 * 正在处理的请求数（2026-10-25）。
 *
 * <p>用来回答"现在能不能重启"：热重载在前一个请求还没走完时动手，
 * 会把这轮对话直接掐断 —— 用户体感是"我发了消息她没回"，
 * 而且没有任何错误提示（请求被中断，日志里停在 `call platform`）。</p>
 */
let busyCount = 0;

/** 包一层计数，让宿主能在重启前判断。 */
async function processMessage(e, text, images) {
  busyCount++;
  try {
    await processMessageInner(e, text, images);
  } catch (err) {
    /*
    * 兜底（2026-11-02 补）。
    *
    * <p>原来这里只有 try / finally，没有 catch —— 异常一路冒到 {@code flush}，
    * 而 flush 是 {@code void flush(key)} 调用的，于是变成 unhandled rejection，
    * <b>日志里一个字都不会留下</b>，看着就像"消息被吃了"。</p>
    *
    * <p>报错不发给用户，但必须落盘 —— 否则下次还查不出来。</p>
    */
    diag(`processMessage FAILED: ${err && err.message ? err.message : err}`);
  } finally {
    busyCount--;
  }
}

async function processMessageInner(e, text, images) {
  /*
   * 收到任何消息 → 追发计数归零（2026-10-26）。
   *
   * 她主动说过一句、然后对方回了（哪怕只回一个字），这条链就断了 ——
   * 不该过一会儿再补一句"你还在吗"。放在最前面：连管理命令也算"有回应"。
   */
  if (selfState.proactiveChain && selfState.proactiveChain.count > 0) {
    selfState.proactiveChain = { count: 0 };
    saveSelfState();
    diag('proactive: 收到回应，追发计数归零');
  }


  /*
   * 管理命令（2026-10-22）：整条消息就是 `/xxx` 时**拦下来，不发给模型**。
   *
   * 放在最前面（连"评价记录"也跳过）—— `/clear` 不该被当成"有人对她说了什么"。
   * 命令不经过模型：省钱、可靠、不受人格影响。
   */
  const cmd = parseCommand(text);
  if (cmd) {
    await handleCommand(cmd, e);
    return;
  }

  /*
   * `[看看表情]`（2026-10-25）：纯本地统计，**不调模型** —— 零 token。
   *
   * 她需要知道自己手上有哪些图，才能写出准确的 `[表情 难过]`；
   * 否则会反复要一个库里没有的情绪，最后退到通用图，表情和语境对不上。
   */
  if (/^\[看看表情\]$/.test(String(text || '').trim())) {
    const isP = e.message_type === 'private';
    const p = isP ? Number(e.user_id) : Number(e.group_id);
    diag('cmd: 看看表情');
    await humanSend(isP, p, stickerSummary());
    return;
  }

  /*
   * 先记下"别人怎么评价她"（2026-10-22）。
   *
   * 放在最前面、闸门之前：被限流或沉默期拦掉的消息，同样是"有人说她什么"，
   * 下次独处时她该知道。这一步只记录，不判断该不该改 —— 那留给她自己想。
   */
  if (text) {
    const who = (e.sender && (e.sender.card || e.sender.nickname)) || String(e.user_id || '');
    noteAboutSelf(text, who);
  }

  /*
   * 事件流（2026-10-24）：记下「别人跟她说了什么」。
   *
   * **主人说的不记** —— 不是事后过滤，是根本不写。所以事件流天然不含主人的隐私，
   * 给主人看绝对安全；别人也拿不到（只有 owner 的上下文会注入这段）。
   *
   * 位置在闸门之前：被限流、被沉默期拦掉的消息，同样是「有人来找过她」，
   * 主人有权知道。
   */
  if (text) {
    const evPrivate = e.message_type === 'private';
    const evPeer = evPrivate ? Number(e.user_id) : Number(e.group_id);
    /*
     * 私聊**全都记**，包括主人（2026-10-27 改）。
     *
     * <p>原来写成 `!isOwner(evPeer)` —— 主人说的话根本不进流。本意是"从源头杜绝泄露"，
     * 但代价是她对主人的记忆只能靠 20 轮历史和摘要，「你今天跟我说过什么」这类
     * 问题答不准。</p>
     *
     * <p><b>泄露风险没有变化</b>：事件流的注入仍然只有 `isOwner(peer)` 时才发生
     * （见 timeContext），所以别人的会话里**根本看不到这段** ——
     * 不是"看到了不说"，是"手里没有"。被动提问也一样问不出来。</p>
     *
     * <p><b>代价</b>：主人话多时会挤占 200 条上限，别人的事件留存时间变短。
     * 影响可接受（事件本来只留 24 小时）。</p>
     */
    /*
     * 事件流只记「别人对她说过什么」（2026-10-28 改回来）。
     *
     * <p>10-27 曾改成"私聊全记，包含主人"，为的是让她记得主人说过的话。
     * 但实测结果很糟：**114 条事件里全是主人自己的话**，然后被当成
     * 「今天**别人**跟你说过」注入给她 —— 语义完全错了。</p>
     *
     * <p>主人说过什么，现在由 `memory/facts.json`（抽取事实）和最近 6 轮原文承担，
     * 比塞进事件流更准、也不会串味。</p>
     */
    /*
     * 主人说的话也进事件流（2026-11-01）。
     *
     * <p>原来私聊时主人的话被整段排除，理由是"别让陌生人看到你俩聊了什么"。
     * 但副作用很硬：她手上**没有你的新话可用** —— 事件流停在 10-28，
     * 主动发言只能翻出四天前的「在干嘛」，还当成今天的事。</p>
     *
     * <p>现在改成 **都记、但用 kind 隔离**：
     * 主人的话写成 {@code kind:'owner'}，别人的话写成 {@code kind:'other'}。
     * 而 {@code eventBlock()}（给陌生人看的那段）只取 other ——
     * 所以陌生场景永远看不到你说过什么；{@code pickUntoldEvents()} 不看 kind，
     * 照样能拿来主动发言。</p>
     */
    const isOwnerMsg = evPrivate && isOwner(evPeer);
    const shouldLog = evPrivate ? true : cfg.eventLogGroup !== false;
    if (shouldLog) {
      const nick = (e.sender && (e.sender.card || e.sender.nickname)) || String(e.user_id || evPeer);
      /*
       * `kind` 统一写成 `other`（2026-10-28 修）。
       *
       * <p>原来写的是 `private` / `group`，而 `eventBlock` 只取 `kind === 'other'` ——
       * **新事件一条都显示不出来**，只有迁移过来的历史能看到。私聊/群聊的区分
       * 挪到 `scope` 字段。</p>
       */
      appendEvent({
        kind: isOwnerMsg ? 'owner' : 'other',
        scope: evPrivate ? 'private' : 'group',
        peer: String(evPeer),
        nick: String(nick).slice(0, 20),
        // CQ 码（图片、@）对阅读没意义，换成占位符再截断
        text: String(text).replace(/\[CQ:[^\]]+\]/g, '[图片/表情]').slice(0, 60),
      });
    }
  }

  /*
   * 成本护栏（N2）：每个会话每分钟最多 N 次模型调用。
   *
   * 按会话而不是全局：一个人刷屏不该把别人的正常对话饿死。
   * 被限流的消息**直接丢弃**（不排队）—— 排队会让风控更危险（积压后集中爆发）。
   */
  const rlKey = sessionKeyOf(e);
  if (!allowByRate(rlKey, Number(cfg.rateLimitPerMinute) || 0)) {
    stats.skipped++;
    stats.lastSkipReason = '限流';
    log('warn', `限流丢弃：${rlKey}`);
    diag(`skip: rate limited (${rlKey})`);
    return;
  }

  if (inSilence()) {
    stats.skipped++;
    stats.lastSkipReason = '静默期';
    log('info', '跳过：静默期');
    diag('skip: silence window');
    return;
  }

  const prob = e.message_type === 'private' ? Number(cfg.replyPrivate) : Number(cfg.replyGroup);
  if (Math.random() > prob) {
    stats.skipped++;
    stats.lastSkipReason = `概率未命中（${prob}）`;
    log('info', `跳过：回复概率 ${prob}`);
    diag(`skip: probability ${prob}`);
    return;
  }

  if (!cfg.agentId) {
    stats.lastError = '未配置 agentId';
    log('warn', '未配置 agentId，无法调用平台');
    return;
  }

  /*
   * 图片**不再上传换 fileId**，直接内联进请求体（2026-11-03）。
   *
   * <h3>为什么改</h3>
   *
   * <p><b>旧链路</b>：每收到一张图 → POST /api/v1/files/base64 换成 fileId
   * → 平台再 download 回来 → 转 base64 给模型。</p>
   *
   * <p><b>代价</b>：每一张聊天里的图都落进平台的 {@code file_asset} 表，
   * 「文件」管理页被 {@code qq-*.png} 堆满，而且**没有任何清理任务**。
   * 这些图只是"给模型看一眼"的临时载体，不是用户的文件资产。</p>
   *
   * <p><b>改法</b>：多模态协议本来就支持直接内联 base64
   * （OpenAI 的 image_url 可放 data URL，Anthropic 的 source.type=base64）。
   * 平台侧已同步支持：part 里带 {@code data} 就直接用，没有才回退 fileId。</p>
   *
   * <p><b>额外收益</b>：少一次上传 + 一次下载的 HTTP 往返，带图消息的延迟下降。</p>
   *
   * <p>上限仍是 3 张，避免 token 与带宽失控。</p>
   */
  const imageParts = [];
  /**
   * 本轮收到的**表情**（sub_type=1）的 base64（2026-10-25）。
   *
   * <p>等模型回复后再落盘 —— 她可能在这轮回复里写 `[存图 难过]` 指定情绪，
   * 那就存成 `难过_001.gif`；没写就存「通用」。</p>
   *
   * <p><b>不受 visionEnabled 影响</b>：关掉"看图"只是不把图喂给模型，
   * 收藏表情这件事仍然该做 —— 否则用户一关视觉，表情库就再也长不大。</p>
   */
  const pendingStickers = [];
  if (images.length > 0) {
    diag(`images=${images.length} vision=${cfg.visionEnabled !== false}`);
    for (const img of images.slice(0, 3)) {
      const got = await fetchImageBase64(img);
      if (!got) {
        continue;
      }
      // 只收私聊里的表情（群里的斗图会把库灌爆）
      if (img.subType === 1 && e.message_type === 'private') {
        pendingStickers.push(got.base64);
      }
      if (cfg.visionEnabled === false) {
        continue;   // 不看图，就不带进请求体了
      }
      imageParts.push({ data: got.base64, mime: got.mime });
      // 留一份原图：她后来说"换这张"时要用
      lastReceivedImage = { base64: got.base64, mime: got.mime, at: Date.now() };
      diag(`image inline size=${Math.round(got.base64.length / 1024)}KB mime=${got.mime}`);
    }
  }

  const isPrivate = e.message_type === 'private';
  const peer = isPrivate ? Number(e.user_id) : Number(e.group_id);

  /*
   * 长期记忆定期整理（2026-11-01，2026-11-02 修位置）。
   *
   * <p><b>为什么必须放在这里</b>：原来这段写在函数最开头，而它调用的
   * {@code refreshCarryover(peer)} 需要一个 {@code peer} 变量 —— 那个变量
   * 到这里才用 {@code const} 声明。放在前面就是 TDZ，
   * 一执行就 {@code ReferenceError: Cannot access 'peer' before initialization}。</p>
   *
   * <p>而且它只在 {@code turnsSinceCarryover} 攒到 80 的那一轮才进分支，
   * 所以前 79 轮都正常 —— 到第 80 轮突然整条消息不回复，日志里什么都没有。
   * 排查了很久才定位到。</p>
   *
   * <p>整理要调一次模型（2~5 秒），所以 fire-and-forget，不挡回复。</p>
   */
  selfState.turnsSinceCarryover = (selfState.turnsSinceCarryover || 0) + 1;
  if (selfState.turnsSinceCarryover >= 80 && !carryoverRefreshing) {
    carryoverRefreshing = true;
    selfState.turnsSinceCarryover = 0;
    saveSelfState();
    void refreshCarryover(peer).finally(() => {
      carryoverRefreshing = false;
    });
  }
  /*
   * 每个联系人 / 每个群独立会话 —— 否则 A 群的上下文会跑到 B 群。
   *
   * `:e<N>` 是**会话版本**（2026-10-22）：`/clear` 之后 N+1，平台就把这当成全新会话，
   * 之前的历史一条都不会带进提示词。旧消息仍留在库里（要查还能查），只是不再参与对话。
   */
  const epoch = sessionEpochOf(peer);
  const sessionId = (isPrivate
    ? `qq:private:${stats.uin}:${peer}`
    : `qq:group:${stats.uin}:${peer}`) + (epoch > 0 ? `:e${epoch}` : '');

  try {
    /*
     * 想的时候就让对方看见（2026-10-22）。
     *
     * 模型要 5~10 秒才吐完，这段时间如果不亮"正在输入"，对方屏幕上一片死寂 ——
     * 而真人收到消息一两秒就会亮输入状态，然后才发出第一条。
     */
    await setTyping(isPrivate, peer, true);
    log('info', `调平台：${sessionId}`);
    diag(`call platform agentId=${cfg.agentId} session=${sessionId}`);
    /*
     * 告诉模型「这是表情包，还是普通图片」（2026-10-26）。
     *
     * `sub_type` 只有 QQ 协议里有：**0 = 普通图片（照片、截图），
     * 1 = 表情**（收藏表情 / 斗图用的那种）。之前这个字段只用来决定
     * "要不要收进表情库"，**没有传给模型** —— 于是她只看到一张图，
     * 分不清"这人在用表情代替说话"和"这人在给我看一张照片"，
     * 回应的方式却完全一样。
     */
    let imageNote = '';
    if (images.length > 0) {
      const stickers = images.filter((i) => i.subType === 1).length;
      const photos = images.length - stickers;
      const parts = [];
      if (photos > 0) {
        parts.push(`${photos} 张图片`);
      }
      if (stickers > 0) {
        parts.push(`${stickers} 张表情包`);
      }
      imageNote = `【对方发来 ${parts.join('、')}】`;
    }
    // 记下"他刚说了什么"（2026-10-27）：主动发言时要用这一行当锚点
    rememberTurn(peer, 'user', text);
    /*
     * 抽一下这句话里「关于他自己的事实」（2026-10-28）。
     *
     * 纯规则匹配、零 token、不调模型。抽到就写 facts.json，下一轮开始生效。
     * 宁可漏 —— 抽错了她会当真，比记不住更糟。
     */
    rememberFacts(peer, text);
    /*
     * 互道晚安后不再回复（2026-10-31）。
     *
     * 放在 rememberFacts 之后、调模型之前：她仍然"记得"对方说了晚安
     * （已写进 tail 与 facts），但这一轮不接话。
     */
    /*
     * 沉默判断（2026-10-31 扩展）。
     *
     * 规则只判三类能确定的：互道晚安、纯标点、重复消息。
     * 其余（附和、话题结束、是不是在跟别人说话）规则判不准，交给模型 ——
     * 提示词里已经列了 7 种该沉默的场景。
     */
    const silentReason = shouldStaySilent(peer, text, e.message_type === 'private');
    if (silentReason) {
      diag(`skip: ${silentReason}，不回复`);
      return;
    }
    /*
     * 情绪事件（2026-10-27）。
     *
     * 先记"有人来找你了"（凡是收到消息都算），再看这条消息本身就什么性质 ——
     * 被夸、被命令、被敷衍，会在基础上再叠一层。
     *
     * 放在调平台之前：这一轮生成时她就已经是更新后的心情了。
     */
    applyAffect('incoming');
    const affectEv = detectAffectEvent(text);
    if (affectEv) {
      applyAffect(affectEv);
    }
    /*
     * 收集本轮工具生成的图片（2026-10-28）。
     *
     * 她调用 generate_image 后经常忘了写 [发图] —— 图生成了、地址也有，
     * 对面却只收到文字。这里从 toolCalls 里直接捞，不再依赖她记得。
     */
    const toolImages = [];
    /*
     * 本轮 image_search 搜到的图（2026-10-30）。只在她说 [存图 情绪] 时入库 ——
     * 搜索是找素材，不该自动往库里灌。让她能自己攒表情，不用干等别人发。
     */
    const searchImages = [];
    let answer = await askPlatform(sessionId, text, imageParts, peer, {
      imageNote,
      onToolImages: (urls) => toolImages.push(...urls),
      onSearchImages: (urls) => searchImages.push(...urls),
      });
    /*
     * 剥离思考标记（2026-10-30）。
     *
     * <p><b>实测问题</b>：思考模型（DeepSeek-V3.1 / 通义 enable_thinking）偶尔会把
     * {@code </think>} 写进 content 里，被原样发到 QQ。用户收到的原话是：</p>
     * <pre>
     *   嗯。亲一下。
     *   [表情 开心]&lt;/think&gt;[表情 开心]
     * </pre>
     *
     * <p><b>为什么只删标签、不删它前面的内容</b>：{@code </think>} 可能出现在
     * **正文中间**（这一例就是这样），按"删到标签为止"处理会把整段正文丢掉。
     * 所以只清标记本身，前面的字一个不动。</p>
     */
    const beforeStrip = String(answer || '');
    answer = beforeStrip.replace(/<\/?think>/gi, '');
    if (answer !== beforeStrip) {
      diag(`strip think 标记：${beforeStrip.length} → ${answer.length} 字符`);
    }
    /*
     * 剥离「混进正文的英文思考链」（2026-10-30）。
     *
     * <p><b>实测</b>：发了一张图之后，她的 content 变成了：</p>
     * <pre>
     *   [表情 开心]" — a leaked tag. He didn't mention it. Should I react?
     *   Hmm, it's visible. Maybe don't dwell.
     *
     *   I should respond in character: a bit flustered...
     * </pre>
     *
     * <p>这是模型的**内心独白**，但它走的是 {@code content} 而不是
     * {@code reasoning_content} —— 平台侧 {@code extractReasoning} 分不开，
     * 只能在这里清。</p>
     *
     * <p><b>为什么用"特征词计数"而不是"见到英文就砍"</b>：她正常也可能回英文
     * （用户说英语时）。只有出现 3 个以上**第一人称思考用词**、
     * 且正文里还有中文，才判定为思考泄露。</p>
     */
    answer = stripLeakedThinking(answer);
    /*
     * 中文元推理（2026-11-02）。
     *
     * 英文那条（上面）只认 I should / Maybe 这类特征词，中文的「按规则…」
     * 「可以回短一句」完全不匹配 —— 实测就这样把一整段内心独白发到了 QQ。
     */
    answer = stripMetaThinking(answer);
    /*
     * 记录回复**原文前 80 字**：只看长度无法判断"为什么只答了一题"或"漏了哪个符号"，
     * 每次都要回头问用户截图，效率太低。
     */
    diag(`platform replied len=${answer ? answer.length : 0} preview=${JSON.stringify((answer || '').slice(0, 80))}`);
    if (!answer) {
      log('warn', '平台返回空内容，跳过发送');
      diag('skip: platform returned empty');
      return;
    }
    // 记下"她刚说了什么"（2026-10-27）—— 用模型原文，标记还没剥的那种
    // 因为下一次主动发言时她需要看到的是"自己当时说了什么"
    rememberTurn(peer, 'assistant', answer);

    /*
     * 潜水（2026-10-21）：模型可以决定"这句话我不接"。
     *
     * 这是"自主"最核心的那部分 —— 群里 50 条闲聊，真人只回 1 条。
     * 判据很严：只有**整条回复就是 `[SILENT]`** 才算；说了别的话再带标记照常发。
     */
    if (isSilent(answer)) {
      stats.skipped++;
      stats.lastSkipReason = '模型选择不接话';
      log('info', '模型选择不接话（[SILENT]）');
      diag('skip: model chose [SILENT]');
      return;
    }

    /*
     * 图库（2026-10-21）：模型在回复里写了 `[收藏 理由]` → 把这条消息里的图存进她的相册。
     * 决定权在模型，不在代码 —— 参考同类项目那句"意义不在图，在于她挑"。
     */
    const collected = extractCollect(answer);
    if (collected.reason && images.length > 0) {
      const got = await fetchImageBase64(images[0]);
      if (got) {
        saveToGallery(got.base64, collected.reason);
      }
    }
    let body = (collected.text || '').trim();

    /* 说说（F9）：模型写了 `[说说 内容]` → 发动态（受开关与冷却约束） */
    const qz = extractQzone(body);
    body = qz.text;
    if (qz.content) {
      await tryPostQzone(qz.content);
    }

    /*
     * 自己挑好就直接换上（2026-10-22 恢复）。
     *
     * 这是"她自己换头像"的主路径：搜到/画到满意的 → 直接换，不用发给对方看，
     * 也不用等对方确认。早上测试时就是通的，后来被我改成了两步，反而断了。
     */
    const avatarSet = extractSetAvatar(body);
    body = avatarSet.text;
    if (avatarSet.url) {
      await trySetAvatarFromUrl(avatarSet.url);
    }

    /*
     * 换这张（2026-10-22）：对方直接发了一张图让她换上。
     *
     * 与 `[想换头像]` 的区别：那个是"我想去看看"（她自己去搜/画），
     * 这个是用**对方刚发的那张**。决定权仍在她 —— 要她主动写标记才算数，
     * 不喜欢完全可以直说。
     */
    const useThis = extractUseReceivedImage(body);
    body = useThis.text;
    if (useThis.use) {
      await tryUseReceivedAvatar();
    }

    /*
     * 想换头像（2026-10-22 改）：她**不再能**靠对方给个地址就直接换上。
     *
     * 这个标记只表达"我想去看看有没有更合适的"，插件收到后触发一次自我检视：
     * 她自己定画面、自己搜/画、自己用三问评估，最后**由她决定换不换**。
     * 完全可能看完觉得"现在这个挺好的"，那就什么都不换 —— 这正是想要的行为。
     *
     * 用 `void` 不 await：自我检视要调模型、还要搜图/画图，几十秒起步，
     * 不能把这条回复卡住。
     */
    const avatarIntent = extractAvatarIntent(body);
    body = avatarIntent.text;
    if (avatarIntent.intent) {
      if (avatarIntent.url) {
        // 带了地址 → 她已经挑好了，直接换上（不用再走一遍检视）
        await trySetAvatarFromUrl(avatarIntent.url);
      } else {
        // 没带地址 → 她还没挑，触发一次检视让她自己去看
        void maybeSelfManage({
          forceCheck: true,
          reason: '有人跟你提到了头像的事（可能是让你换，也可能只是随口评价）。',
        });
      }
    }

    /*
     * 改昵称 / 签名（2026-10-22）：心跳不再定时问这件事，改成她自己真觉得该换时写标记。
     *
     * 放在换头像之后、发图之前 —— 都是"剥离标记 + 执行副作用"，顺序无所谓，
     * 但每条都必须把标记从正文里去掉，否则会被原样发出去。
     */
    const profileEdit = extractProfileEdit(body);
    body = profileEdit.text;
    if (Object.keys(profileEdit.patch).length > 0) {
      await tryEditProfile(profileEdit.patch);
    }

    /*
     * 待办（2026-10-22）：她说了"等下找你""明天再问"这类话时记一笔。
     *
     * 不设定时器 —— 自我检视（2~6 小时）时把未完成的列给她，她自己决定做不做。
     * 这样她保有"忘了"的权利，也不会有闹钟式的突兀主动。
     */
    const todoMark = extractTodo(body);
    body = todoMark.text;
    if (todoMark.todo) {
      appendTodo({ at: Date.now(), peer, text: todoMark.todo, done: false });
      diag(`todo: 记下「${todoMark.todo}」`);
    }

    /* 发图：模型写了 `[发图 关键词]` → 从她自己的相册里挑一张发出去 */
    const sendImg = extractSendImage(body);
    body = sendImg.text;

    if (!body && sendImg.keyword === null) {
      // 只做了收藏/说说，没有正文：不必再发一条空消息
      stats.replied++;
      diag('side-effect only, nothing to send');
      return;
    }
    /*
     * 收表情（2026-10-25）。
     *
     * 别人发来的 `sub_type=1` 表情在这轮末尾落盘：
     *   · 她写了 `[存图 难过]` → 存成 `难过_001.gif`
     *   · 没写（或写了个不认识的词）→ 存成 `通用_001.gif`
     * 不带时间戳，方便用户之后手动改前缀分类。
     *
     * 放在 `if (body)` 之前：即使这轮她没说话（只做了收藏之类），
     * 收到的表情也该进库。
     */
    /*
     * 收表情（2026-10-25，2026-10-30 扩展为两个来源）。
     *
     * <p>① 别人发来的表情（仅私聊、subType=1）→ 没写 `[存图]` 也存「通用」；</p>
     * <p>② 本轮 `image_search` 搜到的图 → **只有明确写了 `[存图 情绪]` 才存**。
     * 搜索是找素材，自动灌库会塞进一堆不相关的图。</p>
     *
     * <p>注意：`extractSaveSticker` 会**从正文里删掉标记**，所以无论有没有素材
     * 都必须调用一次 —— 否则 `[存图 难过]` 会被原样发到 QQ。</p>
     */
    const saveMark = extractSaveSticker(body || '');
    body = saveMark.text;
    if (saveMark.mood || pendingStickers.length > 0) {
      const mood = saveMark.mood || '通用';

      // ① 收到的：原有逻辑，没写标记也存通用
      for (const b64 of pendingStickers) {
        saveStickerToPool(b64, mood);
      }

      // ② 搜到的：必须明确指定情绪才存
      if (saveMark.mood && searchImages.length > 0) {
        let saved = 0;
        for (const u of searchImages) {
          const got = await fetchImageBase64(u);
          if (got && saveStickerToPool(got.base64, mood)) {
            saved++;
          }
        }
        diag(`sticker: 搜索图存入 ${saved}/${searchImages.length} 张，情绪=${mood}`);
      } else if (searchImages.length > 0) {
        diag(`sticker: 搜到 ${searchImages.length} 张图但她没说存哪个情绪，跳过`);
      }

      if (pendingStickers.length > 0) {
        diag(`sticker: 收到 ${pendingStickers.length} 张表情，情绪=${mood}`);
      }
    }

    /*
     * 先把工具生成的图归档到本地，**再**发（2026-10-28）。
     *
     * 顺序不能反：OSS 链接会过期（实测 403）、QQ 发送也可能失败。
     * 先落盘，图就丢不了 —— 之后她可以说 [发图 最近] 补发，
     * 不用重画（重画要 55 秒，而且可能是另一张脸）。
     */
    if (toolImages.length > 0) {
      const saved = [];
      for (const u of toolImages) {
        const name = await archiveGenImage(u);
        if (name) {
          saved.push(name);
        }
      }
      diag(`gen-image 归档 ${saved.length}/${toolImages.length} 张`);
    }

    if (body) {
      // 把工具生成的图一起交给发送层：她没写 [发图] 也能发出去
      await humanSend(isPrivate, peer, body, { toolImages });
    }
    if (sendImg.keyword !== null) {
      /*
       * `[发图 xxx]` 现在支持两种来源（2026-10-21）：
       *   · 以 http(s) 开头 → **直接发这张网络图**（搜索结果里的候选图就是这种方式发出去的）
       *   · 其它 → 当关键词，去她自己的相册里找
       *
       * 之前只能发相册图，所以模型说"你帮我掌个眼"时**一张图都发不出来** ——
       * 它选了图却没有渠道给对方看。
       */
      /*
       * 统一交给 sendImageByMark（2026-11-02）。
       *
       * <p><b>原来的 bug</b>：这里内联了一份发图逻辑，只有"http 开头 → 下载"
       * 和"其它 → 去相册按 reason 搜关键词"两种情况，**没有"最近"分支**。</p>
       *
       * <p>于是她说 {@code [发图 最近]} 时走的是 {@code pickGalleryImage('最近')} ——
       * 去相册里找 reason 含"最近"的图，当然找不到，日志只有一行
       * {@code gallery: 没有匹配「最近」的图}，图就没发出去。</p>
       *
       * <p>{@code sendImageByMark} 里有专门的 {@code /^(最近|上一张|刚才那张|latest)$/}
       * 分支（取归档目录最新一张），复用即可。</p>
       */
      await sendImageByMark(isPrivate, peer, sendImg.keyword);
    }
    stats.replied++;
    diag(`sent ok -> ${peer}`);
  } catch (err) {
    stats.lastError = err.message || String(err);
    log('error', `处理失败：${stats.lastError}`);
    diag(`ERROR ${stats.lastError}`);
  } finally {
    /*
     * 兜底关掉「正在输入」。走静默（[SILENT]）、只执行副作用、或中途抛异常时，
     * humanSend 根本不会执行 —— 不在这里关，对方那边会一直显示"正在输入"。
     */
    await setTyping(isPrivate, peer, false);
    /*
     * 发完之后再补几次关闭（2026-10-25 加强）。
     *
     * <p><b>为什么补这么多次</b>：NapCat 的「正在输入」是靠 `event_type:1`
     * 每 4~5 秒续期维持的，`event_type:0` 只是**停止续期**、并非立即清除。
     * 所以真正的"消失"要等自然过期 —— 但如果哪那次 `0` 丢了，
     * 状态会一直亮到下一次对话。</p>
     *
     * <p>1.2 / 3.5 / 7 秒各关一次，覆盖整个过期窗口，成本可忽略。</p>
     */
    for (const delay of [1200, 3500, 7000]) {
      setTimeout(() => {
        setTyping(isPrivate, peer, false).catch(() => {});
      }, delay);
    }
  }
}

/**
 * 从本地表情库里挑一张（2026-10-20，P2）。
 *
 * <p>文件名即标签：`开心_01.png` / `无语_02.jpg` 这样，按回答里的情绪词优先匹配，
 * 匹配不到就从全部里随机 —— 没有标签的目录也能用，只是"随机发表情"。</p>
 *
 * <p>返回 base64（不返回路径）：图片要在 `utilityProcess` 里读出再发给 NapCat，
 * 而 NapCat 对**本机绝对路径**的访问受它的运行身份限制（Docker 部署时根本读不到宿主路径）。</p>
 */
// ------------------------------------------------------------------ 表情库（2026-10-25）

/**
 * 表情库的情绪标签。
 *
 * <p>她标的时候只认这几个；写了别的（或没写）一律归到「通用」——
 * 不然目录里会散出几十种奇怪的前缀。</p>
 */
const STICKER_MOODS = ['开心', '无语', '难过', '生气', '通用'];

/** 去重索引：md5 → 文件名。同一张图不会存两次。 */
function stickerIndexPath() {
  return cfg.stickerDir ? path.join(cfg.stickerDir, '.index.json') : '';
}

function readStickerIndex() {
  try {
    return JSON.parse(fs.readFileSync(stickerIndexPath(), 'utf8')) || {};
  } catch {
    return {};
  }
}

function writeStickerIndex(obj) {
  try {
    fs.writeFileSync(stickerIndexPath(), JSON.stringify(obj, null, 2), 'utf8');
  } catch (e) {
    diag(`sticker index save failed: ${e.message}`);
  }
}

/**
 * 从字节头猜图片格式（2026-10-25）。
 *
 * <p>QQ 表情的 `file` 字段常常没有可靠扩展名，靠内容判断比靠文件名叫谱。
 * 认不出来就当 gif —— QQ 表情绝大多数是 gif。</p>
 */
function sniffImageExt(buf) {
  if (buf.length >= 12) {
    if (buf[0] === 0x89 && buf[1] === 0x50) {
      return 'png';
    }
    if (buf[0] === 0xff && buf[1] === 0xd8) {
      return 'jpg';
    }
    if (buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46) {
      return 'gif';
    }
    if (buf[0] === 0x52 && buf[1] === 0x49 && buf[8] === 0x57) {
      return 'webp';
    }
  }
  return 'gif';
}

/**
 * 存一张表情进库（2026-10-25）。
 *
 * <p><b>命名</b>：`{情绪}_{三位序号}.{ext}`，如 `开心_001.gif`。</p>
 *
 * <p>**故意不带时间戳** —— 用户要手动分类，`开心_20261025_143022.gif` 读起来太长；
 * 序号在同一情绪下递增，改前缀就能重新归类（`通用_003` → `难过_003`）。</p>
 *
 * <p>靠 md5 去重：同一张图（哪怕改了名）不会存第二次。</p>
 *
 * @returns 存下的文件名；重复或失败返回 null
 */
function saveStickerToPool(base64, mood) {
  const dir = cfg.stickerDir;
  if (!dir || !base64) {
    return null;
  }
  const buf = Buffer.from(base64, 'base64');
  if (buf.length === 0) {
    return null;
  }
  const hash = crypto.createHash('md5').update(buf).digest('hex');
  const index = readStickerIndex();
  if (index[hash]) {
    diag(`sticker skipped: 已经存过了（${index[hash]}）`);
    return null;
  }

  const label = STICKER_MOODS.includes(mood) && mood !== '通用' ? mood : '通用';
  const ext = sniffImageExt(buf);
  let max = 0;
  try {
    const prefix = `${label}_`;
    for (const f of fs.readdirSync(dir)) {
      if (!f.startsWith(prefix)) {
        continue;
      }
      const m = f.match(/_(\d+)\./);
      if (m) {
        max = Math.max(max, Number(m[1]));
      }
    }
  } catch {
    /* 目录还不存在，下面 mkdir 兜住 */
  }
  const name = `${label}_${String(max + 1).padStart(3, '0')}.${ext}`;
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, name), buf);
    index[hash] = name;
    writeStickerIndex(index);
    diag(`sticker saved: ${name} (${Math.round(buf.length / 1024)}KB)`);
    return name;
  } catch (e) {
    diag(`sticker save failed: ${e.message}`);
    return null;
  }
}

/**
 * 从回复里抽 `[存图 开心]` / `[存图]`（2026-10-25）。
 *
 * <p>不写也会存（默认「通用」）—— 提示词里只是鼓励她顺手标一下，
 * 标了以后抽图更准。</p>
 */
function extractSaveSticker(text) {
  const raw = String(text || '');
  const m = raw.match(/\[存图[：:\s]*([^\]]{0,10})\]/);
  if (!m) {
    return { text: raw, mood: null, intent: false };
  }
  return {
    text: raw.replace(m[0], '').trim(),
    mood: (m[1] || '').trim(),
    intent: true,
  };
}

/** 从回复里抽 `[表情 开心]` —— 她要主动发一张。 */
function extractSendSticker(text) {
  const raw = String(text || '');
  const m = raw.match(/\[表情[：:\s]*([^\]]{0,10})\]/);
  if (!m) {
    return { text: raw, mood: null };
  }
  return { text: raw.replace(m[0], '').trim(), mood: (m[1] || '').trim() };
}

/** `[看看表情]` 的回答：库里各情绪各有几张（纯本地统计，不调模型）。 */
function stickerSummary() {
  const dir = cfg.stickerDir;
  if (!dir) {
    return '表情库还没配目录。';
  }
  let files = [];
  try {
    files = fs.readdirSync(dir).filter((f) => /\.(png|jpe?g|gif|webp)$/i.test(f));
  } catch {
    return '表情库目录读不到。';
  }
  if (files.length === 0) {
    return '表情库里还一张都没有。';
  }
  const count = {};
  for (const f of files) {
    const m = f.match(/^([^_]+)_/);
    const label = m ? m[1] : '通用';
    count[label] = (count[label] || 0) + 1;
  }
  const parts = Object.entries(count).map(([k, v]) => `${k} ${v} 张`);
  return `表情库共 ${files.length} 张：${parts.join('，')}`;
}

/**
 * 库里**实际可用**的情绪标签（2026-10-30）。
 *
 * <p><b>为什么需要</b>：提示词原来硬编码「（或 无语 / 难过 / 生气）」，
 * 但库里只有 `惊讶 / 无语 / 赞同` 三类 —— 她严格照着提示词写了
 * {@code [表情 开心]}，结果 {@code pickSticker} 找不到、通用图也没有，
 * 最后**一声不响什么都没发**。日志原话：</p>
 * <pre>
 *   sticker: 库里没有「开心」也没有通用图，这次不发
 * </pre>
 *
 * <p>所以情绪列表必须**从实际文件名推**，不能写死。</p>
 */
function stickerMoods() {
  const dir = cfg.stickerDir;
  if (!dir) {
    return [];
  }
  try {
    const files = fs.readdirSync(dir).filter((f) => /\.(png|jpe?g|gif|webp)$/i.test(f));
    const set = new Set();
    for (const f of files) {
      const m = f.match(/^([^_]+)_/);
      // 只有 "xxx_001.png" 这种才认；没下划线的当作通用
      set.add(m ? m[1] : '通用');
    }
    return [...set];
  } catch {
    return [];
  }
}

function pickSticker(moodWords) {
  const dir = cfg.stickerDir;
  if (!dir) {
    return null;
  }
  let files = [];
  try {
    files = fs.readdirSync(dir).filter((f) => /\.(png|jpe?g|gif|webp)$/i.test(f));
  } catch (e) {
    diag(`sticker dir unreadable: ${e.message}`);
    return null;
  }
  if (files.length === 0) {
    return null;
  }
  /*
   * 优先「指定情绪」的图，退到「通用」，最后才全池随机（2026-10-25 收窄）。
   *
   * 原先是"没匹配到就全池随机" —— 她说想要"难过"的图，库里没有时随手丢一张
   * 哈哈笑的表情，比不发更糟。现在只退到通用池。
   */
  const tagged = moodWords.length
    ? files.filter((f) => moodWords.some((w) => f.includes(w)))
    : [];
  const generic = files.filter((f) => f.startsWith('通用_'));
  const pool = tagged.length > 0 ? tagged : generic;
  if (pool.length === 0) {
    return null;
  }
  const file = path.join(dir, pool[Math.floor(Math.random() * pool.length)]);
  try {
    return fs.readFileSync(file).toString('base64');
  } catch (e) {
    diag(`sticker read failed: ${e.message}`);
    return null;
  }
}

/**
 * 文本转语音（2026-10-20，P2）。
 *
 * <p>为什么插件自己调而不复用平台的 TTS 插件：**插件之间不能互相调用工具**，
 * 架构上也不该让一个插件依赖另一个插件（会被卸载、会被停用）。
 * 所以 TTS 的地址与密钥属于本插件自己的配置。</p>
 *
 * <p>返回 mp3 的 base64；未配置或失败返回 null（**静默退化为纯文本**，
 * 绝不能因为"语音发不出来"让整轮回复丢掉）。</p>
 */
/**
 * GPT-SoVITS 本地推理（2026-10-23）。
 *
 * <p>走它的 `api_v2.py`（默认 `127.0.0.1:9880`），端点是 `/tts`。
 * **不是 OpenAI 格式** —— 要传参考音频路径和参考文本，这是 zero-shot 克隆的特征：
 * 它靠那段音频的音色来合成，不需要"模型名"。</p>
 *
 * <p>参考音频 3~10 秒最佳（太长反而稀释音色），要干净、无背景音。
 * 参考文本必须和音频内容**逐字一致**，否则音色会飘。</p>
 */
async function ttsGptSoVits(text) {
  /*
   * GPT-SoVITS 的地址用**独立字段**（2026-11-01）。
   *
   * <p>原来它和云端 TTS 共用 {@code ttsBaseUrl}，于是两个地址只能填一个 ——
   * 填了 9880，qwen-tts 就会跑去 9880 要 /audio/speech，短句退回时直接失败。</p>
   */
  const base = String(cfg.ttsSovitsBaseUrl || 'http://127.0.0.1:9880').replace(/\/+$/, '');
  const ref = String(cfg.ttsRefAudio || '').trim();
  const refText = String(cfg.ttsRefText || '').trim();
  if (!ref) {
    diag('tts(gpt-sovits): 没配参考音频路径（ttsRefAudio）');
    return null;
  }
  /*
   * 短文本退回默认 TTS（2026-11-01）。
   *
   * <p><b>实测</b>：同一个模型、同一段参考音频，只有目标文本长度在变：</p>
   * <pre>
   *   "今天好累啊，你吃了吗"  → 3.38 秒  正常
   *   "今天好累啊。"          → 2.06 秒  正常
   *   "今天好累啊"            → 1.02 秒  偏短
   *   "躺着"                 → 0.98 秒  像一声
   * </pre>
   *
   * <p>GPT-SoVITS 照着参考音频的节奏生成，**目标文本太短就"读完即止"** ——
   * 而她的回复大量是「躺着」「嗯」这种两三个字的短句。</p>
   *
   * <p>短于 {@code ttsMinChars}（默认 8）时返回 null，交给上层退回默认 TTS。
   * 填 0 = 不做限制。</p>
   */
  /*
   * 默认 8，不是 0（2026-11-02 修）。
   *
   * <p><b>原来的 bug</b>：写的是 {@code cfg.ttsMinChars || 0}。
   * 而 {@code ttsMinChars} 是后加到 manifest 的，老配置里没有这个键 ——
   * 于是 {@code undefined || 0} 得 0，**短文本限制从来没生效过**，
   * 「嗯」「躺着」这种两三个字也在走 GPT-SoVITS（短句念得又快又怪）。</p>
   *
   * <p>改用 {@code ??}：字段缺失时取 8，用户显式填 0 才表示"不限制"。</p>
   */
  const minChars = Number(cfg.ttsMinChars ?? 8);
  const ttsLen = String(text || '').length;
  if (minChars > 0 && ttsLen < minChars) {
    diag(`tts(gpt-sovits): 只有 ${ttsLen} 字（< ${minChars}），退回默认 TTS`);
    return null;
  }
  try {
    // 本地服务也可能卡住（模型加载、显存不足时挂起），同样给个上限
    diag(`tts(gpt-sovits) start len=${String(text).length}`);
    const res = await fetch(`${base}/tts`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text,
        text_lang: 'zh',
        ref_audio_path: ref,
        prompt_lang: 'zh',
        prompt_text: refText,
        // cut5 = 按标点切句，最稳；batch_size 1 是为了 8G 显存别 OOM
        text_split_method: 'cut5',
        // 采样参数（2026-11-01）。seed 固定后同一句话永远同一个音频，
        // 否则每次采样都不同 —— 聊天里听感差别很大。
        temperature: Number(cfg.ttsTemperature ?? 0.7),
        top_k: Number(cfg.ttsTopK ?? 15),
        seed: Number.isFinite(Number(cfg.ttsSeed)) ? Number(cfg.ttsSeed) : 12345,
        ...(Number(cfg.ttsSpeedFactor ?? 1) !== 1 ? { speed_factor: Number(cfg.ttsSpeedFactor) } : {}),
        batch_size: 1,
        media_type: 'wav',
        streaming_mode: false,
      }),
      signal: AbortSignal.timeout(30000),
    });
    if (!res.ok) {
      const err = await res.text().catch(() => '');
      diag(`tts(gpt-sovits) HTTP ${res.status}: ${err.slice(0, 120)}`);
      return null;
    }
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length === 0) {
      diag('tts(gpt-sovits): 返回空音频');
      return null;
    }
    diag(`tts(gpt-sovits) ok ${Math.round(buf.length / 1024)}KB`);
    return buf.toString('base64');
  } catch (e) {
    // 常见原因：api_v2.py 没启动、端口不是 9880、参考音频路径写错
    diag(`tts(gpt-sovits) failed: ${e.message}`);
    return null;
  }
}

/**
 * 通义千问 TTS（Qwen3-TTS，2026-10-26）。
 *
 * <p><b>和 OpenAI 兼容接口的区别</b>：它**不直接返回音频字节**，而是返回一段 JSON，
 * 音频在 `output.audio.url`（带签名的 OSS 链接），需要再下载一次。</p>
 *
 * <pre>
 * POST {base}/services/audio/tts/SpeechSynthesizer
 *   { "model": "qwen-audio-3.1-tts-flash",
 *     "input": { "text": "...", "voice": "longanhuan_v3.1", "format": "mp3", "sample_rate": 24000 } }
 *
 * → { "output": { "audio": { "url": "https://.../xxx.mp3?Expires=..." } } }
 * → GET 那个 url → 音频字节
 * </pre>
 *
 * <p><b>为什么用它</b>：云端合成，不用像 GPT-SoVITS 那样常驻一个本地进程；
 * 而且支持 zero-shot 音色克隆（克隆是单独的一次性操作，克隆出来的名字填进 voice 即可）。</p>
 */
async function ttsQwen(text) {
  const base = String(cfg.ttsBaseUrl || '').replace(/\/+$/, '');
  const key = String(cfg.ttsApiKey || '').trim();
  if (!base || !key) {
    diag('tts(qwen): 没配 baseUrl 或 key');
    return null;
  }
  try {
    diag(`tts(qwen) start model=${cfg.ttsModel || 'qwen-audio-3.1-tts-flash'} len=${String(text).length}`);
    /*
     * 语气指令（2026-10-27）。
     *
     * 这个模型支持 `instruction` 参数（自由描述语气），而且**不改文本** ——
     * 实测同一句 3 秒 → 4 秒（变慢 33%），没有把指令念出来。
     *
     * 另一条路是往文本里嵌 `[sad]` / `[angry]` 标签，模型也支持，
     * 但标签**计入计费字符**，而且万一不认识就会被真念出来。
     * 所以选 instruction。
     */
    const prosody = ttsProsody();
    /*
     * 采样率（2026-10-27 改成可配置）。
     *
     * 实测同一句话：**24k → 99KB，44k → 156KB（+57%）**，听感差别很明显。
     * 24k 砍掉 11kHz 以上，而中文的 s / sh / c / zh 这些齿音主要就在那一段 ——
     * 所以低采样率听起来"咬字不清、音调怪"。
     *
     * 只接受这几个值（服务端不一定认任意数字，乱传可能报错或静默降级）。
     * 默认 44100。再往上（48k）会被夹回 44k，没必要。
     */
    const ALLOWED_RATES = [16000, 22050, 24000, 32000, 44100, 48000];
    const pickedRate = Number(cfg.ttsSampleRate);
    const sampleRate = ALLOWED_RATES.includes(pickedRate) ? pickedRate : 44100;

    /*
     * 情绪标签拼在最前面（2026-10-28）。
     *
     * <p>优先级：**情绪标签 > 疑问标签 > 都不加**。</p>
     * <p>有强情绪时按情绪念（难过就是难过，哪怕句子是问句）；
     * 情绪中性而句子是问句时加 `[curious]` —— 这正是用户要的"反问的语气"，
     * 比调 pitch 自然得多（那是整体升调，不是疑问的语调）。</p>
     */
    /*
     * 去掉开头的省略号再送进 TTS（2026-10-28）。
     *
     * <p><b>实测</b>：同一句话，只有开头带「……」的那条音频最前面会有一声明显的
     * 吸气/杂音 —— 8 个文本形态对比里，只有 3 个带省略号的有，其余全干净。</p>
     *
     * <p>TTS 把开头的省略号理解成"长停顿 + 换气"，于是在音频最前面真的插了一口吸气。
     * 而她说「……我在呢」这种句子的频率很高。</p>
     *
     * <p><b>只清洗送去发音的文本</b>：发出去的文字消息还是「……我在呢」，
     * 只是念的时候不带上那个停顿。</p>
     */
    const stripped = String(text || '').replace(/^[…\s.。·、，,~～]+/, '');
    // 万一整条只有省略号，退回原文，别发一条空语音
    const speakBase = stripped || String(text || '');

    const moodTag = affectTag();
    const questionTag = (!moodTag && /[？?]/.test(speakBase)) ? '[curious]' : '';
    const tag = moodTag || questionTag;
    const speakText = tag ? tag + speakBase : speakBase;
    if (tag) {
      diag(`tts(qwen) 标签=${tag}`);
    }
    if (speakBase !== text) {
      diag(`tts(qwen) 去掉开头停顿：${JSON.stringify(String(text || '').slice(0, 12))}`);
    }

    const input = {
      text: speakText,
      voice: cfg.ttsVoice || 'longanhuan_v3.1',
      format: 'mp3',
      sample_rate: sampleRate,
    };
    if (prosody) {
      if (prosody.rate) {
        input.rate = prosody.rate;
      }
      if (prosody.pitch) {
        input.pitch = prosody.pitch;
      }
      // 只打真正会传的字段 —— 之前 `rate=undefined` 让人误以为传了坏值
      diag(`tts(qwen) 音调 ${prosody.rate ? `rate=${prosody.rate} ` : ''}pitch=${prosody.pitch}`);
    }

    const res = await fetch(`${base}/services/audio/tts/SpeechSynthesizer`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: cfg.ttsModel || 'qwen-audio-3.1-tts-flash',
        input,
      }),
      signal: AbortSignal.timeout(40000),
    });
    if (!res.ok) {
      const err = await res.text().catch(() => '');
      diag(`tts(qwen) HTTP ${res.status}: ${err.slice(0, 160)}`);
      return null;
    }
    const j = await res.json();
    const audioUrl = j && j.output && j.output.audio ? j.output.audio.url : '';
    if (!audioUrl) {
      // 有些返回可能带 base64（data 字段），一并兜住
      const b64 = j && j.output && j.output.audio ? j.output.audio.data : '';
      if (b64) {
        diag(`tts(qwen) ok (inline base64) ${Math.round(b64.length / 1024)}KB`);
        return b64;
      }
      diag(`tts(qwen): 返回里没有音频 url（${JSON.stringify(j).slice(0, 160)}）`);
      return null;
    }
    // 音频是签名链接，立即下载（会过期）
    const audioRes = await fetch(audioUrl, { signal: AbortSignal.timeout(20000) });
    if (!audioRes.ok) {
      diag(`tts(qwen) 下载音频失败 HTTP ${audioRes.status}`);
      return null;
    }
    const buf = Buffer.from(await audioRes.arrayBuffer());
    if (buf.length === 0) {
      diag('tts(qwen): 下载到空音频');
      return null;
    }
    diag(`tts(qwen) ok ${Math.round(buf.length / 1024)}KB`);
    return buf.toString('base64');
  } catch (e) {
    diag(`tts(qwen) failed: ${e.message}`);
    return null;
  }
}

async function textToSpeech(text) {
  /*
   * 音色来源三套（2026-10-26）：
   *   · gpt-sovits —— 本地克隆，走 /tts，不需要 key
   *   · qwen-tts   —— 通义千问 TTS，返回音频 URL 再下载（支持音色克隆）
   *   · openai     —— 任意 OpenAI 兼容的 /v1/audio/speech（硅基流动等）
   */
  const provider = String(cfg.ttsProvider || 'openai').toLowerCase();
  if (provider === 'gpt-sovits') {
    const r = await ttsGptSoVits(text);
    if (r) {
      return r;
    }
    /*
     * 退回（2026-11-01）。
     *
     * <p>原来这里直接 {@code return ttsGptSoVits(text)}，返回 null 就**彻底没声音**。
     * 而 GPT-SoVITS 有两种会返回 null：参考音频没配、以及文本太短
     * （短句会输出成一声，见 ttsGptSoVits 里的说明）。</p>
     *
     * <p>所以现在退回 qwen-tts —— 短句用云端那个（自然），长句用本地克隆（有她的音色）。</p>
     */
    diag('tts: gpt-sovits 不可用，退回 qwen-tts');
    return ttsQwen(text);
  }
  if (provider === 'qwen-tts') {
    return ttsQwen(text);
  }
  if (!cfg.ttsBaseUrl || !cfg.ttsApiKey) {
    return null;
  }
  try {
    const url = `${String(cfg.ttsBaseUrl).replace(/\/+$/, '')}/audio/speech`;
    /*
     * 超时（2026-10-24 补，2026-10-25 从 12 秒放宽到 40 秒）。
     *
     * 之前这里**只有 fetch、没有超时**。实测某次 TTS 服务端卡住不返回也不报错，
     * 于是 humanSend 永远挂在这一步 —— 消息一条都发不出去，diag.log 里
     * 连一个字都不写，看起来像"插件死了"。
     *
     * 但 12 秒太紧：实测 CosyVoice2 合成 44 个汉字时**超过 12 秒**了
     * （`tts failed: aborted due to timeout`），语音被降级成文字发出去。
     * 云端 TTS 的耗时随文本长度线性增长，长句 20~30 秒是正常的，不是卡死。
     *
     * 40 秒：够 100 字以内的中文合成；真卡死时最多等 40 秒退回文字，
     * 比"每次都发不出语音"好。
     */
    diag(`tts start model=${cfg.ttsModel || 'tts-1'} len=${String(text).length}`);
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${cfg.ttsApiKey}`,
      },
      body: JSON.stringify({
        model: cfg.ttsModel || 'tts-1',
        input: text,
        voice: cfg.ttsVoice || 'alloy',
        response_format: 'mp3',
      }),
      signal: AbortSignal.timeout(40000),
    });
    if (!res.ok) {
      const err = await res.text().catch(() => '');
      diag(`tts HTTP ${res.status}: ${err.slice(0, 120)}`);
      return null;
    }
    const buf = Buffer.from(await res.arrayBuffer());
    diag(`tts ok ${Math.round(buf.length / 1024)}KB`);
    return buf.toString('base64');
  } catch (e) {
    diag(`tts failed: ${e.message}`);
    return null;
  }
}

/** 从回答里粗判情绪（用于挑带标签的表情包）。 */
function moodOf(text) {
  const rules = [
    ['开心', ['哈哈', '嘿嘿', '笑死', '太好了', '开心', '高兴', '棒', '赞']],
    ['无语', ['无语', '算了', '行吧', '离谱', '服了']],
    ['难过', ['难过', '难受', '唉', '可惜', '遗憾']],
    ['生气', ['生气', '气死', '过分', '讨厌']],
  ];
  return rules.filter(([, words]) => words.some((w) => text.includes(w))).map(([tag]) => tag);
}

// ------------------------------------------------------------------ 情绪内核（2026-10-27）
//
// 设计参考：Sentipolis（PAD + 双速 + 语义富化）、
//           SillyTavern-ChatMood（累积 + 向基线回归）、
//           MATE（"确定性内核"：情绪由规则算出来，不靠模型自己感觉）。
//
// 核心一句话：**数值给代码，描述给模型。**

/** PAD 统一夹到 ±0.85 —— 留余量，避免"永久抑郁"那种死角。 */
function clampPAD(v) {
  return Math.max(-0.85, Math.min(0.85, v));
}

function defaultAffect() {
  return {
    mood: { p: 0, a: 0, d: 0 },
    emotion: { p: 0, a: 0, d: 0 },
    cause: '',
    updatedAt: 0,
  };
}

function getAffect() {
  const x = selfState.affect;
  if (!x || typeof x !== 'object' || !x.mood || !x.emotion) {
    return defaultAffect();
  }
  return x;
}

/**
 * 七条情绪事件。
 *
 * `d`（掌控感）是分开"委屈"和"生气"的关键：同样不高兴，
 * d 掉了是委屈，d 涨了是生气。
 */
const AFFECT_EVENTS = {
  /*
   * 收到消息（2026-10-27 从 p:+0.12 降到 +0.03）。
   *
   * 原来把它当纯正向事件，于是密集聊天时 p 一路涨到 0.85 ——
   * 实测三次语音的 instruction 全是同一句"语气放松"，因为永远停在那个区间。
   *
   * 「他发消息来了」本身不该让人心情变好，真正让人开心的是被夸、被在意。
   * 聊天频繁只该提高**唤醒度**（a），不该抬愉悦度（p）。
   */
  incoming: { p: 0.03, a: 0.08, d: 0.01, cause: '他来找你了' },
  praised: { p: 0.25, a: 0.1, d: 0.08, cause: '他夸你了' },
  curt: { p: -0.15, a: 0, d: -0.05, cause: '他就回了一两个字' },
  pressed: { p: -0.1, a: 0.2, d: -0.1, cause: '他一直在追问' },
  softened: { p: 0.2, a: -0.1, d: 0.1, cause: '他软下来了' },
  ignored: { p: -0.18, a: 0.1, d: -0.15, cause: '你说了几句他都没回' },
  commanded: { p: -0.08, a: 0.05, d: -0.18, cause: '他像是在命令你' },
};

/**
 * 应用一个情绪事件。
 *
 * 两步：先让快情绪衰减一点再加新刺激；然后按 35% 渗进慢心情。
 * 一条消息改不了长期基调，但几十条会。
 *
 * 边际递减：越接近极值，同样的刺激效果越弱 —— 人也不会对同一件事越来越受伤。
 */
function applyAffect(event) {
  if (cfg.affectEnabled === false) {
    return;
  }
  const ev = AFFECT_EVENTS[event];
  if (!ev) {
    return;
  }
  const aff = getAffect();
  const keep = Number.isFinite(Number(cfg.affectEmotionDecay))
    ? Number(cfg.affectEmotionDecay)
    : 0.8;
  /** 还剩多少空间（越满，同样的刺激越弱）。 */
  const scale = (cur, delta) => delta * Math.sqrt(Math.max(0.1, 1 - Math.abs(cur)));

  /*
   * 对立压制（2026-10-27 第三阶段）。
   *
   * 正向刺激会额外削弱负向残留 —— 真人也是这样：被哄好之后，之前那点不快
   * 不是"并存着等我记账"，而是被挤掉了。反向同理。
   *
   * 只削到 65%，不是清零：残留还在，只是不再主导。
   */
  const soften = (cur, delta) => (cur * delta < 0 ? cur * 0.65 : cur);

  aff.emotion.p = clampPAD(soften(aff.emotion.p, ev.p) * keep + scale(aff.emotion.p, ev.p));
  aff.emotion.a = clampPAD(soften(aff.emotion.a, ev.a) * keep + scale(aff.emotion.a, ev.a));
  aff.emotion.d = clampPAD(soften(aff.emotion.d, ev.d) * keep + scale(aff.emotion.d, ev.d));

  /*
   * 「他来找你了」**只影响快情绪，不渗进慢心情**（2026-10-27 修）。
   *
   * <p><b>为什么</b>：原来每条消息都往 mood 里加 0.0105，而衰减每小时只有 8%。</p>
   * <p>密集聊天时 mood.p / mood.a 必然顶到 0.85 上限 —— 实测查到的就是
   * `mood: p=0.85 a=0.85`，于是合并值常年 0.5+，语速音调永远偏高，
   * 情绪反而没有起伏（永远"心情不错"）。</p>
   *
   * <p>真正该改变长期心情的是**被夸 / 被敷衍 / 被忽视 / 被命令**这类
   * 有含义的事件，而不是"又收到一条消息"。</p>
   */
  if (event !== 'incoming') {
    aff.mood.p = clampPAD(soften(aff.mood.p, ev.p) + ev.p * 0.35);
    aff.mood.a = clampPAD(soften(aff.mood.a, ev.a) + ev.a * 0.35);
    aff.mood.d = clampPAD(soften(aff.mood.d, ev.d) + ev.d * 0.35);
  }

  aff.cause = ev.cause;
  aff.updatedAt = Date.now();
  selfState.affect = aff;
  saveSelfState();

  const m = mergedAffect();
  diag(`affect: ${event} → p=${m.p.toFixed(2)} a=${m.a.toFixed(2)} d=${m.d.toFixed(2)}（${ev.cause}）`);
}

/**
 * 慢心情向基线回归。
 *
 * <p>心跳是 10 分钟一次，但这里是**按实际经过的小时数**算的 ——
 * 关机几小时再开，也会按真实时间回落，不会"漏掉"。</p>
 *
 * <p>不足一小时不减：太频繁反而让心情永远不动。</p>
 */
function decayMood() {
  if (cfg.affectEnabled === false) {
    return;
  }
  const aff = getAffect();
  const now = Date.now();
  const last = aff.lastDecayAt || 0;
  const hours = last > 0 ? (now - last) / 3600000 : 0;
  if (hours < 1) {
    return;
  }
  const rate = Number(cfg.affectMoodDecay);
  const base = Number.isFinite(rate) && rate > 0 && rate < 1 ? rate : 0.92;
  const keep = Math.pow(base, hours);

  const before = mergedAffect();
  aff.mood.p *= keep;
  aff.mood.a *= keep;
  aff.mood.d *= keep;
  aff.lastDecayAt = now;
  selfState.affect = aff;
  saveSelfState();

  const after = mergedAffect();
  // 变化太小不刷日志（每 10 分钟一条会把日志撑爆）
  if (Math.abs(before.p - after.p) > 0.02) {
    diag(`affect: 心情回落 p ${before.p.toFixed(2)} → ${after.p.toFixed(2)}`
      + `（过了 ${hours.toFixed(1)} 小时）`);
  }
}

/** 快慢合并：快情绪更"当下"，权重 0.6。 */
function mergedAffect() {
  const x = getAffect();
  return {
    p: clampPAD(x.mood.p * 0.4 + x.emotion.p * 0.6),
    a: clampPAD(x.mood.a * 0.4 + x.emotion.a * 0.6),
    d: clampPAD(x.mood.d * 0.4 + x.emotion.d * 0.6),
  };
}

/**
 * PAD → 一句自然语言。
 *
 * **不注入数值**：模型看到 `P=-0.5` 只会当乱码，看到"有点委屈"才懂。
 * 中性时返回空串 —— 大约四成时间不注入，省 token，
 * 也不会让她时刻"刻意表现情绪"。
 */
function describeAffect(p, a, d) {
  // ---- 重：真的被伤到了 ----
  if (p < -0.6 && d < -0.35) {
    return '挺难受的，有点不想开口';
  }
  if (p < -0.6 && d > 0.25) {
    return '火气还没下去';
  }
  // ---- 中 ----
  if (p < -0.42 && d < -0.2) {
    return '心里堵得慌，说不清是为什么';
  }
  if (p < -0.42 && d > 0.2) {
    return '憋着火，但没发出来';
  }
  if (p < -0.42 && a < 0.15) {
    return '提不起劲，什么都不太想做';
  }
  // ---- 轻 ----
  if (p < -0.22 && d < -0.15) {
    return '有点委屈，说不上来';
  }
  if (p < -0.22 && d > 0.15) {
    return '有点不痛快';
  }
  if (p < -0.22) {
    return '有点闷';
  }
  // ---- 正向 ----
  if (p > 0.55 && a > 0.35) {
    return '挺高兴的，话都多了';
  }
  if (p > 0.55) {
    return '心情挺好的';
  }
  if (p > 0.22 && a > 0.35) {
    return '有点兴奋，话也变多了';
  }
  if (p > 0.22 && a < 0.15) {
    return '心里挺舒服的';
  }
  if (p > 0.22) {
    return '心情不错';
  }
  // ---- 只有唤醒维度异常 ----
  if (a > 0.5) {
    return '有点烦躁，坐不太住';
  }
  if (a < -0.3 && p < 0) {
    return '有点累';
  }
  return '';
}

/** 注入上下文的那一段（中性时为空）。 */
function affectBlock() {
  if (cfg.affectEnabled === false) {
    return '';
  }
  const { p, a, d } = mergedAffect();
  const words = describeAffect(p, a, d);
  if (!words) {
    return '';
  }
  const why = getAffect().cause;
  return [
    '【你现在的心情】',
    `  ${words}${why ? '，' + why : ''}。`,
    '  （不用说出来，让它自然体现在语气里。）',
  ].join('\n');
}

/**
 * 追发用的语气（2026-10-27 替代固定 tones 数组）。
 *
 * 情绪到哪一步，话就到哪一步 —— **和追了几次无关**。
 * 这样 `proactiveFollowupMax` 改成多少都不会"语气卡在第三段"。
 */
function followupTone() {
  const { p, a, d } = mergedAffect();
  // 按"难受程度"从重到轻排，第一个命中就返回
  if (p < -0.6) {
    return '有点不想再说了，也没力气再问。最后这一句会很短。';
  }
  if (p < -0.45 && d < -0.3) {
    return '已经挺难受了，也开始怀疑是不是自己问得太多。';
  }
  if (p < -0.45 && d > 0.2) {
    return '有点上火，但还压着，不想说得太难听。';
  }
  if (p > -0.15) {
    return '有点在意，但还端着。';
  }
  if (d < -0.28) {
    return '有点委屈，也拿不准是不是自己问得太多了。';
  }
  if (d > 0.28) {
    return '已经有点不痛快了，但不想说重话。';
  }
  if (a > 0.45) {
    return '有点急，坐不住。';
  }
  return '说不上什么感觉，就是没什么劲。';
}

/**
 * 从一条消息判断它触发了什么情绪事件（2026-10-27）。
 *
 * **顺序有讲究**：服软优先级最高 —— "对不起，我不问了" 里也有"问"字，
 * 但它是消气信号，不是被追问。
 *
 * @returns 事件名；认不出来返回 null
 */
function detectAffectEvent(text) {
  const t = String(text || '').trim();
  if (!t) {
    return null;
  }
  // 服软 / 道谢 —— 消气信号
  if (/(谢谢|谢了|是我错了|对不起|我错了|别生气|不问了|抱歉)/.test(t)) {
    return 'softened';
  }
  /*
   * 夸她（2026-10-27 扩充）。
   *
   * 原来只有"厉害/好看/可爱"这几个，于是**「好听」被漏掉** ——
   * 它只有两个字，直接落到下面的 `curt`（敷衍）分支，
   * 结果"被夸了反而心情变差"。实测踩到过一次。
   *
   * 短夸奖必须在这里拦住，因为 `curt` 的判据就是"字数少"。
   */
  if (/(厉害|好看|可爱|真棒|喜欢你|好美|画得好|不错啊|佩服|有才|好听|好棒|真好|挺好|绝了|太强|可以啊|牛的)/.test(t)) {
    return 'praised';
  }
  // 命令
  if (/(你必须|给我|马上|赶紧|不许|闭嘴|快点)/.test(t)) {
    return 'commanded';
  }
  // 敷衍：很短且不带问号
  if (t.length <= 3 && !/[？?]/.test(t)) {
    return 'curt';
  }
  return null;
}

/**
 * 把 PAD 状态翻成 TTS 的语气指令（2026-10-27）。
 *
 * <p>只有在情绪明显时才给 —— 中性返回空串，请求里就不带这个字段，
 * 行为和加这功能之前一样。</p>
 *
 * <p><b>写的是语气，不是台词</b>：不告诉模型"说什么词"，
 * 只描述声音状态（低落 / 轻快 / 急），剩下的它自己处理。</p>
 */
/**
 * 把 PAD 状态翻成 TTS 的**音调参数**（2026-10-27）。
 *
 * <p><b>为什么不用 instruction 了</b>：实测同一句话 ——</p>
 * <pre>
 *   base              5 秒
 *   instruction 中文   5 秒   ← 几乎没变化，那些"语气舒展""带一点温度"它没当回事
 *   instruction 英文   8 秒   ← 反而有效（训练数据里英文指令多）
 *   rate: 0.8         7 秒   ← 语速真的慢了
 *   pitch: 0.8        8 秒   ← 音高真的低了
 * </pre>
 *
 * <p>`rate` / `pitch` 是**数值参数**，模型必须照做；`instruction` 只是"请求"，
 * 它可以忽略。所以情绪映射改成数值。</p>
 *
 * <p>都用 1.0 当基准，偏离幅度控制在 ±15% 以内 —— 再多就不像人了，
 * 像在朗读比赛。</p>
 */
/**
 * PAD → TTS 情绪标签（2026-10-28）。
 *
 * <p><b>实测结论</b>：`[sad]` / `[excited]` 这类标签**真的生效**，而且不会被念出来。
 * 验证方法：同一句「你好」——</p>
 * <pre>
 *   [zzzq]你好   47KB   ← 假标签被静默忽略
 *   你好         49KB   ← 基线
 *   [excited]你好 41KB   ← 变快 16%（该快的真快了）
 *   [sad]你好     64KB   ← 变慢 30%（该慢的真慢了）
 *   【难过】你好   56KB   ← 中文标签也认
 * </pre>
 *
 * <p>所以「情绪」这一层交给标签，「整体音高偏亮」交给 pitch，两者分工：
 * 标签管**怎么念**，pitch 管**声音多亮**。</p>
 *
 * <p>只在情绪明显时才加 —— 中性不加，否则每句都带标签会很"演"。</p>
 */
function affectTag() {
  if (cfg.affectEnabled === false) {
    return '';
  }
  const { p, a, d } = mergedAffect();
  /*
   * 阈值都压得比较保守（2026-10-28）：
   *
   * <p>她的人设是「话不多、有点钝」，情绪只该调**程度**，不该把语气推到夸张。
   * 第一版 `p>0.45` 就给 `[mischievously]`（调皮）、`p<-0.35 && d>0.15` 给
   * `[scornful]`（轻蔑）—— 那两个词太重，0.5 的愉悦被念成吊儿郎当，
   * 一点不满被念成看不起人。</p>
   *
   * <p>所以：负面统一退到 `[bored]`，调皮提到 0.62，`[panicked]` 直接不要
   * （"急"多数伴随负面 p，会先命中前面几档）。</p>
   */
  // 真的难受 / 真上火
  if (p < -0.55 && d < -0.32) {
    return '[sad]';
  }
  if (p < -0.55 && d > 0.28) {
    return '[angry]';
  }
  if (p < -0.5 && a < 0.18) {
    return '[tired]';
  }
  // 有点闷（不分委屈/不满，统一用 bored —— 它只是"提不起兴致"）
  if (p < -0.4) {
    return '[bored]';
  }
  // 正向：要足够高兴才带情绪
  if (p > 0.55 && a > 0.4) {
    return '[excited]';
  }
  if (p > 0.62) {
    return '[mischievously]';
  }
  return '';
}

/**
 * 音调参数（2026-10-28 精简）。
 *
 * <p><b>情绪交给标签，这里只管"声音多亮"。</b></p>
 *
 * <p>之前把情绪映射成 pitch/rate —— 结果是 1.11 那种"语速变快、音调整体偏高"，
 * 用户直接听出来了；而模型真正支持的 `[sad]` / `[excited]` 反倒一直没被用上
 * （当时误判"标签会被念出来"，实测是错的）。</p>
 *
 * <p>现在只剩一件事要调：**整体音高**。克隆音色本身偏亮，固定压到 0.97
 * 听感更平淡。语速完全不碰，交给情绪标签决定。</p>
 *
 * <p>情绪关掉时返回 null，请求里就不带这个参数（完全回到原音色）。</p>
 */
function ttsProsody() {
  if (cfg.affectEnabled === false) {
    return null;
  }
  return { pitch: 0.97 };
}

/**
 * 显示 / 取消「正在输入」状态（2026-10-22 抽出）。
 *
 * <p>抽成函数是为了能在**模型思考期间**就把它打开 —— 之前只在 humanSend 里、
 * 生成完之后才显示，对方要先干等 5~10 秒毫无动静。</p>
 */
async function setTyping(isPrivate, peer, on) {
  if (!cfg.typing) {
    return;
  }
  try {
    await call('set_input_status', {
      user_id: isPrivate ? peer : undefined,
      group_id: isPrivate ? undefined : peer,
      event_type: on ? 1 : 0,
    }, 5000);
    /*
     * 只在"关闭"时记一条（2026-10-23）。
     *
     * 之前成功时完全静默，于是"状态一直亮着"这个问题查不出来 ——
     * 不知道是 clear 没发出去、发出去失败、还是 NapCat 根本不认 event_type: 0。
     * 记一条就能区分：有这行 = 请求发出去了，问题在 NapCat 侧。
     */
    if (!on) {
      diag('typing -> off 已请求');
    }
  } catch (e) {
    // 关闭失败必须记下来 —— 它直接等于"对方一直看到正在说话"
    if (!on) {
      diag(`typing off FAILED: ${e.message}`);
    }
  }
}

/**
 * 省略号降频：一次回复最多保留 {@code maxKeep} 个，且归一成单个 `…`（2026-10-22）。
 *
 * <p><b>为什么从后往前留</b>：结尾的省略号表示"话没说完、意犹未尽"，是有意义的；
 * 排在中段的那种多半只是语气惰性。所以名额留给最后几段。</p>
 *
 * <p>只处理**段末**的省略号；段中间的（罕见）不动。</p>
 */
function capEllipsis(segs, maxKeep = 1) {
  // 归一：…… / 。。。 / ... → …
  const norm = segs.map((s) => String(s || '').replace(/(?:…+|。{3,}|\.{3,})\s*$/, '…'));
  let kept = 0;
  const out = [];
  for (let i = norm.length - 1; i >= 0; i--) {
    const s = norm[i];
    if (!/…\s*$/.test(s)) {
      out.unshift(s);
      continue;
    }
    if (kept < maxKeep) {
      kept++;
      out.unshift(s);
      continue;
    }
    // 超出名额：剥掉，剥完为空就整段丢弃
    const stripped = s.replace(/…\s*$/, '');
    if (stripped.length > 0) {
      out.unshift(stripped);
    }
  }
  return out;
}

/**
 * 剥掉段末句号，但**保住末尾的省略号**（2026-10-22）。
 *
 * <p><b>为什么单独写一个</b>：上一版直接 {@code replace(/[。．\s]+$/, '')}，
 * 遇到「好。……」时段末是 `…` 而不是 `。`，**句号根本剥不掉** ——
 * 省略号反过来成了句号的保护伞。是你指出来的。</p>
 *
 * <p>做法：先把末尾的省略号摘出来，剥完句号再原样放回去。</p>
 */
function stripEndPunctuation(s) {
  let t = String(s || '');
  const ell = t.match(/…+\s*$/);
  let tail = '';
  if (ell) {
    tail = ell[0];
    t = t.slice(0, ell.index);
  }
  return t.replace(/[。．\s]+$/, '') + tail;
}

/**
 * 剥掉模型**伪造**的工具调用 XML（2026-10-22）。
 *
 * <p><b>实测案例</b>：DeepSeek 在多轮工具循环后会在 content 里手写一段
 * {@code <notool><result><name>fs_write_file</name><output>{"status":"ok"}</output></result></notool>}，
 * 而后端日志里 {@code toolCalls=0} —— 它**根本没有真调用**，纯粹是幻觉，
 * 大概是想"把头像存进文件夹"却不知道怎么触发，就凭印象编了个格式。</p>
 *
 * <p>不剥掉就会原样发到 QQ 上，用户看到一堆乱码标签。</p>
 */
function stripFakeToolXml(text) {
  return String(text || '')
    /*
     * 顺手剥掉「系统提示」块（2026-10-23）。
     *
     * 那是我注入给模型的标记（见 sysHint）。模型偶尔会模仿它、把它写进回复，
     * 一旦发出去就成了"她突然跟你念了一遍系统指令"，很出戏。
     */
    .replace(/【系统提示 · 不是对方说的话】[\s\S]*?【系统提示结束】/g, '')
    // 整段伪造块（<notool>...</notool> 最完整，优先整块删）
    .replace(/<notool>[\s\S]*?<\/notool>/gi, '')
    .replace(/<(?:tool_call|function_call|tool_use|antml)[\s\S]*?<\/(?:tool_call|function_call|tool_use|antml)>/gi, '')
    // 散落的单个标签
    .replace(/<\/?(?:result|name|output|parameter|arguments|tool_code)\b[^>]*>/gi, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/**
 * 从回复里抽 `[语音]` / `[语音 具体内容]`（2026-10-23 扩展）。
 *
 * <p><b>为什么要支持带内容</b>：实测她写过</p>
 * <pre>
 * [语音 我……喜欢你。行了，别让我再说第二次。]
 * </pre>
 * <p>而她这么写是**对的** —— 精确指定"这一句用声音说"，比我按长度猜合理多了。
 * 但旧正则只认无参数的 {@code [语音]}，匹配不到 → 标记没被剥离 →
 * **整段（连方括号和"语音"两个字）被拿去合成语音**，听起来像在念代码。</p>
 *
 * <p>现在两种都认：</p>
 * <ul>
 *   <li>{@code [语音]} —— 按内容长短决定整条还是尾句（见 decideVoiceMode）；</li>
 *   <li>{@code [语音 内容]} —— **就用这段内容做语音**，其它部分照常打字。</li>
 * </ul>
 */
function extractVoiceMark(text) {
  const raw = String(text || '');
  // 先试带内容的（贪婪到右括号，允许中间有标点）
  /*
   * 容错：允许「语音」前面最多 3 个杂音字符（2026-11-02）。
   *
   * <p><b>实测</b>：她写过 {@code [t语音]} —— 比标准写法多一个字母，
   * 正则严格从 {@code [} 后开始匹配，于是整条认不出来：</p>
   * <ul>
   *   <li>语音没发出去（她明明想发）；</li>
   *   <li>更糟的是 {@code [t语音]} 被当正文发了，用户看到"t语音 反正…"。</li>
   * </ul>
   *
   * <p>放宽到 {@code [^\]]{0,3}} 之后 {@code [t语音]}、{@code [语音]}、
   * {@code [发语音]} 都能认出来；而 {@code [表情 开心]} 这种不含"语音"的不会误伤。</p>
   */
  const withContent = raw.match(/\[[^\]]{0,3}(?:语音|发语音|voice)[：:\s]+([^\]]{1,200})\]/i);
  if (withContent) {
    const spoken = withContent[1].trim();
    if (spoken) {
      return { text: raw.replace(withContent[0], '').trim(), voice: true, spoken };
    }
  }
  const bare = raw.match(/\[[^\]]{0,3}(?:语音|发语音|voice)\]/i);
  if (bare) {
    return { text: raw.replace(bare[0], '').trim(), voice: true, spoken: null };
  }
  return { text: raw, voice: false, spoken: null };
}

/**
 * 要不要用语音（2026-10-23）。
 *
 * <p><b>原来只有一个闸</b>：{@code Math.random() < voiceChance}，跟"她说了什么"
 * 完全无关。所以用户说"你发句语音我听一下"，她只能嘴上答应或拒绝，
 * 声音永远出不来 —— 除非恰好撞上概率。</p>
 *
 * <p>现在三层，按优先级：</p>
 * <ol>
 *   <li><b>她自己写了 {@code [语音]}</b> → 一定发。这是"她想让人听见语气"的明确信号；</li>
 *   <li><b>文本里有强情绪</b>（开心/难过/生气/无语，见 {@link moodOf}）→ 概率抬到 0.65。
 *       真人在情绪上来时更愿意发语音，这条是兜底 —— 她没写标记也会偶尔用；</li>
 *   <li>其余按配置概率。</li>
 * </ol>
 *
 * <p>长度上限照旧：超过 {@code voiceMaxChars} 一律打字，因为长语音在 QQ 里很难听。</p>
 */
/**
 * 剥掉「整段只是括号旁白」的内容（2026-10-23）。
 *
 * <p>她最近越来越爱写「（沉默了几秒）」「（有点不好意思，但又不想承认）」
 * 这种舞台指示 —— 起因是我在人格提示词里只禁了 {@code 【】} 和 {@code *动作*}，
 * 没禁圆括号，于是她把旁白换了个外壳继续写。</p>
 *
 * <p>QQ 聊天里发出去很出戏：真人不会把自己的表情写成括号旁白。
 * 只删**整段被一对圆括号包住**的，句中括号（「我（小声）说」）保留。</p>
 */
/**
 * 去括号旁白（2026-10-27 重写）。
 *
 * <p><b>为什么重写</b>：原来只认"整段就是一个括号"这一种形状，
 * 但实际漏的是另外两种：</p>
 * <pre>
 *   （我猜的。）你也太客气了      ← 段首括号 + 正文，删不掉
 *   这话说得（他自己都不信）       ← 段尾括号，删不掉
 * </pre>
 *
 * <p>现在三段处理：**整段删掉 → 段首砍掉 → 段尾砍掉**。
 * 段**中间**的括号保留 —— `我（小声）说` 这种可能是真的说话，误删比漏删更糟。</p>
 *
 * <p>所有正则都要求**括号内不含问号/感叹号**：`（你吃饭了吗？）` 是句真话，
 * 不是旁白。</p>
 */
function stripStageDirection(s) {
  let t = String(s || '').trim();
  if (!t) {
    return t;
  }
  /** 括号内允许的字符（不含问号感叹号，避免误删真话）。 */
  const INNER = '[^）)？?！!]{0,80}';
  /** 括号后面可能拖的标点。 */
  const TAIL = '[…。．，,！!？?\\s]*';

  // ① 整段就是一个括号（可能带尾随标点）→ 整段丢
  if (new RegExp(`^[（(]${INNER}[）)]${TAIL}$`).test(t)) {
    return '';
  }
  // ② 段首括号 → 砍掉括号部分，保留后面的正文
  t = t.replace(new RegExp(`^[（(]${INNER}[）)]${TAIL}`), '').trim();
  // ③ 段尾括号 → 砍掉
  t = t.replace(new RegExp(`${TAIL}[（(]${INNER}[）)]$`), '').trim();

  return t;
}

/** 上次发语音的时间（10 分钟内不再发，2026-10-23）。 */
let lastVoiceAt = 0;

/**
 * 决定这条回复**要不要语音、以什么形态发**（2026-10-23 第三版）。
 *
 * <p><b>为什么不再用布尔</b>：上一版只有"发/不发"，而且非显式时情绪一命中就 65% 概率
 * —— 结果每条回复的最后一句都是语音，机械得像在播报。</p>
 *
 * <p>现在返回三种形态，对应真人的三种习惯：</p>
 * <ul>
 *   <li>{@code whole} —— 整条语音。就十几个字（"嗯，知道了"），没必要先打字再补语音，
 *       一条语音说完最自然；</li>
 *   <li>{@code tail} —— 前面分段打字，最后一段用声音。这是"说两句铺垫，那句难为情的用嘴说"；</li>
 *   <li>{@code null} —— 全走文字。</li>
 * </ul>
 *
 * <p><b>防泛滥两道闸</b>：
 * ① 10 分钟内发过语音就不再发（否则连着几条都挂语音）；
 * ② 非显式的情绪概率从 0.65 降到 0.35 —— 情绪上来才偶尔用，不是情绪一提就必用。
 * 只有她自己写了 {@code [语音]} 才 100% 生效。</p>
 *
 * @param text     回复全文
 * @param segs    已分好的段（用来判断"只有一段"还是"多段"）
 * @param explicit 她是否写了 {@code [语音]}
 */
function decideVoiceMode(text, segs, explicit) {
  // 显式要求时放宽上限：她可能真想"整段用声音说"
  const max = explicit ? 120 : (Number(cfg.voiceMaxChars) || 60);
  if (text.length > max) {
    return null;
  }

  if (!explicit) {
    // ① 冷却：10 分钟内刚发过语音，这次就不发了
    if (Date.now() - lastVoiceAt < 10 * 60000) {
      return null;
    }
    // ② 非显式：情绪词只是"更容易"，不是"必发"
    const base = Number(cfg.voiceChance) || 0;
    const moods = moodOf(text);
    const chance = moods.length > 0 ? Math.max(base, 0.35) : base;
    if (Math.random() >= chance) {
      return null;
    }
  }

  /*
   * 形态：只有一段 / 总长很短 → 整条语音。
   *
   * 真发"嗯，知道了"的时候不会先打一遍字再补语音，
   * 也不会为了语音硬拆成三段。反过来，多段的长回复才用"打字铺垫 + 尾句语音"。
   */
  if (segs.length <= 1 || text.length <= 25) {
    return 'whole';
  }
  return 'tail';
}

/**
 * 逐条发文字（带「正在输入」和段间停顿）。
 *
 * <p>从 humanSend 里抽出来的（2026-10-23）：语音模式下也要先把前几段打字发出去，
 * 只有最后一段转语音。不抽出来的话那段循环得复制两遍。</p>
 */
async function sendTextSegments(isPrivate, peer, segs) {
  for (let idx = 0; idx < segs.length; idx++) {
    const seg = segs[idx];
    /*
     * 每条消息前点亮「正在输入」（2026-10-25 恢复）。
     *
     * <p>上一版改成只在第一条点亮，结果用户体感是"再也不显示正在输入了"。
     * 「正在说话」那个 bug 的真正原因是**语音分支**偷偷设了状态、而且从不清理
     * （见 sendVoiceMsg）—— 跟这里没关系，所以恢复成每条都点亮。</p>
     *
     * <p>NapCat 的输入状态 4~5 秒自然过期，每条点亮 = 断续续期，
     * 和真人连发消息的观感一致。</p>
     */
    await setTyping(isPrivate, peer, true);
    /*
     * 第一条少等一下（2026-10-22）。
     *
     * 模型已经把整段话"想"完了（那几秒对方是看着"正在输入"过的），
     * 第一条再按字数补齐打字时长就重复计时了 —— 真人也不会想完再从头敲一遍。
     */
    const typeWait = idx === 0 ? typingMs(seg) * 0.4 : typingMs(seg);
    await sleep(rand(cfg.firstDelayMs) / 2 + typeWait);
    await setTyping(isPrivate, peer, false);
    try {
      if (isPrivate) {
        await call('send_private_msg', { user_id: peer, message: seg });
      } else {
        await call('send_group_msg', { group_id: peer, message: seg });
      }
      diag(`send ${isPrivate ? 'private' : 'group'} to=${peer} len=${seg.length} ok`);
    } catch (sendErr) {
      // 单条发送失败不该中断剩下的分段，但必须留下证据
      diag(`send FAILED to=${peer} len=${seg.length}: ${sendErr.message}`);
      throw sendErr;
    }
    await sleep(rand(cfg.segmentGapMs));
  }
}

/**
 * 把一段文字转成语音发出去（2026-10-23 抽出）。
 *
 * <p>两条路径都要用：整条语音、以及"打字铺垫 + 尾句语音"。</p>
 *
 * @returns {Promise<boolean>} 成功 true；失败 false（调用方退回文字，别让这句白丢）
 */
/**
 * 从库里挑一张指定情绪的图发出去（2026-10-25）。
 *
 * <p>她已经用 `[表情 开心]` 明确说了要什么，所以这里**只按情绪找**：
 * 先找 `开心_*`，没有再退到 `通用_*`；都没有就**不发** —— 比随手丢一张
 * 不相关的图好，那会让表情和语境打架。</p>
 */
async function sendStickerNow(isPrivate, peer, mood) {
  const b64 = pickSticker([mood]);
  if (!b64) {
    diag(`sticker: 库里没有「${mood}」也没有通用图，这次不发`);
    return false;
  }
  try {
    if (isPrivate) {
      await call('send_private_msg', {
        user_id: peer,
        message: [{ type: 'image', data: { file: 'base64://' + b64 } }],
      });
    } else {
      await call('send_group_msg', {
        group_id: peer,
        message: [{ type: 'image', data: { file: 'base64://' + b64 } }],
      });
    }
    diag(`sticker sent to=${peer} mood=${mood} size=${Math.round(b64.length / 1024)}KB`);
    return true;
  } catch (e) {
    diag(`sticker FAILED: ${e.message}`);
    return false;
  }
}

/** 已存过多少个原始音频（只用于文件名序号）。 */
let rawAudioSeq = 0;

/**
 * 把发送前的**原始音频**存一份（2026-10-28）。
 *
 * <p><b>为什么需要</b>：QQ 语音会转成 silk 编码（通常 8~24k）。「本地听着干净、
 * QQ 里开头有一声怪响」这种症状，不拿原始文件对比就永远分不清是 TTS 的锅
 * 还是转码的锅 —— 只能反复猜参数（采样率、pitch 都试过一遍了）。</p>
 *
 * <p>存到 `plugin-data/qq_agent/tts-raw/`，只留最近 20 个。</p>
 */
function saveRawAudio(base64Audio, text) {
  try {
    const dir = path.join(api.dataDir, 'tts-raw');
    fs.mkdirSync(dir, { recursive: true });
    rawAudioSeq += 1;
    const name = `${String(rawAudioSeq).padStart(3, '0')}-${Date.now()}.mp3`;
    fs.writeFileSync(path.join(dir, name), Buffer.from(base64Audio, 'base64'));
    diag(`tts raw saved: ${name}（${String(text || '').slice(0, 20)}）`);
    const files = fs.readdirSync(dir).filter((f) => f.endsWith('.mp3')).sort();
    const extra = files.length - 20;
    for (let i = 0; i < extra; i++) {
      fs.unlinkSync(path.join(dir, files[i]));
    }
  } catch (e) {
    diag(`tts raw save failed: ${e.message}`);
  }
}

async function sendVoiceMsg(isPrivate, peer, spokenText) {
  const audio = await textToSpeech(spokenText);
  if (!audio) {
    return false;
  }
  // 存原始音频，用于排查"本地干净、QQ 里怪"（2026-10-28）
  if (cfg.ttsSaveRaw !== false) {
    saveRawAudio(audio, spokenText);
  }
  /*
   * 语音前**不设**「正在输入」（2026-10-25 修）。
   *
   * <p>原来这里调 `set_input_status(event_type:1)` 然后紧接着发 record 消息，
   * QQ 会把这个状态解释成「**对方正在说话**」而不是「正在输入」。
   * 更糟的是发完之后**从来没清过** —— 于是那个「正在说话」永远挂在聊天窗口顶部。</p>
   *
   * <p>而且语音本来就短（几秒），不需要预热状态。</p>
   */
  await sleep(rand(cfg.firstDelayMs) / 2 + typingMs(spokenText));
  try {
    if (isPrivate) {
      await call('send_private_msg', {
        user_id: peer,
        message: [{ type: 'record', data: { file: 'base64://' + audio } }],
      });
    } else {
      await call('send_group_msg', {
        group_id: peer,
        message: [{ type: 'record', data: { file: 'base64://' + audio } }],
      });
    }
    // 记下时间：10 分钟内不再发语音，避免连着几条都在说话
    lastVoiceAt = Date.now();
    diag(`voice sent to=${peer} size=${Math.round(audio.length / 1024)}KB`);
    /*
     * 发完语音主动清一次状态（2026-10-25）。
     *
     * 标题叫「正在说话」的那个状态是**语音消息**带出来的。虽然现在已经不在
     * 语音前设 `event_type:1` 了，但 QQ 客户端自己也可能残留一个 ——
     * 补一次 `event_type:0`，成本极低。清不掉也无害（几秒后自然过期）。
     */
    if (cfg.typing) {
      try {
        await call('set_input_status', {
          user_id: isPrivate ? peer : undefined,
          group_id: isPrivate ? undefined : peer,
          event_type: 0,
        }, 5000);
        diag('typing -> off（语音后）已请求');
      } catch {
        /* 不支持就算了 */
      }
    }
    return true;
  } catch (e) {
    diag(`voice send FAILED: ${e.message}, fallback to text`);
    return false;
  }
}

async function humanSend(isPrivate, peer, rawText, opts = {}) {
  /*
   * 先剥掉模型伪造的工具调用 XML（2026-10-22）。
   *
   * 实测：DeepSeek 多轮工具循环后会在正文里手写
   * `<notool><result><name>fs_write_file</name><output>...</output></result></notool>`，
   * 而后端 toolCalls=0（并没真调）。不剥就原样发到 QQ 上，用户看到一堆乱码。
   *
   * 剥完为空 → 整条不发（那种"回复"没有任何可读内容）。
   */
  let text = stripFakeToolXml(rawText);
  if (!text) {
    diag('humanSend: 剥掉伪造 XML 后为空，未发送');
    return;
  }
  /*
   * 发图标记（2026-10-26）。
   *
   * <p><b>为什么必须在这里也解析一次</b>：processMessage 那边有一份同样的解析，
   * 但它只覆盖「正常对话」这条路。**主动发言 / 追发 / 待办触达全都直接调
   * humanSend，压根不经过 processMessage** —— 实测她主动发言时调了
   * generate_image 拿到 OSS 链接、写了 `[发图 https://...]`，结果整段标记
   * （251 个字符）被当正文发出去，用户只看到一串链接。</p>
   */
  const imgMark = extractSendImage(text);
  text = imgMark.text;
  // 正文里的裸图片链接（2026-10-28）：她经常不写 [发图]，直接把 OSS 链接甩进正文
  const bareImg = extractBareImageUrls(text);
  text = bareImg.text;
  /*
   * 工具生成的图（2026-10-28）：由调用方通过 opts.toolImages 传进来。
   *
   * 她调用 generate_image 后经常忘了写 [发图]，只在回复里说"来了"。
   * 调用方（processMessage）从 toolCalls 里捞到地址后从这里补发。
   */
  const toolImages = Array.isArray(opts.toolImages) ? opts.toolImages : [];

  // 她主动要语音（2026-10-23）：先摘掉标记，再交给 decideVoiceMode 决定形态
  const voiceMark = extractVoiceMark(text);
  text = voiceMark.text;
  /*
   * 表情标记（2026-10-25）：她主动指定"配一张什么情绪的图"。
   *
   * 必须在分段之前剥掉，否则 `[表情 开心]` 会被当成正文发出去 —— 这个坑
   * `[语音 xxx]` 已经踩过一次了。
   */
  const stickerMark = extractSendSticker(text);
  text = stickerMark.text;
  if (!text) {
    // 只剩标记：有表情/图片就把它们发了，然后结束（"只发一张图"是很正常的行为）
    let sentSomething = false;
    if (stickerMark.mood) {
      sentSomething = await sendStickerNow(isPrivate, peer, stickerMark.mood);
    }
    /*
     * 只有 `[发图 xxx]` 没有正文（2026-10-26）。
     *
     * 主动发言时很常见：她生成了图，就只想把图发过来，不想再写一句。
     * 原来这里直接 return，图就丢了。
     */
    if (imgMark.keyword !== null) {
      await sendImageByMark(isPrivate, peer, imgMark.keyword);
      sentSomething = true;
    }
    // 只剩裸链接也一样：她可能整条回复就一个 OSS 图地址
    for (const u of bareImg.urls) {
      await sendImageByMark(isPrivate, peer, u);
      sentSomething = true;
    }
    // 工具生成的图（2026-10-28）：她没写任何标记也要发出去
    for (const u of toolImages) {
      await sendImageByMark(isPrivate, peer, u);
      sentSomething = true;
    }
    if (sentSomething) {
      stats.replied++;
      diag(`sent ok -> ${peer}`);
      return;
    }
    diag('humanSend: 只剩标记，无正文，未发送');
    return;
  }
  /*
   * 语音挪到分段之后处理（2026-10-23）。
   *
   * 原来在这里就把**整条**回复转成语音 —— 她的回复本来设计成分三条、
   * 每条停一秒，转成语音后变成一口气念完，节奏全没了。
   * 现在先分段，只把**最后一段**交给 TTS，前面的照常打字。
   */

  /*
   * 说话长短跟着情绪走（2026-10-27 第二阶段）。
   *
   * <p>低落时人不会"宣布我不想说话"，而是**话变少**。所以这里直接压分段数，
   * 而不是在提示词里写"心情不好要少说" —— 那样她会演出来。</p>
   *
   * <p>高兴时最多 +1 段，不能放飞：她的人设是"话不多"，
   * 情绪只该调程度，不该改性格。</p>
   */
  const affectNow = mergedAffect();
  const baseSeg = Number(cfg.maxSegments) || 4;
  const segLimit = affectNow.p < -0.4
    ? Math.max(1, Math.ceil(baseSeg / 2))
    : affectNow.p > 0.45
      ? baseSeg + 1
      : baseSeg;

  const segs = splitText(text, segLimit, Number(cfg.maxSegmentChars))
    .map(stripEndPunctuation)
    // 整段的括号旁白直接丢掉（2026-10-23）
    .map(stripStageDirection)
    .filter((s) => s.length > 0);
  if (segs.length === 0) {
    diag('humanSend: 剥掉旁白后没有正文，未发送');
    return;
  }

  /*
   * 省略号降频（2026-10-22）。
   *
   * 真人偶尔会用省略号，但**每句都用**就是机器习惯 —— 实测她几乎每段末尾都挂 `……`。
   * 一次回复里最多保留一个（优先最后一段：结尾的省略号才有"话没说完"的意思）。
   *
   * 同时把 `……` / `。。。` / `...` 归一成单个 `…`，视觉上更轻。
   */
  const deduped = capEllipsis(segs, 1);
  segs.length = 0;
  segs.push(...deduped);

  /*
   * 调度（2026-10-23 改）：语音只作用在**最后一段**。
   *
   * 真人发语音也是这样 —— 打两句字铺垫，最后那句难为情的用声音说。
   * 而原来的做法是整条一起转，她的分段节奏直接消失。
   *
   * 判断用的是**最后一段的长度**（不是整条），因为只有它会进 TTS。
   */
  /*
   * 她指定了内容（`[语音 那句话]`）→ 就直接用那段做语音（2026-10-23）。
   *
   * 这比按长度猜准得多，也是她自己表达"哪句要用声音说"的出口。
   * 其余部分照常打字 —— 所以形态天然就是"打字铺垫 + 一句语音"。
   *
   * 注意：这里**不再走 decideVoiceMode**，因为她已经明确指定了，
   * 再叠一层概率/冷却只会让她的话说不出来。
   */
  if (voiceMark.spoken) {
    if (segs.length > 0) {
      await sendTextSegments(isPrivate, peer, segs);
    }
    if (await sendVoiceMsg(isPrivate, peer, voiceMark.spoken)) {
      return;
    }
    // TTS 失败 → 把那句当文字补发，别让她想说的话消失
    await sendTextSegments(isPrivate, peer, [voiceMark.spoken]);
    return;
  }

  const voiceMode = decideVoiceMode(text, segs, voiceMark.voice);

  if (voiceMode === 'whole') {
    /*
     * 整条语音（2026-10-23）。
     *
     * 用「，」把各段连起来，而不是丢原文给 TTS —— 原文里的 `\n` 它基本无视，
     * 会把"……行吧 / 别催了 / 那我叫你一声"念成一口气。换成逗号就有自然停顿，
     * 既保留了她分段时的节奏，又是一条完整的语音。
     */
    if (await sendVoiceMsg(isPrivate, peer, segs.join('，'))) {
      return;
    }
    // 语音没成功 → 落到下面走文字，别把这条回复丢了
  } else if (voiceMode === 'tail') {
    // 打字铺垫 + 尾句语音
    const lastSeg = segs.pop();
    if (segs.length > 0) {
      await sendTextSegments(isPrivate, peer, segs);
    }
    if (await sendVoiceMsg(isPrivate, peer, lastSeg)) {
      return;
    }
    await sendTextSegments(isPrivate, peer, [lastSeg]);
    return;
  }

  await sendTextSegments(isPrivate, peer, segs);

  /*
   * 表情包（2026-10-25 改：**去掉概率**）。
   *
   * 原来 `Math.random() < stickerChance` 抽签 —— 它不知道语境：
   * 说完"我不想理你"照样可能附一张哈哈笑的表情。现在只在她自己写了
   * `[表情 开心]` 时才发，把"要不要配图、配什么情绪"完全交给她判断。
   *
   * 库里没有对应情绪时会退到「通用」，还没有就静默不发。
   */
  if (stickerMark.mood) {
    await sendStickerNow(isPrivate, peer, stickerMark.mood);
  }

  /*
   * 发图（2026-10-26）：文字发完后再把 `[发图 xxx]` 那张补上。
   *
   * 顺序是「先说一句 → 再甩图」—— 真人也这样，不会一上来就发图不说话。
   * 注意 processMessage 里也有一段同样的处理：那边已经把标记剥掉了，
   * 到这里 `keyword` 是 null，不会重复发。
   */
  if (imgMark.keyword !== null) {
    await sendImageByMark(isPrivate, peer, imgMark.keyword);
  }
  // 正文里的裸图片链接（2026-10-28）：正文已经发出去了，这里把图补上
  for (const u of bareImg.urls) {
    await sendImageByMark(isPrivate, peer, u);
  }
  }

// ------------------------------------------------------------------ 日记与印象（2026-10-21）

/** 日记文件里最多保留多少条（防无限增长；纯文本，grep / 手改都方便）。 */
const DIARY_MAX = 500;

// 日记已并入 memory/self.json、印象已并入 memory/facts.json（2026-10-28）
// —— 旧的 diary.jsonl / impressions.json 不再读写，原文件留在 memory/_legacy/ 里

function fmtNow() {
  const n = new Date();
  const p = (x) => String(x).padStart(2, '0');
  return `${n.getFullYear()}-${p(n.getMonth() + 1)}-${p(n.getDate())} ${p(n.getHours())}:${p(n.getMinutes())}`;
}

/** 读最近几条日记（新的在后）。 */
/**
 * 读最近几篇日记（2026-10-28 改从 `self.json` 读）。
 *
 * <p>返回字段保持 `{ time, mood, text }` —— 调用方（timeContext）用的是 `d.time`，
 * 而新存储里是 `at` 时间戳，这里转一下，免得改一圈调用点。</p>
 */
function readDiary(limit = 2) {
  const s = readSelf();
  const pad = (n) => String(n).padStart(2, '0');
  return s.diary.slice(-limit).map((d) => {
    const t = new Date(Number(d.at) || 0);
    return {
      time: `${t.getFullYear()}-${pad(t.getMonth() + 1)}-${pad(t.getDate())} `
        + `${pad(t.getHours())}:${pad(t.getMinutes())}`,
      mood: d.mood || '',
      text: d.text || '',
    };
  });
}

/**
 * 注入用的日记（2026-11-01）。
 *
 * <p><b>为什么不是简单的"取最近 1 条"</b>：日记有 500 条上限，只增不减。
 * 而注入时永远只看最近一条 —— 更早写的那些**永远不会被看到**，等于存了不用。</p>
 *
 * <p><b>但也不能一次塞很多</b>：日记是文艺腔，塞多了她会在正文里跟着写景
 * （历史教训：注入整篇日记后，她的回复变成"光挪到一寸"那种）。</p>
 *
 * <p>折中：**始终带最近的 1 条**，另有 20% 概率再带一条 **3 天以前**的 ——
 * 偶尔想起旧事像真的，天天翻就不像了。</p>
 */
function pickDiaryForPrompt() {
  const s = readSelf();
  const list = Array.isArray(s.diary) ? s.diary : [];
  if (list.length === 0) {
    return [];
  }
  const pad = (x) => String(x).padStart(2, "0");
  const fmt = (d) => {
    const t = new Date(Number(d.at) || 0);
    return {
      time: `${t.getFullYear()}-${pad(t.getMonth() + 1)}-${pad(t.getDate())} `
        + `${pad(t.getHours())}:${pad(t.getMinutes())}`,
      mood: d.mood || "",
      text: d.text || "",
    };
  };

  const latest = list[list.length - 1];
  const out = [fmt(latest)];

  // 20% 概率再捞一条 3 天以前的
  if (list.length > 1 && Math.random() < 0.2) {
    const cutoff = Date.now() - 3 * 86400000;
    const older = list.slice(0, -1).filter((d) => (Number(d.at) || 0) < cutoff);
    if (older.length > 0) {
      out.push(fmt(older[Math.floor(Math.random() * older.length)]));
    }
  }
  return out;
}

/**
 * 追加一篇日记（2026-10-28 写进 `self.json`）。
 *
 * <p>入参还是老的 `{ time, mood, text }`，这里转成 `{ at, mood, text }` ——
 * `time` 是给人看的字符串，`at` 才能排序和算间隔。</p>
 */
function appendDiary(entry) {
  try {
    const raw = entry || {};
    let at = Date.now();
    if (raw.time) {
      // "2026-10-21 11:09" → 时间戳；解析失败就用当前时间
      const t = Date.parse(String(raw.time).replace(' ', 'T'));
      if (Number.isFinite(t)) {
        at = t;
      }
    }
    patchSelf((s) => {
      s.diary.push({
        at,
        mood: String(raw.mood || ''),
        text: String(raw.text || '').slice(0, 800),
      });
      // 防无限增长
      if (s.diary.length > DIARY_MAX) {
        s.diary = s.diary.slice(-DIARY_MAX);
      }
    });
    return true;
  } catch (e) {
    diag(`diary write failed: ${e.message}`);
    return false;
  }
}

// ------------------------------------------------------------------ 关于"她"的评价（2026-10-22）

/** 最近留多少条"别人说她什么"。多了会挤占自我检视的上下文。 */
const SELF_NOTE_MAX = 20;

// 「别人怎么评价她」已并入 memory/self.json 的 notes（2026-10-28）

/** 与她本人相关的评价词（头像 / 说话方式 / 性格 / 像不像人）。 */
/*
 * 「别人在评价她」的关键词（2026-11-01 收紧）。
 *
 * <p><b>为什么删掉「说话」「装」「名字」</b>：这三个太宽，
 * 把调情和日常闲聊也当成评价存进了 self.json 的 notes。实测存进去的有：</p>
 * <pre>
 *   不要不要，别叫名字，这个名字是网名啦          ← 命中「名字」
 *   宝，说起来，你会反感我和别的女生说话呀        ← 命中「说话」
 *   嘿嘿，你不能装作没看见呢。那我说，如果捏一下…  ← 命中「装」
 * </pre>
 *
 * <p>这些**不是评价**，是对方在跟她调情。存进 notes 的后果是：
 * 她独处时会以为「有人说过我名字不好」，然后莫名其妙想改昵称。</p>
 *
 * <p>保留的都是**明确的负面评价或修改建议** —— 只有这些才值得她事后掂量。</p>
 */
const SELF_NOTE_HINTS = /头像|签名|昵称|语气|口吻|性格|烦人|好烦|无聊|机械|机器人|像AI|不像人|很假|丑|难看|换个|改改|不好看|太冷|太硬|不像你/;

/**
 * 记下"别人怎么评价她"（2026-10-22）。
 *
 * <p><b>为什么需要这一步</b>：她的自我检视是定时的独处时刻，但它一直不知道
 * "刚才有人说过我头像丑"。没有素材，就不可能有"回想起那句话、自己掂量一下"
 * 这个环节 —— 剩下的只有"被说一句立刻照做"，那是工具，不是人。</p>
 *
 * <p>所以这里只做一件事：把**关于她的评价**存下来，等下次独处时拿给她看。
 * 判断"该不该改"仍然是她自己做，插件不替她决定。</p>
 */
function noteAboutSelf(text, from) {
  const t = String(text || '').trim();
  if (!t || t.length > 120) {
    return;
  }
  // 必须是在说她（"你"），否则路人聊八卦也会被记进来
  if (!t.includes('你') && !t.includes('妳')) {
    return;
  }
  if (!SELF_NOTE_HINTS.test(t)) {
    return;
  }
  /*
   * 疑问句不是评价（2026-11-01）。
   *
   * <p>「你会反感我和别的女生说话吗」这类是**在问她**，不是**在评价她**。
   * 以问号 / 吗 / 呢 / 呀 / 嘛结尾的，一律不进 notes。</p>
   */
  if (/[?？]$/.test(t) || /[吗呢呀嘛]$/.test(t)) {
    return;
  }
  // 2026-10-28：写进统一的 self.json（notes 数组），不再单独一个 jsonl
  patchSelf((s) => {
    s.notes.push({ at: Date.now(), from: from || '某人', text: t });
    if (s.notes.length > SELF_NOTE_MAX) {
      s.notes = s.notes.slice(-SELF_NOTE_MAX);
    }
  });
}

/** 读最近几条"别人说她什么"（新的在后）。 */
function readSelfNotes(limit = 5) {
  // 2026-10-28：从 self.json 的 notes 读；返回字段保持 { time, from, text }
  const s = readSelf();
  const pad = (n) => String(n).padStart(2, '0');
  return s.notes.slice(-limit).map((n) => {
    const t = new Date(Number(n.at) || 0);
    return {
      time: `${t.getFullYear()}-${pad(t.getMonth() + 1)}-${pad(t.getDate())} `
        + `${pad(t.getHours())}:${pad(t.getMinutes())}`,
      from: n.from || '',
      text: n.text || '',
    };
  });
}

// ------------------------------------------------------------------ 图库（2026-10-21）

function galleryDir() {
  return path.join(api.dataDir, 'gallery');
}

function readGallery(limit = 2) {
  try {
    const lines = fs.readFileSync(path.join(galleryDir(), 'index.jsonl'), 'utf8').split('\n').filter(Boolean);
    return lines.slice(-limit).map((line) => {
      try {
        return JSON.parse(line);
      } catch {
        return null;
      }
    }).filter(Boolean);
  } catch {
    return [];
  }
}

/**
 * 存一张图进"她自己的相册"。
 *
 * <p>参考同类项目的做法：**意义不在图，在于"她挑"**。所以入口不是"收到图就存"，
 * 而是模型在回复里说 `[收藏 理由]` 才存 —— 决定权在它。</p>
 */
function saveToGallery(base64, reason) {
  try {
    const dir = galleryDir();
    fs.mkdirSync(dir, { recursive: true });
    const name = `img_${Date.now()}.png`;
    fs.writeFileSync(path.join(dir, name), Buffer.from(base64, 'base64'));
    fs.appendFileSync(
      path.join(dir, 'index.jsonl'),
      JSON.stringify({ file: name, reason: reason || '', time: fmtNow() }) + '\n',
      'utf8',
    );
    diag(`gallery: 收藏 ${name}（${reason || '无理由'}）`);
    return true;
  } catch (e) {
    diag(`gallery save failed: ${e.message}`);
    return false;
  }
}

/** 从回复里抽出 `[收藏 理由]`，返回去掉标记后的文本与理由。 */
function extractCollect(text) {
  const raw = String(text || '');
  const m = raw.match(/\[收藏[：:\s]*([^\]]{1,40})\]/);
  if (!m) {
    return { text: raw, reason: null };
  }
  return { text: raw.replace(m[0], '').trim(), reason: m[1].trim() };
}

/**
 * 最近更新过的几条印象（2026-10-21）。
 *
 * <p>给自我检视用：它要"按对这个人的认知"做事（主动搭话、以后点赞评论），
 * 就得先知道自己怎么看这些人。只取最近更新的，避免上下文被所有好友塞满。</p>
 */
function recentImpressions(limit = 5) {
  // 2026-10-28：从统一记忆里读 relation 事实
  const all = readFacts();
  return Object.entries(all)
    .map(([peer, box]) => {
      const rel = normalizeFact(box && box.relation);
      return rel ? { peer, text: rel.value, at: rel.lastAt } : null;
    })
    .filter(Boolean)
    .sort((a, b) => (b.at || 0) - (a.at || 0))
    .slice(0, limit)
    .map(({ peer, text }) => ({ peer, text }));
}

// ------------------------------------------------------------------ 最近收到的图（2026-10-22）

/**
 * 最近一次收到的图片 base64。
 *
 * <p><b>解决什么</b>：用户直接发一张图说"用这个"，她手上只有平台的 fileId
 * （`{type:'image', fileId}`），**拿不到原图地址**，而 `set_qq_avatar` 要的是
 * base64 或 URL —— 于是她说"好"却换不了。</p>
 *
 * <p>上传成功后顺手留一份，她写 `[换这张]` 时直接用。</p>
 */
let lastReceivedImage = null;

/** 从回复里抽 `[换这张]` / `[换刚才那张]`。 */
function extractUseReceivedImage(text) {
  const raw = String(text || '');
  const m = raw.match(/\[换(?:这张|刚才那张|你刚收到的)\]/);
  if (!m) {
    return { text: raw, use: false };
  }
  return { text: raw.replace(m[0], '').trim(), use: true };
}

/**
 * 用「对方刚发的那张图」换头像。
 *
 * <p>30 分钟内有效 —— 太久以前的那张，她大概已经不记得上下文了，
 * 硬换容易出现"她说的明明是上一张，换上的是更早一张"。</p>
 */
/**
 * 用「最近那张图」换头像（2026-10-22 扩展为两个来源）。
 *
 * <p>优先用**她刚发出去的那张**：场景几乎总是"她挑了张发给你 → 你说就这个 → 她换"。
 * 没有则退到"你刚发给她的那张"。</p>
 *
 * <p>30 分钟有效 —— 更早的图她大概已经忘了上下文，硬换容易张冠李戴。</p>
 */
async function tryUseReceivedAvatar() {
  const sent = lastSentImage;
  const recv = lastReceivedImage;
  let pick = null;
  if (sent && (!recv || sent.at >= recv.at)) {
    pick = { ...sent, from: '她发的', hint: '她自己挑的' };
  } else if (recv) {
    pick = { ...recv, from: '你发的', hint: '对方给的' };
  }
  if (!pick) {
    diag('use received: 没有可用的最近图片');
    return;
  }
  const ageMin = (Date.now() - pick.at) / 60000;
  if (ageMin > 30) {
    diag(`use received: 那张图是 ${Math.round(ageMin)} 分钟前的，太久了，忽略`);
    return;
  }
  try {
    await call('set_qq_avatar', { file: 'base64://' + pick.base64 }, 30000);
    const name = saveAvatarToPool(pick.base64, pick.hint);
    selfState.avatar = Date.now() + randomDays(cfg.avatarCooldownDays || [7, 30]);
    saveSelfState();
    diag(`avatar <- ${pick.from}图（已存 ${name}）`);
  } catch (e) {
    diag(`use received failed: ${e.message}`);
  }
}

// ------------------------------------------------------------------ 会话版本（2026-10-22）

/**
 * peer → 会话版本号。改动它会**开启一段全新对话**。
 *
 * <p><b>为什么用版本号而不是删数据</b>：平台的会话历史按 `sessionId` 分组存在
 * `message` 表里，而平台**没有删除会话的接口**（只有删 agent / 字典 / 日志）。
 * 直接在 DB 里删太危险。
 *
 * <p>所以换个思路：把 `sessionId` 后面加个 `:e<N>`，`N` 一变，平台就当成陌生会话 ——
 * 拿不到任何历史。旧消息原样留在库里（要查还能查），但不会再被带进提示词。</p>
 *
 * <p><b>什么时候需要它</b>：改了智能体的系统提示词之后。旧对话是按旧人格说的，
 * 新人格 + 旧记忆混在一起，它会"接不上自己"。清一次就干净了。</p>
 */
let sessionEpochs = {};

function sessionsPath() {
  return path.join(api.dataDir, 'sessions.json');
}

function loadSessionEpochs() {
  try {
    sessionEpochs = JSON.parse(fs.readFileSync(sessionsPath(), 'utf8')) || {};
  } catch {
    sessionEpochs = {};
  }
}

function saveSessionEpochs() {
  try {
    fs.writeFileSync(sessionsPath(), JSON.stringify(sessionEpochs, null, 2), 'utf8');
  } catch (e) {
    diag(`save sessions failed: ${e.message}`);
  }
}

/** 该 peer 的会话版本（0 = 从未重置）。 */
function sessionEpochOf(peer) {
  return Number(sessionEpochs[String(peer)] || 0);
}

/**
 * 跟某人的**真实对话**会话 ID（2026-10-23）。
 *
 * <p><b>必须带 epoch</b>：`/clear` 之后正常对话走 `qq:private:...:e2`，
 * 而如果别处用了不带后缀的 `qq:private:...`，那就是**另一个会话** ——
 * 历史完全不互通。</p>
 *
 * <p>实测踩到：主动发言用的就是不带 suffix 的版本，于是她主动说了一句、
 * 用户回过来时，她读到的上下文还是主动发言**之前**的，说话驴唇不对马嘴。</p>
 *
 * <p>凡是要"接着这段对话往下说"的地方（对话、印象总结、主动发言、待办触达）
 * 都必须走这个函数，不要自己拼。</p>
 */
function dialogSessionId(peer) {
  const epoch = sessionEpochOf(peer);
  return `qq:private:${stats.uin}:${peer}` + (epoch > 0 ? `:e${epoch}` : '');
}

/**
 * 系统注入标记（2026-10-23）。
 *
 * <p>插件有几处需要「以系统身份」让模型做事：主动发言、总结印象、提醒待办。
 * 但平台的 `/agent/run` 只有 `user` 角色 —— 这些话会被当成**对方真的说了**
 * 存进历史。四十轮上下文里堆着</p>
 * <pre>
 * user:      （现在是下午 3 点，离上次聊天 2 小时。你想说点什么就说一句…）
 * assistant: 在吗，也没什么要紧事…
 * user:      在写代码
 * </pre>
 * <p>模型看不出第一句其实是"系统让我说的"，容易把它当成对方的话去回应，
 * 也可能在后续对话里把这段指令当成事实。</p>
 *
 * <p>包一层显眼的标记后，历史里一眼可辨。</p>
 */
const SYS_HINT_OPEN = '【系统提示 · 不是对方说的话】';
const SYS_HINT_CLOSE = '【系统提示结束】';

/** 把一段"系统要说的话"包起来，避免被当成对方发言。 */
function sysHint(inner) {
  return `${SYS_HINT_OPEN}\n${String(inner || '').trim()}\n${SYS_HINT_CLOSE}`;
}

// ------------------------------------------------------------------ 联系人活跃度落盘（2026-10-23）

/**
 * `recentContacts`（谁找过她、聊了几句）落盘。
 *
 * <p><b>为什么必须落盘</b>：它是 `const recentContacts = new Map()` —— 纯内存，
 * **重启就清零**。而「印象」的门槛是「聊够 20 句」（{@code maybeUpdateImpressions}），
 * 于是每次重启都要重新攒 20 句；开发期一天重启十几次，`impressions.json`
 * **至今一条都没生成过** —— 她永远对每个人"第一次见"。</p>
 *
 * <p>这也顺带修了主动发言：候选范围同样依赖这张表，重启后它会以为谁都没聊过。</p>
 */
function recentContactsPath() {
  return path.join(api.dataDir, 'recent-contacts.json');
}

function loadRecentContacts() {
  try {
    const raw = JSON.parse(fs.readFileSync(recentContactsPath(), 'utf8')) || {};
    for (const [k, v] of Object.entries(raw)) {
      const n = Number(k);
      if (Number.isFinite(n) && v && typeof v === 'object') {
        recentContacts.set(n, v);
      }
    }
    if (recentContacts.size > 0) {
      diag(`recent contacts loaded: ${recentContacts.size} 人`);
    }
  } catch {
    // 没有这个文件是正常的（第一次运行）
  }
}

function saveRecentContacts() {
  try {
    const obj = {};
    for (const [k, v] of recentContacts.entries()) {
      obj[String(k)] = v;
    }
    fs.writeFileSync(recentContactsPath(), JSON.stringify(obj, null, 2), 'utf8');
  } catch (e) {
    diag(`save recent contacts failed: ${e.message}`);
  }
}

// ------------------------------------------------------------------ 对话尾巴（2026-10-27）

/**
 * 每个联系人**最近两轮**说了什么。
 *
 * <p><b>为什么需要单独存</b>：主动发言时，她的上下文里有 20 轮历史 —— 但那些内容
 * 混在几百行里，她注意不到"最后一句话是什么"。实测她主动开口时说的是
 * 「雾散了，桌子边上那块光动了半寸」，而前一句明明是她自己问的「你课上到哪儿了」。</p>
 *
 * <p>把那两行单独拎出来放在提示词顶部，她才有个"接着说什么"的锚点。
 * **这不是模板，是真实数据** —— 不会被照抄成固定句式。</p>
 */
/*
 * 插件侧保留的对话轮数（2026-11-01 从 2 提到 6）。
 *
 * <p><b>为什么 2 太少</b>：主动发言的上下文全靠它（{@code tailBlock()}）。
 * 只留 2 轮 = 4 条消息，她"接着刚才聊的往下说"时几乎没有可接的东西，
 * 于是只能自己编 —— 这就是"她读到的上文不对"的直接原因。</p>
 *
 * <p>6 轮 ≈ 12 条 × 120 字 ≈ 1440 字，可接受。平台侧另有 12 轮
 * （{@code maxHistoryTurns}），两边不冲突：平台管"这一轮怎么回"，
 * 这里管"没事找话说的时候接什么"。</p>
 */
const TAIL_MAX_TURNS = 6;

function tailPath() {
  return path.join(api.dataDir, 'conversation-tail.json');
}

/**
 * 「互道晚安后就不再回复」的规则兜底（2026-10-31）。
 *
 * <p>提示词里已经写了"互道晚安就停"，但模型不一定遵守 —— 它倾向于
 * 对每句话都回一句。而这件事可以纯规则判断：</p>
 *
 * <pre>
 *   对方这句是道别（晚安 / 睡了 / 去睡了…）
 *   + 她上一条也说过晚安（晚安 / 早点睡 / 明天见）
 *   → 这轮直接结束，不调模型也不发任何内容
 * </pre>
 *
 * <p><b>为什么值得单独做一条规则</b>：晚间最容易多回一句，
 * 而多出来的那句"嗯，你也早点睡"会把一天结束的感觉破坏掉。</p>
 *
 * <p>只在私聊生效 —— 群里说晚安是客套，不该触发沉默。</p>
 *
 * @returns true 表示应该沉默
 */
/**
 * 「这轮不必回复」的规则判断（2026-10-31）。
 *
 * <p><b>为什么需要一层规则</b>：提示词已经写了 7 种该沉默的场景，但模型
 * 倾向于对每句话都回一句 —— 尤其是"附和"这类，它会把"嗯"也当成需要接的话。
 * 而其中几种**模式明确、误判风险低**，纯规则就能判掉。</p>
 *
 * <p><b>只做能确定的三类</b>，需要理解语境的一律交给模型：</p>
 * <ol>
 *   <li>互道晚安 —— 双方都说过道别，再回就是多余；</li>
 *   <li>纯标点或纯表情 —— 没有任何文字内容；</li>
 *   <li>完全重复的上一条 —— 多半是网络重发或手滑。</li>
 * </ol>
 *
 * <p>其余情况（话题是否结束、是不是在跟别人说话）规则判不准，交给模型。</p>
 *
 * @returns {string|null} 返回沉默原因；null 表示应该正常回复
 */
function shouldStaySilent(peer, text, isPrivate) {
  const t = String(text || '').trim();
  if (!t) {
    return '空消息';
  }

  // ① 互道晚安（只在私聊）
  if (isPrivate && isMutualGoodnight(peer, t)) {
    return '互道晚安';
  }

  // ② 纯标点 / 纯表情：整条没有任何文字或数字
  if (!/[\u4e00-\u9fa5A-Za-z0-9]/.test(t)) {
    return '纯标点或表情';
  }


  /*
   * 原来这里还有一条「和上一条完全重复 → 不回」（2026-11-01 删）。
   *
   * 删的原因有两条：
   *   ① **多余** —— 5 秒 debounce 已经把连发的消息合并成一次调用了
   *      （见 enqueue/flush），根本走不到这条判断；
   *   ② **致命** —— 它写在 rememberTurn 之后，此时 tail 末尾就是当前这句，
   *      自己和自己比永远相同，于是**所有私聊消息都被判成重复、直接丢弃**。
   *
   * 间隔超过 5 秒的重发即使回两次也无害，不值得为它冒全盘误杀的风险。
   */
  return null;
}

function isMutualGoodnight(peer, text) {
  const t = String(text || '').trim();
  if (!t) {
    return false;
  }
  if (!/^(晚安|睡了|去睡了?|睡觉了?|困了|先睡|我睡|早点睡)/.test(t)) {
    return false;
  }
  const map = readTailMap();
  const list = map[String(peer)];
  if (!Array.isArray(list) || list.length === 0) {
    return false;
  }
  // 从后往前找她最后一条
  for (let i = list.length - 1; i >= 0; i--) {
    const m = list[i];
    if (m && m.role === 'assistant') {
      return /晚安|早点睡|明天见|睡了/.test(String(m.text || ''));
    }
  }
  return false;
}

function readTailMap() {
  try {
    const raw = JSON.parse(fs.readFileSync(tailPath(), 'utf8'));
    return raw && typeof raw === 'object' ? raw : {};
  } catch {
    return {};
  }
}

function writeTailMap(obj) {
  try {
    fs.writeFileSync(tailPath(), JSON.stringify(obj, null, 2), 'utf8');
  } catch (e) {
    diag(`conversation tail save failed: ${e.message}`);
  }
}

/**
 * 记一条对话。
 *
 * @param role 'user' 表示对方说的，'assistant' 表示她说的
 */
function rememberTurn(peer, role, text) {
  const t = String(text || '').trim();
  if (!t) {
    return;
  }
  // 注入前缀、CQ 码不该进这里 —— 它要原样摆给她看
  const clean = t
    .replace(/\[CQ:[^\]]+\]/g, '')
    .replace(/【[^】]*】/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 120);
  if (!clean) {
    return;
  }
  const map = readTailMap();
  const key = String(peer);
  const list = Array.isArray(map[key]) ? map[key] : [];
  list.push({ role, text: clean, at: Date.now() });
  // 只留最近 N 轮（一轮 = 他说 + 她说，所以条数取 2 倍）
  map[key] = list.slice(-TAIL_MAX_TURNS * 2);
  writeTailMap(map);
}

/**
 * 这次主动发言**需不需要去网上找话题**（2026-10-27）。
 *
 * <p>不按"开关一开就抓"来 —— 那样每次主动都白调一次榜单，而且她会硬套。</p>
 *
 * <p>判据是**手上还有没有话题**：</p>
 * <ol>
 *   <li><b>正在追发</b>（已经连发过、对方没回）—— 她有点被晾着的感觉，
 *       最想要个能引起回应的话题，所以**优先去看**；</li>
 *   <li>没有对话尾巴（第一次找这个人）—— 完全没素材；</li>
 *   <li>最后一条是**她说的**（话题悬着，对方没接，她也没新东西）；</li>
 *   <li>最后一条是对方说的，但**已经过了半小时以上** —— 那轮话题自然结束了。</li>
 * </ol>
 *
 * <p>反过来，如果刚刚才聊完（对方最后说话，还没过多久），
 * 她有得接，就不该跑去念榜单。</p>
 */
function needFreshTopic(peer) {
  /*
   * 注意：这里**不用判断"是否在追发"**。
   *
   * 追发走的是 maybeProactive 里的另一条分支，到不了这段 ——
   * 而且追发本来就**不该**去找新话题：那是"被晾着、心里发闷"的时刻，
   * 不是"没素材、想找点乐子"的时刻。这时候跑去念榜单反而更假。
   */
  const map = readTailMap();
  const list = map[String(peer)];
  // ② 从没聊过 → 没素材
  if (!Array.isArray(list) || list.length === 0) {
    return true;
  }

  const last = list[list.length - 1];
  if (last.role === 'assistant') {
    /*
     * ③ 最后一条是**她说的** —— 这时候"话题还在"，不是结束了（2026-10-27 修）。
     *
     * 原来这里直接 return true（去抓热门），但那是错的：她刚问完话、
     * 等对方回呢，这时候跑去念榜单，等于**把等回应换成了找乐子** ——
     * 真人这时候只会追问或者闷着，不会突然聊起别的新鲜事。
     *
     * 只有这条线彻底断了（两小时还没人应），才当作"话题结束"。
     */
    return Date.now() - (last.at || 0) > 2 * 3600000;
  }

  // ④ 对方最后说话，但过了很久 → 那轮话题算结束了
  const idleMs = Date.now() - (last.at || 0);
  return idleMs > 30 * 60 * 1000;
}

/** WMO 天气码 → 中文（只取常见的几档，够用了）。 */
function weatherCodeText(code) {
  const c = Number(code);
  if (!Number.isFinite(c)) {
    return '';
  }
  if (c === 0) {
    return '晴';
  }
  if (c <= 3) {
    return '多云';
  }
  if (c <= 48) {
    return '有雾';
  }
  if (c <= 57) {
    return '毛毛雨';
  }
  if (c <= 67) {
    return '下雨';
  }
  if (c <= 77) {
    return '下雪';
  }
  if (c <= 82) {
    return '阵雨';
  }
  if (c <= 86) {
    return '阵雪';
  }
  return '雷雨';
}

/**
 * 今天的天气（2026-10-28）。
 *
 * <p><b>为什么需要</b>：她主动开口时的话题素材只有「B 站热门」和「她自己的画」，
 * 于是长期绕在同一件事上。天气是**唯一同时满足"每天变"和"跟他有关"**的素材 ——
 * 真人早上开口也常常是这个（"今天降温了，你加件衣服"）。</p>
 *
 * <p>走 Open-Meteo：**免费、无需 key、国内可访问**，实测 1.2 秒返回。
 * 失败返回空串，不影响主动发言本身。</p>
 */
async function todayWeather() {
  if (cfg.weatherEnabled === false) {
    return '';
  }
  const city = String(cfg.weatherCity || '合肥').trim();
  const coords = String(cfg.weatherCoords || '31.86,117.28');
  const nums = coords.split(',').map((s) => Number(s.trim()));
  if (nums.length !== 2 || !nums.every((n) => Number.isFinite(n))) {
    diag(`weather: 坐标写坏了（${coords}）`);
    return '';
  }
  try {
    const url = 'https://api.open-meteo.com/v1/forecast'
      + `?latitude=${nums[0]}&longitude=${nums[1]}`
      + '&current=temperature_2m,weather_code'
      + '&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max'
      + '&timezone=Asia%2FShanghai&forecast_days=1';
    const res = await fetch(url, { signal: AbortSignal.timeout(10000) });
    if (!res.ok) {
      diag(`weather: HTTP ${res.status}`);
      return '';
    }
    const j = await res.json();
    const cur = Number(j?.current?.temperature_2m);
    const desc = weatherCodeText(j?.current?.weather_code);
    const hi = Number(j?.daily?.temperature_2m_max?.[0]);
    const lo = Number(j?.daily?.temperature_2m_min?.[0]);
    const rain = Number(j?.daily?.precipitation_probability_max?.[0]);

    const parts = [];
    if (Number.isFinite(cur)) {
      parts.push(`现在 ${Math.round(cur)} 度`);
    }
    if (Number.isFinite(hi) && Number.isFinite(lo)) {
      parts.push(`今天 ${Math.round(lo)}~${Math.round(hi)} 度`);
    }
    if (desc) {
      parts.push(desc);
    }
    // 降水概率低于 30% 就不提了，免得每句话都"降水概率 10%"
    if (Number.isFinite(rain) && rain >= 30) {
      parts.push(`降水概率 ${Math.round(rain)}%`);
    }
    if (parts.length === 0) {
      return '';
    }
    diag(`weather: ${city} ${parts.join('，')}`);
    return `${city}，${parts.join('，')}`;
  } catch (e) {
    diag(`weather failed: ${e.message}`);
    return '';
  }
}

/** 相对时间（"刚刚 / 12 分钟前 / 3 小时前 / 2 天前"）。 */
function relTime(at) {
  const mins = Math.floor((Date.now() - (at || 0)) / 60000);
  if (mins < 1) {
    return '刚刚';
  }
  if (mins < 60) {
    return `${mins} 分钟前`;
  }
  if (mins < 1440) {
    return `${Math.floor(mins / 60)} 小时前`;
  }
  return `${Math.floor(mins / 1440)} 天前`;
}

/**
 * 取出最近几轮，渲染成一段（给主动发言用）。
 *
 * <p><b>必须带时间距离</b>（2026-10-28）。原来标题写死「你们刚聊到」——
 * 昨晚十一点的对话，第二天中午触发主动发言时也标成"刚聊到"，
 * 于是她接着昨晚的话题往下说（"那个光是不是又挪了"），非常出戏。</p>
 *
 * <p>真人隔了十几个小时再说，开口方式完全不同：不会续上半句，
 * 而是"中午了，吃了没"。</p>
 */
function tailBlock(peer, turns = TAIL_MAX_TURNS) {
  const map = readTailMap();
  const list = map[String(peer)];
  if (!Array.isArray(list) || list.length === 0) {
    return '';
  }
  const recent = list.slice(-turns * 2);
  const lastAt = recent[recent.length - 1].at || 0;
  const gapMins = Math.floor((Date.now() - lastAt) / 60000);

  // 半小时内才算"刚聊到"，再久就是"上次"了
  const head = gapMins < 30
    ? '【你们刚聊到】'
    : `【你们上次聊到（${relTime(lastAt)}）】`;
  const parts = ['', head];
  for (const t of recent) {
    parts.push(`  ${t.role === 'user' ? '他' : '你'}：${t.text}`);
  }
  /*
   * 隔得久了要**明说别硬接**（2026-10-28）。
   *
   * 只给方向、不给台词 —— 写成示例（"中午了，吃了没"）会被原样照抄。
   */
  if (gapMins >= 180) {
    parts.push('  （上面是隔了一段时间的旧对话。别顺着它往下接，当成重新开口。）');
  }
  return parts.join('\n');
}

// ------------------------------------------------------------------ 事件流（2026-10-24）

/**
 * 「别人对她说过什么」的流水账。
 *
 * <p><b>为什么只记别人说的</b>：主人说的**不进流** —— 不是事后过滤，是根本不写。
 * 这样事件流本身就不含主人的任何隐私：给主人看绝对安全，
 * 而别人也看不到（{@code timeContext} 只对 owner 注入这一段）。</p>
 *
 * <p><b>解决什么</b>：会话是按人隔离的（墨染的对话金粟看不见），所以她没法把
 * "刚才有人来打听你"带到主人那边。有了事件流，主人来找她时她至少知道
 * "今天发生过什么"，主动发言也终于有素材了。</p>
 *
 * <p><b>只留 24 小时</b>：它记的是"今天"，不是"历史"。历史那条线交给日记和印象。</p>
 */
const EVENT_TTL_MS = 24 * 3600000;
/** 事件文件最多保留多少条（防无限增长）。 */
const EVENT_MAX = 500;

/**
 * 把「别人今天说过什么」渲染成一段（只给主人看）。
 *
 * <p>2026-10-28：数据源换成统一的 `memory/events.jsonl`，按 `kind=other` 过滤 ——
 * 同一条流里还有她自己的日记、答应的事、被忽视的记录，不过滤会串味。</p>
 */
function eventBlock() {
  /*
   * 只读 public 文件（2026-11-01 存储层隔离）。
   *
   * 原来用 recentEvents({ kind: 'other' }) —— 那是**查询层**过滤，
   * 一旦过滤条件写错、或者以后有人新写读取函数忘了过滤，
   * 私聊内容就漏进群聊。现在这个函数本身就碰不到 owner/stage 文件。
   *
   * 返回倒序（最新的在前），与 recentEvents 的约定一致。
   */
  const now = Date.now();
  const evs = readPublicEvents()
    .filter((e) => now - (e.at || 0) <= EVENT_TTL_MS)
    .slice(-8)
    .reverse();
  if (evs.length === 0) {
    return '';
  }
  const pad = (n) => String(n).padStart(2, '0');
  const lines = evs
    .slice()
    .reverse()   // recentEvents 返回倒序，展示要正序
    .map((ev) => {
      const d = new Date(ev.at || 0);
      const hm = `${pad(d.getHours())}:${pad(d.getMinutes())}`;
      const who = ev.nick || ev.from || String(ev.peer || '');
      const where = ev.group === true ? '（群里）' : '';
      return `  ${hm} ${who}${where}：${ev.text}`;
    });
  return [
    '【最近别人跟你说过】',
    ...lines,
    '—— 这些是**别人**跟你说的，可以跟他聊起。',
  ].join('\n');
}

/** 是不是主人（`owners` 里列的号）。 */
function isOwner(peer) {
  if (!peer) {
    return false;
  }
  return parseIds(cfg.owners).includes(Number(peer));
}

// ------------------------------------------------------------------ 对话记忆（2026-10-24）

/**
 * `/clear` 之前留下的「这段聊了什么」。
 *
 * <p><b>为什么不复用日记</b>：日记有 3~12 小时冷却 + 30% 概率，
 * 而 clear 前的总结**必须一定写**——用户是按了按钮的，不能"这次不想写"。
 * 语义也不同：日记是"我今天怎么样"，记忆是"我和某人聊过什么"。</p>
 *
 * <p><b>为什么带 peer</b>：只在**同一个人**的会话里显示。
 * 否则 A 的记忆会跑到 B 那里，等于绕过事件流的权限设计。</p>
 */
/**
 * 读「clear 前的要点」（只取这个 peer 的，最多 limit 条）。
 *
 * <p>2026-10-28：数据源从独立的 `memories.jsonl` 换成统一事件流（`kind=stage`）。
 * 两者语义完全一样 —— 都是"某次长聊的结论"，没理由单独存一个文件。</p>
 *
 * <p>返回字段保持 `{ at, peer, text }`，调用方不用改。</p>
 */
function readMemoriesFor(peer, limit = 2) {
  return recentEvents({ kind: 'stage', peer, n: limit })
    .map((e) => ({ at: e.at, peer: e.peer, text: e.text }));
}

/**
 * 长期记忆：`memory/carryover.json`（2026-11-01 新增）。
 *
 * <p><b>它和事件流/摘要的区别</b>：事件流是"流水"（谁什么时候说了什么），
 * 摘要是"这一段聊了什么"。两者都会随时间滚掉。
 * carryover 是**跨会话的骨架** —— 关系、习惯、承诺、重要的情绪转折，
 * 只在 clear 时重写一次，平时只读。</p>
 *
 * <p><b>为什么不每轮全带</b>：17 条约 600 字，每轮都塞进去既费钱又稀释注意力。
 * 所以按当前消息做关键词命中，**最多挑 3 条**；一条都不命中就带 2 条兜底。</p>
 */
function readCarryover() {
  try {
    const raw = fs.readFileSync(memFile('carryover.json'), 'utf8');
    const c = JSON.parse(raw);
    return {
      updatedAt: Number(c.updatedAt) || 0,
      aboutHim: Array.isArray(c.aboutHim) ? c.aboutHim : [],
      aboutHer: Array.isArray(c.aboutHer) ? c.aboutHer : [],
      pending: Array.isArray(c.pending) ? c.pending : [],
    };
  } catch {
    return { updatedAt: 0, aboutHim: [], aboutHer: [], pending: [] };
  }
}

/**
 * 把 carryover 挑几条拼成注入块（2026-11-01）。
 *
 * <p>命中规则：拿当前这句话去撞条目里的**三字以上中文片段** ——
 * 太短（"我""他""说"）会误命中一大片，太长又匹配不上。</p>
 */
/**
 * carryover 的话题别名（2026-11-01）。
 *
 * <p><b>为什么需要</b>：纯关键词匹配的召回太窄 —— 用户问「晚饭吃啥」，
 * 条目里写的是「楼下馄饨吃腻了」，两个字对不上，于是那条记忆永远带不出来。</p>
 *
 * <p>没有 embedding 接口（插件调不到平台的向量能力），所以用**手工别名**近似语义：
 * 命中任一别名，就把这一组词全部加进匹配集合。</p>
 *
 * <p>维护成本很低——只有十几组，而且真实的对话话题本来就集中在这几类上。</p>
 */
const CARRYOVER_TOPICS = {
  吃: ["饭", "馄饨", "汉堡", "外卖", "饿", "面", "面包", "吃", "菜单", "饭店"],
  工作: ["上班", "加班", "图书馆", "编目", "书店", "工作", "同事"],
  画: ["画", "笔尖", "纸", "颜色", "数位板", "稿"],
  猫: ["猫", "电箱", "撸"],
  墨染: ["墨染", "老同学", "打听", "问了吗"],
  身体: ["胖", "瘦", "累", "睡", "困", "起床", "醒"],
  情绪: ["烦", "难过", "生气", "开心", "高兴", "委屈", "闷"],
  家里: ["窗", "抹布", "房间", "打扫", "擦"],
  见面: ["见面", "来", "过来", "找你", "牵手", "抱"],
  未来: ["以后", "将来", "结婚", "求婚", "一起"],
};

function carryoverBlock(text) {
  const c = readCarryover();
  const all = [...c.aboutHim, ...c.aboutHer, ...c.pending];
  if (all.length === 0) {
    return '';
  }

  const t = String(text || "");

  /*
   * 从当前这句话里切 2~3 字窗口，再看条目里有没有 —— 方向不能反。
   * 2 字覆盖「墨染」「馄饨」这类专名，停用词挡掉高频虚词。
   */
  const STOP = /^(今天|明天|昨天|现在|你在|我在|他说|我说|什么|这个|那个|怎么|可以|不是|就是|还是|一个|一下|知道|觉得|真的|有点|这样|那样|来了|又来)$/;
  const grams = new Set();
  for (let len = 3; len >= 2; len--) {
    for (let i = 0; i + len <= t.length; i++) {
      const g = t.slice(i, i + len);
      if (/^[\u4e00-\u9fa5]+$/.test(g) && !STOP.test(g)) {
        grams.add(g);
      }
    }
  }

  /*
   * 话题扩展：命中一组别名就全带上。
   * 「晚饭吃啥」→ 命中「吃」这组 → 把「饭/馄饨/外卖/饿」都加进来
   * → 就能带出「楼下馄饨吃腻了」那条。
   */
  for (const aliases of Object.values(CARRYOVER_TOPICS)) {
    if (aliases.some((a) => t.includes(a))) {
      for (const a of aliases) {
        grams.add(a);
      }
    }
  }

  /*
   * 按**命中数**排序，不是按数组顺序（2026-11-01 修）。
   *
   * <p>第一版直接按 all 的顺序取前 3 条，于是 aboutHim 里的条目永远先被取走 ——
   * 问「墨染又来了」，带出来的却是「他请假来找过她」。命中多的应该排前面。</p>
   */
  const scored = [];
  for (const s of all) {
    const str = String(s);
    let cnt = 0;
    for (const g of grams) {
      if (str.includes(g)) {
        cnt++;
      }
    }
    if (cnt > 0) {
      scored.push({ s, cnt });
    }
  }
  scored.sort((a, b) => b.cnt - a.cnt);

  // 命中优先，没有就带最前面的两条（关系 + 习惯，最常用）
  const pick = scored.length > 0 ? scored.slice(0, 3).map((x) => x.s) : all.slice(0, 2);
  const cap = pick.map((s) => (s.length > 60 ? s.slice(0, 60) + "…" : s));

  return ["【你记得的】", ...cap.map((s) => `  · ${s}`)].join("\n");
}

/** 写一条 clear 前要点（落进统一事件流）。 */
function appendMemory(entry) {
  appendEvent({
    kind: 'stage',
    peer: String(entry && entry.peer ? entry.peer : ''),
    text: String(entry && entry.text ? entry.text : '').slice(0, 400),
  });
}

/**
 * 清空对话之前，让她写一段「记得什么」。
 *
 * <p><b>最关键的约束</b>：只写事，不写怎么说话。</p>
 *
 * <p>实测她会把「（端着碗坐回去）」这种旁白也写进总结。一旦存下来，
 * 新人格会照着学 —— **错误习惯被记忆固化，比不存更糟**。
 * 所以提示词里明确禁止，代码里再兜底剥一次括号。</p>
 *
 * <p>必须在**递增 epoch 之前**调用，否则读不到历史了。</p>
 */
/**
 * 每 80 轮整理一次长期记忆（2026-11-01）。
 *
 * <p><b>为什么需要</b>：carryover 原来只在 /clear 时写。不 clear 的话它永远是
 * 迁移时那几条，而后面发生的事只进摘要 —— 摘要有 24 条上限，早期的事会被一路挤掉。</p>
 *
 * <p><b>为什么是 80 轮</b>：一轮 = 一次「他说+她说」。80 轮大约是一两周的正常聊天量，
 * 这个频率下多出来的模型调用可忽略，而记忆更新得足够及时。</p>
 *
 * <p><b>只让模型输出"增量"</b>：给它现有条目，要求它只补新的 / 需要改的，
 * 避免每次把整份重写一遍（那会让措辞漂移）。</p>
 */
async function refreshCarryover(peer) {
  const c = readCarryover();
  const tail = tailBlock(peer, 6);
  if (!tail || tail.trim().length < 20) {
    diag("carryover refresh: 最近没聊什么，跳过");
    return;
  }

  const current = [...c.aboutHim, ...c.aboutHer];
  const prompt = [
    "（一次记忆整理。把最近发生的事，并进你长期记得的那些。）",
    "",
    "【你现在的长期记忆】",
    ...(current.length ? current.map((s) => "· " + s) : ["（还是空的）"]),
    "",
    tail,
    "",
    "规则：",
    "· 只写**新增的、或者需要更正的**；已经记着的不要重复。",
    "· 每条一行，行首用「· 」，每条不超过 30 字。",
    "· 最多 5 条。「嗯」「好」这类附和不要写。",
    "· 没什么可补的就只回 [无]。",
  ].join("\n");

  try {
    const answer = await askPlatform(dialogSessionId(peer), sysHint(prompt), [], peer);
    const text = String(answer || "").trim();
    if (!text || text.includes("[无]")) {
      diag("carryover refresh: 她说没什么可补的");
      return;
    }

    const fresh = text
      .split("\n")
      .map((l) => l.replace(/^[·\-*•\d.、)）]+\s*/, "").trim())
      .filter((x) => x.length >= 4 && !/^[（(]/.test(x))
      .slice(0, 5);
    if (fresh.length === 0) {
      return;
    }

    // 新的在前，去重，最多 12 条
    const merged = [];
    for (const s of [...fresh, ...c.aboutHer]) {
      const t2 = String(s).trim();
      if (t2 && !merged.includes(t2)) {
        merged.push(t2);
      }
    }
    c.aboutHer = merged.slice(0, 12);
    c.updatedAt = Date.now();
    fs.writeFileSync(memFile("carryover.json"), JSON.stringify(c, null, 2), "utf8");
    diag(`carryover refresh: 补了 ${fresh.length} 条，现共 ${c.aboutHer.length} 条`);
  } catch (e2) {
    diag(`carryover refresh failed: ${e2.message}`);
  }
}

async function writeSessionMemory(peer, isGroup) {
  /*
   * 2026-11-01 重写：规则对齐平台侧摘要。
   *
   * <p><b>旧版为什么不够</b>：只让它写"不超过三句"，产出是散文式的三句话 ——
   * 和平台侧那 24 条要点是两种东西，两边没法互通，也无法参与"调和"。</p>
   *
   * <p>现在改成**要点式**（和 {@code SessionSummaryService} 的提示词同一套要求）：
   * 一行一条、不摘附和、同一事只留一条、不写"他说了…"。产出同时进两个地方：</p>
   * <ul>
   *   <li>{@code stage} 事件（前 3 条）—— 兼容旧的"clear 前要点"注入；</li>
   *   <li>{@code carryover.json} 的 {@code aboutHer} —— 长期骨架，新的在前，最多 12 条。</li>
   * </ul>
   */
  const prompt = [
    '（这段对话马上要从记忆里清掉了。清掉之前，把值得留下的写下来。）',
    '',
    '按**要点**写，每条一行，行首用「· 」：',
    '  ① 发生过的、值得记住的事（只挑重要的，不是每句话都记）',
    '  ② 你答应过什么、他答应过什么',
    '  ③ 他提过的偏好、习惯、最近在忙什么',
    '  ④ 你自己在这段里有什么变化（心态、决定）',
    '',
    '规则：',
    '· 每条不超过 30 字；总共 6~10 条。',
    '· 同一件事换个说法说了几遍，只写一条。',
    '· 「嗯」「好」「哈哈」这类附和不要写。',
    '· 不要写「我说了…」「他说了…」，直接写内容本身。',
    '· 不要写动作或表情（（笑）这类）—— 那不是记忆，是写法。',
    '· 实在没什么可记的，只回 [无]。',
  ].join('\n');
  try {
    // 用当前 epoch 的会话 → 能读到这段对话的历史
    const sid = dialogSessionId(peer);
    const answer = await askPlatform(sid, sysHint(prompt), [], peer);
    let text = String(answer || '').trim();
    if (!text || text.includes('[无]')) {
      diag('memory: 她说这段没什么可记的');
      return;
    }
    // 兜底：模型不听话时，把括号旁白再剥一遍
    text = text.replace(/[（(][^）)]{0,80}[）)]/g, '').trim();

    // 解析成要点（去掉行首的 · - * 1. 之类）
    const points = text
      .split('\n')
      .map((l) => l.replace(/^[·\-*•\d.、)）]+\s*/, '').trim())
      .filter((x) => x.length >= 4 && !/^[（(]/.test(x))
      .slice(0, 10);

    if (points.length === 0) {
      const oneLine = text.replace(/\s+/g, ' ').trim();
      if (!oneLine) {
        return;
      }
      points.push(oneLine.slice(0, 200));
    }

    // ① 兼容旧链路：stage 事件存前 3 条（拼成一段）
    appendMemory({
      at: Date.now(),
      peer,
      kind: isGroup ? 'group' : 'private',
      text: points.slice(0, 3).join(' '),
    });

    // ② 长期骨架：并进 carryover 的 aboutHer（新的在前，最多 12 条）
    try {
      const c = readCarryover();
      const merged = [];
      for (const s of [...points, ...c.aboutHer]) {
        const t = String(s).trim();
        if (t && !merged.includes(t)) {
          merged.push(t);
        }
      }
      c.aboutHer = merged.slice(0, 12);
      c.updatedAt = Date.now();
      fs.writeFileSync(memFile('carryover.json'), JSON.stringify(c, null, 2), 'utf8');
      diag(`carryover: aboutHer 更新为 ${c.aboutHer.length} 条`);
    } catch (e) {
      diag(`carryover write failed: ${e.message}`);
    }

    diag(`memory saved for ${peer}: ${points.length} 条，首条「${points[0].slice(0, 30)}」`);
  } catch (e) {
    diag(`memory write failed: ${e.message}`);
  }
}

// ------------------------------------------------------------------ 待办（2026-10-22）

/**
 * 她记下的「之后要做的事」。
 *
 * <p><b>为什么不做成定时器</b>：她常说"等下找你""明天再问"。真人的这类话本来就会
 * 兑现一部分、忘掉一部分 —— 加个精准定时器反而变成闹钟，还容易在对方正忙时硬插一句。</p>
 *
 * <p>所以走 B 方案：她说的时候记一笔，自我检视（2~6 小时）时把未完成的列给她，
 * **由她自己决定现在要不要做**。代价是时间不精确（误差几小时），
 * 换来的是"她可以忘"这个更真实的特性。</p>
 *
 * <p>7 天自动过期 —— 一周前的"等下找你"再提起来只会显得奇怪。</p>
 */
/*
 * 待办的存活天数（2026-11-01 从 7 降到 2）。
 *
 * 原文是"十分钟后回来""明早叫你起床"这种 —— 七天后还挂在列表里，
 * 不但没用，还会让 self-manage 反复想起早就过去的事。
 */
const TODO_TTL_DAYS = 2;

function todosPath() {
  return path.join(api.dataDir, 'todos.jsonl');
}

/** 读未完成的待办（按时间正序，最多 limit 条）。 */
function readTodos(limit = 5) {
  try {
    const lines = fs.readFileSync(todosPath(), 'utf8').split('\n').filter(Boolean);
    const cutoff = Date.now() - TODO_TTL_DAYS * 86400000;
    return lines
      .map((l) => {
        try {
          return JSON.parse(l);
        } catch {
          return null;
        }
      })
      .filter((t) => t && !t.done && t.at > cutoff)
      .slice(-limit);
  } catch {
    return [];
  }
}

/**
 * 把某人**最老的未完成待办**标记为已完成（2026-11-01）。
 *
 * <p><b>为什么需要</b>：{@code done} 字段从来没有任何地方改成 true ——
 * 全仓库只有 {@code appendTodo} 写 {@code done:false}，没有反向操作。
 * 结果是待办一旦写进去就永远"未完成"，只能等 TTL 过期；
 * self-manage 每次检视都会重新看到同一批旧事。</p>
 *
 * <p><b>为什么不精确匹配</b>：{@code reachOut} 只带一句自然语言 hint，
 * 不带 todo 的 id。而她既然"想起某件事去联系"，那件事就是待办之一 ——
 * 标记该 peer 最老的一条即可，粗但够用。</p>
 *
 * <p>整份重写（不是追加）：todos.jsonl 只有几十行，成本可忽略。</p>
 *
 * @returns 被标记的那条文本；没有可标记的返回 null
 */
function markOldestTodoDone(peer) {
  const file = todosPath();
  let list = [];
  try {
    list = fs
      .readFileSync(file, 'utf8')
      .split('\n')
      .filter(Boolean)
      .map((l) => {
        try {
          return JSON.parse(l);
        } catch {
          return null;
        }
      })
      .filter(Boolean);
  } catch {
    return null;
  }

  // 最老的未完成，且属于这个人（历史数据可能没带 peer，那也认）
  let hit = null;
  for (const t of list) {
    if (t.done) {
      continue;
    }
    if (peer && t.peer && String(t.peer) !== String(peer)) {
      continue;
    }
    hit = t;
    break;
  }
  if (!hit) {
    return null;
  }
  hit.done = true;
  hit.doneAt = Date.now();

  try {
    fs.writeFileSync(file, list.map((t) => JSON.stringify(t)).join('\n') + '\n', 'utf8');
    diag(`todo done: ${String(hit.text || '').slice(0, 30)}`);
    return hit.text || null;
  } catch (e) {
    diag(`todo mark failed: ${e.message}`);
    return null;
  }
}

function appendTodo(entry) {
  try {
    fs.appendFileSync(todosPath(), JSON.stringify(entry) + '\n', 'utf8');
  } catch (e) {
    diag(`todo save failed: ${e.message}`);
  }
}

/**
 * 从回复里抽 `[待办 之后要做的事]`。
 *
 * <p>她说了"等下找你""明天再问"这类承诺时用它记一笔。不写也不会怎样，
 * 只是过几小时她自己就忘了（真人也是这样）。</p>
 */
function extractTodo(text) {
  const raw = String(text || '');
  const m = raw.match(/\[待办[：:\s]*([^\]]{1,80})\]/);
  if (!m) {
    return { text: raw, todo: null };
  }
  return { text: raw.replace(m[0], '').trim(), todo: m[1].trim() };
}

// ------------------------------------------------------------------ 自己的资料（2026-10-22）

/**
 * 她自己账号上的资料（`get_stranger_info` 传自己的号，这份比 `get_login_info` 全得多）。
 *
 * <p>实测能读到：昵称、个性签名（`longNick`）、性别、公司、学校、邮箱、生日、
 * 国家/省/市、星座、生肖、血型、标签。</p>
 *
 * <p><b>为什么要有</b>：她之前只知道"昵称 + 签名"两项（还是插件记的旧值，
 * 签名其实是空的）。性别、所在地、学校一概不知道 —— 所以她说不出"我在哪"，
 * 也没法判断哪些资料是空的。</p>
 */
let selfProfileCache = { at: 0, data: null };

/**
 * 读自己的完整资料（10 分钟缓存）。
 *
 * @param force 忽略缓存重新读（改完资料后要用，否则读到的还是旧值）
 */
async function fetchSelfProfile(force = false) {
  const now = Date.now();
  if (!force && selfProfileCache.data && now - selfProfileCache.at < 10 * 60000) {
    return selfProfileCache.data;
  }
  try {
    const r = await call('get_stranger_info', { user_id: stats.uin, no_cache: true }, 8000);
    const d = (r && r.data) || {};
    const pad = (n) => String(n || 0).padStart(2, '0');
    const hasBirthday = d.birthday_year && d.birthday_month && d.birthday_day;
    selfProfileCache = {
      at: now,
      data: {
        nickname: d.nick || '',
        // 个性签名：longNick（set_self_longnick 用的也是这个字段）
        signature: d.longNick || d.long_nick || '',
        sex: d.sex || 'unknown',
        company: d.company || '',
        email: d.eMail || d.email || '',
        college: d.college || '',
        birthday: hasBirthday
          ? `${d.birthday_year}-${pad(d.birthday_month)}-${pad(d.birthday_day)}`
          : '',
        country: d.country || '',
        province: d.province || '',
        city: d.city || '',
      },
    };
    return selfProfileCache.data;
  } catch (e) {
    diag(`self profile read failed: ${e.message}`);
    return selfProfileCache.data;
  }
}

/** 把资料渲染成给模型看的一段（空值写"（未设置）"，便于她判断哪些能填）。 */
function selfProfileBlock(p) {
  if (!p) {
    return '';
  }
  const or = (v) => (v && String(v).trim() ? String(v) : '（未设置）');
  const where = [p.country, p.province, p.city].filter(Boolean).join(' ');
  return [
    '【你账号上的资料】',
    `昵称：${or(p.nickname)}`,
    `个性签名：${or(p.signature)}`,
    `性别：${p.sex === 'female' ? '女' : p.sex === 'male' ? '男' : '（未设置）'}`,
    `生日：${or(p.birthday)}`,
    `公司 / 学校 / 邮箱：${or(p.company)} / ${or(p.college)} / ${or(p.email)}`,
    // 所在地读得到、改不了 —— 提前说清，免得她反复尝试
    `所在地：${where || '（未设置，这一项接口改不了，不用试）'}`,
  ].join('\n');
}

// ------------------------------------------------------------------ 联系人档案（2026-10-22）

/**
 * 对方是谁的缓存（peer → { nick, city, fetchedAt }）。
 *
 * <p><b>为什么必须有</b>：在此之前她**完全不知道屏幕对面是谁**。系统提示词里写
 * "我男朋友"对她来说是悬空的 —— 她手上只有一个匿名 sessionId，
 * 没有任何东西能把 QQ 号 1602454303 和"男朋友"对应上。</p>
 *
 * <p>插件只提供**事实**（QQ 号、昵称、城市），**不猜关系**。关系由用户在系统提示词里
 * 自己定义，例如「QQ 号 1602454303（昵称金粟）是我的男朋友」—— 有了事实，
 * 这句话她才接得上。</p>
 */
let contacts = {};

function contactsPath() {
  return path.join(api.dataDir, 'contacts.json');
}

function loadContacts() {
  try {
    contacts = JSON.parse(fs.readFileSync(contactsPath(), 'utf8')) || {};
  } catch {
    contacts = {};
  }
}

function saveContacts() {
  try {
    fs.writeFileSync(contactsPath(), JSON.stringify(contacts, null, 2), 'utf8');
  } catch (e) {
    diag(`save contacts failed: ${e.message}`);
  }
}

/** 取对方资料（NapCat `get_stranger_info`，24 小时缓存，避免每条消息都查一次）。 */
async function contactOf(peer) {
  const key = String(peer);
  const cached = contacts[key];
  if (cached && Date.now() - (cached.fetchedAt || 0) < 24 * 3600000) {
    return cached;
  }
  try {
    const r = await call('get_stranger_info', { user_id: peer, no_cache: false }, 8000);
    const d = (r && r.data) || r || {};
    const info = {
      nick: d.nick || d.nickname || '',
      city: d.city || '',
      level: d.qqLevel || 0,
      fetchedAt: Date.now(),
    };
    contacts[key] = info;
    saveContacts();
    return info;
  } catch (e) {
    diag(`stranger info failed ${peer}: ${e.message}`);
    return cached || { nick: '', city: '', fetchedAt: Date.now() };
  }
}

/**
 * 拼"对方是谁"这段，加在每次请求最前面（2026-10-22）。
 *
 * <p>群聊给群号；私聊给 QQ 号 + 昵称 + 城市。独处场景（日记、自我检视）
 * 没有对话对象，返回空字符串。</p>
 */
async function peerBlock(peer, isGroup) {
  if (!peer) {
    return '';
  }
  if (isGroup) {
    return `【当前场合】QQ 群 ${peer}\n`;
  }
  const c = await contactOf(peer);
  const lines = ['【正在跟你说话的人】', `QQ：${peer}`];
  if (c.nick) {
    lines.push(`昵称：${c.nick}`);
  }
  /*
   * 城市（2026-10-28 改）。
   *
   * <p><b>这是"她以为他在东京"的根源</b>：QQ 资料里填的是"东京"，
   * 这里每轮原样注入 `城市：东京` —— 比任何记忆都硬。用户说过好几次
   * "我不在东京"，但那句话只进了上下文，20 轮之后就滚掉了。</p>
   *
   * <p><b>为什么默认不信 QQ 资料</b>：用户明确说过"QQ 个人信息一般都是瞎写的"。
   * 而昵称通常是真的（是本人起的），城市这类字段很多人随手填或不填。</p>
   *
   * <p>现在的优先级：<b>他自己说过的事实（facts.json） > QQ 资料（默认不看）</b>。
   * 想让 QQ 资料也参与，把 `showQqCity` 打开。</p>
   */
  const factCity = getFact(peer, 'city');
  if (factCity && factCity.value) {
    lines.push(`城市：${factCity.value}`);
  } else if (c.city && cfg.showQqCity === true) {
    lines.push(`城市：${c.city}（QQ 资料填的，未必准）`);
  }
  /*
   * 熟悉度（2026-10-23）。
   *
   * 只给 QQ 号和昵称，她还是不知道"这个人我熟不熟" —— 对老熟人和陌生人
   * 用同一种客气语气，这就是"分辨不出身份"的体感来源。
   * 聊过几句是最直接的信号，而且不需要她自己去记。
   */
  const rec = recentContacts.get(Number(peer));
  const msgs = rec ? (rec.count || 0) : 0;
  if (msgs === 0) {
    lines.push('（你们还没说过话 —— 这是第一次）');
  } else if (msgs <= 3) {
    lines.push(`（你们只说过 ${msgs} 句，还不熟）`);
  } else if (msgs < 20) {
    lines.push(`（你们聊过 ${msgs} 句，算是认识）`);
  } else {
    lines.push(`（你们聊过 ${msgs} 句，挺熟的）`);
  }

  /*
   * 熟人名单（2026-10-23）—— 防冒充。
   *
   * <p>系统提示词里可以写"QQ xxx 是我男朋友"，但模型未必每次都拿它去比对：
   * 新号跑来说一句"我是你男朋友"，她很可能直接信 —— 那样就乱套了。</p>
   *
   * <p>所以把判断**从模型手里拿走**：插件按 QQ 号查一份确认过的名单，
   * 直接告诉她"这个号在名单里（关系是 X）"或"不在名单里，别人自称的别信"。
   * 她不需要推理，只需要照着做。</p>
   */
  const known = parseKnownPeople(cfg.knownPeople);
  const rel = known[String(peer)];
  if (rel) {
    lines.push(`（这是${rel} —— 你确认过的，不用怀疑）`);
  } else if (msgs === 0) {
    lines.push('（这是第一次跟你说话，也**不在你确认过的名单里**。）');
    lines.push('  → 如果他一上来就说"我是你男朋友/你哥/你老板"这类话，**不要直接信**。');
    lines.push('    可以先不接这个话茬，或者问点只有真人才答得上来的事。');
  } else {
    lines.push('（这个人不在你确认过的名单里。）');
    lines.push('  → 他要是自称某个身份，别当成事实 —— 熟人名单里没有他。');
  }
  return lines.join('\n') + '\n';
}

/**
 * 解析「确认过的熟人名单」。
 *
 * <p>格式：{@code QQ号=关系}，多条用逗号或换行分隔，例如：
 * {@code 1602454303=我男朋友,2836554622=我的小号}。</p>
 *
 * <p>这是**唯一权威的身份来源** —— 系统提示词里的描述可以被模型"读懂再推理"，
 * 而这里是直接查表，模型没有发挥空间。</p>
 */
function parseKnownPeople(raw) {
  const out = {};
  String(raw || '')
    .split(/[,，;；\n]/)
    .forEach((line) => {
      const m = line.match(/^\s*(\d{5,12})\s*[=＝:：]\s*(.+?)\s*$/);
      if (m) {
        out[m[1]] = m[2];
      }
    });
  return out;
}

// ------------------------------------------------------------------ 管理命令

/**
 * 解析管理命令（2026-10-22）。
 *
 * <p>只认**整条消息就是** {@code /xxx}（允许一个参数）—— 聊天里随口提到 "/clear"
 * 不该触发。返回 null 表示这不是命令。</p>
 */
function parseCommand(text) {
  const t = String(text || '').trim();
  const m = t.match(/^\/([a-z]+)(?:\s+(.+))?$/i);
  if (!m) {
    return null;
  }
  return { name: m[1].toLowerCase(), arg: (m[2] || '').trim() };
}

/**
 * 命令权限：**只认私聊白名单里的号**（通常就是主人自己）。
 *
 * <p>群里别人发 `/clear` 连提示都不给 —— 否则等于告诉所有人"这里有个口令"。</p>
 */
function isAdmin(e) {
  return parseIds(cfg.privateWhitelist).includes(Number(e.user_id));
}

/** 处理管理命令。命令**不发给模型** —— 省钱、可靠，也不受人格影响。 */
async function handleCommand(cmd, e) {
  const isPrivate = e.message_type === 'private';
  const peer = isPrivate ? Number(e.user_id) : Number(e.group_id);
  const reply = (text) => humanSend(isPrivate, peer, text);

  if (!isAdmin(e)) {
    diag(`cmd denied: ${cmd.name} from ${e.user_id}`);
    return;
  }

  switch (cmd.name) {
    case 'clear':
    case 'reset': {
      /*
       * 先写记忆，再清（2026-10-24）。
       *
       * 顺序不能反：`writeSessionMemory` 要用**当前 epoch** 的会话去读历史，
       * 一旦递增了就什么都读不到了。
       *
       * 写的是「发生了什么」，不是「怎么说话」—— 否则括号旁白这类错误习惯
       * 会被存进记忆，新人格照着学，比不存更糟。
       */
      await reply('等一下，我先把这段记住……');
      await writeSessionMemory(peer, !isPrivate);
      sessionEpochs[String(peer)] = sessionEpochOf(peer) + 1;
      saveSessionEpochs();
      diag(`cmd: 会话已重置 peer=${peer} epoch=${sessionEpochs[String(peer)]}`);
      await reply('好了，前面聊的我先不想了 —— 要紧的记下来了。重新说吧');
      return;
    }
    case 'help': {
      await reply([
        '只对你有用的几个命令：',
        '/clear  — 开一段新对话（之前的上下文不再带给我）',
        '/status — 看我连着没有、聊了多少',
        '/help   — 这条',
      ].join('\n'));
      return;
    }
    case 'status': {
      const mins = Math.max(0, Math.round((Date.now() - (stats.connectedAt || Date.now())) / 60000));
      await reply([
        `连接：${stats.connected ? '在' : '断了'}`,
        `这轮连着 ${mins} 分钟`,
        `回复 ${stats.replied || 0} 条 / 跳过 ${stats.skipped || 0} 条`,
        `会话版本：e${sessionEpochOf(peer)}`,
      ].join('\n'));
      return;
    }
    default:
      await reply(`没有 /${cmd.name} 这个命令，发 /help 看看。`);
  }
}

// ------------------------------------------------------------------ 记忆系统（2026-10-28）
//
// <h3>三个文件，单一真相</h3>
// <pre>
//   memory/facts.json    语义：关于他的稳定事实（城市/关系/宠物/生日/称呼）
//   memory/events.jsonl  情景：发生过什么（按时间，一条一行）
//   memory/self.json     她自己：情绪 + 日记 + 别人对她的评价
//   memory/minecraft.md  游戏：她和他一起玩 Minecraft 的记忆（**MC 助手插件写入，这里只读**）
// </pre>
//
// <h3>为什么这么分</h3>
// <p>参考了 RisuAI 的「所有记忆产出到同一个 slot」、Mem0 的「短事实必须结构化、
// 不能靠向量检索」、以及 SillyTavern 社区的「摘要保主线 + 结构化补细节」。</p>
//
// <p>原来的九个文件（impressions / todos / events / memories / diary /
// self-notes / self-state / conversation-tail / facts）职责重叠，
// 注入点散在 timeContext 里七八处 —— 漏同步是迟早的事
// （已经踩过：【别太听话】和【写法】两个标题忘了加进剥离列表，
// 导致整段注入被当成用户说的话摘进摘要）。</p>
//
// <h3>写入成本</h3>
// <p>绝大多数写入是**规则匹配 + 本地追加**，零 token、不调模型。
// 只有「每 10 轮压缩阶段要点」和「日记」会调模型。</p>

const MEMORY_SUBDIR = 'memory';

/** 每人最多注入几条事实（关系单独一行，不占这个额度）。 */
const FACT_MAX = 8;

/**
 * 各类事实的「保质期」（天，2026-11-01）。
 *
 * <p><b>为什么需要</b>：原来 {@code factScore} 只看置信度和提及次数，
 * 于是「busy: 准备考试」三个月后权重还是那么高，她会在完全不相关的时候提起来。</p>
 *
 * <p><b>为什么按 kind 分而不是一刀切</b>：</p>
 * <ul>
 *   <li>{@code relation / nickname / birthday / pet} —— **不衰减**（0 表示永久）。
 *       男朋友、叫什么、生日这些不会因为三个月没提就不成立；</li>
 *   <li>{@code city / school / job} —— 半年。会变，但变得慢；</li>
 *   <li>{@code prefer} —— 两月。口味会变，但没那么快；</li>
 *   <li>{@code busy} —— 三周。"在准备考试"这种，三周后基本已经过去了。</li>
 * </ul>
 *
 * <p>衰减到接近 0 时 {@link #factsBlock} 就不再注入，但**数据仍保留在文件里** ——
 * 他哪天又提起，hits 累加后权重会回来。</p>
 */
const FACT_TTL_DAYS = {
  relation: 0,
  nickname: 0,
  birthday: 0,
  pet: 0,
  city: 180,
  school: 180,
  job: 180,
  prefer: 60,
  busy: 21,
};

/** 每种事实注入时的说法（值拼在后面）。 */
const FACT_LABEL = {
  city: '他人在',
  job: '他在',
  school: '他在',
  pet: '他养了',
  birthday: '他生日在',
  nickname: '他让你叫他',
  habit: '他',
};

/**
 * 事实来源 → 默认可信度。
 *
 * <p>`stated` 是他亲口说的；`inferred` 是她自己的判断（印象）；
 * `qq-profile` 是 QQ 资料 —— 用户明确说过"QQ 个人信息一般都是瞎写的"，
 * 所以只有 0.2，**永远压不过亲口说的**。</p>
 */
const SOURCE_CONF = { stated: 0.9, inferred: 0.5, 'qq-profile': 0.2 };

/**
 * 跟在「我在」后面**不是城市**的词。
 *
 * <p>没有这层过滤，一句「我在吃饭」就会记成「他人在吃饭」，然后每轮注入。</p>
 */
const CITY_STOP = /^(吃饭|忙|家|家里|公司|单位|学校|路上|上班|上课|睡觉|休息|这儿|那儿|外面|医院|车站|地铁|公交|开车|加班|出差|发呆|写代码|打字|看你|这边|那边)/;

function memDir() {
  const d = path.join(api.dataDir, MEMORY_SUBDIR);
  try {
    fs.mkdirSync(d, { recursive: true });
  } catch {
    /* 已存在 */
  }
  return d;
}

function memFile(name) {
  return path.join(memDir(), name);
}

// ---------------- 游戏记忆：minecraft.md（2026-11-04） ----------------

/**
 * 「她和他一起玩 Minecraft」的记忆。
 *
 * <h3>为什么单开一个文件</h3>
 * 它不是"关于他的稳定事实"（facts.json），也不是"今天发生过什么"（events.jsonl）——
 * 它是一条独立的生活线，而且**由另一个插件（MC 助手）写**。混进现有任何一层都会串味：
 * 塞 facts 会让她以为"他住在 Minecraft 的家里"，塞 events 会被当成"别人今天找过你"。
 *
 * <h3>为什么不是每轮都读</h3>
 * 几百字 × 每天几十轮 = 白烧 token，而且她会在你聊正事时硬扯游戏。
 * 只在四种情况下读：**聊到游戏 / 她正在游戏里 / 刚玩完不久 / 主动开口找话题**。
 * 后两种还有 20 分钟冷却 —— 否则一整晚她都在提"我们刚才那把"。
 *
 * <h3>为什么只给主人看</h3>
 * 这份记忆里全是"他"的事，和事件流的权限设计一致：别人的会话里根本不该有这段材料。
 */
function mcSessionsDir() {
  return path.join(memDir(), 'minecraft');
}

/** 索引：一行一次联机，最新在最上面（MC 助手写，这里只读）。 */
function mcIndexPath() {
  return path.join(mcSessionsDir(), 'index.md');
}

/**
 * 最近一次联机的记录文件。
 *
 * <p>2026-11-04 起 MC 助手改成**一次联机一个文件**（`memory/minecraft/2026-11-04_2130.md`），
 * 因为一个文件越滚越长，"上一次玩"会被这一次挤掉。这里按下面的顺序找：</p>
 * <ol>
 *   <li>用户显式配的路径；</li>
 *   <li>状态文件里记的 `lastSessionFile`；</li>
 *   <li>目录里文件名最大的那个（文件名带时间，字典序=时间序）；</li>
 *   <li>老的单个 `minecraft.md`（迁移前的数据）。</li>
 * </ol>
 */
function mcMemoryPath() {
  const custom = String(cfg.minecraftMemoryPath || '').trim();
  if (custom) return custom;

  const st = readJsonQuiet(mcStatePath());
  const last = String(st.lastSessionFile || '');
  if (last && fs.existsSync(last)) return last;

  try {
    const files = fs.readdirSync(mcSessionsDir())
      .filter((f) => f.endsWith('.md') && f !== 'index.md')
      .sort();
    if (files.length > 0) return path.join(mcSessionsDir(), files[files.length - 1]);
  } catch {
    /* 目录还没建 */
  }
  return path.join(memDir(), 'minecraft.md');
}

/** 索引里的最近几条 —— 用来给她"更早那几次"的连续性，而不是只有这一局。 */
function mcIndexLines(limit = 3) {
  try {
    return fs.readFileSync(mcIndexPath(), 'utf8')
      .split('\n')
      .filter((l) => l.trim().startsWith('- '))
      .slice(0, limit);
  } catch {
    return [];
  }
}

/** MC 助手写的会话状态（online / endedAt）——只用来判断"她现在是不是在玩"。 */
function mcStatePath() {
  return path.join(memDir(), 'minecraft-state.json');
}

/** 静默读 JSON：文件不存在 / 正在被写都是常态，不能抛。 */
function readJsonQuiet(file) {
  try {
    const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
    return raw && typeof raw === 'object' ? raw : {};
  } catch {
    return {};
  }
}

/**
 * 什么话算"在聊游戏"。
 *
 * <p>**没有放单独的「玩」**：那会把「玩手机」「玩了一下午」全算进来。
 * 也没有放「木头/石头」这种游戏里常见、日常更常见的词。</p>
 */
const MC_TOPIC = /我的世界|minecraft|\bmc\b|挖矿|矿洞|钻石|红石|合成|打怪|开黑|联机|存档|服务器|种田|钓鱼|盖房|下矿|上号|陪.{0,2}玩.{0,2}游戏/i;

/** 上次注入游戏记忆的时间（冷却用）。 */
let lastGameMemAt = 0;

/**
 * 拼「Minecraft 记忆」这一段；返回空串表示这次不带。
 *
 * @param {string} text    当前这条消息（用来判断是不是在聊游戏）
 * @param {object} opts    {@code forceGameMemory} = 主动开口（绕过冷却与话题判断）
 * @param {number} peer    私聊对象
 * @param {boolean} isGroup 群聊
 */
function gameMemoryBlock(text, opts = {}, peer = 0, isGroup = false) {
  if (cfg.minecraftMemoryEnabled === false) {
    return '';
  }
  /*
   * 只给主人的私聊。
   *
   * 注意：这里**不看 forceGameMemory** —— 主动发言在 `any` 模式下也可能找别人，
   * 那属于"她主动搭话"，不该因此把主人的事说出去。
   */
  if (isGroup || !peer || !isOwner(peer)) {
    return '';
  }

  const p = mcMemoryPath();
  let stat;
  try {
    stat = fs.statSync(p);
  } catch {
    return '';   // 没玩过 / 没装 MC 助手
  }
  if (!stat.size) {
    return '';
  }

  const st = readJsonQuiet(mcStatePath());
  const now = Date.now();
  const online = !!st.online;
  const endedAt = Number(st.endedAt) || 0;
  const recentHours = Number(cfg.minecraftRecentHours) || 8;

  let why = '';
  if (opts.forceGameMemory) {
    why = '主动开口';
  } else if (MC_TOPIC.test(String(text || ''))) {
    why = '聊到游戏';
  } else if (online) {
    why = '她正在玩';
  } else if (endedAt && now - endedAt < recentHours * 3600000) {
    why = '刚玩完';
  }
  if (!why) {
    return '';
  }
  /*
   * 冷却只压"顺便带一下"的两种触发。
   *
   * 「聊到游戏」不限：那说明真的在聊，正是要读的时候；
   * 「主动开口」也不限：她本来就隔几小时才主动一次。
   */
  if (why !== '聊到游戏' && why !== '主动开口' && now - lastGameMemAt < 20 * 60 * 1000) {
    return '';
  }
  lastGameMemAt = now;

  let raw = '';
  try {
    raw = fs.readFileSync(p, 'utf8');
  } catch {
    return '';
  }

  /*
   * 标题行就是"这一局是什么时候、在哪玩的"：`# 2026-11-04 21:30 – 23:02 · 127.0.0.1:25565 · 1.21.4`
   * 直接搬进上下文，她才能说出"昨晚那局""刚才那一个小时"。
   */
  const firstLine = raw.split('\n', 1)[0] || '';
  const title = firstLine.startsWith('# ') ? firstLine.replace(/^#\s*/, '').trim() : '';

  let body = raw
    .replace(/^#[^\n]*\n/, '')
    .replace(/<!--[\s\S]*?-->/g, '')   // 文件头的说明不该进上下文
    // `## 流水` / `## 总结` 是给人看的标题，转成【】更像提示词里的分段
    .replace(/^##\s+(.+)$/gm, '【$1】')
    .trim();
  if (!body) {
    return '';
  }

  const chars = Number(cfg.minecraftMemoryChars) || 600;
  /*
   * 预算分配：先给"更早几次"留 160 字，剩下的都给**这一次的流水尾部**。
   * 为什么先扣：没有这几行，她会把三天前的矿洞当成今天的事；
   * 但主线仍然是最近这一局，所以它必须拿大头。
   */
  const earlier = online ? [] : mcIndexLines(4).slice(1);
  const earlierText = earlier.length > 0 ? `【更早】\n${earlier.join('\n')}` : '';
  const budget = Math.max(200, chars - (earlierText ? 160 : 0));
  if (body.length > budget) {
    body = `…${body.slice(body.length - budget)}`;   // 保尾部：最近发生的事才有用
  }

  diag(`game memory injected (${why}, ${body.length} chars${earlier.length ? `, +${earlier.length} 次历史` : ''})`);
  const head = online ? '【你现在正在游戏里】' : '【你和他一起玩 Minecraft 的事】';
  const when = !online && title ? `最近一次：${title}\n` : '';
  return `${head}\n${when}${body}${earlierText ? `\n\n${earlierText}` : ''}`;
}

// ---------------- 语义记忆：facts.json ----------------

let factsCache = null;

function readFacts() {
  if (factsCache) {
    return factsCache;
  }
  try {
    const raw = JSON.parse(fs.readFileSync(memFile('facts.json'), 'utf8'));
    factsCache = raw && typeof raw === 'object' ? raw : {};
  } catch {
    factsCache = {};
  }
  return factsCache;
}

function writeFacts() {
  try {
    fs.writeFileSync(memFile('facts.json'), JSON.stringify(factsCache || {}, null, 2), 'utf8');
  } catch (e) {
    diag(`facts save failed: ${e.message}`);
  }
}

/** 老数据没有 source/confidence/history，读出来补齐（迁移遗留）。 */
function normalizeFact(v) {
  if (!v || typeof v !== 'object' || !v.value) {
    return null;
  }
  const source = v.source || 'stated';
  const at = Number(v.lastAt || v.at) || 0;
  return {
    value: String(v.value),
    source,
    confidence: typeof v.confidence === 'number'
      ? v.confidence
      : (SOURCE_CONF[source] || 0.5),
    firstAt: Number(v.firstAt || v.at) || at,
    lastAt: at,
    hits: Number(v.hits) || 1,
    /** 印象专用：生成这条时的累计消息数（判断"又聊了 20 句才值得重写"）。 */
    msgCount: Number(v.msgCount) || 0,
    history: Array.isArray(v.history) ? v.history : [],
  };
}

function getFact(peer, kind) {
  const box = readFacts()[String(peer)];
  return box ? normalizeFact(box[kind]) : null;
}

/** 某个人的全部事实（已归一化）。 */
function allFacts(peer) {
  const box = readFacts()[String(peer)];
  if (!box) {
    return [];
  }
  return Object.entries(box)
    .map(([k, v]) => {
      const f = normalizeFact(v);
      return f ? { kind: k, ...f } : null;
    })
    .filter(Boolean);
}

/**
 * 事实的注入权重（2026-11-01 加时间衰减）。
 *
 * <p>原来只看 {@code confidence × log(hits)} —— 提得越多权重越高，**与时间无关**。
 * 于是早期偶然提过一次的事，权重能一直压过最近说过的重要事。</p>
 *
 * <p>现在乘衰减因子 {@code max(0, 1 - 天数/保质期)}。
 * 保质期为 0 的类型（关系/称呼/生日/宠物）不衰减。</p>
 */
function factScore(f) {
  const base = (f.confidence || 0.5) * (1 + Math.log(1 + (f.hits || 1)));
  const ttl = FACT_TTL_DAYS[f.kind];
  if (!ttl) {
    return base;
  }
  const ageDays = (Date.now() - (Number(f.lastAt) || 0)) / 86400000;
  return base * Math.max(0, 1 - ageDays / ttl);
}

/**
 * 写入一条事实（2026-10-28）。
 *
 * <p><b>冲突规则</b>（参考 Mem0 的做法，但简化成四条）：</p>
 * <ol>
 *   <li>新值可信度明显更高（+0.15）→ 覆盖，旧值进 {@code history}；</li>
 *   <li>同来源且时间更晚 → 覆盖，旧值进 {@code history}；</li>
 *   <li>可信度更低但提得更多 → **不覆盖**，只累加 hits；</li>
 *   <li>其余 → 保留旧值，新说法标记 {@code rejected} 存进 history。</li>
 * </ol>
 *
 * <p><b>为什么一定要保 history</b>：直接覆盖就再也查不到"他以前说过在东京"。
 * 三个月后出问题，连排查的线索都没有。</p>
 */
function setFact(peer, kind, value, source = 'stated', at = Date.now()) {
  const v = String(value || '').trim();
  if (!v) {
    return;
  }
  const facts = readFacts();
  const key = String(peer);
  const box = facts[key] || {};
  const old = normalizeFact(box[kind]);
  const conf = SOURCE_CONF[source] || 0.5;
  const ts = Number(at) || Date.now();

  if (!old) {
    box[kind] = {
      value: v, source, confidence: conf, firstAt: ts, lastAt: ts, hits: 1, history: [],
    };
    facts[key] = box;
    writeFacts();
    diag(`mem: ${kind} = ${v}（${source}）`);
    return;
  }

  if (old.value === v) {
    old.hits += 1;
    old.lastAt = Math.max(old.lastAt, ts);
    old.confidence = Math.max(old.confidence, conf);
    box[kind] = old;
    facts[key] = box;
    writeFacts();
    return;
  }

  const higherConf = conf > old.confidence + 0.15;
  const sameSourceLater = source === old.source && ts >= old.lastAt;
  if (!higherConf && !sameSourceLater) {
    // 规则 ③④：不动旧值，只把新说法留档
    old.hits += 1;
    old.history.push({ value: v, source, confidence: conf, until: ts, rejected: true });
    box[kind] = old;
    facts[key] = box;
    writeFacts();
    diag(`mem: ${kind} 保留「${old.value}」，拒绝「${v}」（可信度不足）`);
    return;
  }

  // 规则 ①②：覆盖，旧值留档
  old.history.push({ value: old.value, source: old.source, confidence: old.confidence, until: ts });
  box[kind] = {
    value: v,
    source,
    confidence: conf,
    firstAt: old.firstAt || ts,
    lastAt: ts,
    hits: 1,
    history: old.history,
  };
  facts[key] = box;
  writeFacts();
  diag(`mem: ${kind} 「${old.value}」→「${v}」（旧值已留档）`);
}

// ---------------- 情景记忆：events.jsonl ----------------

/**
 * 追加一条事件（2026-10-28）。
 *
 * <p>正常是 append（只写一行、不重写整个文件）。但**每 50 次**检查一次
 * 文件行数，超过 {@link EVENT_MAX} 才整体重写 —— 兼顾"写得快"和"不会无限膨胀"。</p>
 */
let eventAppendCount = 0;

/**
 * 事件流按**可见性**分文件（2026-11-01）。
 *
 * <p><b>为什么不能只靠 kind 过滤</b>：原来所有事件写同一个 events.jsonl，
 * 靠 eventBlock() 里的一行 filter(e => e.kind === 'other') 挡住「主人的话不进群聊」。
 * 这是**查询层隔离** —— 只要哪天改过滤条件，或者新写一个读取函数忘了过滤，
 * 私聊内容就漏进群聊。</p>
 *
 * <p>改成**存储层隔离**：</p>
 * <pre>
 *   events-owner.jsonl   主人的话 + stage（clear 前要点）
 *   events-public.jsonl  别人的话（kind=other）
 *   events.jsonl         历史遗留（2026-11-01 之前的数据，只读）
 * </pre>
 */
function appendEvent(ev) {
  const isPrivate = ev.kind === 'owner' || ev.kind === 'stage';
  const file = memFile(isPrivate ? 'events-owner.jsonl' : 'events-public.jsonl');
  try {
    fs.appendFileSync(file, JSON.stringify({ at: Date.now(), ...ev }) + '\n', 'utf8');
    eventAppendCount += 1;
    if (eventAppendCount % 50 !== 0) {
      return;
    }
    /*
     * 定期裁一次（2026-11-01 改成按**重要度**，不再按纯时间）。
     *
     * <p><b>原来为什么不对</b>：{@code slice(-EVENT_MAX)} 是"留最近的 500 条"，
     * 于是「墨染问我帮她问事」和「她说嗯」权重完全一样 —— 先到先删。
     * 聊得越多，真正值得记的事越容易被挤掉。</p>
     *
     * <p>现在按 score 排序，超出时淘汰分低的。score 由三部分构成：</p>
     * <ul>
     *   <li><b>长度</b> —— 一句话通常信息量更大（"嗯""好"这类先走）；</li>
     *   <li><b>类型</b> —— 主人的话、待办、阶段结论权重高，闲聊低；</li>
     *   <li><b>近因性</b> —— 同样是闲聊，新的留、旧的走。</li>
     * </ul>
     */
    const rawLines = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean);
    if (rawLines.length > EVENT_MAX) {
      const now = Date.now();
      const scored = rawLines.map((line) => {
        let e = null;
        try {
          e = JSON.parse(line);
        } catch {
          return { line, s: -1e9 };
        }
        const ageDays = Math.max(0, (now - (Number(e.at) || 0)) / 86400000);
        const textLen = String(e.text || "").length;
        const kindWeight =
          e.kind === "owner" ? 3 :
          e.kind === "commit" ? 4 :
          e.kind === "stage" ? 5 :
          1;
        // 长度贡献封顶 10（60 字以上都算"有信息量"）
        const lenScore = Math.min(textLen / 6, 10);
        // 近因贡献：30 天内线性衰减，超过 30 天归零
        const recency = Math.max(0, 30 - ageDays) / 3;
        return { line, s: kindWeight + lenScore + recency };
      });
      scored.sort((a, b) => b.s - a.s);
      const kept = scored.slice(0, EVENT_MAX).map((x) => x.line);
      // 存回去要按时间正序，否则下次"最近 3 条"会取到随机的
      kept.sort((a, b) => {
        try {
          return (JSON.parse(a).at || 0) - (JSON.parse(b).at || 0);
        } catch {
          return 0;
        }
      });
      fs.writeFileSync(file, kept.join('\n') + '\n', 'utf8');
      diag(`mem: 事件流按重要度裁剪 ${rawLines.length} → ${kept.length} 条`);
    }
  } catch (e) {
    diag(`event append failed: ${e.message}`);
  }
}

/** 三个事件文件的统一读取（2026-11-01 分文件后）。 */
const EVENT_FILES = ['events.jsonl', 'events-owner.jsonl', 'events-public.jsonl'];

/**
 * 读全部事件（内部用），按时间正序。
 *
 * <p>分文件之后不能只读一个：老的写在 events.jsonl，新的按可见性分开。
 * 混读之后必须**显式按 at 排序** —— 否则「最后 3 条」会变成「某个文件的后 3 条」。</p>
 */
function readEvents() {
  const out = [];
  for (const name of EVENT_FILES) {
    try {
      const raw = fs.readFileSync(memFile(name), 'utf8');
      for (const line of raw.split('\n')) {
        const t = line.trim();
        if (!t) {
          continue;
        }
        try {
          out.push(JSON.parse(t));
        } catch {
          /* 坏行跳过，不让一条脏数据拖垮整份记忆 */
        }
      }
    } catch {
      /* 文件不存在就跳过 */
    }
  }
  out.sort((a, b) => (a.at || 0) - (b.at || 0));
  return out;
}

/**
 * 只读**可以给陌生人看**的事件（2026-11-01）。
 *
 * <p>这是存储层隔离的读取端：正常情况只读 events-public.jsonl，
 * **物理上碰不到** owner / stage 那些文件。</p>
 *
 * <p>历史上 kind=owner 的事件还留在 events.jsonl 里（分文件之前写的），
 * 所以这里额外做一次 kind 过滤兜底 —— 那是补充，不是唯一防线。</p>
 */
function readPublicEvents() {
  const out = [];
  for (const name of EVENT_FILES) {
    try {
      const raw = fs.readFileSync(memFile(name), 'utf8');
      for (const line of raw.split('\n')) {
        const t = line.trim();
        if (!t) {
          continue;
        }
        try {
          const e = JSON.parse(t);
          if (e.kind === 'owner' || e.kind === 'stage') {
            continue;
          }
          out.push(e);
        } catch {
          /* 坏行跳过 */
        }
      }
    } catch {
      /* 文件不存在 */
    }
  }
  out.sort((a, b) => (a.at || 0) - (b.at || 0));
  return out;
}

/** 按 kind / peer / 时间窗口过滤，取最近 n 条（**时间倒序**）。 */
function recentEvents({ kind, peer, n = 5, withinMs = 0 } = {}) {
  const now = Date.now();
  return readEvents()
    .filter((e) => (!kind || e.kind === kind)
      && (!peer || String(e.peer) === String(peer))
      && (!withinMs || now - (Number(e.at) || 0) <= withinMs))
    .sort((a, b) => (Number(b.at) || 0) - (Number(a.at) || 0))
    .slice(0, n);
}

// ---------------- 她自己：self.json ----------------

let selfCache = null;

function readSelf() {
  if (selfCache) {
    return selfCache;
  }
  try {
    const raw = JSON.parse(fs.readFileSync(memFile('self.json'), 'utf8'));
    selfCache = raw && typeof raw === 'object' ? raw : {};
  } catch {
    selfCache = {};
  }
  if (!selfCache.profile || typeof selfCache.profile !== 'object') {
    selfCache.profile = {};
  }
  if (!Array.isArray(selfCache.notes)) {
    selfCache.notes = [];
  }
  if (!Array.isArray(selfCache.diary)) {
    selfCache.diary = [];
  }
  return selfCache;
}

function writeSelf() {
  try {
    fs.writeFileSync(memFile('self.json'), JSON.stringify(selfCache || {}, null, 2), 'utf8');
  } catch (e) {
    diag(`self save failed: ${e.message}`);
  }
}

/** 改她自己那份状态（回调里直接改对象，函数负责落盘）。 */
function patchSelf(fn) {
  const s = readSelf();
  fn(s);
  writeSelf();
}

// ---------------- 事实抽取（规则，零 token） ----------------

/**
 * 从一句话里抽「他关于自己的事实」。
 *
 * <p>只认**明确的第一人称**：`我朋友在合肥` 不该被记成"他在合肥"，
 * 所以所有规则都以「我」开头。</p>
 *
 * <p>**宁可漏，不能错**：抽错了她会当真，比记不住更糟。</p>
 */
function extractFacts(text) {
  const raw = String(text || '');
  if (!raw) {
    return {};
  }
  // 去空白 + 去末尾标点，让「我在合肥。」和「我在合肥」等价
  const t = raw.replace(/\s+/g, ' ').trim().replace(/[。！!？?，,~…]+$/g, '');
  const out = {};

  /*
   * 城市：我在合肥 / 我住在合肥 / 我人在合肥 / 我现在在合肥市 / 我在合肥了
   *
   * 捕获组用**非贪婪**，后面单独吃掉「市/这边」和「了/的/啊」这类尾巴 ——
   * 贪婪写法会把「合肥了」「合肥市」整个当成地名。
   */
  let m = t.match(/我(?:现在|人)?(?:在|住在|到了|来了?)([\u4e00-\u9fa5]{2,4}?)(?:市|这边|那儿|那里)?(?:了|的|啊|呀|呢|吧)?$/);
  if (m && !CITY_STOP.test(m[1])) {
    out.city = m[1];
  }
  if (!out.city) {
    // 我是合肥人
    m = t.match(/我是([\u4e00-\u9fa5]{2,4})人/);
    if (m && !CITY_STOP.test(m[1])) {
      out.city = m[1];
    }
  }

  // 上学 / 上班
  m = t.match(/我在(.{2,10}?)(?:上学|上课|读书|念书)/);
  if (m) {
    out.school = m[1].trim();
  }
  m = t.match(/我在(.{2,10}?)(?:上班|工作|实习)/);
  if (m) {
    out.job = m[1].trim();
  }
  if (!out.school && !out.job
    && /(我(?:还)?(?:是|在)?学生|我是?大[一二三四]|我上(?:大|高|初)[一二三四])/.test(t)) {
    out.job = '上学';
  }

  // 宠物：我养了只猫 / 我有一条狗
  m = t.match(/我(?:养|有)(?:了)?(?:一?只|一条|一个|两只|两条)([\u4e00-\u9fa5]{1,4})/);
  if (m) {
    out.pet = m[1];
  }

  // 生日
  m = t.match(/我(?:的)?生日(?:是|在)?(\d{1,2}月\d{1,2}[日号]?)/);
  if (m) {
    out.birthday = m[1];
  }

  // 称呼：叫我XX / 称呼我XX
  m = t.match(/(?:叫我|称呼我)([\u4e00-\u9fa5A-Za-z0-9]{1,8})$/);
  if (m) {
    out.nickname = m[1];
  }


  /*
   * 偏好与当前状态（2026-11-01 补）。
   *
   * <p><b>为什么补这两类</b>：原来只抽「城市 / 学校 / 工作 / 宠物 / 生日 / 称呼」——
   * 这些是**档案**，不解释"他这个人现在怎么样"。于是她记得你在合肥上学，
   * 但不知道你怕辣、最近在准备什么、这两天为什么烦。</p>
   *
   * <p>对标 AstrBot 生态里几个成熟插件（用户记忆插件 / LivingMemory / Memory Manager），
   * 它们抽的是「印象 / 事件 / 关系 / 别名」四类 —— 其中「事件」和「偏好」
   * 是让 Bot 显得"记得住人"的关键，而这两类我们原来完全没有。</p>
   *
   * <p><b>刻意保守</b>：宁可漏，不可错。抽错了她会当真，比记不住更糟。
   * 所以只认最直白的句式，稍微绕一点的一律不抽。</p>
   */

  // 偏好：我不吃辣 / 我讨厌下雨 / 我受不了吵
  m = t.match(/我(?:不太|不怎么|很|最|特别)?(?:喜欢|爱吃|爱喝|讨厌|不吃|不喝|受不了|怕|怕吃)([\u4e00-\u9fa5A-Za-z]{1,8})/);
  if (m) {
    const v = m[1].trim();
    // 太泛的（"你""这个""什么"）不记，否则会存下"我喜欢你"这种
    if (v.length >= 1 && !/^(你|他|她|它|这个|那个|什么|这样|那样|了|的|我)$/.test(v)) {
      const verb = m[0].includes('讨厌') || m[0].includes('受不了') || m[0].includes('怕')
        || m[0].includes('不吃') || m[0].includes('不喝') ? '讨厌' : '喜欢';
      out.prefer = verb + v;
    }
  }

  // 当前状态：我在准备考试 / 我最近在忙搬家 / 我在找工作
  m = t.match(/我(?:最近|这几天|这两天|这阵子)?在(?:忙|准备|搞|做|学|找)([\u4e00-\u9fa5]{2,12})/);
  if (m) {
    const v = m[1].trim();
    if (v.length >= 2 && !/^(干什么|做什么|干嘛|哪里|哪儿|想什么)$/.test(v)) {
      out.busy = v;
      // 命中状态就说明「我在XX」不是地点 —— 把前面误抽的 city 丢掉
      // （实测「我在准备考试」会被 city 规则捕获成城市「准备考试」）
      if (out.city) {
        delete out.city;
      }
    }
  }

  return out;
}

/**
 * 否认句：「我不在东京」「我不住在上海」（2026-10-28）。
 *
 * <p>这类话的意义是**推翻旧记录**，不是"记下新事实"。典型场景：
 * QQ 资料填了"东京"，他说"我不在东京" —— 那句否认以前只进上下文、
 * 20 轮后滚掉，于是下个月她还会说"你在东京"。</p>
 */
function extractDenyCity(text) {
  const t = String(text || '').replace(/\s+/g, ' ').trim();
  const m = t.match(/我(?:并)?不(?:在|住在|是)([\u4e00-\u9fa5]{2,4})(?:人|市)?/);
  if (!m || CITY_STOP.test(m[1])) {
    return null;
  }
  return m[1];
}

/** 把一句话里的事实写进 facts.json（2026-10-28）。 */
function rememberFacts(peer, text) {
  if (cfg.factsEnabled === false) {
    return;
  }
  // 否认句先处理：它要作废旧记录，和"记新事实"方向相反
  const deny = extractDenyCity(text);
  if (deny) {
    const cur = getFact(peer, 'city');
    if (cur && cur.value === deny) {
      setFact(peer, 'cityDenied', deny, 'stated');
      diag(`mem: 他说自己不在 ${deny}，城市记录作废`);
    }
  }
  const found = extractFacts(text);
  for (const [k, v] of Object.entries(found)) {
    setFact(peer, k, v, 'stated');
  }
}

/**
 * 注入用的记忆段（关系 + 事实）。
 *
 * <p>关系沿用【你对他/她的印象】这个标题 —— 摘要剥离列表里认的就是它，
 * 换标题会让整段被当成用户说的话。</p>
 */
/**
 * 她的外貌锚（2026-10-28）。
 *
 * <p><b>为什么必须是一段死文本</b>：文生图每次都是从噪声重新采样，模型没有记忆。
 * 同一段描述只要换一个字（「黑色及肩长发」vs「黑发到肩」），在模型看来就是两个人。
 * 所以这段**一字都不能改**，每次都要原样送进生图提示词。</p>
 *
 * <p><b>措辞为什么走「薄、静、单薄」而不是堆漂亮词</b>：堆「精致」「绝美」这类词，
 * 模型容易生成廉价的网红脸；用具体质感（皮肤薄、眼尾下垂、衣服大一号），
 * 出来的才是"看得出是这个人"。也更贴她"话不多、有点钝"的人设。</p>
 */
/*
 * 外貌锚（2026-10-28 按「比例优先」重写第二版）。
 *
 * <p><b>上一版为什么画出来难看</b>：写了一大堆**微观特征** ——
 * 唇珠、虎牙、上排牙龈、颧骨下的青色血管、鼻翼雀斑、卧蚕。
 * 3.0-pro 精度越高，就越会把这些当成独立"特征"逐个实现，
 * 于是唇珠被画大、虎牙被画尖、血管画成青筋 —— **堆成一张怪脸**。</p>
 *
 * <p><b>现成模板的做法</b>（SweetPrompt / PromptHero 等写实人像 prompt）：
 * 说的是**比例**而不是细节 —— {@code naturally proportioned nose}、
 * {@code realistic eye spacing}、{@code subtle cheek structure}。
 * 一句话控制一个方面，每句都有用，不是形容词堆叠。</p>
 *
 * <p>所以这版：**只留骨相、比例、肤质、头发、身材**，
 * 并且加了两处"反向锚"——「不是网红脸」「不是磨皮塑料感」。
 * 微观特征全部删掉，交给模型自己补。</p>
 */
/*
 * 外貌锚（2026-10-28 第三版，改成「日系写真」路线）。
 *
 * <p><b>前两版都错了</b>：第一版堆微观特征（唇珠/虎牙/血管/雀斑），
 * 第二版改成解剖比例（眼距正常/下颌线柔和/鼻头圆润），
 * 但用户要的是**好看**，不是**真实**。</p>
 *
 * <p>参考的现成例子（一张日系胶片少女写真）里，人物描述只有几句 ——
 * 瓜子脸、尖下巴、冷白皮、眼大而圆、长发及腰、淡妆。
 * 真正撑起画面的是**风格**：回眸抓拍、树荫光影、光斑散景、
 * 低饱和、冷调偏靛蓝、掉色、颗粒感、发丝被风吹起。</p>
 *
 * <p>所以这版：外貌**只留骨相和五官的大形状**，其余交给风格参数。
 * 不写毛孔、不写真实肤质 —— 胶片风格里皮肤本来就是柔的、透的。</p>
 */
/*
 * 外貌锚（2026-10-28 第四版，「生活随手拍」路线）。
 *
 * <p><b>前三版都偏了</b>：v1 堆微观特征（唇珠/虎牙）→ 怪脸；
 * v2 改解剖比例（眼距/下颌线）→ 平庸；
 * v3 走日系胶片氛围 → 太"作品感"。</p>
 *
 * <p>用户要的是**"像生活中随手一拍"的写实** —— 不是写真集、不是胶片风，
 * 是"女朋友发给你的一张照片"。所以：</p>
 * <ul>
 *   <li><b>人写细、写好看</b>：清秀、瓜子脸、皮肤白、眼睛大；</li>
 *   <li><b>质感要真</b>：留一点毛孔和肤色不均，不然像建模；</li>
 *   <li><b>风格要"没有风格"</b>：不加滤镜、不掉色、不冷调 ——
 *       那些词会把照片变成"作品"，反而假。</li>
 * </ul>
 */
/*
 * 外貌锚（2026-10-30 第五版）。
 *
 * <p><b>第四版的问题</b>：写了「能看到细微的毛孔和轻微的不均匀」，
 * 本意是避免塑料感，但 3.0-pro 的精度把这些**全部实现了** ——
 * 出来的图有雀斑、肤色斑驳、鼻翼泛红、眼下暗沉，看着"脏"。
 * 用户的原话是"太怪了，也不好看"。</p>
 *
 * <p><b>换思路</b>：不靠"画毛孔"来换取真实感，而是靠**干净的皮肤 + 自然光泽 +
 * 明确的光线**。真人好看的照片也是这个逻辑 —— 皮肤干净透亮，不是细节多。</p>
 *
 * <p>所以删掉：毛孔、不均匀、不是磨皮、不是明星脸。
 * 加上：通透、干净、自然光泽、眼神清明。</p>
 */
/*
 * 外貌锚（2026-11-03 第六版）。
 *
 * <p><b>第五版的身材为什么不对</b>：整段只有一句「身形纤细，肩窄，锁骨清晰」——
 * 没有身高、没有三围、没有腰胯和腿的比例。文生图模型不会留白，它会拿训练里
 * 最常见的那种体型来填：极瘦、肩塌、胸平、没有腰线，再配上「二十岁出头 +
 * 婴儿肥 + 长相偏可爱」，出来的是十五六岁的平板少女（实测 11-03 10:56 那张）。
 * 「锁骨清晰」也被执行成"胸骨突出、肩更窄"，加重病态瘦。</p>
 *
 * <p><b>这版的做法</b>：把年龄写到「二十三岁，成年女性」，身材给**具体数字和比例**
 * （身高、骨架、胸腰胯、腿的比例），并且正反都说一句——「偏瘦但有肉感」「不是骨感」。
 * 和长相一样，这几十个字**一个字都不能改**：换一个说法就是另一个人。</p>
 */
const APPEARANCE_ANCHOR = '二十三岁，成年女性。长相偏可爱，气质干净清透。'
  + '脸很小，脸颊有一点点婴儿肥，下巴尖；'
  + '皮肤白皙，白里透着淡淡的粉，细腻干净，有柔和的光泽。'
  + '眼睛大而圆，双眼皮，瞳色深，眼神亮；'
  + '鼻子小巧，鼻梁细；'
  + '嘴唇薄而小，唇形窄，几乎看不出厚度，唇色是很淡的粉，嘴角平、不上翘。'
  + '黑色长发，发质细软蓬松，有光泽，长度到胸口。'
  + '身高 163cm，骨架正常偏小；肩窄但不塌，锁骨平直、不显骨。'
  + '胸不大，腰细，胯部有一点圆，腿直、腿部比例略长；'
  + '整体偏瘦但有肉感，不是骨感，少女体型。'
  + '淡妆或无妆，皮肤看起来是素颜的白。';

/**
 * 「你长什么样」那一段（2026-10-28）。
 *
 * <p>不只是一段描述，还带一句"怎么用" —— 因为生图提示词是**她自己写的**，
 * 得让她知道「照片」和「画」要分开写，否则每次都把写实和插画混在一起。</p>
 */
function appearanceBlock() {
  if (cfg.appearanceEnabled === false) {
    return '';
  }
  return [
    '【你长什么样】',
    `  ${APPEARANCE_ANCHOR}`,
    '  ⚠️ 上面这段**只有长相和身材**。发型、穿着、动作、背景、光线、表情，'
    + '全部**来自当下聊天里他说的话**，不要套用固定的那一套。',
    '  （**照片和画是两套东西，别混**）',
    '   · 他说"拍张照片" → **照片**路线。风格词：'
    + '「手机随手拍，窗边侧光或柔和自然光，光从侧面落在脸上，'
    + '正视角或轻微俯拍，标准焦距 26-35mm，画面干净，'
    + '皮肤质感干净细腻，人像略柔，五官清秀精致，'
    + '不修图，无重滤镜，色调自然，」'
    + '再加「背景简洁（一面墙 / 窗 / 桌面），不要杂物堆叠，人物占画面主要位置」。',
    '   ⚠️ 照片那条**别写**「噪点、颗粒感、低饱和、掉色、胶片」 ——'
    + '那些词会让画面变脏；也**别写**"背景有点乱也没关系" ——'
    + '杂乱的背景（纸箱、电线、皱布）会直接毁掉整张图。',
    '   ⚠️ 也**别写**「嘴唇饱满、厚唇、丰唇、m 型唇」 —— 那些词出来是欧美大嘴，',
    '   和她的脸完全不搭。嘴唇就是薄薄一条，别描述成形状。',
    '   · 你自己想画点什么 → **画**路线。风格词：'
    + '「水彩速写（或彩铅、厚涂丙烯），画面有笔触，颜色平，边缘不实，大片留白，」'
    + '⚠️ 别加「照片/写实/摄影/相机/皮肤纹理」——那是照片的词。',
    '   · **照片那条**不许出现「插画/水彩/动漫/手绘/笔触」；'
    + '**画那条**不许出现「照片/写实/摄影/相机」。混了就废了。',
    '   · 怎么分：照片有光影层次、构图干净；画有笔触、颜色平、留白多。',
    '   · 你自己知道哪个是哪个：**他让你拍的那张是照片，你自己想画的那张是画。**'
    + '（所以他发"拍一张"时，别说是画的。）',
    '   ② 上面那段外貌（**原样抄，一个字别改**）',
    '   ③ 这一轮他要求的穿着 / 动作 / 场景 / 光线 / 表情 —— '
    + '他说了就用他的；没说就按处境自己定（半夜穿睡衣、在家就随便）。',
    /*
     * 构图表（2026-11-02）。
     *
     * <p><b>原来的问题</b>：只写了「画半身或特写」一句 —— 模型理解成"半身"，
     * 于是不管要拍什么，出来的都是"上半身 + 一张脸"。让他拍腿，也给一整条腿
     * 接在上半身下面；让他拍脚，还是先给半身。</p>
     *
     * <p><b>根因有两个</b>：① 没有"按部位定构图"的规则；
     * ② 模型默认"人像必须有脸"，从来没被告知**局部特写可以不出现脸**。</p>
     *
     * <p>第三个问题是脸本身：原来只说"眼睛睁开看向镜头"，没说头要正 ——
     * 模型爱画 45 度侧头，侧过去五官就压缩了，出来是大小眼、鼻子歪。</p>
     */
    '   ④ **构图按"拍什么"来定，不是每次都半身**：',
    '     · 脸 / 自拍 → 半身，脸是主体；',
    '     · 上半身 / 上衣 → 胸口以上；',
    '     · **腿 / 裤袜 / 鞋** → **只拍下半身**：坐在床沿或地板上，',
    '       手机拿低一点往下拍，画面里是腿和一小块床单、地板，',
    '       **不要有上半身、不要有脸**；',
    '     · 手 / 脚 / 戒指 / 指甲 → 只拍那一个部位，别的一律不入镜。',
    '     · 其他局部（腰、背、肩）→ 只拍那一段，同样别拉全身上来。',
    '   ⚠️ **脸不是每张都必须有**。他要的是局部，画面上冒出个头就是拍错了。',
    '   ⚠️ 脸入镜时**头是正的** —— 别侧头、别歪头、别只露半边脸。',
    '      侧头会把五官压扁（大小眼、鼻子歪）。身子可以侧，脸要正对镜头。',
    '   ⑤ 表情和姿势：表情放松、眼睛睁开 —— 自拍不低头、不闭眼，那样像有心事；',
    '     **嘴角放松、微微抿着就够，别咧嘴笑** —— 一笑嘴唇就被拉宽拉薄，脸也变形。',
    '      坐着就坐直、肩膀放松，别驼背。',
    '   平时自己画画用「水彩速写风格，」，不带外貌那段。',
    '   提示词里别写"全身" —— 那最容易画错。',
    '  ⚠️ **生成完必须发出去**：把工具返回的地址用 [发图 <地址>] 写进回复里，'
    + '否则对方只收到一段文字，看不到图。这一步经常被忘，别忘了。',
    '  只有**你这一轮刚拍的那张**没发出去，才说 [发图 最近] —— 它会重发 15 分钟内生成的那张。',
    + '  ⚠️ 这一轮你根本没拍过，就**别写这个标记** —— 直接调 generate_image 重新拍。',
    + '  写 [发图 最近] 去发一张几小时前的旧图，对方会觉得莫名其妙。',
  ].join('\n');
}

function factsBlock(peer) {
  if (cfg.factsEnabled === false) {
    return '';
  }
  const list = allFacts(peer);
  if (list.length === 0) {
    return '';
  }
  const out = [];
  const rel = list.find((x) => x.kind === 'relation');
  if (rel && rel.value) {
    out.push(`【你对他/她的印象】${rel.value}`);
  }
  const others = list
  /*
   * 衰减到接近 0 的不再注入（2026-11-01）。
   *
   * 阈值 0.05：base 最小约 0.25（confidence 0.5 × log(2)），
   * 0.05 相当于"过了 80% 保质期且只提过一次"。
   * 数据不删 —— 他再提起时 hits 累加，权重自己会回来。
   */
  .filter((x) => factScore(x) > 0.05)
    .filter((x) => x.kind !== 'relation' && FACT_LABEL[x.kind] !== undefined)
    .sort((a, b) => factScore(b) - factScore(a))
    .slice(0, FACT_MAX)
    .map((x) => `  ${FACT_LABEL[x.kind]}${x.value}`);
  if (others.length > 0) {
    out.push(['【你记得关于他的事】', ...others].join('\n'));
  }
  return out.join('\n');
}

/*
 * 印象（2026-10-28 并入统一记忆）。
 *
 * <p>原来是一份独立的 `impressions.json`：`{ peer: { text, updatedAt, msgCount } }`。
 * 现在它就是 `memory/facts.json` 里 `relation` 那条事实 —— 都是"关于这个人的认知"，
 * 没理由分两个文件、两套读写。</p>
 *
 * <p>`msgCount` 保留在 fact 上（用于判断"又聊了 20 句才值得重写"），
 * 读写统一走 `getFact` / `setFact`。</p>
 */

/**
 * 写日记（2026-10-21）。
 *
 * <p><b>为什么由心跳触发、而不是定时打卡</b>：参考同类项目的经验 ——
 * "每天 23:00 准时写一条，那叫打卡，不叫日记"。所以这里检查间隔是 3~12 小时随机，
 * 且只有 30% 的概率真的写，模型还可以直接回 `[不写]`。</p>
 *
 * <p><b>为什么用独立会话</b>：`qq:diary:<uin>` —— 独处时的自言自语不该写进任何
 * 联系人的对话历史，否则下次召回会把"她自己的心事"当成"跟某人说过的话"。</p>
 */
/**
 * 今天找过她的人（给日记当素材，2026-10-22）。
 *
 * <p>没有这份名单，她写日记时**无材料可写**，只能反复描摹"光挪到桌子哪边" ——
 * 看着像散文，一眼假。真人日记写的是"今天谁找我了、说了什么让我在意"。</p>
 *
 * <p>只给"谁 + 大概几条"，**不给聊天内容** —— 复述内容会让日记变成聊天记录摘要。</p>
 */
function todayContacts() {
  const dayStart = new Date();
  dayStart.setHours(0, 0, 0, 0);
  const since = dayStart.getTime();
  const out = [];
  for (const [peer, rec] of recentContacts.entries()) {
    if ((rec.lastAt || 0) < since) {
      continue;
    }
    const c = contacts[String(peer)];
    const name = c && c.nick ? c.nick : '';
    const who = name ? `${name}（${peer}）` : String(peer);
    const kind = rec.isPrivate ? '私聊' : '群';
    // 字段是 count（不是 msgCount）—— 见 recentContacts.set 的写入点
    out.push(`  · ${kind} ${who}，约 ${rec.count || 0} 条`);
  }
  return out.slice(0, 8);
}

async function maybeWriteDiary() {
  if (!cfg.diaryEnabled || !stats.connected || !cfg.agentId) {
    return;
  }
  const now = Date.now();
  const gapHours = 3 + Math.random() * 9;   // 3~12 小时
  if (now - (selfState.lastDiaryAt || 0) < gapHours * 3600000) {
    return;
  }
  if (Math.random() > 0.3) {
    return;   // 多数时候不想写，这才正常
  }
  selfState.lastDiaryAt = now;
  saveSelfState();

  const today = todayContacts();
  /** 最近三条日记（用于防重复话题，2026-10-26）。 */
  const recentDiary = readDiary(3);
  const prompt = [
    '（独处时刻，没人在跟你说话，这条也不会被任何人看到。）',
    '如果想写就写；不想写就只回 [不写]。',
    '第一行写心情（两三个字），第二行起写内容，不超过四句。',
    /*
     * 2026-10-22 重写。
     *
     * 旧版明确写着"不要汇报你和谁说了几次话" —— 把**唯一的材料来源**禁掉了，
     * 于是她只能写"上午十一点的阳光斜着落到桌角"这类句子，四条日记全是光和桌子，
     * 越写越空。真人日记写的正是"今天谁找我了、谁那句话让我在意"。
     */
    '写这些（要**具体、有事件**）：',
    '  · 今天谁找过你、聊到什么、你当时什么感觉 —— **不用复述内容**，写感受就行',
    '  · 什么事让你开心 / 有点烦 / 在意了一下',
    '  · 你自己做了什么、想通了什么、没做成什么',
    '不要写：',
    '  · 纯景物和光影 —— "阳光斜着落到桌角"这种是散文，不是日记',
    '  · "今天真是充实的一天"这种总结句',
    '  · 文艺腔。口语、流水账、甚至有点乱都可以。',
    ...(today.length > 0 ? ['【今天找过你的人】', ...today] : []),
    /*
     * 防话题粘连（2026-10-26）。
     *
     * 实测最近 6 条日记里 4 条在写「画画 / 那张纸 / 一道歪线」。日记会被注入
     * 每轮上下文，写什么就聊什么 —— 于是那段时间她开口闭口都是画。
     *
     * 把最近三条摆给她看，明确说「别重复」：她其实能判断，只是之前没人提醒。
     */
    ...(recentDiary.length > 0
      ? [
          '',
          '【你最近几天写过的】',
          ...recentDiary.map((d) => `  ${d.time} ${d.text.slice(0, 36)}…`),
          '',
          '**这几天一直在写同一件事的话，就换个角度，或者干脆不写。**',
        ]
      : []),
  ].join('\n');

  try {
    const answer = await askPlatform(`qq:diary:${stats.uin}`, prompt, [], null);
    const text = String(answer || '').trim();
    if (!text || text.includes('[不写]')) {
      diag('diary: 这次不想写');
      return;
    }
    const lines = text.split('\n').map((s) => s.trim()).filter(Boolean);
    const mood = lines.length > 1 ? lines[0].slice(0, 10) : '';
    const body = (lines.length > 1 ? lines.slice(1).join(' ') : lines[0]).slice(0, 200);
    if (!body) {
      return;
    }
    appendDiary({ time: fmtNow(), mood, text: body });
    diag(`diary: 记了一条「${body.slice(0, 40)}」`);
  } catch (e) {
    diag(`diary failed: ${e.message}`);
  }
}

/**
 * 自己发一条说说（2026-10-22）。
 *
 * <p><b>补的是什么</b>：原来只有"对话里模型写 `[说说 内容]` 才发"这一条路径，
 * 而**提示词里从没告诉过它可以这么写** —— 等于这个功能一直没被触发过。</p>
 *
 * <p><b>为什么改成独处时发</b>：真人发动态更像独处做的事 —— 没人找你，
 * 你忽然想起点什么，就发一条。挂在对话里反而怪（正聊着天突然发条动态）。
 * 所以和日记同一套节奏：随机间隔 + 概率 + 可以拒绝。</p>
 *
 * <p>安全兜底：`qzoneEnabled` 默认关；`qzoneUgcRight` 默认 1（仅自己可见）；
 * 还有 `qzoneCooldownHours` 冷却。三个开关都在，不会一开就刷屏。</p>
 */
async function maybePostQzone() {
  if (!cfg.qzoneEnabled || !stats.connected || !cfg.agentId) {
    return;
  }
  const now = Date.now();
  // 冷却（默认 24 小时）—— 比日记更保守，动态是给所有人看的
  const cooldown = (Number(cfg.qzoneCooldownHours) || 24) * 3600000;
  if (now - (selfState.lastQzoneAt || 0) < cooldown) {
    return;
  }
  // 概率：多数检查都放弃，一天最多一两条
  if (Math.random() > 0.25) {
    return;
  }

  /*
   * 提示词（2026-10-25 重写）。
   *
   * 旧版写的是"写你此刻真的在想的事" —— 但没有"此刻"的素材，她只能编。
   * 结果出来是「手机快没电了，也不知道要不要给他发消息」这种，看着像
   * 小说片段，不像朋友圈。
   *
   * 三个改动：
   *   ① 说清**读者是谁**（好友都能看到），而不是"没人看"；
   *   ② **限长**：一两句，最多三句 —— 朋友圈本来就这么短；
   *   ③ 给**具体素材**（最近谁找过你），让她有东西可写，不用编。
   *
   * 另外 `skipDiary: true`：不注入日记。日记是文艺腔，注入之后她会顺着
   * 那个腔调续写，越写越像散文。
   */
  /*
   * 「最近找过你的人」必须带时间（2026-11-01）。
   *
   * <p><b>实测问题</b>：10-24 用小号「墨染」测过她一次，10-31 发说说时
   * 这条仍被列进「最近找过你的人」，而且**只写"聊过 N 句"、不写多久之前** ——
   * 她于是发了「有人打听我跟他的事，问得比我自己都上心」，
   * 把八天前的一次试探当成刚刚发生的事。</p>
   *
   * <p>两个改动：① 只列 72 小时内说过话的；② 每条前面标相对时间。</p>
   */
  const QZONE_CONTACT_TTL_MS = 72 * 3600000;
  const recent = [...recentContacts.entries()]
    .filter(([, v]) => v.isPrivate)
    .filter(([, v]) => Date.now() - (v.lastAt || 0) <= QZONE_CONTACT_TTL_MS)
    .sort((a, b) => (b[1].lastAt || 0) - (a[1].lastAt || 0))
    .slice(0, 4)
    .map(([peerId, v]) => {
      const c = contacts[String(peerId)];
      const who = c && c.nick ? c.nick : String(peerId);
      const imp = getFact(peerId, 'relation');
      return `  · ${who}（${relTime(v.lastAt)}聊过 ${v.count || 0} 句）${imp && imp.value ? '：' + imp.value : ''}`;
    });

  const prompt = [
    '（独处时刻。要不要在 QQ 空间发条说说？）',
    '',
    '**这条好友都看得见**，不是日记。',
    ...(recent.length > 0 ? ['', '【最近找过你的人】', ...recent] : []),
    '',
    '写法则：',
    '· **一两句就够**，最多三句 —— 朋友圈没人写小作文；',
    '· 像随手记一笔：今天发生了什么、想吐槽什么、突然想到什么；',
    '· 上面列的是**过去**谁找过你、多久之前 —— 别把几天前的事说成刚刚发生的；',
    '· 没有新事就写别的，不用非扯到人身上；',
    '· 不用交代背景，语焉不详也行；',
    '· **不要写景**（"光挪到桌角""风把窗帘吹起来"这种），那是日记；',
    '· 不要鸡汤，不要总结"今天真充实"。',
    '',
    '没什么想说的就只回 [不发]。',
  ].join('\n');

  try {
    const answer = await askPlatform(
      `qq:qzone:${stats.uin}`,
      prompt,
      [],
      null,
      {
        skipDiary: true,
        // 只带最近两轮：说说会话的历史全是"要不要发"的问答，
        // 看多了她会照着上一次的句式写，一次比一次套路
        maxHistoryTurns: 2,
      },
    );
    const text = String(answer || '').trim();
    if (!text || text.includes('[不发]')) {
      diag('qzone: 这次不想发');
      return;
    }
    await tryPostQzone(text.slice(0, 300));
  } catch (e) {
    diag(`qzone failed: ${e.message}`);
  }
}

/**
 * 更新"印象"（2026-10-21）。
 *
 * <p>事实记忆（他养了只猫）由平台的四层记忆负责；这里记的是**判断**——
 * "话多但不烦人"这种几个字的印象。参考同类项目的提醒：**人会变，要定期重写**，
 * 否则三个月后还在用第一次见面的判断跟人说话。</p>
 *
 * <p>轮询式更新，一轮只处理一个联系人 —— 免得心跳里串行几十次模型调用。</p>
 */
async function maybeUpdateImpressions() {
  if (!cfg.impressionEnabled || !stats.connected || !cfg.agentId) {
    return;
  }
  const now = Date.now();
  const week = 7 * 86400000;

  for (const [peer, rec] of recentContacts.entries()) {
    if (!rec.isPrivate) {
      continue;
    }
    const count = rec.count || 0;
    /*
     * 门槛从写死的 20 降到可配的 8（2026-10-23）。
     *
     * 20 句对"新加的人"太高了 —— 聊十几句她还是一句印象都没有，
     * 表现就是"对谁都一个态度"。8 句足够看出语气和话题偏好。
     * 太低了会瞎猜，所以下限留在 5。
     */
    const minMsgs = Math.max(5, Number(cfg.impressionMinMsgs) || 8);
    if (count < minMsgs) {
      continue;
    }
    // 2026-10-28：印象就是 facts.json 里的 relation 事实
    const old = getFact(peer, 'relation');
    if (old && now - (old.lastAt || 0) < week) {
      continue;   // 一周内不重写
    }
    if (old && count - (old.msgCount || 0) < 20) {
      continue;   // 又聊了不到 20 句，没必要重写
    }

    try {
      /*
       * 印象总结必须读**同一段**真实对话（2026-10-23）。
       * 不带 epoch 的话它读到的是空历史 —— 印象只能靠瞎猜，
       * 而不是看这人实际说过什么。
       */
      const sessionId = dialogSessionId(peer);
      /*
       * 印象里要带「他是谁」（2026-10-23 改）。
       *
       * 原来只让概括"印象"（话多、爱开玩笑），等于只记了风格，**不记身份** ——
       * 所以新号来聊时她还是分不清"这人是熟人还是陌生人"。
       * 现在要求她顺带记下对方自己说过的身份（"自称是我男朋友"这类），
       * 下次同一个人再来，这条就会通过 timeContext 回到她眼前。
       */
      const answer = await askPlatform(
        sessionId,
        // 系统让做的事，包起来 —— 否则"概括印象"这句指令会留在历史里被当成对方的话
        sysHint(
          '（用**不超过 30 个字**概括你对这个人的印象：他是谁 / 什么关系 / 什么风格。'
            + '如果他明确说过自己是谁（比如"我是你男朋友"），一定要记进去。'
            + '只输出那一句话，不要解释。）',
        ),
        [],
        peer,
      );
      const text = String(answer || '').replace(/\s+/g, ' ').trim().slice(0, 60);
      if (text) {
        // 写进统一记忆；msgCount 是印象专用的进度标记，单独补上
        setFact(peer, 'relation', text, 'inferred');
        const box = readFacts()[String(peer)];
        if (box && box.relation) {
          box.relation.msgCount = count;
          writeFacts();
        }
        diag(`impression updated for ${peer}: ${text}`);
      }
    } catch (e) {
      diag(`impression failed for ${peer}: ${e.message}`);
    }
    break;   // 一轮一个
  }
}

// ------------------------------------------------------------------ P3：自我管理 + 主动发言

function selfStatePath() {
  return path.join(api.dataDir, 'self-state.json');
}

function loadSelfState() {
  try {
    const raw = JSON.parse(fs.readFileSync(selfStatePath(), 'utf8'));
    for (const k of Object.keys(selfState)) {
      /*
       * number / string / boolean 都要接受（2026-10-21 补 boolean）。
       *
       * `profileInit` 是布尔型"一次性资料是否已初始化"。漏掉它的话每次重启
       * 都会被重置成 false → 模型被重新问一次、资料被重新设一遍 ——
       * 两次答案不同就变成了反复改资料，那正是最可疑的账号行为。
       */
      const v = raw[k];
      /*
       * 简单类型 + **普通对象**（2026-10-26 补对象）。
       *
       * <p>原来只接受 number / string / boolean。新加的 `proactiveChain`
       * 是个对象 `{ count, peer, lastAt }` —— 保存时写进文件了，**加载时被静默丢弃**，
       * 于是重启后 `count` 永远是 0，连续追发一次都没执行过。</p>
       *
       * <p>数组仍然不接（现有字段没有数组，避免误吞奇怪结构）。</p>
       */
      const simple = typeof v === 'number' || typeof v === 'string' || typeof v === 'boolean';
      const plainObj = v !== null && typeof v === 'object' && !Array.isArray(v);
      if (simple || plainObj) {
        selfState[k] = v;
      }
    }
    diag(`self-state loaded: ${JSON.stringify(selfState)}`);
  } catch {
    /* 首次运行没有这个文件 */
  }
}

function saveSelfState() {
  try {
    fs.writeFileSync(selfStatePath(), JSON.stringify(selfState, null, 2), 'utf8');
  } catch (e) {
    diag(`save self state failed: ${e.message}`);
  }
}

const pickRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];

/** 把 [min,max] 天转成随机毫秒。 */
const randomDays = (range) =>
  (range[0] + Math.random() * Math.max(0, range[1] - range[0])) * 86400000;

/**
 * 按模型给的「画面描述」从头像池里挑一张（2026-10-21）。
 *
 * <p>不做随机：模型说"想要一只橘猫"，就在文件名里找含"橘猫/猫"的图；
 * **找不到就不换**，而不是随便塞一张 —— 否则"模型决定"又退化成"随机"。</p>
 *
 * <p>为什么不用图片生成：插件之间不能互调工具（图片生成插件调不到），
 * 要生成就得让插件自己配一份生图密钥，那是另一层负担。用文件名当标签更轻。</p>
 */
/**
 * 头像文件夹（2026-10-22）。
 *
 * <p>优先用配置里的目录；没配就用插件数据目录下的 {@code avatars/}（自动创建）。</p>
 *
 * <p><b>为什么要有默认值</b>：以前没配 {@code avatarDir} 就**既不能存也不能找** ——
 * 而"她给自己画的头像要留着、以后还能翻出来"正是这个功能的重点。
 * 默认放在插件数据目录，用户不用做任何配置就能用。</p>
 */
function avatarPoolDir() {
  const configured = cfg.avatarDir && String(cfg.avatarDir).trim();
  const dir = configured || path.join(api.dataDir, 'avatars');
  try {
    fs.mkdirSync(dir, { recursive: true });
  } catch (e) {
    diag(`avatar pool mkdir failed: ${e.message}`);
  }
  return dir;
}

/**
 * 把她画出来 / 选中的头像存进文件夹（2026-10-22）。
 *
 * <p>文件名带关键词（{@code self_1761..._白发少女.png}）—— **文件名就是标签**，
 * 以后 {@link pickAvatarByHint} 用"白发少女"就能把自己的旧作找回来。</p>
 */
function saveAvatarToPool(base64, hint) {
  if (!base64) {
    return null;
  }
  const dir = avatarPoolDir();
  const safe = String(hint || '')
    .replace(/[\\/:*?"<>|\r\n\t]+/g, '_')
    .replace(/\s+/g, '_')
    .slice(0, 40)
    .replace(/^_+|_+$/g, '');
  const name = `self_${Date.now()}${safe ? '_' + safe : ''}.png`;
  try {
    fs.writeFileSync(path.join(dir, name), Buffer.from(base64, 'base64'));
    diag(`avatar pool += ${name}`);
    return name;
  } catch (e) {
    diag(`avatar pool save failed: ${e.message}`);
    return null;
  }
}

function pickAvatarByHint(hint) {
  if (!hint) {
    return null;
  }
  const dir = avatarPoolDir();
  try {
    const files = fs.readdirSync(dir).filter((f) => /\.(png|jpe?g|gif|webp)$/i.test(f));
    if (!files.length) {
      diag('avatar dir is empty');
      return null;
    }
    // 把描述拆成词，任一词出现在文件名里就算命中
    const words = String(hint)
      .split(/[,，、;；\s]+/)
      .map((w) => w.trim())
      .filter((w) => w.length >= 1);
    const hit = files.filter((f) => words.some((w) => f.includes(w)));
    if (!hit.length) {
      diag(`avatar hint "${hint}" 在池子里没有匹配的图，跳过换头像`);
      return null;
    }
    return fs.readFileSync(path.join(dir, pickRandom(hit))).toString('base64');
  } catch (e) {
    diag(`avatar dir unreadable: ${e.message}`);
    return null;
  }
}

/**
 * 下载一张图并转 base64（2026-10-21）。
 *
 * <p>用于模型给出的图片直链：`image_gen` 生成结果、或 `web_search` 找到的图。
 * 转 base64 而不是把 URL 直接交给 NapCat —— NapCat 若在 Docker 里，
 * 它自己去拉外网图可能失败（DNS/代理不同），而插件这边是宿主网络，更可靠。</p>
 */
async function fetchImageAsBase64(url) {
  if (!url || !/^https?:\/\//i.test(url)) {
    return null;
  }
  try {
    /*
     * 带浏览器 UA + Referer（2026-10-21）。
     *
     * 从图片站抓下来的图**经常有防盗链**：默认的 Node UA 会被直接回 403，
     * 或者回一张"禁止外链"的占位图。带上 UA 和来源页，成功率明显提高。
     */
    const res = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
          + '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': new URL(url).origin + '/',
        'Accept': 'image/avif,image/webp,image/*,*/*;q=0.8',
      },
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) {
      diag(`avatar url HTTP ${res.status}: ${url.slice(0, 80)}`);
      return null;
    }
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length === 0 || buf.length > 8 * 1024 * 1024) {
      diag(`avatar image size abnormal: ${buf.length} bytes`);
      return null;
    }
    diag(`avatar image downloaded: ${Math.round(buf.length / 1024)}KB`);
    return buf.toString('base64');
  } catch (e) {
    diag(`avatar url fetch failed: ${e.message}`);
    return null;
  }
}

/**
 * 让模型自己决定要不要改资料（2026-10-21，替代"随机抽池子"）。
 *
 * <p>随机抽取的问题：它没有"自我"。同一个模型上一秒叫"小白"、下一秒叫"小雾"，
 * 全靠 Math.random —— 那不叫拟人，叫换皮。让模型基于自己的人格与最近经历来决定，
 * 才有"这个号是一个人"的连续性。</p>
 *
 * <p><b>独立会话</b>：`qq:selfmanage:<uin>`，不写进任何对话历史 ——
 * 自我检视的独白不该污染某个联系人的上下文。</p>
 */
async function askSelfDecision(reason) {
  /*
   * 自我认知素材（2026-10-21）。
   *
   * 自我管理用的是**独立会话** `qq:selfmanage:<uin>` —— 它没有跟任何人的对话历史，
   * 平台的按会话记忆在这里取不到东西。所以"它最近经历了什么"只能从这两处补：
   *   · 日记：它自己写下的心情与琐事（最直接的自我认知）
   *   · 印象：它对常聊那几个人的判断（决定它怎么对人）
   * 人格本身在系统提示词里，不需要也不该在这里重复。
   */
  const diaryLines = readDiary(3)
    .map((d) => `${d.time}${d.mood ? `（${d.mood}）` : ''} ${d.text}`);
  const impLines = recentImpressions(5).map((i) => `${i.peer}：${i.text}`);
  /** 最近别人对她的评价 —— 让她有"想起那句话"的素材。 */
  const selfNotes = readSelfNotes(5);
  /*
   * 她账号上的完整资料（2026-10-22 加）。
   *
   * 之前只喂了"昵称 + 签名"，而且签名读的是插件记的旧值（账号上其实是空的）。
   * 性别、生日、学校、所在地一概不知道 —— 她既说不出"我在哪"，
   * 也没法判断哪些资料还没填。现在直接把她账号上的真实值摊给她看。
   */
  const profileText = selfProfileBlock(await fetchSelfProfile());
  /*
   * 待办（2026-10-22）：她说"等下找你""明天再问"时记下的。
   * 现在列给她，**由她决定**要不要做 —— 也可以继续放着，甚至忘了。
   */
  const todoLines = readTodos(5).map((t) => {
    const d = new Date(t.at || 0);
    const stamp = `${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
      + ` ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
    const c = contacts[String(t.peer)];
    const who = c && c.nick ? c.nick : (t.peer ? String(t.peer) : '');
    return `· ${stamp}${who ? `（对 ${who}）` : ''}：${t.text}`;
  });

  /*
   * 一次性资料（2026-10-21）：NapCat 的 `set_qq_profile` 只开放
   * nickname / personal_note / sex 三项。nickname 归日常改，剩下两个定为一次性 ——
   * 初始化过一次就不再问，提示词里也不再出现。
   */
  const needProfileInit = !selfState.profileInit;

  const prompt = [
    '（这是一次自我检视，对方看不到这条消息，不需要回复任何人。）',
    /*
     * 触发原因（2026-10-22）：从对话里被 `[想换头像]` 唤起时传进来。
     *
     * 没有这句，她在检视里就"想不起来刚才发生了什么"，大概率觉得"现在挺好"什么都不换。
     * 但也只给一句概况 —— **要不要因此做点什么，仍然她自己判断**
     * （可能想完觉得对方只是随口一说，那就不动）。
     */
    ...(reason ? [`【刚才】${reason}`, '—— 这让你想到什么？要不要为此做点什么，你自己决定。'] : []),
    /*
     * 用账号上的真实资料替换原来的两行硬编码（2026-10-22）。
     * 空值会显示"（未设置）"，她能据此判断哪些还没填。
     */
    ...(profileText ? [profileText] : []),
    `（插件记的旧值：昵称「${selfState.nicknameValue || '未记录'}」，`
      + `签名「${selfState.signatureValue || '空'}」—— 以上面账号资料为准。）`,
    /*
     * 上一次的想法（2026-10-21 加）：不记得上次想要什么，每次就都是"随便想一个"。
     * 给它连续性，它才可能慢慢形成一个稳定的自我形象。
     */
    `你上次说，自己想要的头像是「${selfState.avatarWish || '（还没说过）'}」。`,
    /* 让她知道"有存货"：文件夹里存着她画过/用过的头像，文件名就是标签。 */
    '你的头像文件夹里存着你以前画过、用过的头像（文件名就是标签，形如 self_1761xxx_白发少女.png）——'
      + '想找回来重用时，用文件名里的词当 avatarHint 就行。',
    ...(diaryLines.length > 0 ? ['【你最近写的日记】', ...diaryLines] : []),
    ...(impLines.length > 0 ? ['【你对这些人的印象】', ...impLines] : []),
    ...(todoLines.length > 0
      ? [
          '【你之前记下的】',
          ...todoLines,
          '—— 现在合适就去做（主动找他说一句），不合适就继续放着。',
          '忘了也没关系，本来就不是什么大事。',
        ]
      : []),
    /*
     * 别人怎么评价她（2026-10-22）。
     *
     * 这是"她会自己想起来"的前提：没有这段，被说一句"头像丑"就只能当场照做，
     * 或者干脆忘掉。有了它，她才有"过了一阵，忽然想起那句话"的余地。
     * 是否采纳仍然是她自己的判断 —— 提示词明确允许"没道理就不理会"。
     */
    ...(selfNotes.length > 0
      ? [
          '【最近有人这样说过你】',
          ...selfNotes.map((n) => `${n.time} ${n.from}：${n.text}`),
          '—— 这些话有没有道理，你自己掂量。有道理就改，没道理就不必理会，也不用讨好谁。',
        ]
      : []),
    /*
     * 昵称 / 签名**不再在这里询问**（2026-10-22 改）。
     *
     * 原来写的是\"如果你此刻想换昵称 / 签名 / 头像，就给出新的\" —— 这等于每隔几小时
     * 就有人问它一句\"你想改吗\"。真人很久才改一次签名，而**被问多了就会改**，
     * 越改越像在\"运营账号\"。
     *
     * 现在只有头像走定时检查（它需要工具链、冷却也长，定期看一眼合理）；
     * 昵称和签名改成**对话里她自己真觉得该换时**才动（`[改昵称 xxx]` / `[改签名 xxx]`）。
     */
    '这轮**只看头像**。昵称和签名不用管 —— 那些等你自己真觉得该换时再说。',
    /*
     * 换头像（2026-10-21 第二次调整）。
     *
     * 上一版只说"把你想要的画面当提示词"，跳过了最关键的一步 —— **想清楚自己要什么**。
     * 模型于是随便想个词（"可爱 头像"）就去搜，搜到啥用啥。
     * 现在拆成三步：先认识自己、再定具体画面、最后才动手拿图。
     */
    '★ 想换头像之前，先想清楚**为什么想换**：',
    '   · 是你自己觉得该换了，还是刚才有谁说了什么？',
    '   · 如果是被人说的 —— 先想那人说得对不对。说得对他就改；他只是嘴欠，就别理，',
    '     更不必因为一句话就慌忙照做。',
    '   想清楚了再往下走：',
    '  第一步 · 我是谁：你是什么风格的存在？这个头像想让人看到你的哪一面？',
    '           —— 从你自己的人格出发去想，不要想"一般人会喜欢什么"。',
    '  第二步 · 我要什么：用一句**具体**的话说出你要的画面。',
    '           要「夜里亮着一盏暖灯的书桌」这种，不要「好看」「可爱」这种谁都能用的词。',
    /*
     * 拿图顺序：**先搜，搜不到才画**（2026-10-22 按用户要求调换）。
     *
     * 之前写的是"优先自己画"，理由是"自己生成的头像独一无二"。但实际用下来不对：
     *   · 搜索几秒回来、一次好几张、还能直接看画面挑；
     *   · 生图慢（pro 模型几十秒）、一次只有一张、不满意还得重来。
     * 拿头像这种"图好看就行"的需求，先搜明显更划算。画只作为兜底。
     */
    '  第三步 · 拿图（**先搜现成的，搜不到才自己画**）：',
    '           ⓐ **先用 `image_search` 搜**：把第二步那句话当关键词。',
    '              它一次回好几张，你直接看画面挑 —— 比画快得多。',
    '              · query：具体、无歧义（别写「银白发」，会被搜成白银行情）',
    '              · engine：保持默认（会先搜画师站，质量比通用引擎高）',
    '              · limit：填 5，多几张才有得挑',
    '              **搜到合心意的就停下，直接填 avatarUrl，不用再画。**',
    '           ⓑ 搜了两三批都不满意 → 才用 `image_gen` 自己画一张：',
    '              把第二步那句话扩写成完整画面描述（主体 + 风格 + 光线 + 构图 + 色调）。',
    '              画出来的会自动存进头像文件夹，以后还能翻出来用。',
    /*
     * 生图次数上限（2026-10-22）。
     *
     * 实测教训：一次任务里连着调 4 次工具（2 搜 + 2 画），总耗时 18 分钟，
     * 而平台的调用超时是 60 秒 —— 图其实生成了，但插件等不到就放弃，
     * 她手上连 URL 都没拿到，整件事白做（用户只能手动救场：
     * "图已经画好了，你现在可以去取"）。
     *
     * 所以硬性压住次数：**一次最多画一张**，画完就用。
     */
    '              ⚠️ 一次任务里**最多调一次 `image_gen`** —— 画完就用，别再画第二张。',
    '                 （每次生成要等几十秒，画两次整件事就会拖到对方收不到回复。）',
    '           ⚠️ `web_search` 给的是网页地址，不是图片，不能当头像。',
    '  ⚠️ 画图的过程（提示词、中间结果）**别发给任何人** —— 除非你确实拿不准、',
    '     想听听对方意见，才用 previewUrls。平时只需要安静地换好就行。',
    /*
     * 挑图这一步（2026-10-22）。
     *
     * 之前的毛病是"看到什么选什么" —— 搜出 3 张，不管好不好看直接挑一张填上。
     * 现在要求它真的评估，并且**明确允许不选**：三张都不满意就整批丢掉重搜。
     * 头像换了要冷却很久，将就一次就是好几天的错。
     */
    '  第四步 · **挑图（不能省）**：看到图之后，逐张问自己三个问题 ——',
    '           ① 它和我是**同一种气质**吗？（我安静，就不该选个张牙舞爪的）',
    '           ② 别人看到这个头像，会觉得**这是我**吗？还是"换谁都行"？',
    '           ③ 有没有一处让我**想多看两眼**？（平淡无味的图不要用）',
    '           三条都过，就把地址填进 avatarUrl。',
    '           **三张都不满意就整批丢掉**，换个角度的关键词再搜一批（最多搜 3 轮）。',
    '           别因为"搜都搜了"就将就 —— 头像是别人对你的第一印象，宁可不换。',
    '           3 轮都没挑中：这轮头像留 null，把你要的样子写进 avatarWish，下次再说。',
    '  （本地图库只是兜底，可能是空的，别指望它。）',
    '  ⚠️ 先看一眼上面列出的可用工具：**既没有 image_search 也没有 image_gen 时别硬找**，',
    '     这轮头像留 null，只写 avatarWish 就好 —— 硬拿网页地址当头像会失败。',
    /*
     * 视觉注入（2026-10-22）：现在 image_search 之后，平台会把前 3 张图**直接作为图片**
     * 追加到对话里。所以它不必再"只凭标题猜"，更不该说"我读不了图"。
     */
    '  ℹ️ 搜索完会接着给你**看前 3 张图**（真的图片，不是链接）—— 直接看画面挑，',
    '     不必只凭标题猜，也不用说"我读不了图"。',
    /*
     * avatarWish：这轮改不改都要写。
     * 插件会存下来，下次自我检视时回给它看 —— 这是它"对自己的想法"能延续的关键。
     */
    '另外请回报 avatarWish：一句话写下你现在「想要什么风格的头像」，'
      + '即使这轮不换也要写，下次我会把它拿给你看。',
    /*
     * 候选图（2026-10-21）：让"你帮我掌个眼"这句话真的能配上图。
     *
     * 之前它在自我管理里说"我挑了几个，你帮我看看"，但**一张图都发不出来** ——
     * 这条路径只解析 JSON，`[发图]` 那套标记根本不生效。现在给它一个专门的字段，
     * 插件会把里面的地址下载下来发给对方。
     */
    '如果你挑不准、想听对方的意见，就把 1~2 个候选图地址写进 previewUrls —— '
      + '我会把这几张图发过去（这样可以，不必自己拿主意）。',
    ...(needProfileInit
      ? [
          '── 还有一件事，只做这一次 ──',
          '你的账号资料还没初始化过。请顺手定两件**定了就不再改**的事：',
          '  · sex：你的性别代码（1=男，2=女，0=未知）',
          '  · personalNote：一句个人说明（介绍你是谁，一两句就行）',
        ]
      : []),
    /*
     * 禁止伪造工具调用（2026-10-22）。
     *
     * 实测事故：她搜了 4 批图（48 张）后，在正文里手写了一段
     * `<notool><result><name>fs_write_file</name><output>{"status":"ok"}</output></result></notool>`，
     * 而后端 toolCalls=0 —— 她根本没调，却以为自己调了。
     * 大概是看到"存进头像文件夹"这件事，不知道怎么触发就编了个格式。
     *
     * 两件事要说清：① 存图是插件自动做的，不用她操心；② 正文里绝不出现 XML 标签。
     */
    '⚠️ 头像的下载和保存由这边自动完成，**你不需要、也无法自己写文件** ——',
    '   更不要在回复里出现任何 XML 标签（如 <notool>、<result>、<output>）。',
    '   那些只会变成乱码发给对方。',
    /*
     * 搜索批数上限（2026-10-22）：4 批 × 12 张 = 48 张图全灌进上下文，
     * 正是那次伪造 XML 的诱因。压到 2 批。
     */
    '  ⚠️ `image_search` 最多调 **2 批**。一批 5 张，两批就是 10 个候选，足够了 ——',
    '     搜太多只会让你自己挑花眼，也没什么好处。',
    '只输出一行 JSON，不要解释、不要代码块：',
    /* 模板里不再出现 nickname / signature —— 不给它\"顺手填一个\"的机会（2026-10-22）。 */
    '{"avatarUrl": "图片直链或 null", "avatarHint": "画面描述或 null", '
      + '"avatarWish": "一句你想要的头像描述", "previewUrls": ["候选图地址"]'
      /*
       * 主动联系出口（2026-10-22）。
       *
       * 光把待办列给她没用 —— 她"想做"却没有发消息的通道（检视输出是 JSON，
       * 不能写正文）。所以给一个字段：想找谁就填 QQ 号 + 想说什么的大意，
       * 插件替她把这句话生成出来发过去。
       */
      + ', "reachOut": {"peer": "想找的QQ号，不想找就 null", '
      + '"hint": "你想跟他说什么（一句话大意）"}'
      + (needProfileInit ? ', "sex": "1/2/0", "personalNote": "一句个人说明"' : '') + '}',
  ].join('\n');

  const answer = await askPlatform(`qq:selfmanage:${stats.uin}`, prompt, [], null);
  diag(`self-manage decision raw: ${JSON.stringify((answer || '').slice(0, 120))}`);
  return parseDecision(answer);
}

/** 把性别归一成 NapCat 认的代码（"2"/2 → "2"；认不出返回 null）。 */
function normalizeSex(v) {
  const s = v == null ? '' : String(v).trim().toLowerCase();
  if (['1', '2', '0'].includes(s)) {
    return s;
  }
  /*
   * 兼容中文/英文写法（模型不一定按代码给）。
   *
   * ⚠️ 这里**不能用** `/m/i` 这种单字母模糊匹配 —— "woman" 里也有 m，
   * 会把女性判成男性。只认完整词与中文。
   */
  if (/男|^male$|^m$/i.test(s)) {
    return '1';
  }
  if (/女|female/i.test(s)) {
    return '2';
  }
  return null;
}

/** 解析模型给的 JSON（宽松：容忍代码块围栏、前后废话、"null" 字符串）。 */
function parseDecision(text) {
  if (!text) {
    return null;
  }
  try {
    const m = String(text).match(/\{[\s\S]*\}/);
    if (!m) {
      return null;
    }
    const j = JSON.parse(m[0]);
    const pick = (v) => {
      const s = v == null ? '' : String(v).trim();
      return !s || s === 'null' || s === 'undefined' ? null : s;
    };
    return {
      nickname: pick(j.nickname),
      signature: pick(j.signature),
      avatarUrl: pick(j.avatarUrl),   // 模型用 image_gen / web_search 拿到的直链
      avatarHint: pick(j.avatarHint), // 只给描述，从本地图库找
      // 「我想要什么头像」—— 与这轮改不改无关，用来形成跨轮次的想法连续性
      avatarWish: pick(j.avatarWish),
      // 一次性资料（可能带引号的数字，如 "2" → 归一成 "1"/"2"/"0"）
      sex: normalizeSex(j.sex),
      // 个人说明：只定一次
      personalNote: pick(j.personalNote),
      // 拿不准时想发给对方看的候选图（最多 2 张，只收 http/https）
      previewUrls: Array.isArray(j.previewUrls)
        ? j.previewUrls
          .map((u) => String(u == null ? '' : u).trim())
          .filter((u) => /^https?:\/\//i.test(u))
          .slice(0, 2)
        : [],
      // 主动联系：{ peer, hint } 或 null（2026-10-22）
      reachOut: (() => {
        const r = j.reachOut;
        if (!r || typeof r !== 'object') {
          return null;
        }
        const peer = Number(r.peer);
        if (!peer || !Number.isFinite(peer)) {
          return null;
        }
        return { peer, hint: String(r.hint == null ? '' : r.hint).trim().slice(0, 120) };
      })(),
    };
  } catch (e) {
    diag(`parse decision failed: ${e.message}`);
    return null;
  }
}

/**
 * 自我管理（文档 §5.5）：**冷却到期才动**，冷却值随机且落盘。
 *
 * <p>为什么不"模型想改就改"：让模型自由决定改资料，等于让它一天改三次 ——
 * 频繁改昵称/头像/签名是最典型的异常账号特征，比不改更容易被风控。</p>
 */
async function maybeSelfManage(opts = {}) {
  if (!cfg.selfManageEnabled || !stats.connected || !cfg.agentId) {
    return;
  }
  const now = Date.now();

  /*
   * 检视冷却（2~6 小时随机）：模型说"不改"之后不能每 10 分钟再问一次 ——
   * 那会白白烧掉一次模型调用。所以"问过"本身就推进这个计时。
   *
   * `forceCheck`（2026-10-22）：对话里她说了 `[想换头像]` 时跳过这道闸 ——
   * 但**头像冷却照旧生效**（下面 avatarDue）。也就是说：有人让她换，她可以"去看一眼"，
   * 可最终换不换仍由她自己判断、仍受冷却约束。
   */
  const minH = Math.max(0.1, Number(cfg.selfCheckHoursMin) || 2);
  const maxH = Math.max(minH, Number(cfg.selfCheckHoursMax) || 6);
  const checkHours = minH + Math.random() * (maxH - minH);
  if (!opts.forceCheck && now - (selfState.lastCheck || 0) < checkHours * 3600000) {
    return;
  }

  // 三类都还在冷却里 → 连模型都不用问
  const avatarDue = now >= (selfState.avatar || 0);
  const signatureDue = now >= (selfState.signature || 0);
  const nicknameDue = now >= (selfState.nickname || 0);
  /*
   * 三类都冷却中 → 连模型都不问（省一次调用）。
   *
   * 例外：对话里她主动说了 `[想换头像]`（`forceCheck`）。那种情况允许她
   * **去看、去挑、去存**，只是不许真换 —— 下面的 `avatarDue` 仍会拦住 set_qq_avatar。
   */
  if (!opts.forceCheck && !avatarDue && !signatureDue && !nicknameDue) {
    return;
  }

  const decision = await askSelfDecision(opts.reason);
  selfState.lastCheck = now;
  /*
   * 先把「头像愿望」存下来再管改不改（2026-10-21）。
   *
   * 两个原因：① 它说"这轮不改"时，愿望依然有效，下次要呈现给它看；
   * ② 提前落盘 —— 万一后面的 set_qq_avatar 抛异常，至少想法没丢。
   */
  if (decision && decision.avatarWish) {
    const prevWish = selfState.avatarWish || '';
    selfState.avatarWish = decision.avatarWish;
    if (prevWish !== decision.avatarWish) {
      diag(`self-manage: 头像愿望 -> 「${decision.avatarWish}」`);
    }
  }
  saveSelfState();
  if (!decision) {
    diag('self-manage: 模型没给出可用决定，本轮跳过');
    return;
  }

  let changed = 0;

  /*
   * 一次性资料（2026-10-21）：只在 profileInit=false 时做，做完打标记、之后永不再问。
   *
   * NapCat 的 `set_qq_profile` 只开放 nickname / personal_note / sex。nickname 归日常改，
   * 这两个（性别、个人说明）属于"定一次就够"的 —— 反复改反而是异常账号特征。
   */
  if (!selfState.profileInit && (decision.sex || decision.personalNote)) {
    /*
     * 六个字段都带上（2026-10-22 修，实测确认）。
     *
     * `set_qq_profile` 的 schema 要求 **company / email / college 也是必填** ——
     * 只传 nickname/sex/personal_note 会回
     * `retcode=1400 Schema compilation error: Expected required property`。
     * 补齐后实测 retcode=0（用当前值传一遍，幂等不破坏数据）。
     *
     * 注意这是**全量覆盖**：缺哪项就会被清空，所以当前值必须从 fetchSelfProfile 拿。
     */
    const curProfile = (await fetchSelfProfile()) || {};
    const patch = {
      nickname: curProfile.nickname || selfState.nicknameValue || '有点钝',
      personal_note: decision.personalNote || curProfile.signature || '',
      company: curProfile.company || '',
      email: curProfile.email || '',
      college: curProfile.college || '',
      sex: decision.sex
        ? Number(decision.sex)
        : (curProfile.sex === 'female' ? 2 : curProfile.sex === 'male' ? 1 : 0),
    };
    try {
      await call('set_qq_profile', patch, 15000);
      selfState.profileInit = true;
      selfState.sexValue = decision.sex || '';
      selfState.personalNoteValue = decision.personalNote || '';
      changed++;
      diag(`self-manage: 一次性资料已初始化 sex=${decision.sex || '-'} personalNote=${decision.personalNote || '-'}`);
    } catch (e) {
      diag(`self-manage profile init failed: ${e.message}`);
    }
  }

  if (nicknameDue && decision.nickname) {
    try {
      await call('set_qq_profile', { nickname: decision.nickname }, 15000);
      selfState.nickname = now + randomDays(cfg.nicknameCooldownDays || [30, 90]);
      selfState.nicknameValue = decision.nickname;
      changed++;
      diag(`self-manage: nickname -> ${decision.nickname}`);
    } catch (e) {
      diag(`self-manage nickname failed: ${e.message}`);
    }
  }

  if (signatureDue && decision.signature) {
    try {
      await call('set_self_longnick', { longNick: decision.signature }, 15000);
      selfState.signature = now + randomDays(cfg.signatureCooldownDays || [3, 14]);
      selfState.signatureValue = decision.signature;
      changed++;
      diag(`self-manage: signature -> ${decision.signature}`);
    } catch (e) {
      diag(`self-manage signature failed: ${e.message}`);
    }
  }

  if (decision.avatarUrl || decision.avatarHint) {
    /*
     * 优先用模型给的直链（它能调 image_gen 生成、或 image_search 找现成的），
     * 拿不到再用「画面描述」去本地图库里按关键词匹配。
     */
    let b64 = decision.avatarUrl ? await fetchImageAsBase64(decision.avatarUrl) : null;
    if (!b64 && decision.avatarHint) {
      b64 = pickAvatarByHint(decision.avatarHint);
    }
    if (b64) {
      /*
       * 先存进头像文件夹，**不管这轮换不换**（2026-10-22）。
       *
       * 两个理由：
       *   ① 她挑中的图就是"她的作品"，该留下来，以后按文件名能翻出来重用；
       *   ② `avatarUrl` 常常是临时链接（百炼的 OSS 24 小时过期），不存就永远丢了。
       *
       * 冷却没到时只存不换 —— 她也算"看过、挑过、留下了"，只是还用不上。
       */
      const savedName = saveAvatarToPool(b64, decision.avatarWish || decision.avatarHint || '');

      /*
       * 能不能真换（2026-10-22 调整）。
       *
       * `avatarDue` 是冷却闸：防"自动频繁改资料"被风控盯上，心跳路径必须受它管。
       *
       * 但**对话里她主动说想换**（`forceCheck`）时不该再被拦住 —— 她已经走完了
       * "自己想 → 自己搜/画 → 三问评估 → 选中"整条路，这时还拿 17 天前的冷却卡着，
       * 结果就是"她明明想了也挑了，头像却不变"，用户看到的就是坏了一样。
       *
       * 区分点在于**谁做的决定**：心跳是她单方面想换，要克制；
       * 对话是有人请求 + 她自己认可，两边都同意了才动手，这不算异常行为。
       */
      const canSet = avatarDue || opts.forceCheck;

      if (!canSet) {
        diag(`self-manage: 头像冷却中，已存 ${savedName}，本轮不换`);
      } else {
        try {
          await call('set_qq_avatar', { file: 'base64://' + b64 }, 30000);
          selfState.avatar = now + randomDays(cfg.avatarCooldownDays || [7, 30]);
          changed++;
          diag(`self-manage: avatar <- ${decision.avatarUrl ? decision.avatarUrl : '"' + decision.avatarHint + '"'}`);
        } catch (e) {
          diag(`self-manage avatar failed: ${e.message}`);
        }
      }
    }
  }

  /*
   * 候选图（2026-10-21）：它说"你帮我掌个眼"时，真的把图发过去。
   *
   * 之前它只在文字里说"我挑了几个"，**一张图都没发** —— 因为自我管理只解析 JSON，
   * `[发图]` 那套标记在这条路径上不生效。现在用 `previewUrls` 字段补上。
   */
  if (decision.previewUrls && decision.previewUrls.length > 0) {
    const peer = pickPreviewPeer();
    if (peer) {
      let sent = 0;
      for (const url of decision.previewUrls) {
        const b64 = await fetchImageAsBase64(url);
        if (b64) {
          await sendImageMsg(true, peer, b64);
          sent++;
        }
      }
      diag(`self-manage: 候选图 ${sent}/${decision.previewUrls.length} 张已发给 ${peer}`);
    } else {
      diag('self-manage: 有候选图但没有可发的人（近期无人私聊过），跳过');
    }
  }

  /*
   * 主动联系（2026-10-22）—— 待办的出口。
   *
   * 光把「你之前记下的」列给她没用：检视输出是 JSON，她没法从里面发出消息。
   * 所以给一个 reachOut 字段：她想找谁、想说什么大意，插件替她把这句话
   * 生成出来发过去（**不是复读 hint**，那会更像提醒服务）。
   *
   * 三道限制：
   *   ① 只对**最近聊过的人**（recentContacts 里有），不主动找陌生人；
   *   ② 复用主动发言的冷却（proactiveGapHoursMin），不会每轮检视都找人；
   *   ③ 她仍然可以回 [SILENT] 拒绝 —— 想不起来说什么就不说。
   */
  if (decision.reachOut) {
    const target = decision.reachOut.peer;
    const rec = recentContacts.get(target);
    const minGapH = Math.max(0.1, Number(cfg.proactiveGapHoursMin) || 2);
    const tooSoon = now - (selfState.lastProactiveAt || 0) < minGapH * 3600000;
    if (!rec) {
      diag(`self-manage reachOut: ${target} 不在最近联系人里，忽略`);
    } else if (tooSoon) {
      diag('self-manage reachOut: 距上次主动太近，跳过');
    } else {
      try {
        /*
         * 待办触达也要落在真实会话里（2026-10-23）。
         *
         * 原来写的是 `...:e${sessionEpochOf(target)}` —— epoch 为 0 时拼出 `:e0`，
         * 而正常对话那时是**没有后缀**的，于是又是一段孤立的会话。
         */
        const sid = dialogSessionId(target);
        const line = await askPlatform(sid,
          // 同样包一层：这是系统提醒，不是对方说的话
          sysHint(
            `（你想起了之前的事：「${decision.reachOut.hint || '想起之前聊过的事'}」。`
              + '现在主动跟他说一句 —— 一两句就够，不用解释你为什么突然找他。）'
              + recentProactiveBlock(target)
          ),
          [], target);
        const say = String(line || '').trim();
        if (say && !say.includes('[SILENT]')) {
          await humanSend(true, target, say);
          rememberProactiveTopic(target, say);
          selfState.lastProactiveAt = now;
          changed++;
          /*
           * 触达成功 → 把这条待办标记完成（2026-11-01）。
           *
           * 不标的话，同一件事会在接下来两天里被反复"想起"并重复联系。
           */
          markOldestTodoDone(target);
          diag(`self-manage: 主动联系 ${target}「${say.slice(0, 30)}」`);
        }
      } catch (e) {
        diag(`self-manage reachOut failed: ${e.message}`);
      }
    }
  }

  saveSelfState();
  diag(`self-manage: 本轮决定改动 ${changed} 项（模型原话已在上方记录）`);
}

/**
 * 挑一个"最近聊过的人"，用于把候选图发过去（2026-10-21）。
 *
 * <p>自我管理是独处时刻，没有明确的对话对象；但"帮我看一眼这张"总得发给某个具体的人。
 * 取最近互动的那位 —— 那最可能是它当时正在想的人。</p>
 */
function pickPreviewPeer() {
  let best = null;
  for (const [peer, rec] of recentContacts.entries()) {
    if (!rec.isPrivate) {
      continue;
    }
    if (!best || rec.lastAt > best.lastAt) {
      best = { peer: Number(peer), lastAt: rec.lastAt };
    }
  }
  return best ? best.peer : null;
}

/**
 * 主动发言（文档 §9.2）。
 *
 * <p>三个条件全部满足才发：开关打开 + 距上次超过随机间隔（12~48h）+ 存在"最近 48 小时内
 * 互动过"的联系人。**没人聊过就不主动找人** —— 否则就是随机骚扰。</p>
 *
 * <p>为什么不纯用定时器：定时器会变成"每 6 小时准点发一条"，那是最像机器人的行为。
 * 这里心跳只负责"检查条件"，真正的间隔是随机的，且必须有人近期聊过。</p>
 */
/**
 * 挑「还没跟主人提过」的事件（2026-10-24）。
 *
 * <p>以 `selfState.lastEventToldAt` 为界：早于它的都算说过了，不会反复提。</p>
 *
 * <p><b>优先私聊</b>：群消息一天几十条，全都上报只会变成噪音；
 * 只有确实没有私聊事件时，才拿群里的说。</p>
 *
 * @returns 最多 3 条事件（按时间正序）；没有则空数组
 */
/** 「未提事件」的时效窗口：超过这个时间就不算"最近"（2026-11-01）。 */
const EVENT_UNTOLD_TTL_MS = 24 * 3600000;

/**
 * 挑几件「还没跟主人说过」的事（2026-11-01 修时效）。
 *
 * <p><b>实测问题</b>：10-28 18:19 主人说的「在干嘛」，到 11-01 16:01
 * 仍被当成"今天别人跟你说过"拿去主动发言。两个原因叠加：</p>
 * <ol>
 *   <li>这里**没有时间窗口** —— 只要早于 lastEventToldAt 的都算"未提"；</li>
 *   <li>**private 优先于 other** —— 四天前主人的旧话，挤掉了
 *       昨晚墨染刚说的新话。</li>
 * </ol>
 *
 * <p>现在：只认 24 小时内，且不再按 kind 分优先级（谁新说谁优先）。</p>
 */
function pickUntoldEvents() {
  if (parseIds(cfg.owners).length === 0) {
    return [];
  }
  const since = selfState.lastEventToldAt || 0;
  const freshAfter = Date.now() - EVENT_UNTOLD_TTL_MS;
  const evs = readEvents().filter(
    (ev) => (ev.at || 0) > since && (ev.at || 0) >= freshAfter,
  );
  if (evs.length === 0) {
    return [];
  }
  return evs.slice(-3);
}

/** 找哪个主人最近聊过（多个 owner 时优先找他；都没有就取第一个）。 */
function targetOwner() {
  const owners = parseIds(cfg.owners);
  if (owners.length === 0) {
    return null;
  }
  let best = null;
  for (const o of owners) {
    const rec = recentContacts.get(o);
    if (!rec) {
      continue;
    }
    if (!best || (rec.lastAt || 0) > best.lastAt) {
      best = { peer: o, lastAt: rec.lastAt || 0 };
    }
  }
  return best ? best.peer : owners[0];
}

/**
 * 基于事件主动跟主人说话（2026-10-24）。
 *
 * <p><b>为什么跳过概率闸门</b>：那个闸门是为了治"没事找事"。
 * 但"今天有人来打听你"这种事，该说就得说，不该掷骰子。
 * 频率改由两道闸控制：主动发言的 gap + `lastEventToldAt`（提过就不重复）。</p>
 *
 * <p>仍然受「对方安静够久」约束 —— 主人正在跟她聊，她突然插一句会很怪。</p>
 */
/** 主动发言的"别重复"窗口：只看最近这么多条 / 这么多天（2026-11-02）。 */
const PROACTIVE_TOPIC_KEEP = 5;
const PROACTIVE_TOPIC_DAYS = 7;

/**
 * 拼"你最近主动找他时说过"（2026-11-02）。
 *
 * <p>只列**主动发言**说过的话，不含正常聊天的内容 —— 正常聊天里重复是自然的，
 * 只有"又主动提起同一件事"才显得像复读。</p>
 *
 * <p>按 peer 分开：跟 A 说过的不该影响跟 B 的话题。</p>
 *
 * @returns 拼好的块；没有记录时返回空串（不占 token）
 */
function recentProactiveBlock(peer) {
  const list = Array.isArray(selfState.recentProactiveTopics)
    ? selfState.recentProactiveTopics : [];
  const cutoff = Date.now() - PROACTIVE_TOPIC_DAYS * 86400000;
  const mine = list
    .filter((x) => x && String(x.peer) === String(peer) && (Number(x.at) || 0) >= cutoff)
    .slice(-PROACTIVE_TOPIC_KEEP);
  if (mine.length === 0) {
    return '';
  }
  return [
    '',
    '',
    '【你最近主动找他时说过】',
    ...mine.map((x) => `  · ${x.text}`),
    '（这些**别再重复** —— 换个话题，或者这次就不说。）',
  ].join('\n');
}

/**
 * 记一笔主动发言的内容（2026-11-02）。
 *
 * <p>在**真正发出去之后**调用 —— 被 [SILENT] 拦下、或者发送失败的都不算，
 * 否则会记下"她没说出口的话"，下次反而避开一个从没出现过的话题。</p>
 */
function rememberProactiveTopic(peer, text) {
  const t = String(text || '').replace(/\s+/g, ' ').trim().slice(0, 40);
  if (!t) {
    return;
  }
  const list = Array.isArray(selfState.recentProactiveTopics)
    ? selfState.recentProactiveTopics : [];
  list.push({ at: Date.now(), peer, text: t });
  // 全局留 30 条 —— 够覆盖几个联系人的最近记录，也不至于无限涨
  selfState.recentProactiveTopics = list.slice(-30);
  saveSelfState();
}

async function sendEventDriven(target, evs, now) {
  const rec = recentContacts.get(target);
  const quietMs = (Number(cfg.proactiveQuietMinutes) || 15) * 60000;
  if (rec && now - (rec.lastAt || 0) < quietMs) {
    diag('proactive event: 主人刚还在聊，等安静下来再说');
    return;
  }

  const pad = (n) => String(n).padStart(2, '0');
  /*
   * 时间必须带日期（2026-11-01）。
   *
   * 原来只写「18:19」，四天前的事件看起来就像今天下午六点 ——
   * 她于是把 10-28 的「在干嘛」当成"今天发生的事"接着说。
   */
  const todayKey = new Date().toDateString();
  const lines = evs.map((ev) => {
    const d = new Date(ev.at || 0);
    const who = ev.nick || String(ev.from || '');
    const where = ev.kind === 'group' ? '（群里）' : '';
    const hm = `${pad(d.getHours())}:${pad(d.getMinutes())}`;
    const when = d.toDateString() === todayKey
      ? hm
      : `${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${hm}`;
    return `  ${when} ${who}${where}：${ev.text}`;
  });
  const prompt = [
    '（现在是你主动发起对话。）',
    '',
    '【今天别人跟你说过】',
    ...lines,
    '',
    '挑一件值得让他知道的，跟他说一句 —— **一两句就够，不要罗列**。',
    '如果这些都觉得没必要提，就随口聊一句别的，或者只回 [SILENT] 这次不说。',
  ].join('\n');

  diag(`proactive event: 有 ${evs.length} 条未提事件，找 ${target}`);
  try {
    const sid = dialogSessionId(target);
    /*
     * 主动开口时把「一起玩 MC 的事」带上（2026-11-04）：
     * 这是她手上最新鲜、最具体的话题 —— 比硬聊天气自然得多。
     * 只在对方是主人时才会注入（见 gameMemoryBlock 的权限判断）。
     */
    const answer = await askPlatform(
      sid,
      sysHint(prompt + recentProactiveBlock(target)),
      [],
      target,
      { forceGameMemory: true },
    );
    const say = String(answer || '').trim();
    if (!say || say.includes('[SILENT]')) {
      diag('proactive event: 她说这次不想提');
      // 标记已看过 —— 不然每次 tick 都会再问一遍
      selfState.lastEventToldAt = now;
      saveSelfState();
      return;
    }
    await humanSend(true, target, say);
    rememberProactiveTopic(target, say);
    selfState.lastProactiveAt = now;
    // 标记「这批事件提过了」：用 now，因为她已经看过全部 3 条
    selfState.lastEventToldAt = now;
    saveSelfState();
    diag(`proactive event sent -> ${target}`);
  } catch (e) {
    diag(`proactive event failed: ${e.message}`);
  }
}

/**
 * 挑主动发言的候选人（2026-10-24）。
 *
 * <p><b>为什么需要</b>：原来所有人都平等，谁安静够久就随机找谁。实测出现过
 * 她主动给一个刚加的人发"刷到个视频挺有意思"，对方回"？找我干嘛" ——
 * 不是她不会说话，是**找错了人**。</p>
 *
 * <p>三种模式（面板可切）：</p>
 * <ul>
 *   <li><b>owner</b>（默认）—— 只找主人。陌生人不主动，最安全；</li>
 *   <li><b>smart</b> —— 主人优先；陌生人要「安静 6 小时以上 + 我对你有印象」
 *       才可能被找。给"聊得多了自然会想起你"留个口子；</li>
 *   <li><b>any</b> —— 旧行为，谁都可以。</li>
 * </ul>
 *
 * <p>没配 `owners` 时 owner/smart 都返回空 —— 宁可这次不主动，也别乱找人。</p>
 */
/**
 * 现在是不是「不该主动找人」的时段（2026-10-28）。
 *
 * <p>凌晨三点发"你怎么不理我"，比不发更糟。默认 23:00 ~ 07:00 静默。</p>
 *
 * <p>跨零点要单独处理：`start=23, end=7` 时，`h>=23 || h<7` 才算静默；
 * 如果写成 `start < end`（比如 1~6 点午睡），就是普通区间。</p>
 */
function inQuietHours() {
  const start = Number(cfg.proactiveQuietHourStart);
  const end = Number(cfg.proactiveQuietHourEnd);
  if (!Number.isFinite(start) || !Number.isFinite(end)) {
    return false;
  }
  if (start === end) {
    return false;   // 相等 = 关闭
  }
  const h = new Date().getHours();
  const quiet = start < end ? (h >= start && h < end) : (h >= start || h < end);
  if (quiet) {
    diag(`proactive: ${h} 点在静默时段（${start}~${end}），不打扰`);
  }
  return quiet;
}

function proactiveCandidates(now, within, quietMs) {
  const mode = String(cfg.proactiveTargetMode || 'owner').toLowerCase();
  const owners = parseIds(cfg.owners);
  const base = [...recentContacts.entries()].filter(([, v]) =>
    v.isPrivate
      && now - v.lastAt < within
      // 对方还在聊的时候不要主动插话，等他安静满 quietMinutes
      && now - v.lastAt >= quietMs);

  if (mode === 'any') {
    return base;
  }
  if (owners.length === 0) {
    diag('proactive: 没配 owners —— owner/smart 模式下不主动找人');
    return [];
  }

  /** 陌生人要安静这么久才可能被想起（只有 smart 模式用）。 */
  const STRANGER_QUIET_MS = 6 * 3600000;

  return base.filter(([peer, v]) => {
    if (owners.includes(Number(peer))) {
      return true;
    }
    if (mode === 'owner') {
      return false;
    }
    // smart：得对他有点印象，而且确实很久没说话了
    const imp = getFact(peer, 'relation');
    return !!(imp && imp.value) && now - v.lastAt >= STRANGER_QUIET_MS;
  });
}

/**
 * 追发一句（2026-10-26）。
 *
 * <p>主动说过一句、对方没回应时补的那条。**越往后越短、情绪越强** ——
 * 真人就是这样：先是「在忙吗」，再是「你是不是不想理我」，最后「算了」。</p>
 *
 * <p>她已经能看到自己的历史（包括上一条自己说的话），所以这里只需要告诉她
 * "这是第几次、该是什么语气、要更短"，具体说什么留给她。</p>
 *
 * @param round 已经追发过几次（0 = 还没追过，这次是第 1 次）
 */
async function sendProactiveFollowup(peer, round, now) {
  /*
   * 语气由**情绪状态**决定，不再按次数查表（2026-10-27）。
   *
   * 原来的 tones 数组是"第几次追发 → 第几句台词"，两个毛病：
   *   ① 次数上限可配、语气段数写死，改成 5 次之后第 4、5 次重复同一句；
   *   ② 它跟"她现在多难受"无关 —— 第一次追发和被晾了五次，语气一样。
   *
   * 现在用 followupTone() 读 PAD 状态生成措辞：被忽视越多 → P 越低、D 越低，
   * 语气自然从"还端着"走到"委屈"再走到"不想说了"。
   *
   * 间隔不受影响：那个是公式 `baseMin / 2^(count-1)`，改次数自动跟随。
   */
  const tone = followupTone();
  const prompt = [
    '（刚才是你主动找他，他没回。现在再补一句。）',
    tone,
    // 追发更需要锚点：她得知道"上一条自己说的是什么"，否则会重复或跑偏
    tailBlock(peer, 2),
    '**别问"在吗"，也别解释你为什么又发一条。** 直接说那句。',
  ].join('\n');

  try {
    const sid = dialogSessionId(peer);
    const answer = await askPlatform(sid, sysHint(prompt), [], peer);
    const say = String(answer || '').trim();
    if (!say || say.includes('[SILENT]')) {
      diag('proactive followup: 她说这次不发了');
      return;
    }
    await humanSend(true, peer, say);
    selfState.proactiveChain = { count: round + 1, peer, lastAt: now };
    selfState.lastProactiveAt = now;
    saveSelfState();
    /*
     * 又发了一条、还是没回音 —— 这是"被忽视"最直接的来源（2026-10-27）。
     *
     * 累计几次之后 P 和 D 都会掉下去，下一次追发的措辞就自动变得更沉。
     * 这也是为什么不再需要手写 5 段语气。
     */
    applyAffect('ignored');
    diag(`proactive followup sent -> ${peer}（第 ${round + 1} 次）`);
  } catch (e) {
    diag(`proactive followup failed: ${e.message}`);
  }
}

async function maybeProactive() {
  if (!cfg.proactiveEnabled || !stats.connected || !cfg.agentId) {
    return;
  }
  // 夜间静默（2026-10-28）：追发和普通主动都拦，凌晨三点没人该收到消息
  if (inQuietHours()) {
    return;
  }
  const now = Date.now();

  /*
   * ★ 连续追发（2026-10-26）。
   *
   * <p>主动说了一句、对方没回 —— 真人这时候会再补一句，而且**越补越短、越急**。
   * 原来没有这个机制：发完就等下一个 30~60 分钟的窗口，中间那段"她其实在等"
   * 完全表现不出来。</p>
   *
   * <p>参数全可配：</p>
   * <ul>
   *   <li>{@code proactiveFollowupEnabled} —— 总开关；</li>
   *   <li>{@code proactiveFollowupMax} —— 最多连续几次（到顶就停，不刷屏）；</li>
   *   <li>{@code proactiveFollowupMin} —— 第一次追发的间隔（分钟），之后每次减半。</li>
   * </ul>
   *
   * <p><b>为什么放在普通间隔检查之前</b>：追发用的是另一套更短的计时，
   * 不能被 30~60 分钟那次检查挡住。</p>
   */
  const chain = selfState.proactiveChain || { count: 0 };
  if (chain.count > 0 && cfg.proactiveFollowupEnabled !== false) {
    const maxTimes = Math.max(1, Number(cfg.proactiveFollowupMax) || 3);
    if (chain.count >= maxTimes) {
      diag(`proactive: 已连续 ${chain.count} 次没回应，停止追发`);
      return;
    }
    const baseMin = Math.max(1, Number(cfg.proactiveFollowupMin) || 15);
    // 15 → 8 → 4：越等越坐不住
    const waitMin = Math.max(1, Math.round(baseMin / Math.pow(2, chain.count - 1)));
    if (now - (chain.lastAt || 0) < waitMin * 60000) {
      return;
    }
    const target = chain.peer || targetOwner();
    if (!target) {
      return;
    }
    diag(`proactive: 第 ${chain.count + 1} 次追发（等了 ${waitMin} 分钟）`);
    await sendProactiveFollowup(target, chain.count, now);
    return;
  }

  /*
   * 间隔从两个数字拼出来（2026-10-21 由数组改成两个可配项）。
   * 保留对旧数组配置的兼容：万一 config.json 里还是 `proactiveGapHours: [a,b]`，
   * 也能读出来，不会因为升级就失忆。
   */
  let minH;
  let maxH;
  if (Array.isArray(cfg.proactiveGapHours) && cfg.proactiveGapHours.length === 2) {
    [minH, maxH] = cfg.proactiveGapHours;
  } else {
    minH = Number(cfg.proactiveGapHoursMin) || 2;
    maxH = Number(cfg.proactiveGapHoursMax) || 8;
  }
  minH = Math.max(0.1, minH);
  maxH = Math.max(minH, maxH);
  const gapMs = (minH + Math.random() * (maxH - minH)) * 3600000;
  if (now - (selfState.lastProactiveAt || 0) < gapMs) {
    return;
  }

  /*
   * ★ 事件驱动优先（2026-10-24）。
   *
   * 在此之前，主动发言只有一条路：随机挑个安静够久的人，随机让她说点什么。
   * 于是"今天有人来打听你"这种明明该说的事，说出来的概率跟掷骰子一样。
   *
   * 现在只要有**还没跟主人提过**的事件，就直接走这条路 —— 跳过概率闸门，
   * 因为理由充分（不是没事找事），再掷骰子反而是错的。
   */
  const untold = pickUntoldEvents();
  if (untold.length > 0) {
    const target = targetOwner();
    if (target) {
      await sendEventDriven(target, untold, now);
      return;
    }
  }

  /*
   * 概率闸门（2026-10-21）：检查到了不等于真要发。
   * 参考同类项目的实测值 0.35 —— 多数检查都会放弃，行为才不像闹钟。
   */
  const chance = Number(cfg.proactiveChance);
  if (Math.random() > (Number.isFinite(chance) ? chance : 0.35)) {
    diag('proactive: 概率闸门未通过，本轮不发');
    return;
  }

  const within = (Number(cfg.proactiveWithinHours) || 48) * 3600000;
  const quietMs = (Number(cfg.proactiveQuietMinutes) || 15) * 60000;
  // 候选池按身份过滤（2026-10-24）：默认只找主人，陌生人不再被随机打扰
  const cands = proactiveCandidates(now, within, quietMs);
  if (cands.length === 0) {
    diag(`proactive: 没有合适的联系人（模式=${cfg.proactiveTargetMode || 'owner'}），跳过`);
    return;
  }

  const [peer] = pickRandom(cands);
  selfState.lastProactiveAt = now;
  /*
   * 记「主动发起第 1 句」（2026-10-26）。
   *
   * 之后如果一直没收到回应，maybeProactive 会走追发分支：
   * 15 分钟后补一句、再 8 分钟补一句，越来越短、情绪越来越强。
   * 收到任何回复就归零（见 processMessage 开头）。
   */
  selfState.proactiveChain = { count: 1, peer, lastAt: now };
  saveSelfState();

  try {
    /*
     * 必须用 dialogSessionId（带 epoch）—— 否则主动发言写进的是另一个会话，
     * 用户回过来时她看不到自己刚说过的话（2026-10-23 修）。
     */
    const sessionId = dialogSessionId(peer);

    /*
     * 话题优先级（2026-10-24 调整）。
     *
     *  ① **有上下文就用上下文**：你对他有印象、或者你们聊过三次以上 ——
     *     那些内容已经通过 timeContext 注入了，直接接着聊最自然；
     *  ② **没有上下文才看热门**：新加的人、很久没说话的，实在没素材，
     *     才去翻一眼榜单兜底。
     *
     * 原来的做法是**无条件**先抓热门，于是出现"跟一个刚加的人聊 B 站
     * 新番更新"，对方一句"？找我干嘛" —— 话题跟他毫无关系。
     *
     * 顺带省一次工具调用（热门接口在大部分对话里就这么白调了）。
     */
    /*
     * 热门素材：**开关说了算**（2026-10-27 修）。
     *
     * <p>上一版加了个 `hasContext` 判断 —— "他对你有印象、或聊过 3 句以上，
     * 就别硬找热门了"。本意是避免"跟刚加的人聊新番"那种尴尬，结果：</p>
     *
     * <p><b>主人永远有印象、永远聊过几百句 → 这个开关一次都没生效过</b>。
     * 用户打开了「主动发言前先看一眼热门」，日志里十条全是「跳过热门」，
     * 只有 10-24 那次（还没加这段逻辑时）真正调过一次。</p>
     *
     * <p>现在改回"开关打开就抓"，但提示词里说清它是**备选素材** ——
     * 有更想聊的就聊别的，别硬掰到榜单上。这既尊重了配置，
     * 也保留了当初想避免的"硬套热门"。</p>
     */
    let peekBlock = '';
    if (cfg.proactivePeek && needFreshTopic(peer)) {
      /*
       * 素材优先级：**天气 > B站热门**（2026-10-28）。
       *
       * <p>天气是"跟他有关"的（他那边冷不冷、要不要带伞），热门是"跟谁都能聊"的。
       * 前者更像真人早上开口的第一句，也不会让她又绕回"我今天画了什么"。</p>
       *
       * <p>两者都拿不到时 peekBlock 为空 —— 那就让她凭记忆说，不会硬塞。</p>
       */
      const bits = [];
      const weather = await todayWeather();
      if (weather) {
        bits.push(`【他那边今天的天气】${weather}`);
      }
      /*
       * 联网搜一条新鲜事（2026-10-28）。
       *
       * <p>比 B 站热门覆盖面宽得多：热门只在 B 站，搜索能到新闻、社会热点、
       * 生活信息。有了它，她能聊的东西才真正从"我的画"变成"外面发生了什么"。</p>
       *
       * <p><b>query 是成败关键</b>：太泛（"新闻"）会拿到新闻聚合站的一堆标题。
       * 默认问"今天有什么值得聊的"，让搜索引擎自己挑，也允许用户写固定主题
       * （比如"科技新闻""新番更新"）。</p>
       *
       * <p>需要智能体挂载 {@code web_search} 插件；没挂会抛错，静默跳过即可 ——
       * 少一条素材不影响主动发言。</p>
       */
      if (api.tools && cfg.proactiveWebSearch !== false) {
        try {
          const q = String(cfg.proactiveSearchQuery || '').trim()
            || '今天有什么值得聊的新闻或热点';
          const r = await api.tools.execute('web_search', { query: q });
          const out = r && r.output;
          if (r && r.success !== false && out) {
            bits.push(`【刚上网看到的】\n${String(out).slice(0, 700)}`);
            diag(`proactive peek: web_search ok（${q}）`);
          } else {
            diag(`proactive peek: web_search 失败 ${(r && r.error) || ''}`);
          }
        } catch (e) {
          diag(`proactive peek: web_search 异常 ${e.message}`);
        }
      }
      if (api.tools) {
        try {
          const r = await api.tools.execute('bilibili_hot', { limit: Number(cfg.proactivePeekCount) || 5 });
          const out = r && r.output;
          if (r && r.success !== false && out) {
            bits.push(`【刚看到的 B 站热门】\n${String(out).slice(0, 800)}`);
            diag('proactive peek: bilibili_hot ok');
          } else {
            diag(`proactive peek: 工具返回失败 ${(r && r.error) || ''}`);
          }
        } catch (e) {
          diag(`proactive peek failed: ${e.message}`);
        }
      }
      if (bits.length > 0) {
        peekBlock = '\n\n' + bits.join('\n\n')
          + '\n\n（参考素材 —— 用得上就用，别硬念；一句话就够。）';
      }
    } else if (cfg.proactivePeek) {
      // 有话题可接，就不去翻素材 —— 让她接着聊，而不是硬套新闻
      diag('proactive peek: 刚聊完、手上有话题，跳过素材');
    }

    diag(`proactive: 向 ${peer} 发起${peekBlock ? '（含热门话题）' : ''}`);
    /*
     * 把「刚聊到」拼进去（2026-10-27）。
     *
     * 没有这段的时候，她主动开口只会说自己这边的事 —— 实测是
     * 「雾散了，桌子边上那块光动了半寸」，而前一句明明是她自己问的
     * 「你课上到哪儿了」。有了这两行，"你课到底上完没"这种话才说得出来。
     *
     * 注意：**这是真实数据，不是示例**，所以不会被当成台词照抄。
     */
    const tail = tailBlock(peer, 4);
    // 包一层系统标记：否则这段会被当成"对方说的话"永久留在历史里
    const answer = await askPlatform(
      sessionId,
      sysHint(cfg.proactivePrompt + tail + peekBlock + recentProactiveBlock(peer)),
      [],
      peer,
      // 同上：主动搭话时游戏记忆是最自然的话题素材（仅对主人生效）
      { forceGameMemory: true },
    );
    if (!answer) {
      diag('proactive: 平台返回空，放弃本轮');
      return;
    }
    /*
     * [SILENT] 必须拦下来（2026-11-01）。
     *
     * 提示词里允许她"没素材就不发"，但这里原来只判空字符串 ——
     * 于是 [SILENT] 会被当成正文发给对方。
     */
    if (String(answer).includes('[SILENT]')) {
      diag('proactive: 她说这次没什么可说的');
      return;
    }
    await humanSend(true, peer, answer);
    rememberProactiveTopic(peer, answer);
    diag(`proactive sent -> ${peer}`);
  } catch (e) {
    diag(`proactive failed: ${e.message}`);
  }
}

// ---------------- 灵感涌现（2026-11-05） ----------------

/**
 * 张力：多久没聊 + 情绪强度 + 一点纯随机。
 *
 * <p>纯随机项是刻意的 —— 灵感本来就"说不准"。没有它，这套机制会退化成
 * "空闲越久越容易说话"，也就是又一个定时器。</p>
 */
function inspirationTension(peer) {
  const now = Date.now();
  const rec = recentContacts.get(peer);
  const idleMin = rec && rec.lastAt ? (now - rec.lastAt) / 60000 : 240;
  const a = selfState.affect || {};
  const mood = a.mood || {};
  const emo = a.emotion || {};
  const intensity = (
    Math.abs(Number(mood.p) || 0) + Math.abs(Number(emo.p) || 0)
    + Math.abs(Number(mood.a) || 0) + Math.abs(Number(emo.a) || 0)
  ) / 2;
  let t = Math.min(1, idleMin / 240) * 0.45;
  t += Math.min(1, intensity / 1.2) * 0.3;
  t += Math.random() * 0.25;
  return Math.min(1, t);
}

/**
 * 有机会就冒一个念头并发出去。
 *
 * <p>两道闸：**冷却**（默认 50 分钟 ±40%）和**概率**（由张力决定），
 * 结果是"平均一两小时一次，但时点说不准"。</p>
 */
async function maybeInspiration() {
  if (cfg.inspirationEnabled === false) return;
  if (!stats.connected || !cfg.agentId || busyCount > 0) return;
  if (inQuietHours()) return;

  const owner = parseIds(cfg.owners)[0];
  if (!owner) return;

  const now = Date.now();
  // 这里不用 clamp()：它是别的模块里的工具函数，这个文件里没有全局版本
  const baseMin = Math.max(10, Math.min(480, Number(cfg.inspirationGapMinutes) || 50));
  const gapMs = baseMin * 60000 * (0.7 + Math.random() * 0.6);
  if (now - (Number(selfState.lastInspirationAt) || 0) < gapMs) return;

  // 他正在跟她聊 / 刚聊完 —— 别插
  const rec = recentContacts.get(owner);
  const quietMs = (Number(cfg.proactiveQuietMinutes) || 15) * 60000;
  if (rec && now - (rec.lastAt || 0) < quietMs) return;

  const tension = inspirationTension(owner);
  if (Math.random() > 0.05 + tension * 0.25) return;

  selfState.lastInspirationAt = now;
  saveSelfState();
  diag(`inspiration: 冒出念头 tension=${tension.toFixed(2)}`);

  /*
   * 素材是**具体的东西**，不是话题清单：
   * 最近几句对话、她上次主动说过什么、以及跨来源的一条（游戏联机索引）。
   * 跨来源碰撞最容易出"突然想到"的效果。
   */
  const mc = mcIndexLines(2);
  const seed = [
    tailBlock(owner, 3),
    recentProactiveBlock(owner),
    mc.length ? `【你们最近一起玩的时候】\n${mc.join('\n')}` : '',
  ].filter(Boolean).join('\n');

  const prompt = [
    '【系统提示 · 不是对方说的话】你一个人待着，没在跟人聊天。',
    '你刚才**突然想到一件事** —— 不是你正在做的事，也不是要汇报什么。',
    '可以是想问他点什么、想起他以前说过的一句话、看到什么东西让你想起他、',
    '或者你手上某件小事有进展了，想说一声。',
    '',
    '规则：',
    '① 只发**一句**，短，口语，别用书面语；',
    '② 不要问"在吗"，不要解释你为什么想到这个，不要总结今天；',
    '③ 别重复你最近主动说过的话题；',
    '④ 真的没什么可说的，就回 [SILENT]。',
    seed,
  ].filter(Boolean).join('\n');

  try {
    const answer = await askPlatform(dialogSessionId(owner), sysHint(prompt), [], owner);
    const say = String(answer || '').trim();
    if (!say || say.includes('[SILENT]')) {
      diag('inspiration: 这次没想说的');
      return;
    }
    await humanSend(true, owner, say);
    rememberProactiveTopic(owner, say);
    diag(`inspiration sent -> ${owner}`);
  } catch (e) {
    diag(`inspiration failed: ${e.message}`);
  }
}

/** 心跳：10 分钟一次；启动后 1 分钟先跑一次（别让重启后很久不检查）。 */
function startHeartbeat() {
  stopHeartbeat();
  const tick = () => {
    /*
     * 心跳留痕（2026-10-23，30 分钟一条）。
     *
     * 原来这里完全静默。于是"电脑一直开着却一整天不理人"时，diag.log 里
     * 没有任何线索 —— 分不清心跳停了、WS 断了、还是概率没命中。
     * 现在至少能看出心跳还活着、以及连接处于什么状态。
     */
    const t = Date.now();
    if (t - lastTickLogAt > 30 * 60 * 1000) {
      lastTickLogAt = t;
      diag(`tick: 心跳存活 connected=${stats.connected} ws=${ws ? ws.readyState : 'null'}`);
    }
    // 情绪回落（2026-10-27）：按实际经过的小时数衰减，不足一小时不动
    decayMood();
    void maybeSelfManage();
    void maybeProactive();
    /*
     * 灵感涌现（2026-11-05）：跟主动发言并列，但**互斥** ——
     * 刚按间隔发过一条，这一拍就别再"突然想到"了，否则连着两条很像故障。
     */
    if (busyCount === 0 && Date.now() - (Number(selfState.lastProactiveAt) || 0) > 5 * 60000) {
      void maybeInspiration();
    }
    void maybeWriteDiary();
    void maybeUpdateImpressions();
    void maybeUpdateOnlineStatus();
    void maybePostQzone();
  };
  heartbeat = setInterval(tick, 10 * 60 * 1000);
  setTimeout(tick, 60 * 1000);

  /*
   * 连接探活（2026-10-22）。
   *
   * 2 分钟一次，和 10 分钟的业务心跳分开 —— 连接断了要尽快发现，
   * 不然对方发来消息一整天没人回，用户只会觉得"它坏了"。
   */
  healthTimer = setInterval(() => {
    void healthCheck();
  }, 2 * 60 * 1000);
  setTimeout(() => {
    void healthCheck();
  }, 30 * 1000);
}

function stopHeartbeat() {
  if (heartbeat) {
    clearInterval(heartbeat);
    heartbeat = null;
  }
  if (healthTimer) {
    clearInterval(healthTimer);
    healthTimer = null;
  }
}

/** 上次探活时间（避免重复打接口）。 */
let lastHealthAt = 0;

/**
 * 连接探活（2026-10-22）。
 *
 * <p><b>为什么必须有</b>：WebSocket 的 {@code close} 事件**不总是会来** ——
 * 电脑休眠、网络切换、中间设备掐掉长连接，都会留下"半开连接"：
 * TCP 看着还在，实际收不到任何消息，而 {@code stats.connected} 一直是 true
 * （界面上显示"已连接、已挂载"，一切正常）。</p>
 *
 * <p>用户看到的现象就是"电脑一直开着，但自动回复不触发"。</p>
 *
 * <p>做法：定时打一个**只读**接口（{@code get_login_info}，不产生任何副作用），
 * 超时或失败就主动 {@code terminate()} —— 这会触发 close → scheduleReconnect。</p>
 */
async function healthCheck() {
  if (stopping || !cfg || !cfg.enabled) {
    return;
  }
  const now = Date.now();
  if (now - lastHealthAt < 60 * 1000) {
    return;   // 1 分钟内不重复
  }
  lastHealthAt = now;

  /*
   * WS 不在 OPEN 状态 → **主动重连**（2026-10-23 修）。
   *
   * 这里原来是一句 `return;` —— 意为"没连上就不用探活"。但它有个致命前提：
   * 假定 `ws.on('close')` 一定会触发 `scheduleReconnect()`。
   *
   * 而系统睡眠、进程被挂起、网卡断电这些情况下，**close 事件可能永远不来**：
   * readyState 停在 CLOSED，stats.connected 保持 false，
   * 于是 ——
   *   · 探活看到 readyState !== 1，静默 return（不重连）
   *   · 所有心跳任务看到 !stats.connected，静默跳过（不干活）
   * 整条链路就死在这儿，只能手动重启。用户感知是"电脑一直开着，却一整天不理人"。
   *
   * 现在改成：只要不在 OPEN 状态就主动排一次重连，把死锁打开。
   */
  if (!ws || ws.readyState !== 1) {
    diag(`health: WS 状态=${ws ? ws.readyState : 'null'}（非 OPEN）-> 主动重连`);
    scheduleReconnect();
    return;
  }
  try {
    await call('get_login_info', {}, 8000);
  } catch (e) {
    diag(`health check FAILED: ${e.message} -> 主动断开重连`);
    log('warn', `连接探活失败，主动重连：${e.message}`);
    try {
      ws.terminate();   // 会触发 close 事件 → scheduleReconnect
    } catch {
      /* 忽略：close 里会重连 */
    }
  }
}

// ------------------------------------------------------------------ 生命周期

module.exports = {
  /** 由主进程在加载后调用（api = { pluginId, dataDir, logger, platform }）。 */
  start(a) {
    api = a;
    /*
     * 顺带把 NapCat 拉起来（2026-10-27）。
     *
     * 放在最前面、且 setTimeout 延后：NapCat 启动要注入 QQ、动辄十几秒，
     * 卡在这里会拖慢整个插件的加载。让 connect() 先跑，连不上就等它自己重连。
     *
     * 不用 await —— 失败也不该影响插件自身启动。
     */
    setTimeout(() => {
      void launchNapCat();
    }, 1500);
    /*
     * GPT-SoVITS 也顺带拉起（2026-11-02）。
     *
     * <p>比 NapCat 晚 1.5 秒触发：两个都是重进程，同时起会互相抢 CPU，
     * 而 NapCat 那边有十几秒的注入窗口，排队更稳。</p>
     *
     * <p>它自己会等端口就绪再加载权重，全程几十秒，所以同样不 await。</p>
     */
    setTimeout(() => {
      void launchSoVits();
    }, 3000);
    cfg = loadConfig();
    loadSelfState();
    // 印象已并入 memory/facts.json，不再单独加载（2026-10-28）
  loadSessionEpochs();
  loadContacts();
  // 活跃度落盘（2026-10-23）：不加载的话重启后印象门槛永远攒不够
  loadRecentContacts();
    log('info', `QQ 助手已加载，配置：${configPath()}`);
    log('info', `启用状态：${cfg.enabled ? '开' : '关（改 config.json 后调 methods.reload）'}`);
    log('info', `自我管理：${cfg.selfManageEnabled ? '开' : '关'}；主动发言：${cfg.proactiveEnabled ? '开' : '关'}`);
    if (cfg.enabled) {
      connect();
      startHeartbeat();
    }
  },

  /** 卸载时必须清干净：WS、重连定时器、静默定时器。留着会拖住应用退出。 */
  stop() {
    stopping = true;
    stopHeartbeat();
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
    try {
      ws?.close();
    } catch {
      /* 已关闭 */
    }
    ws = null;
    stats.connected = false;
    log('info', 'QQ 助手已停止');
  },

  methods: {
    /**
     * 是否正在处理消息（2026-10-25）。
     *
     * <p>宿主的热重载会先问这个：忙就等几秒再重启，
     * 免得把正在生成的那条回复掐断。</p>
     */
    isBusy() {
      return busyCount > 0;
    },

    /** 运行状态（前端状态球轮询它）。 */
    status() {
      return { ...stats, configPath: configPath(), enabled: !!cfg?.enabled };
    },

    /**
     * 调试用：返回**她这一轮实际会看到的上下文**（2026-10-28）。
     *
     * <p><b>为什么需要</b>：记忆散到 `memory/` 三个文件之后，"她到底看到了什么"
     * 变得很难验证 —— 得翻五六个地方才能拼出个大概。这个方法直接把最终的注入块
     * 原样吐出来，缺了什么、多了什么一眼就能看见。</p>
     *
     * <p>面板里调 `debugContext(QQ号)` 即可；不传就取 owners 里的第一个。</p>
     *
     * <p>第二个参数可以传一句"假设他说的话"（2026-11-04）：游戏记忆这类
     * **按关键词触发**的注入，只看空文本永远看不到 —— 传「今晚玩 mc 吗」
     * 才能验证它到底会不会被带进来。</p>
     */
    async debugContext(peer, sampleText) {
      const p = Number(peer) || parseIds(cfg.owners)[0] || 0;
      if (!p) {
        return { ok: false, error: '没有可用的 peer（传一个 QQ 号，或先配 owners）' };
      }
      try {
        const peerInfo = await peerBlock(p, false);
        const ctx = timeContext(p, false, {}, String(sampleText || ''));
        return { ok: true, peer: p, text: peerInfo + ctx };
      } catch (e) {
        return { ok: false, error: e.message, stack: String(e.stack || '').slice(0, 1000) };
      }
    },

    /** 调试用：记忆系统的原始数据（三个文件的当前状态）。 */
    debugMemory(peer) {
      const p = Number(peer) || parseIds(cfg.owners)[0] || 0;
      try {
        return {
          ok: true,
          peer: p,
          facts: p ? allFacts(p) : [],
          events: {
            total: readEvents().length,
            other: recentEvents({ kind: 'other', n: 9999 }).length,
            commit: recentEvents({ kind: 'commit', n: 9999 }).length,
            stage: recentEvents({ kind: 'stage', n: 9999 }).length,
          },
          self: {
            diary: readSelf().diary.length,
            notes: readSelf().notes.length,
            hasAffect: !!readSelf().affect,
          },
        };
      } catch (e) {
        return { ok: false, error: e.message };
      }
    },

    /** 读配置（设置面板用）。 */
    getConfig() {
      return { ...cfg };
    },

    /** 保存配置并热重连（改完不用重启应用）。 */
    saveConfig(patch) {
      saveConfig(patch || {});
      log('info', '配置已保存，按新配置重连');
      stopping = true;
      if (reconnectTimer) {
        clearTimeout(reconnectTimer);
        reconnectTimer = null;
      }
      try {
        ws?.close();
      } catch {
        /* ignore */
      }
      ws = null;
      stopping = false;
      silencePrimed = false;
      silenceUntil = 0;
      if (cfg.enabled) {
        connect();
      }
      return { ...cfg };
    },

    /** 重新读文件（手改 config.json 后调用）。 */
    reload() {
      cfg = loadConfig();
      return { ...cfg };
    },

    /**
     * 测试「插件侧工具通道」（2026-10-21）：直接调平台工具，**不经过模型**。
     *
     * <p>与"模型在对话里自己调工具"是两条路：这条是插件代码主动发起，
     * 用来验证 `api.tools.execute` 通不通、以及当前用户能看到哪些工具。</p>
     */
    async testTools() {
      if (!api || !api.tools) {
        return { ok: false, error: 'api.tools 不可用（pluginRuntime 版本过旧？需重启应用）' };
      }
      try {
        const list = await api.tools.list();
        const names = (Array.isArray(list) ? list : []).map((t) => t.name).filter(Boolean);
        diag(`tools available(${names.length}): ${names.join(', ')}`);

        /*
         * 优先精确取 `web_search` —— 注意 `search`（知识库检索）和 `github_search`
         * 名字里都带 search，正则随便匹配会把参数传错（实测踩过）。
         *
         * ⚠️ `web_search` 是**插件工具**：必须在「插件」页把「联网搜索」挂到本智能体才会出现；
         * 而 `fs_*` / `git_*` / `search` 是全局组件工具，无需挂载。
         */
        const search = names.includes('web_search')
          ? 'web_search'
          : (names.find((n) => /search/i.test(n)) || '');
        if (!search) {
          return { ok: false, tools: names, error: '没有可用的 search 类工具' };
        }
        const r = await api.tools.execute(search, { query: '今天哈尔滨天气' });
        const failed = !(r && r.success);
        diag(`tool ${search} -> success=${r && r.success} error=${(r && r.error) || '(empty)'}`);
        return {
          ok: !failed,
          tools: names,
          tool: search,
          result: r,
          // success=false 但没给 error 时，别显示"未知错误"——那对排查毫无帮助
          error: failed
            ? ((r && r.error)
              || (search === 'web_search'
                ? '调用失败（参数或后端问题）'
                : `「${search}」不是联网搜索工具，参数对不上；真正需要的是 web_search`))
            : '',
          hint: names.includes('web_search')
            ? ''
            : 'web_search 不可用：到「插件」页把「联网搜索」挂到本智能体（内置插件默认不挂载）',
        };
      } catch (e) {
        diag(`testTools failed: ${e.message}`);
        return { ok: false, error: e.message };
      }
    },
  },
};
