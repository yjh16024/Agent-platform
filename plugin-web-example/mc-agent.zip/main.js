'use strict';

/**
 * MC 助手 · Node 侧（跑在 Electron `utilityProcess` 里）
 *
 * <h3>它做什么</h3>
 * 用 mineflayer 以玩家身份进服务器 → 听游戏内聊天 → 拼上下文（游戏状态 + 共用的记忆 +
 * 「关于他」的事实）→ 调平台 `/agent/run` → 把回复拆成「说话」和「方括号动作」→ 执行。
 *
 * <h3>它和 QQ 助手是同一个"她"</h3>
 * <ul>
 *   <li><b>人格</b>：默认读 `qq_agent/config.json` 里的 agentId，用同一个智能体；</li>
 *   <li><b>记忆</b>：事实（facts.json）、日记（self.json）直接读；</li>
 *   <li><b>游戏记忆</b>：写到 `qq_agent/memory/minecraft.md` —— 由 QQ 助手**按需**读取
 *       （聊到游戏 / 刚玩过 / 主动发言），平时不占上下文。</li>
 * </ul>
 *
 * <h3>为什么动作走"方括号"而不是 function calling</h3>
 * web 插件**不能给平台注册工具**（只有 jar 插件和 MCP 能）。而 QQ 助手已经用同一套
 * 标记协议跑通了 `[表情 开心]` `[发图 xxx]` —— 复用它，平台改动为 0。
 * 代价是模型可能写错格式，所以解析器只认已知动词，认不出的一律留在正文里。
 *
 * <h3>为什么每个动作都要超时</h3>
 * 平台侧一次 `agent/run` 是有上限的，而走路/挖矿是**没有上限**的物理过程。
 * 超时后**不中止执行**（mineflayer 的 pathfinder 还在跑），只是不再等 ——
 * 所以下一轮她可能"还在半路上"，这属于正常现象，不要当成 bug。
 */
const fs = require('node:fs');
const path = require('node:path');

// ------------------------------------------------------------------ 状态

let api = null;
let cfg = null;
let bot = null;
/** 缓存的 mineflayer 模块（懒加载：没装依赖时不该在 require 阶段就炸掉整个插件）。 */
let mineflayer = null;
let stopping = false;
let reconnectTimer = null;
let reconnectDelay = 2000;
let heartbeatTimer = null;
let lastActivityAt = 0;
let lastAutonomyAt = 0;
let lastDigestAt = 0;
let lastSayAt = 0;
let lastInject = '';
let busy = false;
/** 被"同名重复登录"踢了几次（用来退避，避免 5 秒一次的自激循环）。 */
let duplicateKicks = 0;

const stats = {
  connected: false,
  enabled: false,
  server: '',
  username: '',
  received: 0,
  replied: 0,
  actions: 0,
  lastAction: '',
  lastError: '',
  sessionStart: 0,
};

/** 本轮会话的统计（写进这次联机的流水，纯规则统计、不调模型）。 */
const session = {
  started: 0,
  /** 这次联机的记忆文件（`memory/minecraft/<时间>.md`）；未开始时为空。 */
  file: '',
  /** 已经写了多少行（超过 SESSION_LINE_MAX 就只留统计）。 */
  lines: 0,
  trimmed: false,
  /** 写进"总结"的一句话（死亡/发现新地形/标记坐标/备忘）。 */
  highlights: [],
  /** 自上次落盘以来的增量（每 digestMinutes 清零）。 */
  win: { mined: 0, placed: 0, deaths: 0, chatIn: 0, chatOut: 0 },
  /** 整场联机的累计（下线时写总结）。 */
  tot: { mined: 0, placed: 0, deaths: 0, chatIn: 0, chatOut: 0 },
  /** 她自己 `[记]` 的话 / 值得留下的碎片，落盘后清空。 */
  notes: [],
  /** 最近几个动作的结果 —— 下一轮作为【刚才】注入。 */
  lastResults: [],
};

// ------------------------------------------------------------------ 默认配置

const DEFAULTS = {
  // 总开关：默认关。装完不会自己进服，必须先明确启用。
  enabled: false,
  host: '127.0.0.1',
  port: 25565,
  /** 留空 = 让 mineflayer 自己探测（它会 ping 服务器拿协议版本）。 */
  version: '',
  /**
   * 用哪个模块当协议层（2026-11-04）。
   *
   * <p>上游 `mineflayer` 的协议支持落后于游戏本体，连新版本（如 26.x）时
   * 需要换一个跟进的 fork（例如 `@wp2508/mineflayer`），在插件目录装好、
   * 把模块名填在这里即可；加载失败会自动回退到 `mineflayer`。</p>
   */
  mineflayerModule: 'mineflayer',
  username: 'Hers',
  auth: 'offline',
  /** 离线服常要 /login；进服后自动发一次。 */
  loginCommand: '',
  /**
   * 进服后自动执行的换肤命令（2026-11-04）。
   *
   * <p>例如 `skin url https://你的服务器/her.png`。皮肤是服务端的事：
   * 需要服务器装 SkinsRestorer 之类的插件，插件本身改不了账号皮肤。</p>
   */
  skinCommand: '',
  autoReconnect: true,

  /** 留空 = 用 QQ 助手那个智能体（同一个"她"）。 */
  agentId: '',
  /** 留空 = 自动推断为同级的 qq_agent 数据目录。 */
  qqAgentDir: '',
  useFacts: true,
  useDiary: true,
  maxMemoryChars: 700,
  maxHistoryTurns: 6,

  // ---------------- 知识库（2026-11-04） ----------------
  /** 每轮把玩家的话当检索词，自动从**智能体绑定的知识库**里捞几段。 */
  ragEnabled: true,
  /** 自动检索带几条。带太多会挤占上下文，游戏里 3 条够用。 */
  ragTopK: 3,
  /** 0 = 不过滤；调高更严格（只留高分片段）。 */
  ragScoreThreshold: 0,
  /**
   * 看到不认识的东西时，**插件自己**去知识库查一下（调平台 `search` 工具）。
   *
   * <p>这是"不用在代码里硬编码方块/生物资料"的关键：她看到 `zombie`，
   * 插件拿「僵尸 zombie 我的世界」去检索，把命中片段塞进上下文，她再决定躲不躲。</p>
   */
  kbLookup: true,
  /** 每轮最多查几条（查过的会缓存 24 小时，不会重复调）。 */
  kbLookupMax: 2,

  /** 谁能指挥她。空数组 = 谁都不能（默认安全，和 QQ 助手的私聊白名单同一套思路）。 */
  allowPlayers: [],
  /** 名单外的人搭话也回（但永远不执行他们要求的动作）。 */
  respondToStrangers: false,
  debounceSeconds: 3,
  maxActionsPerTurn: 3,
  actionTimeoutSec: 25,
  allowBreakBlocks: true,
  allowPlaceBlocks: true,
  /**
   * 合成"放下才有用"的方块（工作台/熔炉/箱子…）后，**顺手放到她旁边**。
   *
   * <p>不加这一步，模型只会写 `[合成 crafting_table 1]`，做完就报告"做好了"——
   * 因为"放下"要坐标，而它不知道哪格是空的。</p>
   */
  autoPlaceCrafted: true,
  /** 攻击默认关：她分不清"打僵尸"和"打你"。 */
  allowCombat: false,

  /*
   * 反射层（2026-11-05）：脱困 / 自保 / 自防 / 狩猎 / 插火把。
   *
   * <p>全部本地执行（每秒一次），**不调模型**。抄自 Mindcraft 的 modes.js，
   * 阈值也是它的：卡住 20 秒、自防 6 格、狩猎 12 格、火把冷却 30 秒。</p>
   */
  reflexEnabled: true,
  /** 6 格内的怪就打回去（还需 allowCombat）。 */
  selfDefense: true,
  /** 饿了且身上一点吃的都没有，才去打动物（还需 allowCombat）。 */
  hunting: true,
  /** 脚下光照 <8 就插火把（还需 allowPlaceBlocks + 背包有火把）。 */
  autoTorch: true,

  /**
   * 好奇心（2026-11-04）。
   *
   * <p>开关关掉就退回"定时盲问"的旧行为：每 {@code autonomyMinutes} 问一次
   * "你想干点什么"，不再需要"看到了什么"。</p>
   */
  curiosityEnabled: true,
  /** 扫描半径（格）。太大费 CPU，太小看不到什么。 */
  curiosityRadius: 16,
  /** 好奇心超过这个值就算"坐不住"，即使什么新东西都没有也会自己找事。 */
  curiosityThreshold: 0.55,
  /** 她自己说的"想做"最多记多久（小时）。 */
  intentionHours: 3,
  /**
   * 灵感涌现（2026-11-05）：偶尔**突然想干点什么**（想弄块地、想盖点东西、想走一段）。
   *
   * <p>内容由模型自己冒出来，代码只给素材和时机 —— 所以它不在任何行为清单里。</p>
   */
  inspirationEnabled: true,
  /** 两次灵感的基准间隔（分钟）；实际会 ±40% 抖动，发生时刻不可预测才像走神。 */
  inspirationGapMinutes: 25,

  /*
   * 行为链（2026-11-05）：灵感 → 计划 → 逐步执行。
   *
   * <p>计划由模型一次给出，执行全在本地 —— 所以"种一块地"这种多步活儿
   * 只花**一次**模型调用，而不是每步问一次。</p>
   */
  planEnabled: true,
  /** 一个计划最多几步（防止模型写 40 步把家拆了）。 */
  planMaxSteps: 12,
  /** 一次「盖」最多放多少方块（防止拿一张 3000 块的图把服务器卡死）。 */
  buildMaxBlocks: 200,

  /**
   * **永远别碰**的方块（逗号分隔，支持 `前缀*`）。
   *
   * <p>Baritone 的 blacklist 同样的东西。没有它，`[清空 6]` 会把你的箱子、
   * 末影箱、刷怪笼一起清掉 —— 那是不可逆的。</p>
   */
  noTouchBlocks: 'bedrock,barrier,command_block,chest,trapped_chest,ender_chest,shulker_box,spawner',
  /** `[清空]` 一次最多挖多少块（防止她把你家平了）。 */
  clearMaxBlocks: 120,
  /** 某一步失败后重试几次（0 = 不重试，直接交给修正）。 */
  planRetry: 1,
  /** 重试用完之后，允许问模型一次"剩下的步骤怎么改"。 */
  planRepair: true,
  /** 改不动了就**开口求助**（说清卡在哪、缺什么），而不是静默失败。 */
  planAskHelp: true,
  /** 一件事做完后，自动问"还有下一半吗"并接着做（跨计划连续）。 */
  planChain: true,
  /** 最多自动接几次后续计划（0 = 做完就停，等人）。 */
  planChainMax: 2,
  /**
   * 即时反应（2026-11-05）：看到稀有矿 / 有人上线 / 血见底时**立刻**开口，
   * 不等 `decisionSeconds` 的思考间隔。
   *
   * <p>这和 QQ 助手那套"按概率 / 按小时"的主动发言是两回事：这里只认事件，
   * 频率靠 flash 自己的冷却压住（同类 45~120 秒，全局 12 秒）。</p>
   */
  instantReaction: true,

  /**
   * 社交感知（2026-11-05）：谁对我做了什么、要不要问。
   *
   * <p>没有这一层，她被打只会"疼一下"，不会问也不会反应 —— 因为事件层是空的。</p>
   */
  socialEnabled: true,
  /*
   * 「被打要不要问」「要不要搭话」**不做成配置**（2026-11-05 用户要求）：
   * 这类"像不像人"的细节一旦暴露成开关，用户只会把它调成永动机或全关，
   * 两条路都不像人。阈值写在代码里（见 maybeSpeakAfterHit 的概率表）。
   */

  /**
   * 允许她**开口要东西 / 求帮忙**（2026-11-04）。
   *
   * <p>饿了要吃的、被怪堵住喊人来 —— 这类事她自己解决不了，憋着就变成
   * "饿着肚子绕圈"。关掉的话她只会自己想办法。</p>
   */
  askForHelp: true,
  /**
   * 什么新东西都没有时，还要不要"闲逛"。
   *
   * <p><b>默认关</b>：这才是好奇心该有的样子 —— 没看到什么就不动，
   * 而不是每 15 分钟凭空找件事做（那更像闹钟，也更费 token）。</p>
   */
  idleWander: false,

  /**
   * 自主**总开关**：关掉之后她既不"想"也不自己乱走，只回应你的指令。
   *
   * <p>2026-11-04 起它是真正的总闸 —— 以前活力层不受它管，
   * 关了自主她还是会自己溜达，用户当然觉得两边配置打架。</p>
   */
  autonomyEnabled: true,
  /**
   * 两次"动脑"之间的最短间隔（秒，±30% 抖动）。
   *
   * <p>**唯一花 token 的节奏**。原来散落在两个配置组里（一个是 15 分钟、
   * 一个是 75 秒），看起来像互相矛盾 —— 现在统一成这一个。</p>
   */
  decisionSeconds: 75,
  /** 你停手多久后她才开始自己动脑（分钟）。 */
  idleMinutes: 1,
  autonomyQuietStart: 23,
  autonomyQuietEnd: 8,

  /*
   * 活力（2026-11-04）。
   *
   * <p><b>为什么需要这一层</b>：原来的自主是"每 15 分钟醒一次、醒来说一句或走两步"，
   * 中间十几分钟完全静止 —— 真人不会那样。真人是一直在**小动作**里的：
   * 挪两步、转个身看你在干嘛、跟过来、跳一下。</p>
   *
   * <p>这一层全部是**本地行为，不调模型、不花 token**，所以可以高频。
   * 模型只负责"想干什么"这种需要思考的事，频率仍然很低。</p>
   */
  /**
   * 人性化细节总开关（2026-11-05）：
   * 节奏爆发、滞回、社交站位、微动作、走位抖动、克制（走远不追）。
   *
   * <p>关掉之后行为会明显"机械"——但它不影响功能，只影响观感。</p>
   */
  humanizeEnabled: true,
  /** 活力子开关：关掉只是"不许乱走"，思考照旧（总闸在 autonomyEnabled）。 */
  livelyEnabled: true,
  /** 站着一动不动超过这么久（秒），就自己挪一下/看看你。 */
  idleWalkSeconds: 25,
  /** 你在附近而她闲着 —— 跟过来，保持 3 格。 */
  followPlayerWhenIdle: true,

  writeMemory: true,
  /** 游戏内聊天也逐条记进流水（关掉就只剩动作与统计）。 */
  recordChat: true,
  /** 名单外的人说的话也记（关掉 = 只记白名单玩家与她自己的话）。 */
  recordStrangers: true,
  digestMinutes: 10,
  /** 保留最近多少次联机的记录文件（更旧的自动删）。 */
  memoryKeepSessions: 30,
  /** 聊天节流（没暴露在设置面板里，够用就行）。 */
  chatCooldownSec: 1,
};

// ------------------------------------------------------------------ 工具

const sleep = (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms)));

function clamp(n, min, max) {
  const v = Number(n);
  if (!Number.isFinite(v)) return min;
  return Math.min(max, Math.max(min, v));
}

function log(level, ...args) {
  try {
    api?.logger?.[level]?.(...args);
  } catch {
    /* 日志不该影响主流程 */
  }
}

/** 诊断日志：**落盘**（用户报"她不回话"时，唯一能还原现场的线索）。 */
function diag(line) {
  try {
    const f = path.join(api.dataDir, 'diag.log');
    try {
      const st = fs.statSync(f);
      if (st.size > 2 * 1024 * 1024) {
        fs.renameSync(f, `${f}.1`);
      }
    } catch {
      /* 首次写 */
    }
    fs.appendFileSync(f, `${new Date().toISOString()} ${line}\n`, 'utf8');
  } catch {
    /* 磁盘满/权限：不影响功能 */
  }
}

function pad2(n) {
  return String(n).padStart(2, '0');
}

function hhmm(d = new Date()) {
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}

function fmtNow(d = new Date()) {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())} ${hhmm(d)}`;
}

function durationText(ms) {
  const m = Math.floor((Number(ms) || 0) / 60000);
  if (m < 60) return `${m} 分钟`;
  return `${Math.floor(m / 60)} 小时 ${m % 60} 分`;
}

function parseNames(v) {
  if (Array.isArray(v)) {
    return v.map((x) => String(x || '').trim()).filter(Boolean);
  }
  return String(v || '')
    .split(/[,，\s]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

// ------------------------------------------------------------------ 配置

function configPath() {
  return path.join(api.dataDir, 'config.json');
}

function loadConfig() {
  const p = configPath();
  if (!fs.existsSync(p)) {
    fs.writeFileSync(p, JSON.stringify(DEFAULTS, null, 2), 'utf8');
    log('info', `已生成配置模板：${p}`);
    return { ...DEFAULTS };
  }
  try {
    const raw = JSON.parse(fs.readFileSync(p, 'utf8'));
    return { ...DEFAULTS, ...raw };
  } catch (e) {
    log('warn', `配置解析失败，使用默认值：${e.message}`);
    return { ...DEFAULTS };
  }
}

function saveConfigFile(patch) {
  /*
   * 两道过滤（照抄 qq-agent 的教训）：
   * ① 丢掉 undefined —— 表单清空数字框会传 undefined，合并后 Number(undefined) 全是 NaN；
   * ② 只接受 DEFAULTS 里声明过的 key —— 否则 `ok` / `data` 这类返回字段会被顺手写进配置。
   */
  const clean = {};
  for (const [k, v] of Object.entries(patch || {})) {
    if (v !== undefined && Object.prototype.hasOwnProperty.call(DEFAULTS, k)) {
      clean[k] = v;
    }
  }
  cfg = { ...cfg, ...clean };
  fs.writeFileSync(configPath(), JSON.stringify(cfg, null, 2), 'utf8');
  return cfg;
}

// ------------------------------------------------------------------ 共享记忆（与 QQ 助手共用）

/** QQ 助手插件的私有数据目录（同一层 dataRoot 下的 qq_agent）。 */
function qqAgentDir() {
  const custom = String(cfg.qqAgentDir || '').trim();
  if (custom) return custom;
  return path.resolve(api.dataDir, '..', 'qq_agent');
}

function sharedMemDir() {
  const d = path.join(qqAgentDir(), 'memory');
  try {
    fs.mkdirSync(d, { recursive: true });
  } catch {
    /* 已存在 / 无权限时下面的读写会自己报错 */
  }
  return d;
}

/**
 * 游戏记忆的落点（2026-11-04 改：**每次联机一个文件**）。
 *
 * <p>目录：`qq_agent/memory/minecraft/`
 * <ul>
 *   <li>`2026-11-04_2130.md` —— 那一次联机的全量流水（谁说了什么、做了什么、死了几次）；</li>
 *   <li>`index.md` —— 索引，一行一次联机，最新在最上面。</li>
 * </ul>
 *
 * <p><b>为什么按次分文件</b>：她在游戏里的记忆天然以"一局"为单位 ——
 * 从进服到退出。放一个文件里越滚越长，QQ 那边只能读尾巴，
 * 于是"上一次玩"会被这一次挤掉；分文件之后，读哪一段由读取方决定。</p>
 */
function sessionsDir() {
  return path.join(sharedMemDir(), 'minecraft');
}

function indexFile() {
  return path.join(sessionsDir(), 'index.md');
}

/** 旧版单文件（迁移前留下的），只在没有任何分文件时兜底读。 */
function legacyMemoryPath() {
  return path.join(sharedMemDir(), 'minecraft.md');
}

/** 当前正在写的文件；不在线时返回最近一次的。 */
function latestSessionFile() {
  if (session.file) return session.file;
  const st = readJsonFile(statePath(), {});
  const last = String(st.lastSessionFile || '');
  if (last && fs.existsSync(last)) return last;
  try {
    const files = fs.readdirSync(sessionsDir())
      .filter((f) => f.endsWith('.md') && f !== 'index.md')
      .sort();   // 文件名带时间，字典序 = 时间序
    if (files.length > 0) return path.join(sessionsDir(), files[files.length - 1]);
  } catch {
    /* 目录还没建 */
  }
  return '';
}

/**
 * 兼容入口：面板、上下文注入、状态里都还叫 memoryPath。
 *
 * <p>有分文件就用最新的；一次都没玩过才落到旧的单文件（老用户无痛切换）。</p>
 */
function memoryPath() {
  return latestSessionFile() || legacyMemoryPath();
}

/** 给 QQ 助手看的会话状态（它在"要不要读记忆"时会看这个）。 */
function statePath() {
  return path.join(sharedMemDir(), 'minecraft-state.json');
}

function readJsonFile(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8')) || fallback;
  } catch {
    return fallback;
  }
}

function writeJsonFile(file, data) {
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = `${file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tmp, file);   // 原子替换：QQ 助手随时在读，不能让它读到半个文件
  } catch (e) {
    diag(`写 ${path.basename(file)} 失败：${e.message}`);
  }
}

// ---------------- 单实例锁（2026-11-04） ----------------

/*
 * <h3>为什么需要它</h3>
 *
 * <p>Minecraft 一个号只能在线一次。只要同时有两个实例（热重载没杀干净的旧进程、
 * 多开了一个平台窗口、或两个插件 id），它们就会**互相把对方顶下线**：
 * 服务器对后来的那个踢 `multiplayer.disconnect.duplicate_login`，
 * 而被踢的一方重连又顶回去 —— 用户看到的就是"她一直在反复退出和加入"。</p>
 *
 * <p>光靠"别重连"治不了根：真有两个实例时，谁都想连。所以这里用
 * `bot.lock` 做互斥（pid + 30 秒心跳，60 秒没心跳视为残留），
 * 拿不到锁的那个**只记日志不连**，把问题变成一眼可见的一行警告。</p>
 */

const LOCK_STALE_MS = 60_000;

function lockPath() {
  return path.join(api.dataDir, 'bot.lock');
}

function pidAlive(pid) {
  const n = Number(pid);
  if (!n || n <= 0) return false;
  try {
    process.kill(n, 0);   // 只探测，不发信号
    return true;
  } catch (e) {
    /*
     * Windows 上探测"别人的/更高的"进程会抛 EPERM —— 那是**活着但不让碰**，
     * 不能当成"死了"，否则会去抢一个还在用的号（正是这个 bug 想防的事）。
     */
    return !!(e && (e.code === 'EPERM' || e.code === 'EACCES'));
  }
}

function readLock() {
  const v = readJsonFile(lockPath(), null);
  return v && typeof v === 'object' ? v : null;
}

/** 试着占住"这个号"。失败时返回占着它的那个实例信息。 */
function acquireLock() {
  const cur = readLock();
  if (cur && Number(cur.pid) !== process.pid && pidAlive(cur.pid)
    && Date.now() - (Number(cur.at) || 0) < LOCK_STALE_MS) {
    return { ok: false, holder: cur };
  }
  writeJsonFile(lockPath(), {
    pid: process.pid,
    at: Date.now(),
    server: serverText(),
    username: String(cfg.username || ''),
  });
  return { ok: true };
}

/** 心跳：每 30 秒刷新一次，告诉别人"我还活着"。 */
function touchLock() {
  const cur = readLock();
  if (!cur || Number(cur.pid) !== process.pid) return;
  writeJsonFile(lockPath(), { ...cur, at: Date.now() });
}

function releaseLock() {
  const cur = readLock();
  if (!cur || Number(cur.pid) !== process.pid) return;
  try {
    fs.unlinkSync(lockPath());
  } catch {
    /* 已经没了 */
  }
}

let qqCfgCache = { at: 0, data: null };

/** QQ 助手的配置（只读：拿 agentId / owners）。30 秒缓存，避免每条消息都读盘。 */
function qqAgentConfig() {
  const now = Date.now();
  if (qqCfgCache.data && now - qqCfgCache.at < 30_000) {
    return qqCfgCache.data;
  }
  const data = readJsonFile(path.join(qqAgentDir(), 'config.json'), {});
  qqCfgCache = { at: now, data };
  return data;
}

function factsFilePath() {
  return path.join(qqAgentDir(), 'memory', 'facts.json');
}

function selfFilePath() {
  return path.join(qqAgentDir(), 'memory', 'self.json');
}

/** 每种事实的说法（与 QQ 助手的 FACT_LABEL 对齐，值拼在后面）。 */
const FACT_LABEL = {
  city: '他人在',
  job: '他在',
  school: '他在',
  pet: '他养了',
  birthday: '他生日在',
  nickname: '他让你叫他',
  relation: '他和你的关系',
  habit: '他',
};

/**
 * 「关于他」——从 QQ 助手的事实记忆里取。
 *
 * <p><b>只取 owner 那一个人的</b>：游戏里进来的玩家可能不止一个，但"他是谁"只对主人成立。
 * 取不到就返回空串（不编造）。</p>
 */
function factsBlock() {
  if (!cfg.useFacts) return '';
  const owners = parseNames(qqAgentConfig().owners);
  if (owners.length === 0) return '';
  const facts = readJsonFile(factsFilePath(), {});
  const box = facts[String(owners[0])];
  if (!box || typeof box !== 'object') return '';
  const parts = [];
  for (const [kind, label] of Object.entries(FACT_LABEL)) {
    const v = box[kind];
    const value = v && typeof v === 'object' ? v.value : v;
    if (value) parts.push(`${label} ${String(value).slice(0, 40)}`);
  }
  if (parts.length === 0) return '';
  return `【关于他】${parts.join('；')}`;
}

/** 最近一篇日记（只 1 条：多了她会变成文艺腔，这条在 QQ 插件里也踩过）。 */
function diaryLine() {
  const s = readJsonFile(selfFilePath(), {});
  const list = Array.isArray(s.diary) ? s.diary : [];
  if (list.length === 0) return '';
  const d = list[list.length - 1];
  const text = String(d.text || '').slice(0, 80);
  if (!text) return '';
  const t = new Date(Number(d.at) || 0);
  const when = Number(d.at) ? `${pad2(t.getMonth() + 1)}-${pad2(t.getDate())}` : '';
  return `【你最近写的日记】${when}${d.mood ? '（' + d.mood + '）' : ''} ${text}`;
}

/**
 * 读一次联机的记录（正文，去掉标题行与注释）。
 *
 * @param {number} maxChars 最多多少字（保尾部：最近发生的才有用）
 * @param {string} [file]   指定文件；默认"当前/最近一次"
 */
function readMemoryTail(maxChars, file, opts = {}) {
  if (!maxChars) return '';
  const p = file || memoryPath();
  if (!p) return '';
  let raw = '';
  try {
    raw = fs.readFileSync(p, 'utf8');
  } catch {
    return '';
  }
  let body = raw
    .replace(/^#[^\n]*\n/, '')          // 标题行（日期 / 服务器 / 版本）另行展示
    .replace(/<!--[\s\S]*?-->/g, '')    // 文件头的说明不该进上下文
    .trim();

  /*
   * 给自己看的时候**剔掉聊天行**（2026-11-04）。
   *
   * <p>流水里逐条记了"谁说了什么"，而最近 6 轮对话本来就在 history 里 ——
   * 两边都注入等于同一句话出现两次，既费 token，也会让她以为对方说了两遍。</p>
   */
  if (opts.dropChat) {
    body = body
      .split('\n')
      .filter((l) => !/^\d{2}:\d{2} (我：|[^\s：]{1,16}：)/.test(l))
      .join('\n')
      .trim();
  }

  if (!body) return '';
  if (body.length > maxChars) {
    body = `…${body.slice(body.length - maxChars)}`;
  }
  return body;
}

// ---------------- 全量流水（2026-11-04） ----------------

/** 单次联机最多写多少行（防某次挂着几天的会话把文件写成几 MB）。 */
const SESSION_LINE_MAX = 3000;

/**
 * 往**当前这次联机**的流水里追加一行。
 *
 * <p>这是"全量记录"的落点：谁说了什么、她说了什么、每个动作的结果、
 * 死了几次、第一次走到哪。纯本地追加，**不调模型、不花 token**。</p>
 *
 * <p><b>为什么改成全量</b>：以前只写"每 10 分钟一行统计"，于是 QQ 那边
 * 聊到游戏时能说的只有「挖了 37 个方块」——没有任何具体内容，也就没得聊。</p>
 */
function note(text) {
  if (!cfg.writeMemory || !session.file) return;
  const body = String(text || '').replace(/\s+/g, ' ').trim();
  if (!body) return;
  if (session.lines >= SESSION_LINE_MAX) {
    if (!session.trimmed) {
      session.trimmed = true;
      try {
        fs.appendFileSync(session.file, '…（这次记录太长，后面只写统计了）\n', 'utf8');
      } catch {
        /* ignore */
      }
    }
    return;
  }
  try {
    fs.appendFileSync(session.file, `${hhmm()} ${body}\n`, 'utf8');
    session.lines++;
  } catch (e) {
    diag(`写流水失败：${e.message}`);
  }
}

/** 值得写进"总结"的一句话（死亡 / 发现新地形 / 标记坐标 / 她自己的备忘）。 */
function highlight(text) {
  const t = String(text || '').trim();
  if (!t) return;
  session.highlights.push(t.slice(0, 60));
  if (session.highlights.length > 12) {
    session.highlights.shift();
  }
}

/** 开一次新记录：一个新文件 + 标题行。 */
function startSessionMemory() {
  if (!cfg.writeMemory) return;
  try {
    fs.mkdirSync(sessionsDir(), { recursive: true });
  } catch (e) {
    diag(`建记忆目录失败：${e.message}`);
    return;
  }
  const d = new Date();
  let name = `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`
    + `_${pad2(d.getHours())}${pad2(d.getMinutes())}.md`;
  /*
   * 同一分钟里重连两次会撞名（文件名只到分钟）。
   * 撞了就补秒 —— 否则第二次的流水会把第一次的覆盖掉，那是最难发现的数据丢失。
   */
  if (fs.existsSync(path.join(sessionsDir(), name))) {
    name = name.replace(/\.md$/, `_${pad2(d.getSeconds())}.md`);
  }
  session.file = path.join(sessionsDir(), name);
  session.lines = 0;
  session.trimmed = false;
  session.highlights = [];

  /*
   * 标题的"起"用 `session.started`，不是"现在" ——
   * 断线重连时 spawn 那一刻才是真正进服时间，写"现在"会把时长算歪。
   */
  const startAt = session.started ? new Date(session.started) : new Date();
  const head = `# ${fmtNow(startAt)} 起 · ${stats.server} · ${(bot && bot.version) || '?'}\n`
    + '<!-- 由 MC 助手写入：一次联机一个文件，全量流水。可以直接改/删。 -->\n'
    + '\n## 流水\n';
  try {
    fs.writeFileSync(session.file, head, 'utf8');
  } catch (e) {
    diag(`建流水文件失败：${e.message}`);
    session.file = '';
    return;
  }
  note(`进入游戏（${stats.username}）`);
}

/** 这次联机的一句话总结（规则拼接，不调模型）。 */
function sessionSummary() {
  const t = session.tot || {};
  const parts = [];
  if (t.mined) parts.push(`挖了 ${t.mined} 个方块`);
  if (t.placed) parts.push(`放了 ${t.placed} 个`);
  if (t.deaths) parts.push(`死了 ${t.deaths} 次`);
  if (t.chatIn) parts.push(`聊了 ${t.chatIn} 句`);
  const hi = (session.highlights || []).slice(-2).join('；');
  if (hi) parts.push(hi);
  return parts.join('，') || '没做什么';
}

/** 索引：一行一次联机，最新在最上面。QQ 那边读它拿"最近几次都干了什么"。 */
function updateIndex(summary, durMs) {
  if (!session.file) return;
  const line = `- ${session.started ? fmtNow(new Date(session.started)) : fmtNow()}`
    + ` · ${durationText(durMs)} · ${summary} · \`${path.basename(session.file)}\``;
  let lines = [];
  try {
    lines = fs.readFileSync(indexFile(), 'utf8')
      .split('\n')
      .filter((l) => l.trim().startsWith('- '));
  } catch {
    /* 首次 */
  }
  lines.unshift(line);
  const keep = lines.slice(0, clamp(cfg.memoryKeepSessions, 5, 200));
  const out = '# Minecraft 联机记录\n\n'
    + '<!-- 一次联机一个文件，最新在最上面；这里是索引，可以手改 -->\n\n'
    + `${keep.join('\n')}\n`;
  try {
    fs.writeFileSync(indexFile(), out, 'utf8');
  } catch (e) {
    diag(`写索引失败：${e.message}`);
  }
}

/** 只保留最近 N 次联机的文件（文件名带时间，字典序即时间序）。 */
function pruneSessions() {
  const keep = clamp(cfg.memoryKeepSessions, 5, 200);
  try {
    const files = fs.readdirSync(sessionsDir())
      .filter((f) => f.endsWith('.md') && f !== 'index.md')
      .sort();
    for (let i = 0; i < files.length - keep; i++) {
      try {
        fs.unlinkSync(path.join(sessionsDir(), files[i]));
      } catch {
        /* 删不掉就算了，下次再删 */
      }
    }
  } catch {
    /* 目录不存在 */
  }
}

/**
 * 兼容旧调用点：把一段文字写进当前流水。
 *
 * <p>新代码请直接用 {@link note} / {@link highlight} —— 这个只为了让旧的
 * 多行调用还能工作（每行一条，不重复加时间戳）。</p>
 */
function appendMemory(text) {
  const body = String(text || '').trim();
  if (!body) return;
  for (const line of body.split('\n')) {
    const t = line.replace(/^[-#]+\s*/, '').trim();
    if (t) note(t);
  }
}

function writeState(patch) {
  const cur = readJsonFile(statePath(), {});
  writeJsonFile(statePath(), {
    ...cur,
    ...patch,
    server: stats.server,
    updatedAt: Date.now(),
  });
}

// ------------------------------------------------------------------ 世界坐标

function worldPath() {
  return path.join(api.dataDir, 'world.json');
}

function readWorld() {
  const w = readJsonFile(worldPath(), {});
  return w && typeof w === 'object' ? w : {};
}

// ------------------------------------------------------------------ mineflayer

/**
 * 启动自检：依赖不只是"能 require"，还要**数据完整**（2026-11-05）。
 *
 * <p>踩过的坑：平台自动 `npm install` 中途超时，`mineflayer` 能加载，
 * 但 `minecraft-data` 的版本数据目录是空的 —— 于是连接时抛
 * `Cannot find module './minecraft-data/data/pc/1.21.1/blocks.json'`，
 * 而错误信息看起来像"插件坏了"，其实只是装了一半。</p>
 */
function checkDependencies() {
  const out = [];
  for (const m of ['mineflayer', 'mineflayer-pathfinder', 'mineflayer-collectblock', 'vec3']) {
    try {
      require.resolve(m);
      out.push(`${m} ok`);
    } catch {
      out.push(`${m} 缺失`);
      log('error', `依赖缺失：${m} —— 在插件目录执行 npm install，或把 node_modules 整个拷过来`);
    }
  }
  try {
    // eslint-disable-next-line global-require
    const md = require('minecraft-data');
    const want = String(cfg.version || '1.21.1').trim() || '1.21.1';
    const d = md(want);
    if (!d || !d.blocks || Object.keys(d.blocks).length === 0) {
      throw new Error(`${want} 的方块表是空的`);
    }
    out.push(`minecraft-data ${d.version.minecraftVersion} ok`);
  } catch (e) {
    log('error', `minecraft-data 数据不完整（${e.message}）—— 典型症状是 npm install 只装了一半，把 node_modules 整个覆盖一次`);
  }
  diag(`deps: ${out.join(' / ')}`);
}

function loadMineflayer() {
  if (mineflayer) return mineflayer;

  /*
   * 模块名可配（2026-11-04）。
   *
   * <p>上游 mineflayer 的协议支持**永远落后于游戏本体**：26.3 是协议 777，
   * 而上游当时只到 1.21.x，于是"服务端升了、bot 连不上"是常态。
   * 社区通常有三条路：装一个跟进的 fork、用 ViaProxy 把协议转下来、
   * 或者把服务端停在受支持的版本。第一条只需要换个模块名，所以这里做成配置项。</p>
   */
  const wanted = String(cfg.mineflayerModule || 'mineflayer').trim() || 'mineflayer';
  const tryLoad = (name) => {
    try {
      // eslint-disable-next-line global-require, import/no-dynamic-require
      return require(name);
    } catch {
      return null;
    }
  };

  mineflayer = tryLoad(wanted);
  if (!mineflayer && wanted !== 'mineflayer') {
    diag(`mineflayer 模块 ${wanted} 加载失败，回退到 mineflayer`);
    log('warn', `没装上 ${wanted}，已回退到 mineflayer（可能连不上新版本服务器）`);
    mineflayer = tryLoad('mineflayer');
  }
  if (!mineflayer) {
    throw new Error(
      `mineflayer 没装好（尝试过 ${wanted}）：在插件目录执行 \`npm install\`，`
      + '或把 node_modules 一起打进插件 zip。连不上新版本时见「游戏版本」那一项的说明。',
    );
  }
  return mineflayer;
}

function loadClientPlugin(name) {
  try {
    // eslint-disable-next-line global-require
    return require(name);
  } catch (e) {
    diag(`组件未安装：${name}（${e.message}）`);
    return null;
  }
}

function serverText() {
  return `${cfg.host || '127.0.0.1'}:${Number(cfg.port) || 25565}`;
}

function connect() {
  if (stopping) return;
  if (!cfg.enabled) {
    diag('connect 被跳过：总开关未启用');
    return;
  }
  if (bot) return;

  /*
   * 单实例互斥（2026-11-04）：同名账号只能在线一个。
   * 拿不到锁就**不连**，避免和另一个实例互相顶掉（那会表现为反复进出游戏）。
   */
  const lock = acquireLock();
  if (!lock.ok) {
    const h = lock.holder || {};
    const age = Math.round((Date.now() - (Number(h.at) || 0)) / 1000);
    stats.lastError = `另一个实例正在使用「${cfg.username}」（pid ${h.pid}，${age} 秒前心跳）`;
    log('warn', stats.lastError);
    diag(`connect 被拒：${stats.lastError}`);
    // 一分钟后再说 —— 不在这里循环重试
    if (!reconnectTimer && cfg.autoReconnect && !stopping) {
      reconnectTimer = setTimeout(() => {
        reconnectTimer = null;
        connect();
      }, 60_000);
    }
    return;
  }

  let mf;
  try {
    mf = loadMineflayer();
  } catch (e) {
    stats.lastError = e.message;
    log('error', e.message);
    releaseLock();   // 连都没连上，别把号锁着
    return;
  }

  const opts = {
    host: String(cfg.host || '127.0.0.1'),
    port: Number(cfg.port) || 25565,
    username: String(cfg.username || 'Hers'),
    auth: cfg.auth === 'microsoft' ? 'microsoft' : 'offline',
    /*
     * 关掉 mineflayer 自己的 console.error：它会**绕过插件的 logger** 直接写 stderr，
     * 而宿主只收 `{type:'log'}` 消息 —— 那些错误用户根本看不到，却会把终端刷满
     * （重连失败时每几秒一条）。我们自己在 error 事件里记 message + 栈顶，更完整。
     */
    hideErrors: true,
  };
  const version = String(cfg.version || '').trim();
  if (version) {
    opts.version = version;
  }

  stats.server = serverText();
  stats.lastError = '';
  log('info', `连接 ${stats.server}（身份 ${opts.username}，${opts.auth}）`);
  diag(`connect ${stats.server} user=${opts.username} auth=${opts.auth} version=${version || 'auto'}`);

  try {
    bot = mf.createBot(opts);
  } catch (e) {
    stats.lastError = e.message;
    log('error', `创建 bot 失败：${e.message}`);
    releaseLock();
    scheduleReconnect();
    return;
  }
  attachEvents(bot);
}

function attachEvents(b) {
  const pathfinder = loadClientPlugin('mineflayer-pathfinder');
  if (pathfinder) {
    try {
      b.loadPlugin(pathfinder.pathfinder);
    } catch (e) {
      diag(`pathfinder 加载失败：${e.message}`);
    }
  }
  const collect = loadClientPlugin('mineflayer-collectblock');
  if (collect) {
    try {
      b.loadPlugin(collect.plugin || collect);
    } catch (e) {
      diag(`collectblock 加载失败：${e.message}`);
    }
  }

  /*
   * 所有事件都先判断"是不是当前这条连接"（2026-11-04）。
   *
   * 改配置时会先 quit 旧的再建新的，旧连接还会零星吐事件 —— 不判断的话，
   * 她会对**已经作废**的那局说话，日志里还会出现两份"开始玩"。
   */
  const live = (fn) => (...args) => {
    if (bot === b) fn(...args);
  };

  b.once('spawn', live(() => onSpawn()));
  b.on('chat', live((username, message) => onChat(username, message, false)));
  b.on('whisper', live((username, message) => onChat(username, message, true)));
  b.on('death', live(onDeath));
  /*
   * 挨打要立刻有反应（2026-11-04）。
   *
   * <p>不设这条的话，她被僵尸追着咬也只能等下一次"思考"（默认 75 秒）——
   * 而 75 秒够死一次了。这里打一个 urgent 标记，自主那一路会跳过间隔立刻醒。</p>
   */
  b.on('entityHurt', live((e) => {
    if (e !== bot.entity) return;
    senseCache.urgent = { at: Date.now() };
    // 自保要用"最近 3 秒内受过伤"这个判据（濒死逃跑只在挨打后触发）
    reflex.lastHurtAt = Date.now();
    note('挨了一下');
    // 社交层：谁打的、可能为什么、要不要问一句
    onHurtSocial();
  }));
  /*
   * 有人上线是一个**很强的注意点**（2026-11-04）：她自己会看见"某某上线了"，
   * 下一轮就可能主动招呼一句，而不是等对方先说话。
   */
  b.on('playerJoined', live((p) => {
    if (!p || !p.username || p.username === stats.username) return;
    senseCache.social = { name: p.username, at: Date.now() };
    diag(`player joined: ${p.username}`);
    // 有人上线值得立刻招呼一句（不走节流，见 flash）
    flash('join', `${p.username} 上线了`);
  }));
  b.on('playerLeft', live((p) => {
    if (senseCache.social && p && senseCache.social.name === p.username) {
      senseCache.social = null;
    }
  }));
  b.on('kicked', live((reason) => {
    const text = typeof reason === 'string' ? reason : JSON.stringify(reason);
    const dup = /duplicate_login|already|logged in|已在游戏|重复登录/i.test(String(text));
    stats.lastError = dup
      ? '被踢：同名账号已在别处登录（有两个实例在抢这个号）'
      : `被踢出：${String(text).slice(0, 200)}`;
    log('warn', stats.lastError);
    diag(`kicked: ${String(text).slice(0, 300)}${dup ? ' [duplicate-login]' : ''}`);
    releaseLock();

    /*
     * 同名重复登录**绝不能快重连**（2026-11-04 修的坑）。
     *
     * <p>上一版这里是"5 秒后重连"，结果形成自激循环：重连 → 顶掉对方 →
     * 对方也重连 → 再顶回来……日志表现为每 5 秒一次
     * `connect → kicked(duplicate_login) → spawn ok`，用户看到的就是
     * "她一直在反复退出和加入"。</p>
     *
     * <p>现在：退避 10/20/30 秒，且**最多 3 次**就放弃并明说原因 ——
     * 真有两个实例时，让其中一个安静下来比互相抢更有用。</p>
     */
    if (dup && !stopping) {
      duplicateKicks++;
      if (duplicateKicks <= 3 && cfg.autoReconnect && !reconnectTimer) {
        const wait = 10_000 * duplicateKicks;
        log('warn', `同名重复登录（第 ${duplicateKicks} 次）：${wait / 1000} 秒后再试`);
        reconnectTimer = setTimeout(() => {
          reconnectTimer = null;
          connect();
        }, wait);
      } else if (duplicateKicks > 3) {
        log('error', '连续 3 次被同名顶下线：已停止自动重连。'
          + '请确认只开了一个平台窗口 / 只装了一个 MC 助手'
          + '（或手动点一次「停用」再「启用」）');
        stats.lastError = '同名重复登录：已停止自动重连（可能有第二个实例在跑）';
      }
    }
  }));
  b.on('error', live((e) => {
    stats.lastError = String((e && e.message) || e);
    // 栈只留前 6 行：版本不匹配时，值钱的正是 "Unsupported protocol version" 那几行
    const stack = String((e && e.stack) || '').split('\n').slice(0, 6).join(' | ');
    diag(`bot error: ${stats.lastError} :: ${stack}`);
  }));
  b.on('end', (reason) => {
    /*
     * **只处理"当前这个 bot"的结束**（2026-11-04）。
     *
     * <p>改配置时会先 quit 旧的再建新的，两条连接会短暂并存；旧连接稍后
     * 才吐出 `end`。不判断身份的话，它会把**新** bot 的引用清掉、还会
     * 给新会话写一次"下线"——表现是刚连上就显示未连接（很难查）。</p>
     */
    const isCurrent = bot === b;
    const wasConnected = isCurrent && stats.connected;
    if (isCurrent) {
      stats.connected = false;
      bot = null;
    }
    if (wasConnected) {
      closeSessionMemory();
    }
    if (isCurrent) {
      releaseLock();   // 连接已经断了，把号让出来后才能重连
    }
    diag(`bot end: ${reason || ''}${isCurrent ? '' : '（旧连接，忽略）'}`);
    if (isCurrent && !stopping) scheduleReconnect();
  });
  b.on('health', live(() => {
    // 掉血只记录，不做判断 —— 要不要跑/吃由她自己决定（反射层留到下一版）
    if (b.health <= 6) {
      diag(`low health ${Math.round(b.health)}`);
    }
    // 血见底要**立刻**有反应（疼 / 喊人），不能等下一次思考
    if (b.health != null && b.health <= 8) {
      flash('danger', `血量只剩 ${Math.round(b.health)}/20`);
    }
  }));
}

function scheduleReconnect() {
  if (stopping || !cfg.enabled || !cfg.autoReconnect || reconnectTimer) return;
  const wait = reconnectDelay;
  reconnectDelay = Math.min(reconnectDelay * 2, 60_000);
  log('info', `${Math.round(wait / 1000)} 秒后重连`);
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    connect();
  }, wait);
}

function disconnect() {
  const b = bot;
  bot = null;
  stats.connected = false;
  if (b) {
    /*
     * 先**同步发出断开包**，再让进程去死（2026-11-04）。
     *
     * <p>热重载是"stop → 杀进程 → 400ms 后起新进程"。如果断开包没发出去，
     * 服务器还会认为 `Hers` 在线几十秒，新进程立刻用同名登录就会被踢
     * （`You are already logged in`）—— 现象是"热重载之后她一直不在线"，
     * 而日志里写着"热重载完成"，特别难查。</p>
     */
    try {
      b.quit('bye');
    } catch {
      /* 已断开 */
    }
    try {
      if (b._client && typeof b._client.end === 'function') {
        b._client.end();   // 直接把 socket 关掉，不等握手
      }
    } catch {
      /* ignore */
    }
  }
  releaseLock();
  if (stats.sessionStart) {
    closeSessionMemory();
  }
}

// ------------------------------------------------------------------ 会话记忆

function onSpawn() {
  stats.connected = true;
  stats.username = (bot && bot.username) || String(cfg.username || '');
  stats.sessionStart = Date.now();
  reconnectDelay = 2000;
  lastActivityAt = Date.now();
  lastAutonomyAt = Date.now();
  session.started = Date.now();
  session.win = { mined: 0, placed: 0, deaths: 0, chatIn: 0, chatOut: 0 };
  session.tot = { mined: 0, placed: 0, deaths: 0, chatIn: 0, chatOut: 0 };
  session.notes = [];
  session.lastResults = [];
  lastDigestAt = Date.now();
  duplicateKicks = 0;   // 成功进服 → 计数清零

  // 上次没做完的计划，等进服稳定两秒后接着做（断线重连不该让活儿白干）
  setTimeout(() => {
    try {
      resumePlanIfAny();
    } catch (e) {
      diag(`恢复计划失败：${e.message}`);
    }
  }, 3000);
  /*
   * 感知缓存按"这次连接"重置（2026-11-04）。
   *
   * `interestingIds` 也必须清：换服务器可能换了版本，方块 id 表会变 ——
   * 不清的话她会一直找"上一个版本里的煤"。
   */
  senseCache.attentions = null;
  senseCache.at = 0;
  senseCache.social = null;
  interestingIds = null;
  // 活力：进服就先"动一下"，并且把寻路设成不许挖方块
  lastLocalMoveAt = Date.now() - 20_000;   // 让她进服后很快就有个小动作
  ambientHoldUntil = 0;
  setupMovements();

  log('info', `已进入服务器：${stats.username} @ ${stats.server}`);
  diag(`spawn ok ${stats.username} @ ${stats.server} version=${(bot && bot.version) || '?'}`);

  /*
   * 开这一次的记忆文件（2026-11-04）：一次联机 = 一个文件，从"进服"写到"退出"。
   * 里面是全量流水 —— 谁说了什么、她做了什么、结果如何。
   */
  startSessionMemory();
  writeState({
    online: true,
    since: stats.sessionStart,
    endedAt: 0,
    username: stats.username,
    version: (bot && bot.version) || '',
    lastSessionFile: session.file || '',
  });

  if (String(cfg.loginCommand || '').trim()) {
    setTimeout(() => {
      try {
        bot?.chat(String(cfg.loginCommand).trim());
      } catch {
        /* 断线了 */
      }
    }, 2500);
  }

  /*
   * 自动换肤（2026-11-04）。
   *
   * <p>**皮肤是服务端的事，不是插件的事**：离线账号没有 Mojang 档案，服务器上
   * 默认谁看都是 Steve。要让别人看见她的皮肤，通常得服务器装 SkinsRestorer，
   * 然后由她自己在游戏里执行 `/skin url <png地址>`。</p>
   *
   * <p>所以这里只做"进服后替她发一条命令"，皮肤文件仍然由你放在能被服务器
   * 访问到的 HTTP 地址上（64×64 PNG）。</p>
   */
  const skinCmd = String(cfg.skinCommand || '').trim();
  if (skinCmd) {
    // 排在 login 之后：有些服没登录不让发命令
    setTimeout(() => {
      try {
        bot?.chat(skinCmd.startsWith('/') ? skinCmd : `/${skinCmd}`);
        note(`执行换肤命令（${skinCmd.slice(0, 40)}）`);
      } catch {
        /* 断线了 */
      }
    }, 5000);
  }
}

function onDeath() {
  session.win.deaths++;
  session.tot.deaths++;
  session.lastResults = ['你死了，已重生'];
  note('死了一次，已重生');
  highlight('死过');
  /*
   * 失败复盘（2026-11-05）：给她一条"教训"，下一轮由她**自己嘴**说出来。
   * 同类项目的经验：真正让人觉得"这玩意儿活着"的，不是成功率，是失败后的自我解释。
   */
  const p = bot && bot.entity ? bot.entity.position : null;
  setLesson(p
    ? `刚才死在 (${Math.round(p.x)}, ${Math.round(p.z)})，掉的装备最好回去捡`
    : '刚才死了一次，东西掉了');
}

/**
 * 下线：写总结 + 更新索引 + 裁剪旧文件。
 *
 * <p>总结是**规则拼的**（不调模型）：时长、挖了多少、死了几次、这次最值得记的
 * 一两件事。QQ 那边先读索引拿到这句话，需要细节再读流水。</p>
 */
function closeSessionMemory() {
  if (!session.file) {
    stats.sessionStart = 0;
    return;
  }
  const dur = Date.now() - (session.started || Date.now());
  note(`退出游戏（玩了 ${durationText(dur)}）`);
  flushNotes();

  const summary = sessionSummary();
  try {
    fs.appendFileSync(
      session.file,
      `\n## 总结\n- 时长：${durationText(dur)}\n- ${summary}\n`,
      'utf8',
    );
    /*
     * 标题补上结束时间：`# 2026-11-04 21:30 起 · …` → `# 2026-11-04 21:30 – 23:02 · …`
     * QQ 那边直接读这一行就能说"昨晚那局"。
     */
    const raw = fs.readFileSync(session.file, 'utf8');
    if (raw.startsWith('# ') && raw.includes(' 起 · ')) {
      fs.writeFileSync(session.file, raw.replace(' 起 · ', ` – ${hhmm()} · `), 'utf8');
    }
  } catch (e) {
    diag(`收尾写记忆失败：${e.message}`);
  }

  updateIndex(summary, dur);
  pruneSessions();
  writeState({
    online: false,
    endedAt: Date.now(),
    lastSessionFile: session.file,
    summary,
    durationMs: dur,
  });

  /*
   * 收尾时把统计清零（2026-11-04）。
   *
   * <p>不能只依赖 onSpawn 重置：`stop()`、热重载、连上但没 spawn 就断开，
   * 都可能让"下一次"带着上一次的累计数 —— 表现是总结里的数字一天比一天大。</p>
   */
  session.win = { mined: 0, placed: 0, deaths: 0, chatIn: 0, chatOut: 0 };
  session.tot = { mined: 0, placed: 0, deaths: 0, chatIn: 0, chatOut: 0 };
  session.highlights = [];
  session.started = 0;
  session.file = '';
  stats.sessionStart = 0;
}

/** 把这一窗口的进展写成一行（纯统计，不调模型）—— 全量流水里的"锚点"。 */
function flushDigest() {
  const w = session.win;
  const parts = [];
  if (w.mined) parts.push(`挖了 ${w.mined} 个方块`);
  if (w.placed) parts.push(`放了 ${w.placed} 个`);
  if (w.deaths) parts.push(`死了 ${w.deaths} 次`);
  if (w.chatIn) parts.push(`聊天 ${w.chatIn} 句`);

  const p = bot && bot.entity && bot.entity.position;
  const where = p ? `在 (${Math.round(p.x)}, ${Math.round(p.y)}, ${Math.round(p.z)})` : '';
  if (parts.length > 0 || where) {
    note(`进展：${parts.length ? parts.join('，') : '没什么变化'}${where ? ` · ${where}` : ''}`);
  }

  session.win = { mined: 0, placed: 0, deaths: 0, chatIn: 0, chatOut: 0 };
  flushNotes();
  writeState({
    online: stats.connected,
    since: session.started || 0,
    mined: session.tot.mined,
    placed: session.tot.placed,
    deaths: session.tot.deaths,
    chat: session.tot.chatIn,
  });
}

function flushNotes() {
  if (session.notes.length === 0) return;
  for (const n of session.notes.splice(0)) {
    note(n);
  }
}

// ------------------------------------------------------------------ 观察

function describeTime() {
  const tod = bot && bot.time && typeof bot.time.timeOfDay === 'number' ? bot.time.timeOfDay : 0;
  if (tod < 11000) return '白天';
  if (tod < 13000) return '傍晚';
  if (tod < 18000) return '夜里';
  if (tod < 23000) return '深夜';
  return '凌晨';
}

function describeInventory() {
  if (!bot || !bot.inventory) return '';
  const items = bot.inventory.items() || [];
  /*
   * 剩余格子必须报给模型（2026-11-05）。
   *
   * <p>用户的原话是"什么都捡背包满了就不行"——所以"捡不捡"交给模型判断，
   * 但**它得知道还剩几格**，否则没法判断。这里把 `emptySlotCount()` 附在末尾。</p>
   */
  let free = '';
  try {
    const n = bot.inventory.emptySlotCount();
    if (typeof n === 'number') free = `　（剩 ${n} 格）`;
  } catch {
    /* 旧版本没有这个方法 */
  }
  if (items.length === 0) return `空${free}`;
  const sorted = [...items].sort((a, b) => (b.count || 0) - (a.count || 0)).slice(0, 8);
  return `${sorted.map((i) => `${i.name}×${i.count}`).join(' ')}${free}`;
}

const HOSTILE = /zombie|skeleton|creeper|spider|witch|enderman|slime|pillager|vindicator|blaze|ghast|drowned|husk|stray|phantom|silverfish|magma/;

function describeNearby() {
  if (!bot || !bot.entity) return '';
  const me = bot.entity.position;
  const parts = [];

  const players = Object.values(bot.players || {})
    .filter((p) => p && p.username && p.username !== stats.username && p.entity)
    .map((p) => ({ name: p.username, d: p.entity.position.distanceTo(me) }))
    .filter((p) => p.d < 48)
    .sort((a, b) => a.d - b.d)
    .slice(0, 3);
  for (const p of players) {
    parts.push(`${p.name}（玩家，${Math.round(p.d)} 格）`);
  }

  const mobs = Object.values(bot.entities || {})
    .filter((e) => e && e !== bot.entity && e.name && HOSTILE.test(String(e.name)))
    .map((e) => ({ name: e.name, d: e.position.distanceTo(me) }))
    .filter((e) => e.d < 16)
    .sort((a, b) => a.d - b.d)
    .slice(0, 3);
  for (const m of mobs) {
    parts.push(`${m.name}（${Math.round(m.d)} 格）`);
  }

  return parts.join('、');
}

/** 一行（多行）状态。这是模型判断"我现在能干什么"的唯一依据。 */
function observeLine() {
  if (!bot || !bot.entity) return '【你】不在游戏里（没连上）';
  const p = bot.entity.position;
  const dim = String((bot.game && bot.game.dimension) || '').replace('minecraft:', '') || '?';
  const hp = bot.health == null ? '?' : Math.round(bot.health);
  const food = bot.food == null ? '?' : bot.food;
  const lines = [
    `【你】${dim} (${Math.round(p.x)}, ${Math.round(p.y)}, ${Math.round(p.z)})`
    + `  血量 ${hp}/20  饥饿 ${food}/20  ${describeTime()}${bot.isRaining ? ' 下雨' : ''}`,
  ];
  const inv = describeInventory();
  if (inv) lines.push(`【背包】${inv}`);

  // 设施记忆（Mindcraft memory bank）：她"记得"哪里有箱子/工作台
  const fac = facilitiesBlock();
  if (fac) lines.push(fac);

  // 社交事件（2026-11-05）：他刚才打了我 / 我被怪咬了
  const soc = socialBlock();
  if (soc) lines.push(soc);
  // 主手拿的是什么 —— "做好了工作台却没放下"这类判断要靠它
  if (bot.heldItem && bot.heldItem.name) {
    lines.push(`【手上】${bot.heldItem.name}`);
  }
  const near = describeNearby();
  if (near) lines.push(`【附近】${near}`);
  if (session.lastResults.length > 0) {
    lines.push(`【刚才】${session.lastResults.join('；')}`);
  }
  return lines.join('\n');
}

// ------------------------------------------------------------------ 好奇心（2026-11-04）

/*
 * <h3>为什么要单独做一层"好奇心"</h3>
 *
 * <p>原来的自主是**定时盲问**：每 15 分钟叫醒她一次，"你想干点什么"。
 * 她每次都要凭空想，于是永远在重复同一类事（挖木头、看风景），而且
 * 说出来和做出来之间没有因果关系 —— 不是"看到了才想做"。</p>
 *
 * <p>现在拆成三段，和人的顺序一致：</p>
 * <ol>
 *   <li><b>看到</b>（{@link rawAttentions}）：扫附近**没见过的**东西 ——
 *       矿、箱子、苔石、花、活的动物、掉落物、新地形、岩浆、天黑了、有人上线；</li>
 *   <li><b>想</b>（{@link classifyAttentions} + curiosity 数值）：新奇度 × 稀有度 ÷ 距离，
 *       只留前 3；同一个东西 12 小时内不会被反复"发现"。好奇心是一个 0~1 的连续量，
 *       会随时间回落、闲久了上升 —— 所以是"她此刻想不想动"，不是一个开关；</li>
 *   <li><b>说 + 做</b>：这些注意点进上下文，**由她自己决定**说不说、去不去；
 *       我们只是把"先说后做"的顺序固定下来（{@code handleTurn} 先发文字再执行动作）。</li>
 * </ol>
 *
 * <p><b>关键是"只认没见过的"</b>：没有这一步，她会在同一棵橡树前反复惊叹，
 * 那不是好奇心，那是复读。宁可少发现，也不能刷屏。</p>
 */

/** 新奇记忆的保质期：同一样东西 12 小时内只"第一次见"一次。 */
const SEEN_TTL_MS = 12 * 3600_000;
const SEEN_MAX = 300;
/** 意图（她自己说"想去做"的事）最长挂多久。 */
const INTENT_MAX = 3;

function mindPath() {
  return path.join(api.dataDir, 'mind.json');
}

let mindCache = null;

function readMind() {
  if (mindCache) return mindCache;
  const raw = readJsonFile(mindPath(), {});
  const now = Date.now();
  mindCache = {
    curiosity: clamp(typeof raw.curiosity === 'number' ? raw.curiosity : 0.35, 0, 1),
    seen: Array.isArray(raw.seen) ? raw.seen.filter((x) => x && x.id) : [],
    intentions: Array.isArray(raw.intentions)
      ? raw.intentions.filter((x) => x && x.text && Number(x.expiresAt) > now)
      : [],
    /*
     * 念头池（2026-11-05）：**只在这里声明才会被持久化** ——
     * `saveMind` 直接序列化整个对象，没声明的字段读一次就丢。
     */
    ideas: Array.isArray(raw.ideas) ? raw.ideas.filter((x) => x && x.text) : [],
    updatedAt: Number(raw.updatedAt) || 0,
  };
  return mindCache;
}

function saveMind() {
  if (!mindCache) return;
  mindCache.updatedAt = Date.now();
  writeJsonFile(mindPath(), mindCache);
}

function bumpCuriosity(delta) {
  const m = readMind();
  m.curiosity = clamp(m.curiosity + Number(delta || 0), 0, 1);
  saveMind();
  return m.curiosity;
}

let lastSettleAt = 0;

/**
 * 好奇心的自然变化。
 *
 * <p>**向 0.35 回归**而不是一路衰减到 0：人闲着会闷，闷了就想起身。
 * 半衰期约 6 小时；另外"半小时没人理"会额外加一点 —— 这是"自己找事"的来源。</p>
 */
function settleCuriosity() {
  const now = Date.now();
  if (now - lastSettleAt < 10 * 60_000) return;
  const hours = lastSettleAt ? Math.min(6, (now - lastSettleAt) / 3600_000) : 0.5;
  lastSettleAt = now;

  const m = readMind();
  const keep = Math.pow(0.88, hours);
  m.curiosity = clamp(0.35 + (m.curiosity - 0.35) * keep, 0, 1);
  if (now - lastActivityAt > 30 * 60_000) {
    m.curiosity = clamp(m.curiosity + 0.08, 0, 1);
  }
  m.intentions = m.intentions.filter((i) => Number(i.expiresAt) > now);
  m.seen = m.seen.filter((s) => now - (Number(s.at) || 0) < SEEN_TTL_MS).slice(-SEEN_MAX);
  saveMind();
}

/** 值得注意的方块（正则匹配 minecraft-data 的方块名）。 */
// 花：Minecraft 里没有统一的 `_flower` 后缀，必须逐个列（漏了等于"看不见花"）
const INTERESTING_BLOCK = /_ore$|^chest$|^barrel$|^crafting_table$|^furnace$|^mossy_cobblestone$|^spawner$|poppy|dandelion|blue_orchid|allium|azure_bluet|tulip|oxeye_daisy|cornflower|lily_of_the_valley|sunflower|wither_rose|^mushroom|^bamboo$|^melon$|^pumpkin$|^sugar_cane$|^cactus$|^vine$|^lily_pad$|^bookshelf$|^anvil$|^enchanting_table$|^nether_portal$|^obsidian$|^lava$/;

/** 结构线索：同一个坐标附近只算一次，但别处的另一个箱子仍然是新的。 */
const PLACE_KIND = /^(chest|barrel|spawner|anvil|enchanting_table|mossy_cobblestone|nether_portal)$/;

/** 会动的东西（不含怪：怪的优先级是"躲"，不是"好奇"）。 */
const PASSIVE = /cow|pig|sheep|chicken|rabbit|cat|wolf|fox|horse|parrot|panda|axolotl|bee|turtle|frog|goat|llama|villager|wandering_trader/;

const BLOCK_CN = {
  oak_log: '橡木',
  birch_log: '白桦',
  stone: '石头',
  cobblestone: '圆石',
  iron_ore: '铁矿',
  coal_ore: '煤矿',
  copper_ore: '铜矿',
  gold_ore: '金矿',
  diamond_ore: '钻石矿',
  emerald_ore: '绿宝石矿',
  redstone_ore: '红石矿',
  lapis_ore: '青金石矿',
  chest: '箱子',
  barrel: '木桶',
  crafting_table: '工作台',
  furnace: '熔炉',
  mossy_cobblestone: '苔石',
  spawner: '刷怪笼',
  bookshelf: '书架',
  enchanting_table: '附魔台',
  nether_portal: '地狱门',
  obsidian: '黑曜石',
  lava: '岩浆',
  poppy: '虞美人',
  dandelion: '蒲公英',
  sunflower: '向日葵',
  bamboo: '竹子',
  melon: '西瓜',
  pumpkin: '南瓜',
  sugar_cane: '甘蔗',
  cactus: '仙人掌',
  lily_pad: '睡莲',
};

function blockLabel(name) {
  return BLOCK_CN[name] || name;
}

/**
 * 中文俗称 → 英文 id。
 *
 * <p>模型经常写「挖橡木」「拿铁锭」，而 minecraft-data 的注册表里只有英文 id。
 * 不做这层映射，她会一直回「不认识方块」——看着像不会玩，其实是名字对不上。</p>
 */
const CN_TO_EN = (() => {
  const m = {};
  for (const [en, cn] of Object.entries(BLOCK_CN)) {
    m[cn] = en;
  }
  return Object.assign(m, {
    木头: 'oak_log',
    原木: 'oak_log',
    树: 'oak_log',
    树苗: 'oak_sapling',
    木板: 'oak_planks',
    木棍: 'stick',
    煤炭: 'coal',
    煤: 'coal_ore',
    铁: 'iron_ore',
    铁锭: 'iron_ingot',
    铁块: 'iron_block',
    金: 'gold_ore',
    金锭: 'gold_ingot',
    红石: 'redstone',
    钻石: 'diamond',
    青金石: 'lapis_lazuli',
    绿宝石: 'emerald',
    泥土: 'dirt',
    草方块: 'grass_block',
    沙子: 'sand',
    沙: 'sand',
    砂砾: 'gravel',
    玻璃: 'glass',
    火把: 'torch',
    面包: 'bread',
    苹果: 'apple',
    牛肉: 'beef',
    猪肉: 'porkchop',
    鸡肉: 'chicken',
  });
})();

/** 把中文名换成英文 id（认不出就原样返回，交给原有的模糊匹配）。 */
function normalizeName(raw) {
  const n = String(raw || '').trim();
  if (!n) return n;
  return CN_TO_EN[n] || n;
}

/**
 * 一类方块 → 一批 id。
 *
 * <p>「树」「木头」在注册表里根本不存在（只有 `oak_log`/`birch_log`…），
 * 所以这类词要按后缀找一批，否则玩家说「去砍树」她永远找不到目标。</p>
 */
function blockIdsFor(raw) {
  const name = String(raw || '').trim();
  if (!name) return [];
  /*
   * 用**包含**而不是全等：模型会写「附近有树的地方」「挖点木头」这种带修饰的说法。
   * 只要句子里有"树/木头"，就当作"找最近的任意原木"。
   */
  if (/树|木头|原木|木材|橡木|白桦|云杉|丛林木/.test(name) && !CN_TO_EN[name]) {
    const reg = (bot && bot.registry && bot.registry.blocksByName) || {};
    return Object.entries(reg).filter(([k]) => /_log$/.test(k)).map(([, v]) => v.id);
  }
  const def = findBlockByName(normalizeName(name));
  return def ? [def.id] : [];
}

/** 最近的这类方块（找不到返回 null）。 */
function nearestBlockPos(raw, maxDistance = 48) {
  if (!bot || !bot.entity) return null;
  const ids = blockIdsFor(raw);
  if (ids.length === 0) return null;
  const pos = bot.findBlock({ matching: ids, maxDistance });
  return pos
    ? { x: pos.x, y: pos.y, z: pos.z, dist: pos.distanceTo(bot.entity.position) }
    : null;
}

/** 稀有度权重：越"值得过去看一眼"的越高。 */
function blockWeight(name) {
  if (/diamond_ore|emerald_ore/.test(name)) return 3.0;
  if (/_ore$/.test(name)) return 2.2;
  if (PLACE_KIND.test(name)) return 2.6;
  if (/flower|mushroom|bamboo|melon|pumpkin|sugar_cane|cactus|lily_pad|vine/.test(name)) return 1.2;
  if (name === 'lava') return 2.4;
  return 1.0;
}

let interestingIds = null;

function interestingBlockIds() {
  if (interestingIds) return interestingIds;
  const reg = (bot && bot.registry && bot.registry.blocksByName) || {};
  interestingIds = Object.entries(reg)
    .filter(([name]) => INTERESTING_BLOCK.test(name))
    .map(([, def]) => def.id);
  return interestingIds;
}

/** 运行时缓存：一次扫描的结果给"自主"和"闲聊"两处共用，别扫两遍。 */
const senseCache = { attentions: null, at: 0, social: null, biome: '', flash: null, urgent: null };

// ---------------- 即时反应（2026-11-05） ----------------

/*
 * <h3>「看到就想说」不该被节流挡住</h3>
 *
 * <p>好奇心本身是**事件驱动**的（看到新东西才叫醒她，不是按概率抽签），
 * 但外面还套着两层节流：60 秒扫描缓存 + `decisionSeconds`（默认 75 秒）的思考间隔。
 * 结果就是"她明明看见钻石了，要等一分钟才开口" —— 那还是节拍器。</p>
 *
 * <p>所以加一条**打断**通道：少数"值得立刻说话"的事件绕过间隔，直接醒一次。
 * 频率靠两层冷却压住 —— 全局 12 秒最多一次，同类事件各有更长的冷却。
 * 这和 QQ 助手那套"按概率 / 按小时"的主动发言完全无关：这里只认事件。</p>
 */
const FLASH_SPEC = {
  /** 稀有矿：钻石 / 绿宝石 / 远古残骸。 */
  rare: { cool: 120_000, weight: 3.4 },
  /** 有人上线。 */
  join: { cool: 90_000, weight: 3.0 },
  /** 血不多了 / 被围。 */
  danger: { cool: 45_000, weight: 3.8 },
};

let flashAt = 0;
const flashKindAt = Object.create(null);

/**
 * 记一次"想立刻说"的事件。
 *
 * @returns {boolean} 是否真的触发了（被冷却吞掉时返回 false，便于测试）
 */
function flash(kind, label) {
  if (cfg.instantReaction === false) return false;
  const spec = FLASH_SPEC[kind] || { cool: 60_000, weight: 3.0 };
  const now = Date.now();
  if (now - (flashKindAt[kind] || 0) < spec.cool) return false;
  // 全局最小间隔：两类事件前后脚到达时只留一个，避免连着说两句
  if (now - flashAt < 12_000) return false;
  flashKindAt[kind] = now;
  flashAt = now;
  senseCache.flash = {
    kind,
    label: String(label || '').slice(0, 60),
    at: now,
    weight: spec.weight,
  };
  diag(`flash: ${kind} ${label}`);
  return true;
}

/** 还没过期的即时事件（25 秒内）。 */
function freshFlash() {
  const f = senseCache.flash;
  if (!f) return null;
  if (Date.now() - f.at > 25_000) {
    senseCache.flash = null;
    return null;
  }
  return f;
}

/**
 * 扫一遍周围，产出**原始**注意点（还没去重、没算新奇度）。
 *
 * <p>纯本地计算，不调模型。`findBlocks` 只查一批"值得注意"的方块 id，
 * 不是遍历 33³ 的体积 —— 那会每秒几十毫秒地卡住子进程。</p>
 */
function rawAttentions() {
  if (!bot || !bot.entity) return [];
  const me = bot.entity.position;
  const radius = clamp(cfg.curiosityRadius, 6, 32);
  const out = [];

  const ids = interestingBlockIds();
  if (ids.length > 0) {
    const found = bot.findBlocks({ matching: ids, maxDistance: radius, count: 120 }) || [];
    for (const pos of found) {
      const b = bot.blockAt(pos);
      if (!b || !b.name) continue;
      const d = pos.distanceTo(me);
      /*
       * key **不带 kind 前缀** —— {@link classifyAttentions} 会拼成 `block:xxx`。
       * 两处都加前缀会长成 `block:block:chest`：能跑，但 seen 记录和日志都很难看。
       */
      const key = PLACE_KIND.test(b.name)
        ? `${b.name}@${Math.round(pos.x / 8)},${Math.round(pos.y / 8)},${Math.round(pos.z / 8)}`
        : b.name;
      /*
       * 稀有矿值得**立刻**开口（2026-11-05）：这类东西错过就没了，
       * 等 75 秒的思考间隔毫无意义。冷却由 flash 自己管（120 秒）。
       */
      if (d < 24 && /diamond_ore|emerald_ore|ancient_debris/.test(b.name)) {
        flash('rare', `附近有 ${blockLabel(b.name)}（${Math.round(d)} 格）`);
      }
      out.push({
        kind: 'block',
        key,
        label: b.name === 'lava' ? '岩浆（危险，别掉进去）' : blockLabel(b.name),
        dist: d,
        weight: blockWeight(b.name),
        /*
         * **必须带坐标**（2026-11-04 补）。
         *
         * 不给坐标的话，"看到钻石矿"就只是个感叹 —— 她没法写 [去 22 60 10]，
         * 只能干看着。这一条是"好奇心能落地"的关键，别省。
         */
        pos: { x: Math.round(pos.x), y: Math.round(pos.y), z: Math.round(pos.z) },
      });
    }
  }

  for (const e of Object.values(bot.entities || {})) {
    if (!e || e === bot.entity || !e.name) continue;
    let d = 0;
    try {
      d = e.position.distanceTo(me);
    } catch {
      continue;
    }
    if (d > 16) continue;
    const pos = { x: Math.round(e.position.x), y: Math.round(e.position.y), z: Math.round(e.position.z) };
    if (PASSIVE.test(String(e.name))) {
      out.push({
        kind: 'entity', key: String(e.name), label: `${e.name}（活的，可以看看）`, dist: d, weight: 1.6, pos,
      });
    } else if (e.name === 'item') {
      out.push({ kind: 'item', key: 'drop', label: '地上有个掉落物', dist: d, weight: 1.4, pos });
    }
  }

  const here = bot.blockAt(me);
  const biome = here && here.biome && here.biome.name;
  if (biome) {
    /*
     * 生物群系**不参与"想去看看"的排序**（`drive: false`）。
     *
     * 它是"发现"而不是"注意点"：说"你现在站在 plains"没有任何行动价值，
     * 但"第一次走到 cherry_grove"值得写进记忆。所以它只走发现日志那条路，
     * 不占 top3（否则她每次开场都会先宣布自己脚下是什么地形）。
     */
    out.push({
      kind: 'biome',
      key: String(biome),
      label: String(biome),
      dist: 0,
      weight: 3.2,
      drive: false,
    });
  }

  const tod = bot.time && typeof bot.time.timeOfDay === 'number' ? bot.time.timeOfDay : 0;
  if (tod > 11500 && tod < 13200) {
    out.push({ kind: 'time', key: 'dusk', label: '天快黑了', dist: 0, weight: 0.9 });
  }
  if (senseCache.social && Date.now() - senseCache.social.at < 5 * 60_000) {
    out.push({ kind: 'social', key: senseCache.social.name, label: `${senseCache.social.name} 上线了`, dist: 0, weight: 2.8 });
  }
  return out;
}

/**
 * 新奇度 × 稀有度 ÷ 距离 → 只留前 3。
 *
 * <p><b>纯函数</b>，不碰全局状态，便于单独验证（见 {@code methods.selftest}）。</p>
 *
 * @param {Array} raw   原始注意点
 * @param {Array} seen  已见过列表 `[{id, at}]`
 * @param {number} now  当前时间戳
 */
function classifyAttentions(raw, seen, now) {
  const seenSet = new Set((seen || []).map((s) => s && s.id).filter(Boolean));
  const best = new Map();
  for (const r of raw || []) {
    if (!r || !r.kind || !r.key) continue;
    if (r.drive === false) continue;   // 只记录、不驱动（见生物群系那条注释）
    const id = `${r.kind}:${r.key}`;
    /*
     * 只返回**没见过的**。
     *
     * 曾经的写法是"见过的降权到 0.22 继续参与排序"，结果她会在同一个
     * 生物群系上每两分钟感叹一次 —— 降权不等于闭嘴，而上下文里的重复
     * 会让她以为这是刚发生的事。
     */
    if (seenSet.has(id)) continue;
    const dist = Math.max(0, Number(r.dist) || 0);
    const score = (Number(r.weight) || 1) * (1 / (1 + dist / 12));
    const prev = best.get(id);
    if (!prev || score > prev.score) {
      best.set(id, { ...r, id, score });
    }
  }
  return [...best.values()].sort((a, b) => b.score - a.score).slice(0, 3);
}

function markSeen(list) {
  if (!list || list.length === 0) return;
  const m = readMind();
  const now = Date.now();
  for (const a of list) {
    m.seen.push({ id: a.id, at: now });
  }
  m.seen = m.seen.slice(-SEEN_MAX);
  saveMind();
}

// ---------------- 常驻需求（不是"新奇"，是"有用"） ----------------

/*
 * <p>只有"第一次见"的东西值得好奇，那她扫一遍之后就对整片草原失去兴趣了 ——
 * 这正是"看起来一动不动"的根源。真人不同：同一棵树看过一百次，但**天黑了没火把**、
 * **脚下有掉落物**、**有木头没工作台**这些事每次都会想起来。</p>
 *
 * <p>这类"需求"不走新奇度（不写 seen），只做**5 分钟节流**，避免同一条反复念。</p>
 */

const NEED_COOLDOWN = 5 * 60_000;
const needSurfaced = new Map();
/**
 * 她"开口要过"几次。
 *
 * <p>同一个需求提得越多，下次提的间隔越长（8 分钟 → 16 → 24 → 封顶 30）——
 * 真人要不到东西也不会每 5 分钟问一遍，那叫复读机。</p>
 */
const needAskCount = new Map();

/** 最近的敌对生物（判断"敢不敢打"用）。 */
function nearestHostile(maxDist = 10) {
  if (!bot || !bot.entity) return null;
  const me = bot.entity.position;
  let best = null;
  let bestD = maxDist;
  for (const e of Object.values(bot.entities || {})) {
    if (!e || e === bot.entity || !e.name) continue;
    if (!HOSTILE.test(String(e.name))) continue;
    let d = 0;
    try {
      d = e.position.distanceTo(me);
    } catch {
      continue;
    }
    if (d < bestD) {
      bestD = d;
      best = e;
    }
  }
  return best
    ? { name: String(best.name), dist: bestD, x: Math.round(best.position.x), y: Math.round(best.position.y), z: Math.round(best.position.z) }
    : null;
}

/** 身上有没有"能打的家伙"（剑/斧/弓）。 */
function hasWeapon() {
  const items = (bot && bot.inventory && bot.inventory.items()) || [];
  return items.some((i) => /sword|_axe|bow|crossbow|trident|mace/.test(i.name));
}

/** 最近的某类实体（掉落物等）。 */
function nearestEntityPos(re, maxDist) {
  if (!bot || !bot.entity) return null;
  const me = bot.entity.position;
  let best = null;
  let bestD = maxDist;
  for (const e of Object.values(bot.entities || {})) {
    if (!e || e === bot.entity || !e.name || !re.test(String(e.name))) continue;
    let d = 0;
    try {
      d = e.position.distanceTo(me);
    } catch {
      continue;
    }
    if (d < bestD) {
      bestD = d;
      best = e;
    }
  }
  return best
    ? {
      x: Math.round(best.position.x),
      y: Math.round(best.position.y),
      z: Math.round(best.position.z),
      dist: bestD,
    }
    : null;
}

/**
 * 这一轮"该做但还没做"的事，最多 2 条。
 *
 * <p>每条都带 `ask` 标记：</p>
 * <ul>
 *   <li>{@code ask: false} —— 她自己能解决（捡掉落物、自己吃东西、自己做工作台）；</li>
 *   <li>{@code ask: true} —— **必须向玩家开口**（要吃的、求帮忙打怪、要工具）。</li>
 * </ul>
 *
 * <p>这个区分是"她会不会提需求"的关键：不标的话模型只会闷头自己想办法，
 * 于是你看到她饿着肚子绕圈，而不是说一句"有吃的吗"。</p>
 */
function takeNeeds() {
  if (!bot || !bot.entity || cfg.curiosityEnabled === false) return [];
  const now = Date.now();
  const out = [];

  const push = (key, label, weight, pos, ask = false) => {
    /*
     * 要开口的事，重复提的间隔要拉长（8 → 16 → 24 → 30 分钟封顶）。
     * 真人要不到东西也不会每 5 分钟问一遍。
     */
    const asked = Number(needAskCount.get(key)) || 0;
    const cooldown = ask ? Math.min(30, 8 * Math.max(1, asked)) * 60_000 : NEED_COOLDOWN;
    if (now - (Number(needSurfaced.get(key)) || 0) < cooldown) return;
    out.push({ kind: 'need', key, id: `need:${key}`, label, dist: 0, weight, pos, ask });
  };

  const items = (bot.inventory && bot.inventory.items()) || [];
  const has = (re) => items.some((i) => re.test(i.name));
  const tod = bot.time && typeof bot.time.timeOfDay === 'number' ? bot.time.timeOfDay : 0;
  const canAsk = cfg.askForHelp !== false;

  // ---- 需要开口的 ----

  /*
   * 打不过的怪：**不是"看到怪就跑"，而是"看到怪喊人"**。
   * 判定"打不过"看三件事：血少、没武器、或者配置里根本没允许她打。
   */
  const foe = nearestHostile(10);
  if (foe) {
    const weak = (bot.health != null && bot.health < 14)
      || !hasWeapon()
      || cfg.allowCombat === false;
    if (weak) {
      push(
        'threat',
        `附近有 ${foe.name}（${Math.round(foe.dist)} 格），你打不过`,
        3.4,
        { x: foe.x, y: foe.y, z: foe.z },
        canAsk,
      );
    }
  }
  // 饿了但身上一点吃的都没有 → 只能开口要
  const hasFood = has(/bread|apple|cooked_|beef|porkchop|chicken|mutton|carrot|potato|fish|stew/);
  if (!hasFood && bot.food != null && bot.food < 12) {
    push('nofood', '饿了，身上一点吃的都没有', 2.9, undefined, canAsk);
  }
  // 想挖矿但没镐（手里连木镐都没有）
  if (!has(/_(pickaxe|axe|shovel|sword)$/) && bot.food != null && bot.food > 6) {
    push('notool', '身上没有工具，挖不了东西', 2.2, undefined, canAsk);
  }

  // ---- 自己能解决的 ----

  if (tod > 13000 && !has(/torch|lantern|campfire|glowstone|shroomlight/)) {
    push('dark', '天黑了，身上没有火把', 2.6);
  }
  const drop = nearestEntityPos(/^item$/, 8);
  if (drop) {
    push('drop', '地上有掉落物，可以捡起来', 2.4, { x: drop.x, y: drop.y, z: drop.z });
  }
  if (has(/_log$|_planks$/) && !has(/^(crafting_table|furnace|stick)$/)) {
    push('bench', '背包里有木头，还没做工作台', 2.0);
  }
  if (hasFood && bot.food != null && bot.food < 12) {
    push('hungry', '有点饿，背包里有吃的', 2.5);
  }
  if (hasFood && bot.health != null && bot.health < 12) {
    push('hurt', '血量偏低，背包里有吃的', 2.7);
  }

  for (const n of out) {
    needSurfaced.set(n.key, now);
    if (n.ask) {
      needAskCount.set(n.key, (Number(needAskCount.get(n.key)) || 0) + 1);
    }
  }
  return out.sort((a, b) => b.weight - a.weight).slice(0, 2);
}

/**
 * 取这一轮的注意点（**会消耗新奇度**：返回过就算"见过"）。
 *
 * <p>60 秒缓存：心跳每 30 秒跑一次，不缓存等于每 30 秒扫一遍世界。</p>
 */
function takeAttentions() {
  if (!cfg.curiosityEnabled) return [];
  if (!bot || !bot.entity) return [];
  const now = Date.now();
  if (senseCache.attentions && now - senseCache.at < 60_000) {
    return senseCache.attentions;
  }

  const raw = rawAttentions();
  const m = readMind();
  /*
   * 两类驱动合在一起（2026-11-04）：
   * ① `needs` —— 常驻需求（天黑了没火把、有掉落物、有木头没工作台…），**不吃新奇度**；
   * ② `novel` —— 没见过的方块/生物/掉落物，吃新奇度、12 小时只惊叹一次。
   * 需求排前面：它比"那边有朵花"更值得动。
   */
  const needs = takeNeeds();
  const novel = classifyAttentions(raw, m.seen, now);
  const list = [...needs, ...novel].slice(0, 3);
  senseCache.attentions = list;
  senseCache.at = now;

  /*
   * 新地形单独处理：它**不驱动行为**（不占 top3），但"第一次走到某地"
   * 值得写进记忆 —— QQ 那边能读到"她今天第一次去了樱花林"。
   */
  const bio = raw.find((r) => r.kind === 'biome');
  const bioId = bio ? `biome:${bio.key}` : '';
  if (bioId && !m.seen.some((s) => s.id === bioId)) {
    m.seen.push({ id: bioId, at: now });
    if (cfg.writeMemory) {
      note(`第一次走到 ${bio.key}`);
      highlight(`第一次到 ${bio.key}`);
    }
  }

  if (list.length === 0) {
    saveMind();
    return [];
  }

  // 只把"新奇"的写进 seen；需求靠 needSurfaced 的 5 分钟节流
  markSeen(novel);
  // 看到新东西会让好奇心升一点（这才是"被勾起来"）
  if (novel.length > 0) bumpCuriosity(0.05 * novel.length);
  return list;
}

/** 只读不消耗：闲聊时"顺口提一句刚看到的东西"用这个。 */
function peekAttentions() {
  if (!cfg.curiosityEnabled) return [];
  if (!senseCache.attentions) return [];
  if (Date.now() - senseCache.at > 10 * 60_000) return [];
  return senseCache.attentions;
}

function attentionLines(list, title = '【你注意到】') {
  if (!list || list.length === 0) return '';
  const parts = list.map((a) => {
    const bits = [];
    if (a.dist >= 2) bits.push(`${Math.round(a.dist)} 格`);
    if (a.pos) bits.push(`坐标 ${a.pos.x} ${a.pos.y} ${a.pos.z}`);
    return `· ${a.label}${bits.length ? `（${bits.join('，')}）` : ''}`;
  });
  return `${title}\n${parts.join('\n')}`;
}

function curiosityLine() {
  const c = readMind().curiosity;
  if (c >= 0.75) return '【你的好奇心】很高 —— 坐不住，很想去看点什么。';
  if (c >= 0.55) return '【你的好奇心】有点高，想去看看。';
  if (c <= 0.2) return '【你的好奇心】很低，什么都不想动。';
  return '';
}

function intentionsBlock() {
  const list = readMind().intentions;
  if (list.length === 0) return '';
  const now = Date.now();
  const lines = list.slice(0, INTENT_MAX).map((i) => {
    const mins = Math.max(1, Math.round((now - (Number(i.at) || now)) / 60000));
    return `· ${i.text}（${mins} 分钟前你自己说的，还没做）`;
  });
  return `【你自己说过想做的事】\n${lines.join('\n')}`;
}

function addIntent(text) {
  const t = String(text || '').replace(/\s+/g, ' ').trim().slice(0, 60);
  if (!t) return '想做什么？（例如 [想做 去那个山洞看看]）';
  const m = readMind();
  const now = Date.now();
  m.intentions.push({ text: t, at: now, expiresAt: now + clamp(cfg.intentionHours, 1, 24) * 3600_000 });
  m.intentions = m.intentions.slice(-INTENT_MAX);
  m.curiosity = clamp(m.curiosity - 0.1, 0, 1);   // 有了计划，急迫感降一点
  recordIdea(t);                                   // 同时进"念头池"（2026-11-05）
  saveMind();
  return `记下了：${t}`;
}

// ---------------- 灵感涌现（2026-11-05） ----------------

/*
 * <h3>为什么不能由代码写死"种地 / 盖房"</h3>
 *
 * <p>只要代码里列了 `if (空地) wantFarm()`，她的想法就永远只有那几种 —— 那是行为树，
 * 不是灵感。**念头的内容必须由模型在拿到素材后自己冒出来**，代码只负责三件事：</p>
 *
 * <ol>
 *   <li><b>什么时候可能冒出</b>：张力（无聊 / 好奇 / 有没做完的事）× 随机扰动，
 *       而不是"每 15 分钟问一次"。所以它是**不规则**的；</li>
 *   <li><b>给它什么素材</b>：最近做了什么、周围有什么、手上有啥、以前想到过什么 ——
 *       素材越具体，念头越像"就地取材"，而不是空泛的"我想去冒险"；</li>
 *   <li><b>记住它</b>：念头池（会过期、会完成、会放弃）—— 否则每次都是全新的一闪。</li>
 * </ol>
 *
 * <p>注意：**不列举具体想法**。提示词里给的是"可以想任何事"和几类素材，
 * 一旦写成"想种地/想盖房"的清单，它立刻退化成死行为。</p>
 */

let lastInspireAt = 0;

/** 张力：越久没人理、越好奇、手上越有没做完的事，越容易走神。 */
function inspirationTension() {
  const m = readMind();
  const idleMin = (Date.now() - (lastActivityAt || Date.now())) / 60000;
  let t = 0;
  t += Math.min(1, idleMin / 40) * 0.4;
  t += Math.min(1, m.curiosity) * 0.3;
  t += Math.min(1, m.intentions.length / 3) * 0.2;
  const tod = bot && bot.time && typeof bot.time.timeOfDay === 'number' ? bot.time.timeOfDay : 0;
  if (tod > 13000) {
    t += 0.05;   // 夜里更容易胡思乱想
  }
  return clamp(t, 0, 1);
}

/** 记一个念头（同一句话不重复记）。 */
function recordIdea(text) {
  const t = String(text || '').replace(/\s+/g, ' ').trim().slice(0, 60);
  if (!t) return;
  const m = readMind();
  if (!Array.isArray(m.ideas)) m.ideas = [];
  if (m.ideas.some((i) => i && i.text === t)) return;
  m.ideas.push({ text: t, at: Date.now() });
  // 只留最近 8 条、7 天内的 —— 念头不是账本，旧了就该淡忘
  const cutoff = Date.now() - 7 * 86400_000;
  m.ideas = m.ideas.filter((i) => Number(i.at) > cutoff).slice(-8);
  saveMind();
}

/** 念头池（给提示词看）。 */
function ideaBlock() {
  const m = readMind();
  const list = (m.ideas || []).slice(-5);
  if (list.length === 0) return '';
  const now = Date.now();
  const lines = list.map((i) => {
    const mins = Math.max(1, Math.round((now - (Number(i.at) || now)) / 60000));
    return `· ${i.text}（${mins} 分钟前想到的）`;
  });
  return `【你以前冒出来过的念头】\n${lines.join('\n')}\n（还想做就接着做；忘了也无所谓。）`;
}

/** 「突然想到点什么」这一轮的系统提示。 */
function inspirationPrompt() {
  const parts = ['【系统提示 · 不是玩家说的】你在游戏里，没人跟你说话，也没什么事非做不可。'];
  parts.push(observeLine());

  const recent = readMemoryTail(320, '', { dropChat: true });
  if (recent) {
    parts.push(`【你刚才在做什么】\n${recent}`);
  }
  const ideas = ideaBlock();
  if (ideas) parts.push(ideas);

  parts.push(
    '现在可以**随便冒出一个念头** —— 想干什么完全由你决定，不用有用、不用合理，'
    + '也不用跟眼前的东西有关。盖点什么、弄块地、沿着水走、给谁留个牌子、'
    + '把东西堆整齐、找个高地方看日落……都行（这些只是例子，别照着抄）。\n'
    + '规则：① 先用一句说出来（"我想……"），别解释理由；'
    + '② 只是想想，就写 [想做 那句话]；'
    + '③ **真想动手做的**，写一个计划块（下面有格式）—— 你会按顺序自己做，不用一句一句问我；'
    + '④ 什么都不想干就回 [SILENT]。',
  );

  /*
   * 计划块格式（2026-11-05）：让她把"想法"变成可执行的链。
   * 刻意复用现有的动作语法（不引入第二套 JSON），这样解析器和执行器都不用改。
   */
  parts.push(
    '【计划怎么写】想认真做一件事时，用这个格式（最多 '
    + clamp(cfg.planMaxSteps, 3, 30) + ' 步，每步只写一个动作）：\n'
    + '[计划 种一小块小麦]\n'
    + '1. [合成 wooden_hoe 1]\n'
    + '2. [挖 grass_block 6]\n'
    + '3. [捡]\n'
    + '[/计划]\n'
    + '注意：① 前几步要**准备工具和材料**（做镐/做锄/砍树），别一上来就"盖房子"；'
    + '② 每步都必须是你会做的动作，做不到的别写；'
    + '③ 计划写完就不用再重复说，我这边会自动按顺序做；'
    + '④ 只是想试试、不打算真做完，就别写计划块。',
  );
  return parts.join('\n\n');
}

/**
 * 有机会就冒一个念头。
 *
 * <p>两道闸：**冷却**（默认 25 分钟 ±40%，所以间隔是不规则的）和**概率**（由张力决定）。
 * 两者相乘的结果是"平均一两个小时一次，但发生时机说不准" —— 这才像走神。</p>
 */
async function maybeInspire() {
  if (!cfg.enabled || cfg.inspirationEnabled === false) return false;
  if (!bot || !bot.entity || busy) return false;

  const now = Date.now();
  const gap = clamp(cfg.inspirationGapMinutes, 5, 240) * 60_000 * (0.6 + Math.random() * 0.8);
  if (now - lastInspireAt < gap) return false;

  const tension = inspirationTension();
  const p = 0.04 + tension * 0.22;
  if (Math.random() > p) return false;

  lastInspireAt = now;
  diag(`inspire: 冒出念头 tension=${tension.toFixed(2)} p=${p.toFixed(2)}`);
  await handleTurn(inspirationPrompt(), { autonomy: true, canAct: true });
  return true;
}

// ------------------------------------------------------------------ 行为链（2026-11-05）

/*
 * <h3>灵感 → 计划 → 执行</h3>
 *
 * <p>光有"我想种块地"没用，得拆成动作链并真的做完。设计只有一条原则：
 * **计划由模型出，执行不花 token。**</p>
 *
 * <ul>
 *   <li>计划就是文本里的一个块：`[计划 标题] 1. [动作] 2. [动作] [/计划]`
 *       —— 复用已有动作语法，不引入第二套 JSON 协议；</li>
 *   <li>执行器逐步调 {@link runAction}，每步本地跑；</li>
 *   <li>失败先重试，重试用完**才问模型一次**要不要改计划（每份计划只修一次，
 *       否则会陷入"计划→失败→再计划"的死循环）；</li>
 *   <li>聊天/断线/死亡 → **暂停**而不是丢弃，恢复后从断点接着走。</li>
 * </ul>
 */

/** 哪些结果算"这一步没成"。宁可多判一次失败，也别假装做完了。 */
const PLAN_FAIL = /失败|没找到|没看到|做不了|放不上去|不知道|不认识|超时|捡不到|不在游戏|背包里没有|没有可依托/;

function plansPath() {
  return path.join(api.dataDir, 'plans.json');
}

let plansCache = null;

function readPlans() {
  if (plansCache) return plansCache;
  const raw = readJsonFile(plansPath(), { plans: [] });
  plansCache = { plans: Array.isArray(raw.plans) ? raw.plans.filter((p) => p && p.title) : [] };
  return plansCache;
}

function savePlans() {
  if (!plansCache) return;
  writeJsonFile(plansPath(), plansCache);
}

/** 当前在跑（或暂停中）的计划。 */
function activePlan() {
  const { plans } = readPlans();
  return plans.find((p) => p && (p.status === 'running'
    || p.status === 'paused' || p.status === 'waiting')) || null;
}

/**
 * 从模型输出里抠出计划块。
 *
 * @returns {{title:string, steps:string[]}|null}
 */
function parsePlanBlock(text) {
  const m = String(text || '').match(/\[计划\s*([^\]\n]{0,60})\]([\s\S]*?)\[\/计划\]/);
  if (!m) return null;
  const title = (m[1] || '').trim().slice(0, 40) || '一件事';
  const steps = [];
  const re = /\[([^[\]\n]{1,80})\]/g;
  let mm;
  while ((mm = re.exec(m[2])) !== null) {
    let inner = String(mm[1] || '').trim();
    if (!inner || /^\/?计划/.test(inner)) continue;
    inner = inner.replace(/^\d+[.、)）]\s*/, '');
    steps.push(inner);
  }
  if (steps.length === 0) return null;
  return { title, steps: steps.slice(0, clamp(cfg.planMaxSteps, 3, 30)) };
}

/** 去掉计划块（它里面的动作不该被当成本轮立刻执行的动作）。 */
function stripPlanBlock(text) {
  return String(text || '').replace(/\[计划\s*[^\]\n]{0,60}\][\s\S]*?\[\/计划\]/g, ' ');
}

/** 给提示词看："你正在做的一件事"。 */
function planBlock() {
  const p = activePlan();
  if (!p) return '';
  const next = p.steps[p.step] || '';
  const goal = p.goal ? `（他让你：${p.goal}）` : '';
  return `【你正在做的一件事】${p.title}${goal}（第 ${p.step + 1}/${p.steps.length} 步`
    + `${next ? `，下一步：${next}` : ''}）\n（正在按顺序自动做，不用重复；不想做了就说 [停]。）`;
}

let planRunning = false;

/** 计划里有没有她自己写的台词。 */
function planHasSay(plan) {
  return (plan.steps || []).some((s) => /^(说|say)\b/i.test(String(s)));
}

/** 没写台词时，在关键节点补的一句话（按动作类型，别每步都念）。 */
const NARRATE = {
  craft: '做好了',
  give: '给你',
  mine: '弄到点了',
  place: '放好了',
  pickup: '捡回来了',
};

/**
 * 一件事做完了，问她"还有下一半吗"。
 *
 * <p>这是"跨计划连续"的关键：没有它，`给他做把斧头` 做完就结束，
 * 玩家说"那我还要盖房呢"她才会开始第二件事。</p>
 */
async function continueGoal(plan) {
  if (busy || !bot || !bot.entity || !stats.connected) return;
  const left = Math.max(0, (Number(plan.chainLeft) || 0) - 1);
  const prompt = [
    '【系统提示 · 不是玩家说的】你刚把一件事做完了。',
    `刚做完：${plan.title}${plan.goal ? `（他让你：${plan.goal}）` : ''}`,
    '如果这件事还有下一半（答应他的事没完、材料还差、房子才刚起了个头），'
    + '就写一个新的计划块接着做；彻底完事、或者该等他决定，就回 [SILENT]。',
    '别重复刚做完的事，也别为了有事做而硬编一个计划。',
  ].join('\n');
  try {
    const ans = await askPlatform(prompt, buildInject({}));
    const np = parsePlanBlock(ans);
    if (!np) {
      diag('plan chain: 没有后续，停下等人');
      return;
    }
    diag(`plan chain: 继续「${np.title}」（还能自动接 ${left} 次）`);
    startPlanFromModel(np, plan.goal, { from: plan.requester }, { chainLeft: left });
  } catch (e) {
    diag(`plan chain 失败：${e.message}`);
  }
}

/** 把模型给的计划块变成一份可执行的计划，并排进执行器。 */
function startPlanFromModel(parsed, goalText = '', ctx0 = {}, opts = {}) {
  if (!parsed || parsed.steps.length === 0) return;
  const st = readPlans();
  const plan = {
    id: Date.now().toString(36),
    title: parsed.title,
    /*
     * 记下**玩家原话**（2026-11-05）。
     * 这是"她到底在为我做哪件事"的唯一凭据：日志、面板、断点恢复都能对上，
     * 也让"你说的话 → 她做的事"之间有一条可查的线。
     */
    goal: String(goalText || '').replace(/\s+/g, ' ').slice(0, 80),
    /*
     * 记下**谁让她做的**（2026-11-05）。
     *
     * <p>计划里的 `[给你 xxx]` 走的是"给当前说话的人"，而计划执行时没有"当前说话的人"，
     * 于是 `from` 被填成了她自己的名字 —— 表现是她把东西丢给自己。
     * 所以创建计划时把请求者存下来，执行时用它。</p>
     */
    requester: String((ctx0 && ctx0.from) || '').slice(0, 20),
    /** 还能自动接几次后续计划（防止她无限给自己派活）。 */
    chainLeft: Number.isFinite(Number(opts.chainLeft))
      ? Number(opts.chainLeft)
      : clamp(cfg.planChainMax, 0, 5),
    steps: parsed.steps,
    step: 0,
    tries: 0,
    status: 'running',
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  // 只留最近 3 份（做完/失败的自动清掉），免得 plans.json 越滚越大
  st.plans = [...st.plans.filter((p) => p && p.status !== 'done' && p.status !== 'failed'), plan]
    .slice(-3);
  savePlans();
  note(`（计划）决定做「${plan.title}」：${plan.steps.length} 步`);
  diag(`plan: 收到「${plan.title}」${plan.steps.length} 步`);
  setTimeout(() => {
    void runPlan(plan);
  }, 1500);
}

/**
 * 逐步执行计划。
 *
 * <p>不返回"成功/失败"给模型 —— 做完或放弃会写进【刚才】，
 * 下一轮她自己就会提。这样中途完全不用调模型。</p>
 */
async function runPlan(plan) {
  if (!plan || planRunning) return;
  planRunning = true;
  plan.status = 'running';
  plan.updatedAt = Date.now();
  savePlans();
  diag(`plan: 开始「${plan.title}」（${plan.steps.length} 步）`);

  try {
    while (plan.step < plan.steps.length) {
      if (!cfg.enabled || !stats.connected || !bot || !bot.entity) {
        plan.status = 'paused';
        savePlans();
        diag(`plan: 暂停「${plan.title}」（离线）`);
        return;
      }
      // 聊天中 / 有别的动作在跑 → 让路，别抢 pathfinder
      if (busy) {
        await sleep(1500);
        continue;
      }

      const raw = plan.steps[plan.step];
      const hit = matchActionVerb(raw);
      if (!hit) {
        diag(`plan: 第 ${plan.step + 1} 步认不出，跳过：${raw}`);
        plan.step++;
        savePlans();
        continue;
      }

      const r = await runAction(
        { verb: hit.verb, args: hit.args, raw: `[${raw}]` },
        // 「你」指**让做这件事的人**，不是她自己
        { from: plan.requester || '', canAct: true },
      );
      const text = String(r || '');

      if (PLAN_FAIL.test(text)) {
        plan.tries = (Number(plan.tries) || 0) + 1;
        if (plan.tries <= clamp(cfg.planRetry, 0, 3)) {
          diag(`plan: 第 ${plan.step + 1} 步没成，重试 ${plan.tries}：${text}`);
          await sleep(1200);
          continue;
        }
        // 重试用完：问模型一次要不要改计划（每份计划只修一次）
        if (cfg.planRepair !== false && !plan.repaired) {
          plan.repaired = true;
          savePlans();
          const fixed = await repairPlan(plan, text);
          if (fixed) continue;
        }
        /*
         * 三级降级的第②级（2026-11-05）：改不动了就**开口问他**。
         * 这比"静默失败"好得多 —— 用户至少知道她在等什么。
         */
        if (await maybeAskHelp(plan, text)) {
          diag(`plan: 进入等待（等他回应）「${plan.title}」`);
          return;
        }

        /*
         * 求助开关关掉时也**必须出声**（2026-11-05）。
         * 原来这里直接标 failed 走人 —— 玩家那边一片安静，
         * 只能看到"她突然不说话了"，这比做错更难受。
         */
        await say(`${plan.title}没做成，${String(text).slice(0, 18)}，先停一下`);

        plan.status = 'failed';
        plan.updatedAt = Date.now();
        savePlans();
        note(`计划「${plan.title}」卡在第 ${plan.step + 1} 步：${text.slice(0, 40)}`);
        session.lastResults.push(`「${plan.title}」没做完（${text.slice(0, 30)}）`);
        diag(`plan: 放弃「${plan.title}」`);
        return;
      }

      plan.step++;
      plan.tries = 0;
      plan.updatedAt = Date.now();
      savePlans();
      note(`（计划）${plan.title} ${plan.step}/${plan.steps.length}：${raw.slice(0, 40)}`);
      session.lastResults.push(`「${plan.title}」第 ${plan.step} 步：${text.slice(0, 40)}`);

      /*
       * 没写台词的计划，在**产出型节点**补一句（2026-11-05）。
       *
       * <p>只在"合成了 / 挖到了 / 给出去了"这种有结果的步骤上说，
       * 移动和等待不吭声 —— 否则就变成每两秒播报一次的导航仪。</p>
       */
      if (!planHasSay(plan) && (Number(plan.narrated) || 0) < 2) {
        const line = NARRATE[hit.verb];
        if (line) {
          plan.narrated = (Number(plan.narrated) || 0) + 1;
          await say(line);
        }
      }
    }

    plan.status = 'done';
    plan.updatedAt = Date.now();
    savePlans();
    /*
     * 收尾要出声（2026-11-05）。
     *
     * <p>计划里如果她自己写了 `[说 …]`，就以她的话为准；一行都没写的话，
     * 这里补一句「XX 弄好了」—— 否则整套动作做完是**静默**的，
     * 玩家只看到她突然停下，不知道成没成。</p>
     */
    const hadSay = (plan.steps || []).some((s) => /^(说|say)\b/i.test(String(s)));
    if (!hadSay) {
      await say(`${plan.title}弄好了`);
    }
    note(`计划「${plan.title}」做完了`);
    session.lastResults.push(`你刚把「${plan.title}」做完了`);
    diag(`plan: 完成「${plan.title}」`);

    /*
     * 跨计划的连续目标（2026-11-05）。
     *
     * <p>一件事做完就停，是"她只会做我让她做的那一步"的根源。
     * 这里在完成后再问一次模型"还有下一半吗"：有就接着写新计划自动跑，
     * 没有就静默停下。`chainLeft` 限制自我延续的层数，防止她无限给自己派活。</p>
     */
    if (cfg.planChain !== false && (Number(plan.chainLeft) || 0) > 0) {
      await continueGoal(plan);
    }
  } catch (e) {
    plan.status = 'paused';
    savePlans();
    diag(`plan 异常：${e.message}`);
  } finally {
    planRunning = false;
  }
}

/** 卡住时问模型一次：剩下的步骤怎么改。改不动就算了，别死磕。 */
async function repairPlan(plan, failText) {
  const left = plan.steps.slice(plan.step).map((s, i) => `${i + 1}. [${s}]`).join('\n');
  const prompt = [
    '【系统提示 · 不是玩家说的】你正在做一件事，但卡住了。',
    `目标：${plan.title}`,
    `卡住的那一步：[${plan.steps[plan.step]}] —— ${String(failText).slice(0, 60)}`,
    `剩下的步骤：\n${left}`,
    '',
    '请**改写剩下的步骤**（换材料、换工具、砍掉做不到的），只输出新的计划块：',
    '[计划 标题] 1. [动作] 2. [动作] [/计划]',
    '实在做不了就只回 [放弃]。',
  ].join('\n');
  try {
    const ans = await askPlatform(prompt, buildInject({}));
    if (/\[放弃\]/.test(String(ans || ''))) {
      diag('plan: 模型认为做不下去');
      return false;
    }
    const np = parsePlanBlock(ans);
    if (!np || np.steps.length === 0) return false;

    /*
     * 去重（2026-11-05）：模型经常**把整份计划原样返回**，包括已经做完的步骤。
     * 直接拼接会让"说 我去那边找找"这种步骤再跑一遍，玩家看到她重复念叨同一句。
     * 所以先把"与已执行步骤相同"的头部砍掉。
     */
    const done = plan.steps.slice(0, plan.step).map((s) => String(s).trim());
    let fresh = np.steps.map((s) => String(s).trim());
    while (fresh.length > 0 && done.includes(fresh[0])) fresh.shift();
    if (fresh.length === 0) {
      diag('plan: 修正后的计划与已做的完全一样，放弃');
      return false;
    }
    plan.steps = [...plan.steps.slice(0, plan.step), ...fresh];
    plan.updatedAt = Date.now();
    savePlans();
    diag(`plan: 修正为 ${plan.steps.length} 步（新增 ${fresh.length}）`);
    return true;
  } catch (e) {
    diag(`plan 修正失败：${e.message}`);
    return false;
  }
}

// ---------------- 卡住了就开口（2026-11-05） ----------------

/*
 * <h3>为什么"失败就静默放弃"是最糟的处理</h3>
 *
 * <p>用户看到的是"她突然站着不动了"，而实际上她卡住了。真人卡住会说话：
 * 「锄头差两个木头，你有吗」「那边是别人的地，我不敢动」。</p>
 *
 * <p>三级降级：</p>
 * <ol>
 *   <li><b>自己能换路</b> → 改计划（{@link repairPlan}，一次）；</li>
 *   <li><b>需要玩家的资源/权限</b> → **开口求助**（本节），然后计划进入 waiting，
 *       **不再硬试**；</li>
 *   <li><b>环境不允许</b>（没水/没矿/天黑了）→ 报告 + 放弃，记流水。</li>
 * </ol>
 *
 * <p>防唠叨：同一句求助 30 分钟内不重复；玩家一说话就视为"有着落了"，
 * 计划自动从断点恢复。</p>
 */

const REQUEST_TTL_MS = 30 * 60_000;

function requestsPath() {
  return path.join(api.dataDir, 'requests.jsonl');
}

/** 本地粗判"她缺什么"—— 只是给提示词一个锚，不用准。 */
function describeNeed(plan, failText) {
  const t = String(failText || '');
  const bag = t.match(/背包里没有\s*([a-z_]+)/i);
  if (bag) return bag[1];
  if (/不认识方块|没有工具|缺材料|做不了/.test(t)) return '工具或材料';
  if (/没有可依托|放不上去/.test(t)) return '一块平整的地方';
  if (/水|岩浆/.test(t)) return '水或者路';
  return '搭把手';
}

function readRequests(limit = 20) {
  try {
    return fs.readFileSync(requestsPath(), 'utf8')
      .split('\n')
      .filter(Boolean)
      .slice(-limit)
      .map((l) => {
        try {
          return JSON.parse(l);
        } catch {
          return null;
        }
      })
      .filter(Boolean);
  } catch {
    return [];
  }
}

function appendRequest(rec) {
  try {
    fs.appendFileSync(requestsPath(), `${JSON.stringify(rec)}\n`, 'utf8');
  } catch (e) {
    diag(`写 requests 失败：${e.message}`);
  }
}

/** 同一件事 30 分钟内提过就不再说 —— 复读比不求助更烦人。 */
function recentlyAsked(need) {
  const now = Date.now();
  return readRequests().some((r) => r && r.need === need
    && now - (Number(r.at) || 0) < REQUEST_TTL_MS);
}

/**
 * 计划卡住时开口求助。
 *
 * @returns {boolean} 是否真的说了
 */
async function maybeAskHelp(plan, failText) {
  if (cfg.planAskHelp === false || !plan) return false;
  const need = describeNeed(plan, failText);
  if (recentlyAsked(need)) {
    diag(`plan: 「${need}」30 分钟内要过，这次不重复`);
    plan.status = 'waiting';
    plan.askedAt = Date.now();
    savePlans();
    return false;
  }

  const prompt = [
    '【系统提示 · 不是玩家说的】你正在做一件事，卡住了。',
    `你想做的事：${plan.title}`,
    `卡在第 ${plan.step + 1} 步：[${plan.steps[plan.step]}]`,
    `系统的说法是：${String(failText).slice(0, 80)}`,
    `你手上大概缺：${need}`,
    '',
    '现在跟他说一句 —— 要具体：**卡在哪、需要什么、要不要他过来**。',
    '规则：① 只发一句，短，口语；② 别说"我遇到困难了"这种空话；',
    '③ 不要道歉，不要解释系统；④ 他给不给都行，别催。',
  ].join('\n');

  let line = '';
  try {
    line = String(await askPlatform(prompt, buildInject({})) || '').trim();
  } catch (e) {
    diag(`求助生成失败：${e.message}`);
  }
  /*
   * 兜底清洗（2026-11-05）：模型偶尔会把计划块/动作一起吐出来，
   * 直接说出来等于当着玩家念代码。带方括号的一律作废，用模板。
   */
  if (!line || line.includes('[SILENT]') || /[[\]]/.test(line)) {
    line = `${plan.title}卡住了，缺${need}，你有吗`;
  }
  line = line.split('\n').filter((s) => s.trim()).slice(0, 2).join(' ').slice(0, 60);

  const said = await say(line);
  appendRequest({
    at: Date.now(),
    kind: 'plan',
    planId: plan.id,
    title: plan.title,
    need,
    text: line,
    said,
    status: 'pending',
  });
  plan.status = 'waiting';
  plan.askedAt = Date.now();
  savePlans();
  note(`（卡住了）跟他说：${line}`);
  session.lastResults.push(`你卡住了，跟他说「${line}」`);
  diag(`plan: 求助「${line}」`);
  return true;
}

/**
 * 玩家说话了 → 视为"求助有着落"，把等待中的计划接着做。
 *
 * <p>不检查他是否真给了东西 —— 真人也不会核对，先干起来再说；
 * 真不行会再次卡住、再问一次（30 分钟后）。</p>
 */
function resumeWaitingPlan() {
  const p = activePlan();
  if (!p || p.status !== 'waiting') return;
  p.status = 'running';
  p.tries = 0;
  p.repaired = false;   // 求助之后允许再修一次
  p.updatedAt = Date.now();
  savePlans();
  diag(`plan: 他说话了，继续「${p.title}」`);
  setTimeout(() => {
    void runPlan(p);
  }, 2500);
}

/** 进服后接着做没做完的事（断线/重连都靠它）。 */
function resumePlanIfAny() {
  if (cfg.planEnabled === false) return;
  const p = activePlan();
  if (!p) return;
  if (p.status === 'running') p.status = 'paused';
  diag(`plan: 恢复「${p.title}」从第 ${p.step + 1} 步`);
  void runPlan(p);
}

function clearIntents() {
  const m = readMind();
  const n = m.intentions.length;
  m.intentions = [];
  m.curiosity = clamp(m.curiosity - 0.15, 0, 1);
  saveMind();
  return n > 0 ? '不想了' : '本来也没什么打算';
}

// ------------------------------------------------------------------ 知识库（2026-11-04）

/*
 * <h3>为什么不把方块/生物资料写进代码</h3>
 *
 * <p>写死的东西永远是"昨天的 Minecraft"：新版本加一种怪、改一个合成表，
 * 插件就得跟着发版。而平台已经有知识库 + 混合检索，用户自己传一份 wiki 进去
 * 就能覆盖所有方块/物品/生物/怪物 —— 这才是"资料"该待的地方。</p>
 *
 * <h3>两条读取路径，各管一半</h3>
 * <ol>
 *   <li><b>自动检索</b>（`context.useRag`）：玩家说的话就是检索词，
 *       平台把命中片段拼进系统提示词。她回答"钻石矿怎么挖"靠这条；</li>
 *   <li><b>主动查</b>（本节的 {@link knowledgeFor}）：她**看到**不认识的方块/生物时，
 *       插件拿名字去查平台 `search` 工具，把结果塞进这一轮的上下文。
 *       这条是"好奇心"能落地的关键 —— 否则她看见僵尸只知道有个实体叫 zombie。</li>
 * </ol>
 *
 * <p><b>只在绑定了知识库时才生效</b>：平台侧解析不到 kbIds 会直接返回 null，
 * 所以没挂知识库时这两条路都是零成本的空操作，不会报错。</p>
 */

/** 查过的东西缓存多久（知识库内容不会秒变，但也不该永不过期）。 */
const KB_TTL_MS = 24 * 3600_000;
/** 缓存最多留多少条（一个存档玩几个月也就见过百来种东西）。 */
const KB_MAX = 120;

function kbPath() {
  return path.join(api.dataDir, 'knowledge-cache.json');
}

let kbCacheMemory = null;

function readKbCache() {
  if (kbCacheMemory) return kbCacheMemory;
  const raw = readJsonFile(kbPath(), {});
  kbCacheMemory = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  return kbCacheMemory;
}

function saveKbCache() {
  if (!kbCacheMemory) return;
  const now = Date.now();
  const entries = Object.entries(kbCacheMemory)
    .filter(([, v]) => v && v.text && now - (Number(v.at) || 0) < KB_TTL_MS)
    .sort((a, b) => (Number(b[1].at) || 0) - (Number(a[1].at) || 0))
    .slice(0, KB_MAX);
  kbCacheMemory = Object.fromEntries(entries);
  writeJsonFile(kbPath(), kbCacheMemory);
}

/** `search` 工具的 output 有两种形态（数组 / JSON 字符串），统一压成一段纯文本。 */
function kbTextOf(output) {
  let arr = [];
  if (Array.isArray(output)) {
    arr = output;
  } else if (typeof output === 'string') {
    try {
      const parsed = JSON.parse(output);
      if (Array.isArray(parsed)) arr = parsed;
    } catch {
      /* 就是纯文本 */
    }
  }
  const texts = arr.map((x) => (x && (x.content || x.text)) || '').filter(Boolean);
  const raw = texts.length > 0 ? texts.join(' ') : (typeof output === 'string' ? output : '');
  return String(raw)
    // 知识库原文带 Markdown：她不需要 `#` `*`，段落压成一行更省 token
    .replace(/[#*`>|]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 220);
}

/**
 * 调平台的 `search` 工具检索知识库（**不经过模型**）。
 *
 * <p>走 `POST /api/v1/tools/search/invoke`，和用户在工具页点"试跑"是同一条路：
 * 鉴权、审计、截断全都经过，插件没有额外越权。知识库范围留空 = 全部。</p>
 */
async function searchKb(query) {
  const q = String(query || '').trim();
  if (!q) return '';
  if (!api || !api.tools || typeof api.tools.execute !== 'function') {
    diag('kb: api.tools 不可用（pluginRuntime 版本过旧？）');
    return '';
  }
  try {
    const r = await api.tools.execute('search', { query: q });
    if (!r || r.success === false) {
      diag(`kb search failed: ${(r && r.error) || '空结果'}`);
      return '';
    }
    return kbTextOf(r.output);
  } catch (e) {
    diag(`kb search error: ${e.message}`);
    return '';
  }
}

/**
 * 给这一轮的注意点补上"她查到的东西"。
 *
 * <p>查过就缓存，所以同一个僵尸只查一次；失败静默降级（没有知识库也能正常玩）。</p>
 */
async function knowledgeFor(attentions) {
  if (cfg.kbLookup === false) return '';
  const list = (attentions || []).filter((a) => a && ['block', 'entity', 'item'].includes(a.kind));
  if (list.length === 0) return '';

  const cache = readKbCache();
  const picked = list.slice(0, clamp(cfg.kbLookupMax, 1, 4));
  const lines = [];
  let used = 0;

  for (const a of picked) {
    const hit = cache[a.id];
    if (hit && hit.text && Date.now() - (Number(hit.at) || 0) < KB_TTL_MS) {
      lines.push(`· ${a.label}：${hit.text}`);
      used++;
      continue;
    }
    /*
     * 检索词用**英文 id + 中文名**：wiki 里两种写法都有，
     * 只给中文时，"钻石矿"（我的译名）可能和原文"钻石矿石"对不上。
     */
    const q = a.kind === 'entity'
      ? `我的世界 ${a.key} 是什么生物 会不会攻击人`
      : `我的世界 ${a.key} ${blockLabel(a.key)} 是什么 有什么用 怎么获得`;
    const text = await searchKb(q);
    if (!text) continue;
    cache[a.id] = { text, at: Date.now() };
    lines.push(`· ${a.label}：${text}`);
    used++;
  }
  saveKbCache();

  if (used === 0) return '';
  return `【你查到的】\n${lines.join('\n')}\n`
    + '（这些是资料，用你自己的话说；别照念，也别提"资料"两个字。）';
}

// ------------------------------------------------------------------ 活力（2026-11-04）

/*
 * <h3>这一层解决什么</h3>
 *
 * <p>原来的自主是"每 15 分钟醒一次，醒来说一句或走两步"，中间十几分钟完全静止。
 * 真人不是这样的 —— 真人一直在**小动作**里：挪两步、转个身看你、跟过来、跳一下。
 * 那些"像真人"的 bot，绝大部分时间花在这种零成本的琐碎动作上，而不是频繁思考。</p>
 *
 * <p>所以这里把"动"和"想"彻底分开：</p>
 * <ul>
 *   <li><b>动</b>（本节）：每 4 秒看一眼，闲着就自己挪/看你/跟过来。**不调模型、不花 token**；</li>
 *   <li><b>想</b>（{@link tickAutonomy}）：只在她看到新东西、有打算、或闷的时候才思考。</li>
 * </ul>
 *
 * <p><b>安全边界</b>：闲逛用的 Movments 关掉了 `canDig` / `canPlaceBlocks` ——
 * 否则"随便走走"会把她自己埋进洞里，或者把你的房子拆掉。</p>
 */

let ambientTimer = null;
/** 上次"动一下"的时间。 */
let lastLocalMoveAt = 0;
/** `[停]` 之后的一段时间不自动跟人/乱走（尊重她的决定）。 */
let ambientHoldUntil = 0;
/** 当前自动跟随的人 —— 防止每 4 秒重复 setGoal 把寻路算炸。 */
let ambientFollowWho = '';

/** 附近的白名单玩家（她只对"能指挥她的人"有反应）。 */
function nearestAllowedPlayer(maxDist = 16) {
  if (!bot || !bot.entity) return null;
  const allowed = parseNames(cfg.allowPlayers).map((s) => s.toLowerCase());
  let best = null;
  let bestD = maxDist;
  for (const p of Object.values(bot.players || {})) {
    if (!p || !p.username || !p.entity) continue;
    if (p.username === stats.username) continue;
    if (allowed.length > 0 && !allowed.includes(p.username.toLowerCase())) continue;
    const d = p.entity.position.distanceTo(bot.entity.position);
    if (d < bestD) {
      bestD = d;
      best = p;
    }
  }
  return best;
}

/** 寻路参数：闲逛**不许挖方块**、不许搭柱子。 */
function setupMovements() {
  try {
    const { Movements } = require('mineflayer-pathfinder');
    const m = new Movements(bot);
    m.canDig = false;
    m.canPlaceBlocks = false;
    m.allow1by1towers = false;
    m.scafoldingBlocks = [];
    bot.pathfinder.setMovements(m);
    diag('movements: canDig=false / canPlaceBlocks=false（闲逛不会拆家）');
  } catch (e) {
    diag(`movements 设置失败：${e.message}`);
  }
}

function pfMoving() {
  try {
    return !!(bot && bot.pathfinder && typeof bot.pathfinder.isMoving === 'function'
      && bot.pathfinder.isMoving());
  } catch {
    return false;
  }
}

/** 走/跑到某点附近（不等待，交给 pathfinder）。 */
function walkNear(pos, range = 1, maxDistance = 12) {
  try {
    const { goals } = require('mineflayer-pathfinder');
    if (!bot || !bot.entity) return;
    if (bot.entity.position.distanceTo(vecOf(pos)) > maxDistance) return;
    bot.pathfinder.setGoal(new goals.GoalNear(
      Math.floor(pos.x), Math.floor(pos.y), Math.floor(pos.z), range,
    ));
  } catch (e) {
    diag(`walkNear 失败：${e.message}`);
  }
}

// ---------------- 视线（2026-11-05） ----------------

/*
 * <h3>为什么要单独做一层"眼神"</h3>
 *
 * <p>两个都不对：一直盯着玩家看很诡异；完全不看又像没在听人说话。
 * 真人大概是这个节奏 —— <b>大部分时间在环视，偶尔抬眼看他一下，一两秒就移开。</b></p>
 *
 * <p>所以这里拆成两种动作，各带冷却：</p>
 * <ul>
 *   <li><b>环视</b>：在当前朝向上随机偏 ±35°，很轻，几乎察觉不到；</li>
 *   <li><b>看他</b>：1.2~3 秒后自动移开，然后 8~20 秒内不再盯人。</li>
 * </ul>
 *
 * <p>走路时不插手（mineflayer 的物理会自己转向行进方向），否则会打架。</p>
 */

let lookUntil = 0;
let nextPlayerLookAt = 0;

function naturalLook() {
  if (!bot || !bot.entity) return;
  const now = Date.now();
  if (now < lookUntil) return;   // 还在"看这一眼"的时间里，别打断

  const player = nearestAllowedPlayer(10);
  if (player && player.entity && now > nextPlayerLookAt && Math.random() < 0.45) {
    try {
      bot.lookAt(player.entity.position.offset(0, 1.6, 0), false);
    } catch {
      /* 看不到就算了 */
    }
    lookUntil = now + 1200 + Math.random() * 1800;          // 看 1.2~3 秒
    nextPlayerLookAt = now + 8000 + Math.random() * 12000;  // 8~20 秒内不再盯人
    return;
  }

  // 环视：小幅度偏转，像在"扫一眼周围"
  const yaw = (Number(bot.entity.yaw) || 0) + (Math.random() - 0.5) * 1.2;
  const pitch = (Math.random() - 0.5) * 0.25;
  try {
    bot.look(yaw, pitch, false);
  } catch {
    /* ignore */
  }
  lookUntil = now + 800 + Math.random() * 800;
}

/** 闲得发慌时做一件小事：靠过来 / 跳一下 / 随便挪两步（视线由 naturalLook 管）。 */
function doIdleThing() {
  if (!bot || !bot.entity) return;
  lastLocalMoveAt = Date.now();
  const me = bot.entity.position;
  if (bot.entity.inWater || (bot.health != null && bot.health < 8)) return;

  const player = nearestAllowedPlayer(16);
  const roll = Math.random();

  // ① 往你那边挪两步
  if (player && player.entity && roll < 0.45) {
    walkNear(player.entity.position, 2, 16);
    return;
  }
  // ② 小动作：蹲一下 / 挥挥手 / 切快捷栏 / 低头看手上（最容易"像个人"的一类）
  if (humanize() && roll > 0.45 && roll < 0.78) {
    fidget();
    return;
  }
  // ③ 原地蹦一下
  if (roll > 0.85) {
    try {
      bot.setControlState('jump', true);
      setTimeout(() => {
        try {
          bot.setControlState('jump', false);
        } catch {
          /* 断线 */
        }
      }, 250);
    } catch {
      /* ignore */
    }
    return;
  }
  // ④ 随便走 3~7 格
  const ang = Math.random() * Math.PI * 2;
  const r = 3 + Math.random() * 4;
  walkNear({ x: me.x + Math.cos(ang) * r, y: me.y, z: me.z + Math.sin(ang) * r }, 1, 12);
}

// ------------------------------------------------------------------ 反射层（2026-11-05）

/*
 * <h3>抄自 Mindcraft 的 modes.js，但只留"不需要模型"的那几条</h3>
 *
 * <p>脱困、自保、自防、狩猎、插火把 —— 这五件事的共同点是**不该等模型**：
 * 掉进岩浆再等 75 秒思考，人已经没了。阈值基本照搬 Mindcraft（它调过）：
 * 卡住 20 秒、自防 6~8 格、狩猎 12 格、火把冷却 30 秒。</p>
 *
 * <p>每秒跑一次，**不花 token**。打断模型动作时会留一句
 * {@link pendingInterrupt}，下一轮告诉它"刚才是自动反应，不是我改主意"——
 * 这就是 Mindcraft 里那条 `(AUTO MESSAGE)`，没有它模型会以为自己还在挖矿。</p>
 */

const reflex = {
  lastPos: null,
  stillSince: 0,
  lastStuckAt: 0,
  lastTorchAt: 0,
  lastHurtAt: 0,
  lastDefenseAt: 0,
  lastHuntAt: 0,
  lastNoteAt: 0,
};

let reflexTimer = null;
/** 反射打断模型动作时留的话，下一轮注入后即清。 */
let pendingInterrupt = '';

function interruptNote(text, force = false) {
  const now = Date.now();
  if (!force && now - reflex.lastNoteAt < 8000) return;
  reflex.lastNoteAt = now;
  pendingInterrupt = String(text || '').slice(0, 60);
  note(`（自动反应）${pendingInterrupt}`);
  diag(`reflex: ${pendingInterrupt}`);
}

function invItems() {
  return (bot && bot.inventory && bot.inventory.items()) || [];
}

function freeSlots() {
  try {
    return bot.inventory.emptySlotCount();
  } catch {
    return 36;
  }
}

function hasItem(re) {
  return invItems().some((i) => re.test(i.name));
}

function blockNameAt(pos) {
  const b = bot.blockAt(pos);
  return b ? String(b.name || '') : '';
}

const DANGER_BLOCK = /^(lava|fire|soul_fire)$/;
const FALLING_BLOCK = /^(sand|red_sand|gravel|concrete_powder|anvil|chipped_anvil|damaged_anvil)$/;
const WEAPON = /sword|_axe$/;
const FOOD = /bread|apple|cooked_|beef|porkchop|chicken|mutton|carrot|potato|fish|stew/;
const PREY = /cow|pig|sheep|chicken|rabbit/;

/** 朝远离某个点的方向走（没有明确方向时随机挑一个，别原地打转）。 */
function moveAway(fromPos, dist) {
  const me = bot.entity.position;
  let dx = me.x - (fromPos ? fromPos.x : me.x);
  let dz = me.z - (fromPos ? fromPos.z : me.z);
  let len = Math.hypot(dx, dz);
  if (len < 0.5) {
    const a = Math.random() * Math.PI * 2;
    dx = Math.cos(a);
    dz = Math.sin(a);
    len = 1;
  }
  walkNear({ x: me.x + (dx / len) * dist, y: me.y, z: me.z + (dz / len) * dist }, 1, dist + 6);
}

/** 最近的敌对实体（要对象，不是坐标 —— 自防要打它）。 */
function nearestHostileEntity(maxDist) {
  if (!bot || !bot.entity) return null;
  const me = bot.entity.position;
  let best = null;
  let bd = maxDist;
  for (const e of Object.values(bot.entities || {})) {
    if (!e || e === bot.entity || !e.name || !HOSTILE.test(String(e.name))) continue;
    let d = 0;
    try {
      d = e.position.distanceTo(me);
    } catch {
      continue;
    }
    if (d < bd) {
      bd = d;
      best = e;
    }
  }
  return best;
}

/**
 * ① 自保（Mindcraft `self_preservation` 的本地版）。
 *
 * @returns {boolean} true = 这一拍被它接管了
 */
function selfPreservation() {
  if (!bot || !bot.entity) return false;
  const me = bot.entity.position;
  const feet = blockNameAt(me);
  const headBlock = blockNameAt(me.offset(0, 1, 0));
  const above = blockNameAt(me.offset(0, 2, 0));

  // 溺水：头上有水就往上顶
  if (above === 'water' || above === 'flowing_water') {
    try {
      bot.setControlState('jump', true);
      setTimeout(() => {
        try {
          bot.setControlState('jump', false);
        } catch {
          /* 断线 */
        }
      }, 700);
    } catch {
      /* ignore */
    }
    // 自保的提示一律 force：每种危险是不同的话，被节流吞掉会让人误判成"没反应"
    interruptNote('头上有水，先浮上去', true);
    return true;
  }
  // 头顶落沙/沙砾/铁砧：往旁边挪
  if (FALLING_BLOCK.test(above)) {
    moveAway(me.offset(0, 2, 0), 3);
    interruptNote('头顶在落沙子，先躲开', true);
    return true;
  }
  // 岩浆/火：先退开（有桶也先退，别一边烧一边翻背包）
  if (DANGER_BLOCK.test(feet) || DANGER_BLOCK.test(headBlock)) {
    moveAway(me, 6);
    interruptNote('脚下是岩浆/火，先退开', true);
    flash('danger', '身边有岩浆或火');
    return true;
  }
  // 濒死：3 秒内受过伤且血 <5 → 往反方向跑 15 格
  if (bot.health != null && bot.health < 5 && reflex.lastHurtAt
    && Date.now() - reflex.lastHurtAt < 3000) {
    moveAway(me, 15);
    interruptNote('血快没了，先跑远', true);
    flash('danger', `血量只剩 ${Math.round(bot.health)}/20`);
    reflex.lastHurtAt = 0;   // 只逃一次，别每拍都重新触发
    return true;
  }
  return false;
}

/** ② 自防：6 格内的怪就打回去（需要允许攻击）。 */
function selfDefense() {
  if (!cfg.allowCombat || cfg.selfDefense === false) return false;
  const now = Date.now();
  if (now - reflex.lastDefenseAt < 4000) return false;
  const foe = nearestHostileEntity(6);
  if (!foe) return false;
  reflex.lastDefenseAt = now;
  const weapon = invItems().find((i) => WEAPON.test(i.name));
  void (async () => {
    try {
      if (weapon) {
        await bot.equip(weapon, 'hand');
      }
      await bot.lookAt(foe.position.offset(0, 1, 0), false);
      bot.attack(foe);
      interruptNote(`打了一下 ${foe.name}`);
    } catch (e) {
      diag(`selfDefense 失败：${e.message}`);
    }
  })();
  return true;
}

/** ③ 狩猎：饿且身上没吃的才打动物（有吃的就别杀生）。 */
function huntIfStarving() {
  if (!cfg.allowCombat || cfg.hunting === false) return false;
  if (bot.food == null || bot.food > 14) return false;
  if (invItems().some((i) => FOOD.test(i.name))) return false;
  const now = Date.now();
  if (now - reflex.lastHuntAt < 15_000) return false;

  const me = bot.entity.position;
  let prey = null;
  let bd = 12;
  for (const e of Object.values(bot.entities || {})) {
    if (!e || e === bot.entity || !e.name || !PREY.test(String(e.name))) continue;
    let d = 0;
    try {
      d = e.position.distanceTo(me);
    } catch {
      continue;
    }
    if (d < bd) {
      bd = d;
      prey = e;
    }
  }
  if (!prey) return false;

  reflex.lastHuntAt = now;
  void (async () => {
    try {
      await bot.lookAt(prey.position.offset(0, 0.6, 0), false);
      bot.attack(prey);
      interruptNote(`饿了，去打 ${prey.name}`);
    } catch (e) {
      diag(`hunt 失败：${e.message}`);
    }
  })();
  return true;
}

/** ④ 太黑就插火把（冷却 30 秒，别原地连插）。 */
function torchIfDark() {
  if (cfg.autoTorch === false || !cfg.allowPlaceBlocks) return false;
  const torch = invItems().find((i) => i.name === 'torch');
  if (!torch) return false;
  const now = Date.now();
  if (now - reflex.lastTorchAt < 30_000) return false;

  const me = bot.entity.position.floored();
  const here = bot.blockAt(me);
  if (!here || typeof here.light !== 'number' || here.light >= 8) return false;

  const spot = findPlaceSpot();
  if (!spot) return false;
  reflex.lastTorchAt = now;
  void placeItemAt(torch, spot.pos, 'torch').then((r) => {
    if (String(r).startsWith('放好了')) {
      diag('reflex: 插了一支火把');
      note('插了一支火把');
    }
  }).catch(() => {});
  return true;
}

/**
 * ⑤ 脱困：想动却动不了超过 20 秒 → 换方向 + 跳一下。
 *
 * <p>Mindcraft 的判据是"位移 <2 且挖掘目标没变"，这里简化成"在寻路/有动作但位移 <2"。
 * **只在想动的时候算卡住** —— 好好站着发呆不算。</p>
 */
function detectStuck() {
  const me = bot.entity.position;
  const now = Date.now();
  if (!reflex.lastPos) {
    reflex.lastPos = me.clone();
    reflex.stillSince = now;
    return false;
  }
  if (me.distanceTo(reflex.lastPos) > 2) {
    reflex.lastPos = me.clone();
    reflex.stillSince = now;
    return false;
  }
  const trying = pfMoving() || busy;
  if (!trying) {
    reflex.lastPos = me.clone();
    reflex.stillSince = now;
    return false;
  }
  if (now - reflex.stillSince < 20_000) return false;
  if (now - reflex.lastStuckAt < 30_000) return false;

  reflex.lastStuckAt = now;
  reflex.stillSince = now;
  reflex.lastPos = me.clone();
  try {
    bot.pathfinder.setGoal(null);
  } catch {
    /* ignore */
  }
  moveAway(me, 5);
  try {
    bot.setControlState('jump', true);
    setTimeout(() => {
      try {
        bot.setControlState('jump', false);
      } catch {
        /* 断线 */
      }
    }, 300);
  } catch {
    /* ignore */
  }
  interruptNote('卡住了，换个方向走', true);
  return true;
}

/** 每秒一次：自保 → 脱困 → 自防 → （闲着才）狩猎 / 插火把。 */
function reflexTick() {
  if (!cfg.enabled || cfg.reflexEnabled === false) return;
  if (!stats.connected || !bot || !bot.entity || stopping) return;
  try {
    if (selfPreservation()) return;
    if (detectStuck()) return;
    if (selfDefense()) return;
    if (busy || pfMoving()) return;
    if (huntIfStarving()) return;
    torchIfDark();
  } catch (e) {
    diag(`reflex 异常：${e.message}`);
  }
}

// ---------------- 人性化细节（2026-11-05） ----------------

/*
 * <h3>这一层解决"看着像脚本"</h3>
 *
 * <p>调研同类项目（Gamemode One 的 AI Players、GhostPlayers、各类拟人 AFK bot）后，
 * 结论是：**像真人主要来自时间结构与身体语言，不是智商。** 下面这些都是本地计算，
 * 不增加任何模型调用。</p>
 */

/** 这一层的总开关（关掉就退回纯功能，行为会明显机械）。 */
function humanize() {
  return cfg.humanizeEnabled !== false;
}

// ① 节奏：活跃期 / 安静期交替 —— 人不是每秒均匀地"想事情"
let burstUntil = 0;
let nextBurstAt = 0;

function inBurst() {
  if (!humanize()) return false;
  const now = Date.now();
  if (now < burstUntil) return true;
  if (now < nextBurstAt) return false;
  burstUntil = now + (2 + Math.random() * 2) * 60_000;          // 活跃 2~4 分钟
  nextBurstAt = burstUntil + (8 + Math.random() * 12) * 60_000; // 之后安静 8~20 分钟
  diag('burst: 进入活跃期（这几分钟她会主动得多）');
  return true;
}

// ② 滞回：阈值分"进入/退出"两个值，避免在边界上反复摇摆
//    （推理结果每帧一点抖动，直接映射成行为就是"一秒内犹豫三次"）
let restlessState = false;

function updateRestless(cur, enter) {
  if (!restlessState && cur >= enter) {
    restlessState = true;
  } else if (restlessState && cur < enter - 0.12) {
    restlessState = false;
  }
  return restlessState;
}

// ③ 社交站位：站到玩家的**侧后方**，而不是正面贴脸（正面站着最像假人）
function socialSpot(player, dist = 2.6) {
  const p = player.entity.position;
  const yaw = Number(player.entity.yaw) || 0;
  const ang = yaw + Math.PI + Math.PI / 3;   // 背后再偏 60°
  return {
    x: p.x + Math.cos(ang) * dist,
    y: p.y,
    z: p.z + Math.sin(ang) * dist,
  };
}

// ④ 走位不完美：目标点加一点随机偏移（完美直线一眼就是机器）
function jitterPoint(pos, amp = 1.2) {
  return {
    x: pos.x + (Math.random() - 0.5) * amp * 2,
    y: pos.y,
    z: pos.z + (Math.random() - 0.5) * amp * 2,
  };
}

/**
 * 他走远了就不再跟（**克制比殷勤更像人**）。
 *
 * <p>必须放在 tickAmbient 所有早退之前：静默时段 / `[停]` 冷却期会先 return，
 * 如果只写在跟随分支里，"他走了，她还在往旧坐标走"这种情况永远收不回来。</p>
 */
function releaseFollowIfFar() {
  if (!ambientFollowWho) return;
  if (nearestAllowedPlayer(24)) return;
  ambientFollowWho = '';
  try {
    bot.pathfinder.setGoal(null);
  } catch {
    /* ignore */
  }
  diag('他走远了，不再跟过去');
}

// ⑤ 微动作：蹲一下 / 挥手臂 / 切快捷栏 / 低头看手上
function fidget() {
  const roll = Math.random();
  try {
    if (roll < 0.35) {
      bot.setControlState('sneak', true);
      setTimeout(() => {
        try {
          bot.setControlState('sneak', false);
        } catch {
          /* 断线 */
        }
      }, 500 + Math.random() * 500);
      return 'sneak';
    }
    if (roll < 0.6) {
      bot.swingArm('right');
      return 'swing';
    }
    if (roll < 0.8) {
      bot.setQuickBarSlot(Math.floor(Math.random() * 9));
      return 'hotbar';
    }
    // 低头看脚边（"看手上的东西"）
    bot.look(Number(bot.entity.yaw) || 0, 0.7, false);
    lookUntil = Date.now() + 900;
    return 'look-down';
  } catch {
    return '';
  }
}

// ⑥ 失败复盘：死了之后，下一轮让她自己提一句（不是插件替她说，是给她一条"教训"）
let pendingLesson = '';

function setLesson(text) {
  pendingLesson = String(text || '').slice(0, 80);
}

// ------------------------------------------------------------------ 社交感知（2026-11-05）

/*
 * <h3>为什么"被打不吭声、也不问你在干嘛"</h3>
 *
 * <p>她的需求表里只有**资源型**（饿了、缺工具、有怪），没有**关系型**。
 * 所以你做的事对她等于没发生：`entityHurt` 只记了个时间戳，
 * 既不知道是谁打的，也没有"我该不该问一句"的出口。</p>
 *
 * <p>这一节补四层：</p>
 * <ol>
 *   <li><b>事件层</b>：谁对我做了什么（被打、被给了东西、他在忙什么）；</li>
 *   <li><b>归因层</b>：几个候选解释 + 置信度（玩家拿武器打我 / 空手拍我 / 怪 / 摔的）；</li>
 *   <li><b>不确定→提问</b>：置信度不够就**开口问**，别自己编理由；</li>
 *   <li><b>观察层</b>：盯玩家的手持物与移动状态，能说出"你在挖什么"这种话。</li>
 * </ol>
 */

const SOCIAL_TTL = 3 * 60_000;

const socialState = {
  events: [],
  /** 上次问"你打我干嘛" / "你在忙啥" 的时间。 */
  lastAskHitAt: 0,
  lastSmallTalkAt: 0,
  /** 每个玩家最近的位置/手持物，用来判断"他在动还是在忙"。 */
  watchers: Object.create(null),
};

function socialAlive() {
  return cfg.socialEnabled !== false && !!bot && !!bot.entity && stats.connected;
}

function pushSocial(ev) {
  const now = Date.now();
  socialState.events.push({ at: now, ...ev });
  socialState.events = socialState.events.filter((e) => now - e.at < SOCIAL_TTL).slice(-12);
  note(`（社交）${ev.kind}${ev.who ? ` ${ev.who}` : ''}`);
  diag(`social: ${ev.kind} who=${ev.who || '-'} hypo=${ev.hypo || '-'} conf=${(ev.conf || 0).toFixed(2)}`);
}

/** 附近的玩家（按距离）。 */
function nearPlayers(maxDist = 6) {
  if (!bot || !bot.entity) return [];
  const me = bot.entity.position;
  return Object.values(bot.players || {})
    .filter((p) => p && p.username && p.username !== stats.username && p.entity)
    .map((p) => {
      let d = 99;
      try {
        d = p.entity.position.distanceTo(me);
      } catch {
        /* 位置没同步 */
      }
      return { p, d };
    })
    .filter((x) => x.d < maxDist)
    .sort((a, b) => a.d - b.d);
}

/**
 * 被打的反应 —— 四段式（2026-11-05）。
 *
 * <p><b>为什么不是"受伤 → 立刻说一句"</b>：那是文本反射，一眼就是机器。
 * 人被打是四段：愣一下 → 动一下 → 判断要不要说（多数不说）→ 说的时候即兴。</p>
 *
 * <ol>
 *   <li><b>觉察</b>：只更新状态（谁、多疼、第几次），不出声；</li>
 *   <li><b>行为</b>：停下手上的活、转头看他；持械或血少就退两三格；</li>
 *   <li><b>判断</b>：说不说由伤害/血量/次数/是否持械决定，**大多数时候不说**；</li>
 *   <li><b>表达</b>：真要说，就让模型即兴一句，并做近义去重。</li>
 * </ol>
 *
 * <p><b>为什么沉默是默认</b>：真人被拍一下，抬头看你一眼就过去了。
 * 每次都开口问"你打我干嘛"才是最不人的地方。</p>
 */
const hitState = {
  lastAt: 0,
  count: 0,
  lastSpokeAt: 0,
  lastHealth: null,
};

/** 最近说过的话（用来去重：意思太像就不再说一遍）。 */
const recentSays = [];

/** 语义近似去重：字的重合度 > 0.7 就当"说过了"。 */
function recentlySaid(line) {
  const norm = (s) => String(s || '').replace(/[^\u4e00-\u9fa5a-z0-9]/gi, '');
  const a = norm(line);
  if (!a) return true;
  const hit = recentSays.some((b) => {
    const c = norm(b);
    if (!c) return false;
    const set = new Set(a);
    const common = [...set].filter((ch) => c.includes(ch)).length;
    return common / set.size > 0.7;
  });
  if (!hit) {
    recentSays.push(line);
    if (recentSays.length > 8) recentSays.shift();
  }
  return hit;
}

/**
 * ② 行为反应：**先动，别先说话**。
 *
 * <p>被拍一下的第一反应是身体（停手、转头、退开），不是开口。
 * 少了这一段，哪怕句子写得再好也是"文本反射"。</p>
 */
async function reactByBody(who, hypo) {
  if (!bot || !bot.entity) return;
  try {
    // 手上有活 → 先停一下（挖矿/走路被打断，人就是这个反应）
    if (pfMoving()) bot.pathfinder.setGoal(null);

    const p = who ? (bot.players || {})[who] : null;
    if (!p || !p.entity) return;

    const hurt = bot.health != null && bot.health < 10;
    if (hypo === 'player-armed' || hurt) {
      // 拿着武器 / 血不多 → 退两三格，而不是站那儿问"你为什么打我"
      const me = bot.entity.position;
      const dx = me.x - p.entity.position.x;
      const dz = me.z - p.entity.position.z;
      const len = Math.hypot(dx, dz) || 1;
      walkNear({ x: me.x + (dx / len) * 3, y: me.y, z: me.z + (dz / len) * 3 }, 1, 6);
    } else {
      // 空手、不一定有恶意 → 转过来看他
      bot.lookAt(p.entity.position.offset(0, 1.6, 0));
    }
  } catch {
    /* 位置没同步就算了 */
  }
}

/**
 * ③ 判断要不要说 + ④ 让模型即兴。
 *
 * <p>**多数时候不说**才是人：空手拍一下、心情还行、第一次 —— 抬头看你一眼就过去了。
 * 反复来、掉了不少血、或者你拿着武器，才会开口。</p>
 */
async function maybeSpeakAfterHit(who, hypo, conf, dmg) {
  // 人不会 0ms 开口：先愣那么一下
  await sleep(900 + Math.random() * 1400);
  if (!socialAlive()) return;
  if (Date.now() - hitState.lastSpokeAt < 45_000) return;

  let p = 0.45;
  if (dmg >= 4) p += 0.3;                                  // 疼
  if (hypo === 'player-armed') p -= 0.35;                  // 先躲，别嘴硬
  if (bot.health != null && bot.health < 10) p -= 0.2;
  if (hitState.count >= 3) p += 0.45;                      // 反复来才算事
  if (conf >= 0.7) p += 0.05;
  const chance = Math.max(0.05, Math.min(0.95, p));

  if (Math.random() > chance) {
    note('（社交）被打了一下，没吭声');
    session.lastResults.push('刚才他打了你一下，你没吭声');
    diag(`social: 这次选择不说话（p=${chance.toFixed(2)}）`);
    return;
  }

  hitState.lastSpokeAt = Date.now();
  const prompt = [
    '【系统提示 · 不是玩家说的】你刚被打了一下。',
    `· 谁：${who || '没看清'}${hypo === 'player-armed' ? '（手里拿着武器）' : '（空手）'}`,
    `· 掉了 ${Math.round(dmg)} 点血，这是最近第 ${hitState.count} 次`,
    bot.health != null ? `· 你现在血量 ${Math.round(bot.health)}/20` : '',
    '用一句话反应：可以是问、可以是抱怨、也可以只是警告他别闹。20 字以内，别解释系统。',
    '不想说就回 [SILENT]。',
  ].filter(Boolean).join('\n');

  let line = '';
  try {
    /*
     * 注入上下文要单独兜一层：`buildInject` 依赖世界状态，
     * 万一这一步抛错，整句反应就没了 —— 表现是"被打之后什么都不说"，
     * 而这正是最容易被误解成"她没反应"的情况。
     */
    let inject = '';
    try {
      inject = buildInject({}) || '';
    } catch (e) {
      diag(`被打反应：注入上下文失败（降级为无上下文）${e.message}`);
    }
    line = String(await askPlatform(prompt, inject) || '').trim();
  } catch (e) {
    diag(`被打反应生成失败：${e.message}`);
  }
  line = line.split('\n')[0].replace(/[[\]]/g, '').trim().slice(0, 24);
  if (!line || /SILENT|不理/.test(line)) return;
  if (recentlySaid(line)) {
    diag(`social: 和最近说过的太像，跳过（${line}）`);
    return;
  }
  await say(line);
}

function onHurtSocial() {
  if (!socialAlive()) return;
  const now = Date.now();

  // 伤害量：受伤事件不带数值，用血量差估
  let dmg = 0;
  if (bot.health != null) {
    if (hitState.lastHealth != null) dmg = Math.max(0, hitState.lastHealth - bot.health);
    hitState.lastHealth = bot.health;
  }

  // ① 觉察：连击合并成一次反应（否则会被打得刷屏）
  const merged = now - hitState.lastAt < 2000 && hitState.count > 0;
  hitState.lastAt = now;
  hitState.count = merged ? hitState.count + 1 : 1;

  const near = nearPlayers(5);
  const mob = nearestHostile(4);
  let hypo = 'unknown';
  let conf = 0.2;
  let who = '';

  if (near.length > 0 && near[0].d < 4.5) {
    who = near[0].p.username;
    const held = (near[0].p.heldItem && near[0].p.heldItem.name) || '';
    if (/sword|_axe$|mace|trident/.test(held)) {
      hypo = 'player-armed';
      conf = 0.75;
    } else {
      hypo = 'player-hand';
      conf = 0.45;   // 空手也可能是不小心 / 推搡
    }
  } else if (mob && mob.dist < 4) {
    hypo = 'mob';
    conf = 0.8;
  } else {
    hypo = 'fall-or-env';
    conf = 0.35;
  }

  pushSocial({ kind: 'hurt', who, hypo, conf, dmg });

  if (merged) {
    diag(`social: 合并第 ${hitState.count} 次（不重复反应）`);
    return;
  }

  void reactByBody(who, hypo);                       // ②
  void maybeSpeakAfterHit(who, hypo, conf, dmg);     // ③④
}

/** 每 4 秒看一眼玩家在干什么。 */
function observePlayers() {
  if (!socialAlive()) return;
  const now = Date.now();
  for (const { p } of nearPlayers(12)) {
    const e = p.entity;
    const name = p.username;
    const st = socialState.watchers[name] || {
      at: now, x: e.position.x, z: e.position.z, stillSince: now, held: '',
    };
    const moved = Math.hypot(e.position.x - st.x, e.position.z - st.z);
    if (moved > 0.6) {
      st.stillSince = now;   // 还在走动
    }
    st.x = e.position.x;
    st.z = e.position.z;
    st.at = now;
    st.held = p.heldItem ? p.heldItem.name : '';
    socialState.watchers[name] = st;
  }
}

/**
 * 他在忙什么 —— 主动问一句。
 *
 * <p>只在"他停在原地一会儿"或"手里拿着工具"时问，跑动中问会像复读机。</p>
 */
function maybeAskWhatDoing() {
  if (!socialAlive()) return;
  const now = Date.now();
  if (now - socialState.lastSmallTalkAt < 8 * 60_000) return;
  if (busy) return;

  const near = nearPlayers(8)[0];
  if (!near) return;
  const st = socialState.watchers[near.p.username];
  if (!st) return;

  const still = now - st.stillSince > 20_000;
  const tool = /_pickaxe$|_axe$|_shovel$|_hoe$|bucket$/.test(st.held || '');
  if (!still && !tool) return;

  /*
   * 不是"条件满足就开口"（那还是人机）。
   * 三个改动：① 概率（一半时候只是看看、不问）；② 措辞随机挑一句；
   * ③ 近义去重 —— 同一句话八分钟内不会说第二遍。
   */
  if (Math.random() > 0.5) return;

  const pool = tool
    ? ['你在挖什么呢', '弄什么呢', '这是要盖东西？']
    : ['你在忙啥呢', '在干嘛呀', '你站这儿发什么呆'];
  const line = pool[Math.floor(Math.random() * pool.length)];
  if (recentlySaid(line)) return;

  socialState.lastSmallTalkAt = now;
  void say(line);
  pushSocial({ kind: 'smalltalk', who: near.p.username, hypo: 'ask', conf: 0.9 });
}

/** 提示词：刚才发生了什么（只带 2 分钟内的）。 */
function socialBlock() {
  const now = Date.now();
  const list = (socialState.events || []).filter((e) => now - e.at < 2 * 60_000 && e.kind === 'hurt');
  if (list.length === 0) return '';
  const lines = list.slice(-2).map((e) => {
    const sec = Math.max(1, Math.round((now - e.at) / 1000));
    if (e.who) {
      const armed = e.hypo === 'player-armed' ? '，他手上拿着武器' : '';
      return `· ${e.who} 刚才打了你一下（${sec} 秒前${armed}）`;
    }
    if (e.hypo === 'mob') return `· 你刚才被怪咬了一口（${sec} 秒前）`;
    return `· 你刚才挨了一下（${sec} 秒前，附近没看到人，可能是摔的）`;
  });
  return `【刚才发生的事】\n${lines.join('\n')}\n（不明白就直接问他，别自己编理由；也别小题大做。）`;
}

// ---------------- 失效自检（2026-11-04） ----------------

/*
 * <h3>为什么需要她自己去看"平台里是否已禁用"</h3>
 *
 * <p>用户反馈："插件都关了她还在游戏里。" 查下来是典型的**卸载对象错了**：
 * 多开 / 热重载残留的旧进程还活着，而平台只卸载了它手里那一个。
 * 平台的开关（`plugin-web/state.json`）对 Node 进程没有任何强制力 ——
 * 它只决定前端要不要挂载、贡献要不要下发。</p>
 *
 * <p>所以让她**自己查**：`GET /api/v1/plugin-web` 里 `enabled === false`
 * （或者根本不在列表里 = 被卸载），连续两次确认就主动下线并退出进程。
 * 平台重新启用时会重新加载，不影响正常使用。</p>
 */

let enabledStrikes = 0;
let enabledTimer = null;

async function checkPlatformEnabled() {
  if (!api || !api.platform || typeof api.platform.request !== 'function' || !api.pluginId) {
    return;
  }
  let list = null;
  try {
    const r = await api.platform.request({ path: '/api/v1/plugin-web', method: 'GET' });
    list = Array.isArray(r) ? r : (r && Array.isArray(r.data) ? r.data : null);
  } catch (e) {
    // 后端在重启 / 未登录都会到这里：查不到就不算数，绝不能因此退出
    diag(`查询插件启用状态失败：${e.message}`);
    return;
  }
  if (!list) return;

  const me = list.find((x) => x && (x.id === api.pluginId || x.pluginId === api.pluginId));
  const disabled = !me || me.enabled === false;
  if (!disabled) {
    if (enabledStrikes > 0) diag('平台侧已重新启用，取消退出');
    enabledStrikes = 0;
    return;
  }

  enabledStrikes++;
  diag(`平台侧显示「已禁用」（第 ${enabledStrikes} 次确认）`);
  if (enabledStrikes >= 2) {
    shutdownSelf('平台里这个插件已被禁用/卸载');
  }
}

/** 自我下线：断开游戏连接 → 写状态 → 退出进程。 */
function shutdownSelf(reason) {
  stopping = true;
  log('warn', `${reason} —— 主动下线并退出进程（重新启用会再加载）`);
  try {
    stopTimers();
  } catch {
    /* ignore */
  }
  try {
    if (bot) disconnect();
  } catch {
    /* ignore */
  }
  releaseLock();
  writeState({ online: false, endedAt: Date.now(), disabled: true });
  setTimeout(() => {
    try {
      process.exit(0);
    } catch {
      /* ignore */
    }
  }, 300);
}

/**
 * 每 4 秒一次（本地，不含模型）。真正"动"仍然按 `idleWalkSeconds` 节流，
 * 所以不会变成抽搐；但她的反应延迟从"15 分钟"降到了"几秒"。
 */
function tickAmbient() {
  /*
   * 总闸和静默时段都要管到这里（2026-11-04）。
   *
   * <p>以前活力层不属于"自主"，于是出现两种怪状：
   * ① 关掉【④ 自主】她还在自己溜达；② 凌晨三点没人管她，她仍然在院子里转圈。
   * 现在：**自主总开关一关，思考和小动作一起停**；静默时段同理，
   * 她只会站在原地（你说话她照样回应，那条走的是聊天链路）。</p>
   */
  if (!cfg.enabled || !cfg.autonomyEnabled) return;
  if (!cfg.livelyEnabled || !stats.connected || busy) return;
  if (!bot || !bot.entity) return;

  // 他走远了就不再追 —— 这一步必须放在所有早退之前，否则静默时段会漏掉
  releaseFollowIfFar();

  /*
   * 静默时段只在"没人陪"时收敛。
   *
   * <p>原来的写法是硬拦：凌晨你还在玩，她就冻在原地 —— 那比乱走更怪。
   * 现在改成**你在 16 格内就照旧有小动作**，你不在了她才安静待着。</p>
   */
  if (inQuietHours() && !nearestAllowedPlayer(16)) return;
  if (Date.now() < ambientHoldUntil) return;
  if (pfMoving()) return;   // 正在走/正在被指使，别插话

  // 眼神：不走路时才管（走路时物理引擎自己会转向行进方向）
  naturalLook();

  /*
   * 社交观察（2026-11-05）：每 4 秒记一下玩家在动还是在忙、手里拿什么。
   * 没有这一层，她根本说不出"你在挖什么呢"——因为没有素材。
   */
  observePlayers();
  maybeAskWhatDoing();

  // 你跟她在 12 格内、她闲着 → 跟过来（保持 3 格，不贴脸）
  if (cfg.followPlayerWhenIdle) {
    const player = nearestAllowedPlayer(24);
    if (player && player.entity) {
      const d = bot.entity.position.distanceTo(player.entity.position);
      /*
       * 站位：跟到**侧后方** 2.6 格，而不是正面贴脸（2026-11-05）。
       * 正面站着最像假人，也最容易挡住视线；侧后方像"跟着你走的人"。
       */
      if (d > 3.4) {
        // 已经跟着同一个人就不用每 4 秒重设一次目标（会反复重算路径）
        if (ambientFollowWho === player.username && pfMoving()) return;
        ambientFollowWho = player.username;
        const spot = socialSpot(player, 2.6);
        const target = humanize() ? jitterPoint(spot, 0.8) : spot;
        try {
          const { goals } = require('mineflayer-pathfinder');
          bot.pathfinder.setGoal(new goals.GoalNear(
            Math.floor(target.x), Math.floor(target.y), Math.floor(target.z), 1,
          ));
          lastLocalMoveAt = Date.now();
        } catch (e) {
          diag(`自动跟随失败：${e.message}`);
        }
        return;
      }
      ambientFollowWho = '';
    }
  }

  // 活跃期里小动作更密（burstiness：人不是均匀地"每隔 25 秒动一下"）
  const idleMs = clamp(cfg.idleWalkSeconds, 5, 600) * 1000 * (inBurst() ? 0.6 : 1);
  if (Date.now() - lastLocalMoveAt < idleMs * (0.7 + Math.random() * 0.6)) return;
  doIdleThing();
}

// ------------------------------------------------------------------ 动作

/**
 * 动词表。**只认这些** —— 认不出的方括号留在正文里。
 *
 * <p>不这么做的后果：她说话里带个 `[图片]` 就会被当成动作吞掉，
 * 而"吞掉"比"没执行"更难排查（用户只看到她少说了一句）。</p>
 */
const ACTION_VERBS = {
  看: 'observe',
  观察: 'observe',
  看周围: 'lookAround',
  周围: 'lookAround',
  observe: 'observe',
  state: 'observe',
  去: 'goto',
  回家: 'gotoHome',
  goto: 'goto',
  go: 'goto',
  来: 'come',
  过来: 'come',
  come: 'come',
  跟: 'follow',
  跟着: 'follow',
  follow: 'follow',
  停: 'stop',
  别动: 'stop',
  stop: 'stop',
  挖: 'mine',
  mine: 'mine',
  dig: 'mine',
  放: 'place',
  place: 'place',
  合成: 'craft',
  craft: 'craft',
  拿: 'equip',
  装备: 'equip',
  equip: 'equip',
  吃: 'eat',
  eat: 'eat',
  打: 'attack',
  攻击: 'attack',
  attack: 'attack',
  丢: 'toss',
  扔: 'toss',
  toss: 'toss',
  /* 给玩家（2026-11-05）：MC 里只能"丢在他脚边"，没有交易式给予 */
  给: 'give',
  递给: 'give',
  交给: 'give',
  送给: 'give',
  give: 'give',
  捡: 'pickup',
  拾: 'pickup',
  pickup: 'pickup',
  /* 使用类（2026-11-05）：锄地/播种/浇水/开门 都是同一个原语 */
  用: 'use',
  使用: 'use',
  use: 'use',
  锄地: 'use',
  播种: 'use',
  浇水: 'use',
  /* 容器 / 传送门 / 蓝图 / 技能（2026-11-05） */
  存: 'container',
  取: 'container',
  '看箱子': 'container',
  container: 'container',
  盖: 'build',
  build: 'build',
  传送门: 'portal',
  下界: 'portal',
  portal: 'portal',
  技能: 'skill',
  skill: 'skill',
  /* 区域原语（Baritone 借鉴，2026-11-05） */
  /* 找目标并走过去（避免模型瞎编坐标） */
  找: 'find',
  find: 'find',
  清空: 'cleararea',
  清理: 'cleararea',
  cleararea: 'cleararea',
  围栏: 'walls',
  围墙: 'walls',
  walls: 'walls',
  垫柱: 'pillar',
  垫高: 'pillar',
  pillar: 'pillar',
  隧道: 'tunnel',
  tunnel: 'tunnel',
  开荒: 'farm',
  种地: 'farm',
  农场: 'farm',
  farm: 'farm',
  睡: 'sleep',
  sleep: 'sleep',
  说: 'say',
  say: 'say',
  记: 'remember',
  remember: 'remember',
  note: 'remember',
  坐标: 'mark',
  mark: 'mark',
  换肤: 'skin',
  皮肤: 'skin',
  skin: 'skin',
  等: 'wait',
  wait: 'wait',
  /*
   * 好奇心相关的两个动作（2026-11-04）。
   *
   * `[想做 …]` 是**说出来但不立刻做**：她常在"想去但手上还有事"的时候用它，
   * 这句话会被存下来，下一次独自待着时再拿给她看 —— 这是"打算"的连续性。
   */
  想做: 'intent',
  想: 'intent',
  计划: 'intent',
  plan: 'intent',
  算了: 'clearIntent',
  不去了: 'clearIntent',
  放弃: 'clearIntent',
};

/**
 * 中文动词要**前缀匹配**（2026-11-04 修）。
 *
 * <p><b>踩过的坑</b>：模型写 `[去附近有树的地方]`、`[挖橡木]` 这种没有空格的句子，
 * 而解析器按空白切第一个词 —— `去附近有树的地方` 不是任何已知动词，于是整段被当成
 * 正文发进了聊天。表现就是"她只会说话、站着不动"，玩家看到她在念 `[去附近有树的地方]`。</p>
 *
 * <p>按长度从长到短匹配，`看周围` 不会被 `看` 抢走。`想` 单独排除：
 * `[想不起来]` 不该被当成"想做"。`</p>
 */
const CN_VERBS = Object.keys(ACTION_VERBS)
  .filter((k) => /^[\u4e00-\u9fa5]+$/.test(k) && k !== '想')
  .sort((a, b) => b.length - a.length);

/**
 * 看起来像动作、但动词不认识的方括号 —— **也不能当聊天念出去**。
 *
 * <p>这条是兜底：宁可少说一句，也不能让她对着玩家念 `[去附近有树的地方]`。</p>
 */
const LOOKS_LIKE_ACTION = /^(去|来|过来|跟着?|停|别动|挖|放|合成|拿|装备|吃|打|攻击|丢|扔|睡|看|观察|周围|说|记|坐标|等|想做|计划|算了|不去了|放弃|换肤|皮肤|mine|goto|go|follow|stop|dig|place|craft|equip|eat|attack|toss|sleep|say|wait)/i;

/** 把一个方括号里的内容拆成 { verb, args }；认不出返回 null。 */
function matchActionVerb(inner) {
  const parts = String(inner || '').trim().split(/\s+/);
  const head = String(parts[0] || '').trim();
  if (!head) return null;

  const exact = ACTION_VERBS[head] || ACTION_VERBS[head.toLowerCase()];
  if (exact) {
    return { verb: exact, args: parts.slice(1).filter(Boolean) };
  }

  // 无空格写法：`去附近有树的地方` / `挖橡木` / `跟着你` / `回家`
  const cn = head.replace(/^[^\u4e00-\u9fa5]+/, '');
  if (!cn) return null;
  for (const k of CN_VERBS) {
    if (!cn.startsWith(k)) continue;
    const rest = cn.slice(k.length).trim();
    return {
      verb: ACTION_VERBS[k],
      args: [rest, ...parts.slice(1)].filter(Boolean),
    };
  }
  return null;
}

/**
 * 把模型输出拆成「说话」和「动作」。
 *
 * @returns {{actions: Array<{verb:string,args:string[],raw:string}>, lines: string[], dropped: string[]}}
 */
function parseActions(raw) {
  const text = String(raw || '');
  const re = /\[([^[\]\n]{1,80})\]/g;
  const actions = [];
  const dropped = [];
  const spans = [];
  let m;
  while ((m = re.exec(text)) !== null) {
    const inner = String(m[1] || '').trim();
    if (!inner) continue;

    const hit = matchActionVerb(inner);
    if (hit) {
      actions.push({ verb: hit.verb, args: hit.args, raw: `[${inner}]` });
      spans.push([m.index, m.index + m[0].length]);
      continue;
    }
    /*
     * 认不出的方括号：如果是"像动作"的（以已知动词开头但格式怪），
     * 也删掉并记一笔 —— 下一轮她会看到"刚才那个动作没执行"。
     */
    if (LOOKS_LIKE_ACTION.test(inner)) {
      dropped.push(`[${inner}]`);
      spans.push([m.index, m.index + m[0].length]);
    }
  }

  // 只删掉**识别成动作 / 像动作**的方括号，其余原样保留
  let out = '';
  let cursor = 0;
  for (const [s, e] of spans) {
    out += text.slice(cursor, s);
    cursor = e;
  }
  out += text.slice(cursor);

  return { actions, lines: splitChat(out), dropped };
}

/** 正文 → 几条短句（去掉 Markdown、纯括号旁白、动作残渣）。 */
function splitChat(text) {
  return String(text || '')
    .replace(/\*\*/g, '')
    .replace(/`/g, '')
    .replace(/\[SILENT\]/gi, '')   // 沉默标记绝不能当正文发进游戏
    .replace(/^\s*[-*]\s+/gm, '')
    .split(/\n+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0)
    // 整行都是括号旁白 → 丢掉（QQ 助手那边也是这么处理的）
    .filter((s) => !/^[（(][^）)]*[）)]$/.test(s))
    .map((s) => s.slice(0, 120))
    .slice(0, 3);
}

async function say(text) {
  const t = String(text || '').replace(/\s+/g, ' ').trim().slice(0, 120);
  if (!t) return false;
  if (!bot || !bot.entity) return false;
  const gap = clamp(cfg.chatCooldownSec, 0, 10) * 1000;
  const wait = Math.max(0, lastSayAt + gap - Date.now());
  if (wait > 0) await sleep(wait);
  lastSayAt = Date.now();
  try {
    bot.chat(t);
    stats.replied++;
    session.win.chatOut++;
    session.tot.chatOut++;
    diag(`say -> ${t.slice(0, 60)}`);
    if (cfg.recordChat !== false) note(`我：${t}`);
    return true;
  } catch (e) {
    diag(`say failed: ${e.message}`);
    return false;
  }
}

/**
 * 造一个 Vec3。
 *
 * <p>优先用 `vec3` 包（package.json 里显式声明了，避免依赖 npm 的扁平提升）；
 * 拿不到时退回"克隆当前位置再改坐标"—— mineflayer 的所有位置 API 都要求真正的
 * Vec3（`distanceTo` / `floored` 是方法，裸对象会直接崩）。</p>
 */
let Vec3Ctor = null;
function vecOf(p) {
  if (Vec3Ctor === null) {
    try {
      // eslint-disable-next-line global-require
      Vec3Ctor = require('vec3');
    } catch {
      Vec3Ctor = false;
    }
  }
  if (Vec3Ctor) {
    return new Vec3Ctor(Number(p.x) || 0, Number(p.y) || 0, Number(p.z) || 0);
  }
  const base = bot.entity.position.clone();
  base.x = Number(p.x) || 0;
  base.y = Number(p.y) || 0;
  base.z = Number(p.z) || 0;
  return base;
}

function resolveTarget(args) {
  const a = (args || []).map((x) => String(x));
  if (a.length >= 3 && a.slice(0, 3).every((s) => /^-?\d+(\.\d+)?$/.test(s))) {
    return { x: Number(a[0]), y: Number(a[1]), z: Number(a[2]) };
  }
  const name = a.join(' ').trim();
  if (!name) return null;

  const world = readWorld();
  if (world[name]) return world[name];

  const player = Object.values((bot && bot.players) || {}).find(
    (p) => p && p.username && p.username.toLowerCase() === name.toLowerCase(),
  );
  if (player && player.entity) {
    return {
      x: player.entity.position.x,
      y: player.entity.position.y,
      z: player.entity.position.z,
    };
  }

  /*
   * 最后试"方块/类别"（2026-11-04）。
   *
   * <p>玩家说「去砍树」时，模型会写 `[去 树]` 或 `[去附近有树的地方]` ——
   * 这不是坐标也不是玩家名，但**最近的树**是能算出来的。不加这一步，
   * 她只会回「不知道在哪」，看着像不会走路。</p>
   */
  const block = nearestBlockPos(name, 48);
  if (block) return block;

  return null;
}

/**
 * 「你/您」这种人称代词 → 当前正在说话的人（2026-11-04）。
 *
 * <p>模型很爱写 `[跟着你]`、`[去你那儿]`，而 `resolveTarget('你')` 永远找不到
 * 名叫"你"的玩家 —— 于是动作静默失败，看着像不会走。</p>
 */
function derefPlayer(args, ctx) {
  const a = (args || []).map((x) => String(x));
  if (!ctx || !ctx.from || a.length === 0) return a;
  const first = a[0].trim();
  if (/^(你|您)(那儿|那里|那边|身边|旁边)?$/.test(first) || /^you$/i.test(first)) {
    return [ctx.from, ...a.slice(1)];
  }
  return a;
}

function withTimeout(promise, ms, message) {
  return Promise.race([
    promise,
    sleep(ms).then(() => {
      throw new Error(message || '超时');
    }),
  ]);
}

async function waitNear(target, timeoutMs) {
  const end = Date.now() + Math.max(3000, timeoutMs);
  const goal = vecOf(target);
  while (Date.now() < end) {
    if (!bot || !bot.entity) return false;
    if (bot.entity.position.distanceTo(goal) <= 2.2) return true;
    await sleep(400);
  }
  return false;
}

function findBlockByName(name) {
  const reg = bot && bot.registry && bot.registry.blocksByName;
  if (!reg) return null;
  const key = String(name || '').trim();
  if (!key) return null;
  if (reg[key]) return reg[key];
  const lower = key.toLowerCase();
  const found = Object.keys(reg).find((k) => k.toLowerCase() === lower)
    || Object.keys(reg).find((k) => k.toLowerCase().includes(lower));
  return found ? reg[found] : null;
}

function findItemByName(name) {
  // 中文 → 英文（「铁锭」→ iron_ingot）；认不出就原样拿去模糊匹配
  const key = normalizeName(String(name || '').trim());
  if (!key) return null;
  const items = (bot && bot.inventory && bot.inventory.items()) || [];
  return items.find((i) => i.name === key)
    || items.find((i) => i.name.toLowerCase().includes(key.toLowerCase()))
    || null;
}

// ------------------------------------------------------------------ 动作实现

async function actGoto(args) {
  if (!bot || !bot.pathfinder) return '寻路组件没加载，走不了（先 npm install）';
  const target = resolveTarget(args);
  if (!target) {
    /* 分两种失败说清楚：是"名字不认识"还是"认识但附近没有" —— 她下一轮才知道该换策略。 */
    const ids = blockIdsFor(args.join(' '));
    if (ids.length > 0) return `附近 48 格内没看到${args.join(' ')}`;
    return `不知道「${args.join(' ')}」在哪（可以先 [坐标 家] 存点）`;
  }
  const { goals } = require('mineflayer-pathfinder');
  bot.pathfinder.setGoal(new goals.GoalNear(
    Math.floor(target.x), Math.floor(target.y), Math.floor(target.z), 1,
  ));
  const ok = await waitNear(target, clamp(cfg.actionTimeoutSec, 5, 120) * 1000);
  if (!ok) return '还没走到（还在路上）';

  /*
   * 到了要说"附近有什么"（2026-11-05）。
   *
   * <p>原来只回一句"走到了"，模型不知道这地方有没有用 —— 于是它接着
   * 编下一个坐标，人就在石头堆里来回走。带上附近目标，它才能就地开工。</p>
   */
  const near = categoryTargets(8).slice(0, 2)
    .map((t) => `${t.label}（${t.x}, ${t.y}, ${t.z}）${Math.round(t.dist)} 格`)
    .join('、');
  const at = `(${Math.floor(target.x)}, ${Math.floor(target.y)}, ${Math.floor(target.z)})`;
  return near ? `走到了 ${at}，附近有：${near}` : `走到了 ${at}，附近没什么可挖的`;
}

/**
 * `[找 树]` / `[找 铁矿]` —— **一条动作完成"找到 + 走过去"**。
 *
 * <p>这是治"瞎报坐标"的药：让模型自己编坐标必然编错（它看不到世界），
 * 而"找什么"它是能说清的。</p>
 */
async function actFind(args) {
  if (!bot || !bot.entity) return '不在游戏里';
  const raw = (args || []).join(' ').trim();
  if (!raw) return '要找什么？（[找 树] / [找 铁矿] / [找 工作台]）';
  const pos = nearestBlockPos(raw, 64);
  if (!pos) return `64 格内没找到${raw}（换个方向，或者给我坐标）`;
  walkNear(pos, 1, 64);
  const ok = await waitNear(pos, 20_000);
  const at = `(${pos.x}, ${pos.y}, ${pos.z})`;
  return ok ? `找到${raw}了，在 ${at}，已经走到跟前` : `看到${raw}在 ${at}，但过不去`;
}

async function actCome(ctx) {
  if (!ctx.from) return '不知道要走到谁那儿';
  /*
   * 已经贴着了就别再"走到了"（2026-11-05）。
   * 日志里连刷三次 `[过来] -> 走到了 (0ms)`，她其实一直站在旁边 ——
   * 那句"走到了"会让模型以为刚完成了什么，于是接着做别的事。
   */
  const p = Object.values(bot.players || {}).find(
    (x) => x && x.username && x.username.toLowerCase() === String(ctx.from).toLowerCase(),
  );
  if (p && p.entity) {
    try {
      if (bot.entity.position.distanceTo(p.entity.position) < 2.5) {
        return '就在你旁边了';
      }
    } catch {
      /* 位置还没同步，按正常寻路走 */
    }
  }
  return actGoto([ctx.from]);
}

async function actFollow(args) {
  if (!bot || !bot.pathfinder) return '寻路组件没加载，跟不了';
  const name = (args || []).join(' ').trim();
  const player = Object.values(bot.players || {}).find(
    (p) => p && p.username && p.username.toLowerCase() === name.toLowerCase(),
  );
  if (!player || !player.entity) return `没看到 ${name || '（没说跟谁）'}`;
  const { goals } = require('mineflayer-pathfinder');
  bot.pathfinder.setGoal(new goals.GoalFollow(player.entity, 2), true);
  return `跟着 ${player.username}`;
}

function actStop() {
  if (bot && bot.pathfinder) {
    try {
      bot.pathfinder.setGoal(null);
    } catch {
      /* ignore */
    }
  }
  /*
   * 「停」要真的停住（2026-11-04）。
   *
   * 否则活力层两秒后就把她重新带走 —— 她会当着你的面"刚说停就走"，
   * 那是比不动更糟的观感。所以压 2 分钟不自动跟人/乱走。
   */
  ambientHoldUntil = Date.now() + 120_000;

  /*
   * 「停」也要停掉行为链（2026-11-05）。
   *
   * <p>否则她口头答应"好，不做了"，下一秒又接着去挖 —— 那是最伤信任的一种表现。</p>
   */
  const p = activePlan();
  if (p) {
    p.status = 'cancelled';
    p.updatedAt = Date.now();
    savePlans();
    diag(`plan: 被 [停] 取消「${p.title}」`);
    note(`停下了「${p.title}」`);
  }
  return '停下了';
}

async function actMine(args) {
  if (!cfg.allowBreakBlocks) return '配置里关了「允许挖方块」';
  if (!bot || !bot.entity) return '不在游戏里';
  const name = String(args[0] || '').trim();
  const count = clamp(Number(args[1]) || 1, 1, 32);
  if (!name) return '要挖什么？（例如 [挖 oak_log 8]）';
  if (!bot.collectBlock) return '采集组件没加载（先 npm install）';

  /*
   * 名字要兼容三种写法：`oak_log`、`橡木`、`树`（2026-11-04）。
   * 「树」不是注册表里的方块，它对应一批 `*_log`，所以按 id 列表找。
   */
  const ids = blockIdsFor(name);
  if (ids.length === 0) return `不认识方块「${name}」`;

  const positions = (bot.findBlocks({ matching: ids, maxDistance: 32, count }) || [])
    // 黑名单里的东西永远不挖（[清空] 会拆到箱子，挖矿也可能选中你放的方块）
    .filter((p) => {
      const b = bot.blockAt(p);
      return b && !isProtected(b.name);
    });
  if (positions.length === 0) return `附近 32 格内没找到 ${name}（或都在保护名单里）`;

  // 统计"这一类东西"的背包数量（挖树时可能是 birch_log 而不是 oak_log）
  const reg = (bot && bot.registry) || {};
  const targetNames = new Set();
  for (const id of ids) {
    const d = (reg.blocksById && reg.blocksById[id]) || (reg.blocks && reg.blocks[id]);
    if (d && d.name) targetNames.add(d.name);
  }
  const invCount = () => (bot.inventory.items() || [])
    .filter((i) => targetNames.size === 0 || targetNames.has(i.name))
    .reduce((s, i) => s + (i.count || 0), 0);

  const before = invCount();
  const blocks = positions.map((pos) => bot.blockAt(pos)).filter(Boolean);
  // 挖之前先看过去——"盯着自己正在挖的方块"是最便宜的真实感
  try {
    await bot.lookAt(positions[0].offset(0, 0.5, 0), false);
  } catch {
    /* 看不到就算了 */
  }
  const timeout = clamp(cfg.actionTimeoutSec, 5, 120) * 1000;
  try {
    await withTimeout(bot.collectBlock.collect(blocks, { ignoreNoPath: true }), timeout, '挖掘超时');
  } catch (e) {
    return `挖 ${name}：${e.message}`;
  }
  const got = Math.max(0, invCount() - before);
  session.win.mined += got;
  session.tot.mined += got;
  return got > 0 ? `挖 ${name}：捡到 ${got} 个` : `挖了 ${name}，但没捡到（可能掉进别的格子了）`;
}

/**
 * 哪些东西"合成出来就该放下"。
 *
 * <p>不放都是纯亏：工作台/熔炉/箱子这类**只有放着才有用**；
 * 而镐、面包、火把（火把其实该放，但常常要插在特定位置）之类不该自作主张。</p>
 */
const AUTO_PLACE = /^(crafting_table|furnace|blast_furnace|smoker|chest|barrel|stonecutter|loom|cartography_table|smithing_table|grindstone|composter|lectern|beehive|anvil|enchanting_table|bookshelf)$/;

const FACES = [
  { dx: 0, dy: -1, dz: 0 },
  { dx: 0, dy: 1, dz: 0 },
  { dx: 1, dy: 0, dz: 0 },
  { dx: -1, dy: 0, dz: 0 },
  { dx: 0, dy: 0, dz: 1 },
  { dx: 0, dy: 0, dz: -1 },
];

/**
 * 在她身边找一个能放方块的格子（2026-11-05）。
 *
 * <p><b>为什么需要</b>：`[放]` 原来必须带坐标，而模型"做好工作台"之后
 * 根本不知道附近哪一格是空的 —— 于是出现"做好了但没放下来"。</p>
 *
 * <p>顺序：脚下四周 8 格 → 抬高一格（卡在低洼处时用），取第一个
 * "目标是空气且至少一面能依托"的位置。</p>
 */
function findPlaceSpot() {
  if (!bot || !bot.entity) return null;
  const base = bot.entity.position.floored();
  const spots = [];
  for (const [dx, dz] of [[1, 0], [0, 1], [-1, 0], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]]) {
    spots.push([dx, 0, dz]);
    spots.push([dx, 1, dz]);
  }
  const refs = [[0, -1, 0], [0, 1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]];
  for (const [dx, dy, dz] of spots) {
    const p = base.offset(dx, dy, dz);
    const at = bot.blockAt(p);
    if (!at || at.boundingBox !== 'empty') continue;
    for (const [rx, ry, rz] of refs) {
      const ref = bot.blockAt(p.offset(rx, ry, rz));
      if (ref && ref.boundingBox === 'block') {
        return { pos: p, ref, face: vecOf({ x: -rx, y: -ry, z: -rz }) };
      }
    }
  }
  return null;
}

/** 把某个物品放到指定位置（actPlace 与"合成后自动放下"共用）。 */
async function placeItemAt(item, target, label) {
  try {
    await bot.equip(item, 'hand');
  } catch (e) {
    return `拿不出 ${label}：${e.message}`;
  }
  // 放置前看一眼目标格 —— 手眼一致，观感差别很大
  try {
    await bot.lookAt(target.offset(0, 0.5, 0), false);
  } catch {
    /* 看不到就算了 */
  }
  for (const f of FACES) {
    const ref = bot.blockAt(target.offset(f.dx, f.dy, f.dz));
    if (!ref || ref.boundingBox !== 'block') continue;
    try {
      await withTimeout(
        bot.placeBlock(ref, vecOf({ x: -f.dx, y: -f.dy, z: -f.dz })),
        clamp(cfg.actionTimeoutSec, 3, 60) * 1000,
        '放置超时',
      );
      session.win.placed++;
      session.tot.placed++;
      return `放好了 (${Math.floor(target.x)}, ${Math.floor(target.y)}, ${Math.floor(target.z)})`;
    } catch (e) {
      return `放不上去：${e.message}`;
    }
  }
  return '那一格没有可依托的面，放不上';
}

/**
 * 捡地上的掉落物（2026-11-05）。
 *
 * <p><b>为什么交给模型决定</b>：人的判断是"这玩意儿值不值得捡、背包还有没有地方"。
 * 全自动捡只会在满背包时反复发呆，所以这里只提供**能力**，
 * 要不要捡由她看着【背包】里的剩余格子自己决定。</p>
 *
 * <p>写法：`[捡]` 捡最近几个；`[捡 oak_log]` 只捡指定名字的。</p>
 */
async function actPickup(args) {
  if (!bot || !bot.entity) return '不在游戏里';
  const want = args[0] ? normalizeName(String(args[0])).toLowerCase() : '';
  const me = bot.entity.position;

  const drops = Object.values(bot.entities || {})
    .filter((e) => e && e !== bot.entity && e.name === 'item' && e.position)
    .map((e) => {
      let d = 99;
      try {
        d = e.position.distanceTo(me);
      } catch {
        /* 位置还没同步 */
      }
      return { e, d };
    })
    .filter((x) => x.d < 12)
    .sort((a, b) => a.d - b.d)
    .slice(0, 4);

  if (drops.length === 0) return want ? `附近没有 ${want} 的掉落物` : '附近没有掉落物';
  if (freeSlots() <= 0) return '背包满了，捡了也没地方放';

  const before = invItems().reduce((s, i) => s + (i.count || 0), 0);
  for (const d of drops) {
    try {
      walkNear(d.e.position, 1, 12);
      await waitNear(d.e.position, 4000);
    } catch {
      /* 这一个捡不到就试下一个 */
    }
  }
  const after = invItems().reduce((s, i) => s + (i.count || 0), 0);
  const got = Math.max(0, after - before);
  return got > 0
    ? `捡到了 ${got} 个东西（还剩 ${freeSlots()} 格）`
    : '走过去但没捡到（可能被别人捡了，或掉进岩浆）';
}

/**
 * 对目标"使用"（右击）—— **一条原语解锁一大片行为**（2026-11-05）。
 *
 * <p>锄地、播种、浇水、开门、按按钮、点火、放末影之眼、喂动物、用骨粉……
 * 在协议层都是同一件事：`activateBlock`。所以不写十个动作，只写这一个。</p>
 *
 * <p>写法：`[锄地]` `[播种]` `[浇水]` `[用 oak_door]` `[用 bone_meal 128 64 -302]`</p>
 */
async function actUse(args) {
  if (!bot || !bot.entity) return '不在游戏里';
  const a = (args || []).map((x) => String(x).trim()).filter(Boolean);
  const text = a.join(' ');

  let itemRe = null;
  let blockRe = null;
  if (/锄|耕地/.test(text)) {
    itemRe = /_hoe$/;
    blockRe = /^(grass_block|dirt|coarse_dirt|rooted_dirt|podzol|dirt_path)$/;
  } else if (/播种|种下|种/.test(text)) {
    itemRe = /seeds$/;
    blockRe = /^farmland$/;
  } else if (/浇|灌溉/.test(text)) {
    itemRe = /water_bucket$/;
    blockRe = /^farmland$/;
  }

  let target = null;
  const nums = a.filter((x) => /^-?\d+(\.\d+)?$/.test(x)).map(Number);
  if (nums.length >= 3) {
    target = vecOf({ x: nums[0], y: nums[1], z: nums[2] });
  }
  if (!target) {
    const nameArg = a.find((x) => /^[a-z0-9_]+$/.test(x));
    if (nameArg) {
      const pos = nearestBlockPos(nameArg, 6);
      if (pos) target = vecOf({ x: pos.x, y: pos.y, z: pos.z });
    }
  }
  if (!target && blockRe) {
    const reg = (bot.registry && bot.registry.blocksByName) || {};
    const ids = Object.entries(reg).filter(([n]) => blockRe.test(n)).map(([, d]) => d.id);
    if (ids.length > 0) {
      const b = bot.findBlock({ matching: ids, maxDistance: 6 });
      if (b) target = b.position;
    }
  }

  if (itemRe) {
    const item = invItems().find((i) => itemRe.test(i.name));
    if (!item) return '背包里没有要用的东西';
    try {
      await bot.equip(item, 'hand');
    } catch (e) {
      return `拿不出 ${item.name}：${e.message}`;
    }
  }

  if (!target) {
    /*
     * 锄地/播种/浇水都必须有目标方块。找不到就**说清楚**，
     * 不要退化成"用了一下手上的东西" —— 那句话会让她以为做成了，
     * 计划继续往下走，最后整条链空转。
     */
    if (blockRe) {
      return itemRe === /^farmland$/
        ? '附近没有耕地，得先用锄头锄一块'
        : '附近没有能用的地方（要在草地上锄，或者找一块耕地）';
    }
    // 没有目标 = 用手里这件东西（末影珍珠、水桶、骨粉撒地上）
    try {
      bot.activateItem();
      await sleep(300);
      return '用了一下手上的东西';
    } catch (e) {
      return `用不了：${e.message}`;
    }
  }

  const block = bot.blockAt(target);
  if (!block) return '那一格看不到';
  try {
    bot.activateBlock(block);
    await sleep(400);
    return `用了 ${block.name}（${Math.round(target.x)}, ${Math.round(target.y)}, ${Math.round(target.z)}）`;
  } catch (e) {
    return `用不了 ${block.name}：${e.message}`;
  }
}

// ------------------------------------------------------------------ 新原语（2026-11-05）

/*
 * <h3>为什么是"原语"而不是"功能"</h3>
 *
 * <p>种地、盖房、打龙这些念头不该各写一套实现 —— 它们都是**同一批原语的不同排列**。
 * 这一节补的就是缺口最大的三条：容器（物资）、传送门（跨维度）、蓝图（盖房）。</p>
 *
 * <p>参考对象：Baritone 的 `build`（蓝图逐块 + 材料预检）、Litematica 的
 * 调色板+分层结构、Mindcraft 的 memory bank（设施坐标）。</p>
 */

/** 能当"仓库/工作站"用的方块。 */
const CONTAINER_BLOCK = /^(chest|trapped_chest|barrel|shulker_box|ender_chest|furnace|blast_furnace|smoker|dispenser|dropper|hopper)$/;

function findContainerBlock(maxDist = 8) {
  const reg = (bot && bot.registry && bot.registry.blocksByName) || {};
  const ids = Object.entries(reg)
    .filter(([n]) => CONTAINER_BLOCK.test(n))
    .map(([, d]) => d.id);
  if (ids.length === 0) return null;
  return bot.findBlock({ matching: ids, maxDistance: maxDist });
}

/**
 * 容器存取：`[存 箱子 oak_log 8]` / `[取 箱子 oak_log 8]` / `[看箱子]`
 *
 * <p>**这是"物资链"的地基**：没有它，她挖的东西只能一直背在身上，
 * 计划一旦跨天就没法做（背包会满）。</p>
 */
async function actContainer(args) {
  if (!bot || !bot.entity) return '不在游戏里';
  const a = (args || []).map((x) => String(x)).filter(Boolean);
  const text = a.join(' ');
  const view = /看|查|有什么/.test(text);
  const take = /取|拿|取出|拿出来/.test(text);
  const put = !view && !take;

  const block = findContainerBlock(8);
  if (!block) return '附近 8 格内没有箱子/熔炉';

  const nameArg = a.find((x) => /^[a-z0-9_]+$/.test(x) && !CONTAINER_BLOCK.test(x));
  const numArg = a.find((x) => /^\d+$/.test(x));
  const want = nameArg ? normalizeName(nameArg) : '';
  const count = Math.max(1, Number(numArg) || 1);

  try {
    walkNear(block.position, 2, 8);
    await waitNear(block.position, 4000);
    const win = await bot.openContainer(block);
    try {
      if (view) {
        const list = (win.containerItems() || []).slice(0, 12)
          .map((i) => `${i.name}×${i.count}`).join(' ');
        return `箱子里：${list || '空的'}`;
      }
      if (put) {
        const item = want
          ? invItems().find((i) => i.name === want) || invItems().find((i) => i.name.includes(want))
          : invItems()[0];
        if (!item) return `背包里没有 ${want || '可存的东西'}`;
        const n = Math.min(count, item.count);
        await win.deposit(item.type, null, n);
        return `存了 ${item.name}×${n}`;
      }
      const slots = (win.containerItems() || []).filter(
        (i) => !want || i.name === want || i.name.includes(want),
      );
      if (slots.length === 0) return `箱子里没有 ${want || '东西'}`;
      let left = count;
      let got = 0;
      for (const it of slots) {
        if (left <= 0) break;
        const n = Math.min(left, it.count);
        await win.withdraw(it.type, null, n);
        got += n;
        left -= n;
      }
      return `取了 ${got} 个${want ? ` ${want}` : ''}`;
    } finally {
      try {
        win.close();
      } catch {
        /* ignore */
      }
    }
  } catch (e) {
    return `开不了容器：${e.message}`;
  }
}

/** 走进最近的传送门（下界/末地）。打龙、去下界都靠它。 */
async function actPortal() {
  if (!bot || !bot.entity) return '不在游戏里';
  const reg = (bot && bot.registry && bot.registry.blocksByName) || {};
  const ids = ['nether_portal', 'end_portal', 'end_gateway']
    .map((n) => (reg[n] ? reg[n].id : null))
    .filter(Boolean);
  if (ids.length === 0) return '这个版本没有传送门方块';
  const b = bot.findBlock({ matching: ids, maxDistance: 48 });
  if (!b) return '附近 48 格内没有传送门';
  walkNear(b.position, 1, 48);
  await waitNear(b.position, 8000);
  return `走到 ${b.name} 门口了（站进去就会传送）`;
}

// ---------------- 蓝图（Litematica / Baritone build 的简化版） ----------------

/*
 * 不解析 `.litematic`（那是 NBT + 多层 region，工作量和收益不成正比）。
 * 用**同构的简化格式**：调色板 + 分层字符画 —— 和 Litematica 的思路一致，
 * 但可以直接手写、可以让模型生成。
 *
 * <pre>
 * {
 *   "name": "hut",
 *   "palette": { "P": "oak_planks", "L": "oak_log", "G": "glass" },
 *   "layers": [
 *     ["LLLLL", "L...L", "L...L", "L...L", "LLLLL"],   // y=0
 *     ["PPPPP", "P...P", "P...P", "P...P", "PPPPP"]    // y=1
 *   ]
 * }
 * </pre>
 *
 * 关键不是"能盖"，而是**盖之前先算材料**（Baritone 的做法）——
 * 否则盖到一半缺料，她会把自己刚放的墙拆了。
 */

function blueprintsDir() {
  return path.join(api.dataDir, 'blueprints');
}

/**
 * 第一次打开时放一张示范蓝图（5×5 小木屋）。
 *
 * <p>留空目录只会让人对着"还没有蓝图"发愣；给一张能立刻盖出来的图，
 * 她跑一遍就知道这套东西怎么用。</p>
 */
function writeSampleBlueprint() {
  /*
   * 3×3×3 的小屋子：材料大约 24 木板 + 2 原木。
   * 故意做得很小 —— 示范图的第一要求是"她真能盖完"，不是好看。
   */
  const sample = {
    name: 'hut',
    palette: { P: 'oak_planks', L: 'oak_log' },
    layers: [
      ['PPP', 'PPP', 'PPP'],   // 地板
      ['L.L', 'P.P', 'PP.'],   // 墙（右下角留门）
      ['PPP', 'PPP', 'PPP'],   // 屋顶
    ],
  };
  try {
    fs.mkdirSync(blueprintsDir(), { recursive: true });
    writeJsonFile(path.join(blueprintsDir(), 'hut.json'), sample);
    diag('blueprints: 已生成示范蓝图 hut.json');
  } catch (e) {
    diag(`写示范蓝图失败：${e.message}`);
  }
}

function readBlueprint(name) {
  const n = String(name || '').trim().replace(/\.json$/i, '');
  if (!n) return null;
  const p = path.join(blueprintsDir(), `${n}.json`);
  const raw = readJsonFile(p, null);
  if (!raw || !Array.isArray(raw.layers) || !raw.palette) return null;
  return raw;
}

/** 蓝图里一共要多少方块。 */
function blueprintCost(bp) {
  const cost = {};
  for (const layer of bp.layers) {
    for (const row of layer || []) {
      for (const ch of String(row)) {
        if (ch === '.' || ch === ' ') continue;
        const b = bp.palette[ch];
        if (b) cost[b] = (cost[b] || 0) + 1;
      }
    }
  }
  return cost;
}

/** 背包里还缺什么。 */
function blueprintMissing(bp) {
  const cost = blueprintCost(bp);
  const inv = {};
  for (const i of invItems()) inv[i.name] = (inv[i.name] || 0) + i.count;
  const miss = [];
  for (const [name, need] of Object.entries(cost)) {
    const have = inv[name] || 0;
    if (have < need) miss.push(`${name} ${have}/${need}`);
  }
  return miss;
}

/** 把一格放成指定方块（复用 FACES 找依托面）。 */
async function placeOneBlock(pos, item) {
  const cur = bot.blockAt(pos);
  if (cur && cur.name === item.name) return 'skip';
  if (cur && cur.boundingBox === 'block') return 'occupied';
  try {
    await bot.equip(item, 'hand');
  } catch (e) {
    return `equip:${e.message}`;
  }
  for (const f of FACES) {
    const ref = bot.blockAt(pos.offset(f.dx, f.dy, f.dz));
    if (!ref || ref.boundingBox !== 'block') continue;
    try {
      await bot.placeBlock(ref, vecOf({ x: -f.dx, y: -f.dy, z: -f.dz }));
      return 'ok';
    } catch {
      /* 换下一个面 */
    }
  }
  return 'noface';
}

/**
 * 盖房子：`[盖 hut]` / `[盖 hut 128 64 -302]`
 *
 * <p>顺序是**从下往上**（y 升序），否则上面的方块没有依托面。
 * 上限 `buildMaxBlocks` 防止模型拿一张 3000 块的图把服务器卡死。</p>
 */
async function actBuild(args) {
  if (!cfg.allowPlaceBlocks) return '配置里关了「允许放方块」';
  if (!bot || !bot.entity) return '不在游戏里';
  const a = (args || []).map(String);
  const name = a[0] || '';
  if (!name) {
    let list = [];
    try {
      list = fs.readdirSync(blueprintsDir()).filter((f) => f.endsWith('.json')).map((f) => f.replace(/\.json$/, ''));
    } catch {
      /* 目录还没建 */
    }
    if (list.length === 0) {
      writeSampleBlueprint();
      return '还没有蓝图，我先放了一张示范的（hut，3×3 小木屋，约 22 木板 + 2 原木）—— 说 [盖 hut] 就能试';
    }
    return `要盖哪个？现有的：${list.join('、')}`;
  }

  const bp = readBlueprint(name);
  if (!bp) return `没有蓝图「${name}」（要放在 blueprints/${name}.json）`;

  const missing = blueprintMissing(bp);
  if (missing.length > 0) {
    return `材料不够：${missing.join('、')} —— 先去收集（或 [取 箱子 xxx]），凑齐我再盖`;
  }

  const nums = a.filter((x) => /^-?\d+$/.test(x)).map(Number);
  const base = nums.length >= 3
    ? vecOf({ x: nums[0], y: nums[1], z: nums[2] })
    : bot.entity.position.offset(2, 0, 0).floored();

  const max = clamp(cfg.buildMaxBlocks, 10, 2000);
  const inv = {};
  for (const i of invItems()) inv[i.name] = i;
  let placed = 0;
  let skipped = 0;

  for (let y = 0; y < bp.layers.length; y++) {
    const layer = bp.layers[y];
    for (let z = 0; z < layer.length; z++) {
      const row = String(layer[z] || '');
      for (let x = 0; x < row.length; x++) {
        const ch = row[x];
        if (ch === '.' || ch === ' ') continue;
        const blockName = bp.palette[ch];
        if (!blockName) continue;
        const item = inv[blockName];
        if (!item) continue;
        if (placed >= max) {
          note(`盖「${bp.name || name}」到上限 ${max} 块就停了`);
          return `盖到 ${placed} 块停手（上限 ${max}，怕把地方卡住）`;
        }
        const pos = base.offset(x, y, z);
        const r = await placeOneBlock(pos, item);
        if (r === 'ok') placed++;
        else if (r === 'skip') skipped++;
      }
    }
  }
  note(`盖了「${bp.name || name}」：${placed} 块（跳过 ${skipped} 块已有）`);
  return `盖好了：放了 ${placed} 块，跳过 ${skipped} 块本来就有（中心在 ${Math.round(base.x)}, ${Math.round(base.y)}, ${Math.round(base.z)}）`;
}

// ---------------- 技能库（Voyager 的简化版） ----------------

/*
 * <h3>为什么值得做，但必须关在笼子里</h3>
 *
 * <p>Voyager 的核心不是"会写代码"，而是**把多步操作沉淀成可复用的技能**：
 * "种一块地"从 8 步计划变成 1 个技能，200 步的长链才有活路。</p>
 *
 * <p>风险也很明确：模型写的 JS 能在她的进程里做任何事。所以这里：</p>
 * <ul>
 *   <li>技能**单独目录**（`skills/&lt;name&gt;/&lt;version&gt;/`），不碰 main.js；</li>
 *   <li>执行前做**静态检查**，出现 require/process/fs/eval 直接拒绝；</li>
 *   <li>跑在 `vm` 沙箱里，只给 bot + sleep，8 秒同步超时 + 20 秒总超时；</li>
 *   <li>连续失败 3 次自动停用（写进 meta.json），人工审核后才能再开。</li>
 * </ul>
 */

const SKILL_BAD = /\brequire\s*\(|\bprocess\b|\bchild_process\b|\bfs\b|\beval\s*\(|new\s+Function|\bimport\s*\(|\bglobalThis\b/;

function skillsDir() {
  return path.join(api.dataDir, 'skills');
}

function listSkills() {
  try {
    return fs.readdirSync(skillsDir(), { withFileTypes: true })
      .filter((d) => d.isDirectory())
      .map((d) => d.name);
  } catch {
    return [];
  }
}

/** 取某个技能的最新版本。 */
function readSkill(name) {
  const dir = path.join(skillsDir(), String(name || '').trim());
  let versions = [];
  try {
    versions = fs.readdirSync(dir, { withFileTypes: true })
      .filter((d) => d.isDirectory())
      .map((d) => d.name)
      .sort();
  } catch {
    return null;
  }
  if (versions.length === 0) return null;
  const v = versions[versions.length - 1];
  const codePath = path.join(dir, v, 'code.js');
  let code = '';
  try {
    code = fs.readFileSync(codePath, 'utf8');
  } catch {
    return null;
  }
  return {
    name: String(name).trim(),
    version: v,
    code,
    codePath,
    meta: readJsonFile(path.join(dir, v, 'meta.json'), {}) || {},
  };
}

/**
 * 跑一个技能：`[技能 种地]`
 *
 * <p>技能约定：导出（`module.exports` 或全局 `run`）一个函数，
 * 参数是 bot，可以 await。</p>
 */
async function actSkill(args) {
  const name = String((args || [])[0] || '').trim();
  if (!name) {
    const list = listSkills();
    return list.length ? `现有技能：${list.join('、')}（[技能 名字] 跑一个）` : '还没有技能（放 skills/<名字>/1/code.js）';
  }
  const s = readSkill(name);
  if (!s) return `没有技能「${name}」`;
  if (s.meta.disabled) return `技能「${name}」被停用了（失败太多次，需要人工看一遍）`;
  if (SKILL_BAD.test(s.code)) {
    diag(`skill: 「${name}」含危险调用，拒绝执行`);
    return `技能「${name}」里有危险调用，拒绝执行`;
  }

  // eslint-disable-next-line global-require
  const vm = require('node:vm');
  const sandbox = {
    bot,
    sleep,
    diag,
    /*
     * `module` / `exports` 必须给：技能约定用 `module.exports = ...` 导出，
     * 少了这两样，新写的技能一律报 `module is not defined`。
     */
    module: { exports: {} },
    exports: {},
    console: { log: () => {}, error: () => {} },
    Math,
    Date,
    JSON,
    Number,
    String,
    Boolean,
    Array,
    Object,
    Promise,
  };
  const metaPath = path.join(path.dirname(s.codePath), 'meta.json');
  try {
    const ret = new vm.Script(s.code, { filename: `skill:${name}` })
      .runInNewContext(sandbox, { timeout: 8000 });
    const run = typeof ret === 'function' ? ret : sandbox.run;
    if (typeof run !== 'function') return `技能「${name}」没有导出可执行函数`;
    const out = await withTimeout(Promise.resolve(run(bot)), 20_000, '技能超时');
    s.meta.lastRunAt = Date.now();
    s.meta.ok = true;
    s.meta.fails = 0;
    writeJsonFile(metaPath, s.meta);
    note(`用了技能「${name}」`);
    return `技能「${name}」跑完了${out ? `：${String(out).slice(0, 40)}` : ''}`;
  } catch (e) {
    s.meta.fails = (Number(s.meta.fails) || 0) + 1;
    s.meta.lastError = String(e.message || e).slice(0, 80);
    if (s.meta.fails >= 3) {
      s.meta.disabled = true;
      log('warn', `技能「${name}」连续失败 ${s.meta.fails} 次，已自动停用`);
    }
    writeJsonFile(metaPath, s.meta);
    return `技能「${name}」失败（第 ${s.meta.fails} 次）：${e.message}`;
  }
}

// ---------------- 设施记忆（Mindcraft memory bank） ----------------

/*
 * <p>人不会每次重新找箱子 —— 她"记得那儿有个箱子"。这是同类项目里
 * 成本最低、观感提升最明显的一条：走过去、放下东西，不用满地转。</p>
 */

function placesPath() {
  return path.join(api.dataDir, 'places.json');
}

const FACILITY_BLOCK = /^(chest|trapped_chest|barrel|shulker_box|ender_chest|crafting_table|furnace|blast_furnace|smoker|bed|anvil|enchanting_table|brewing_stand)$/;

/** 每 30 秒顺手记一笔附近的工作站位置（8 格去重，最多 60 条）。 */
function recordFacilities() {
  if (!bot || !bot.entity) return;
  const reg = (bot.registry && bot.registry.blocksByName) || {};
  const ids = Object.entries(reg).filter(([n]) => FACILITY_BLOCK.test(n)).map(([, d]) => d.id);
  if (ids.length === 0) return;
  const found = bot.findBlocks({ matching: ids, maxDistance: 12, count: 24 }) || [];
  if (found.length === 0) return;

  const db = readJsonFile(placesPath(), { places: [] }) || { places: [] };
  const list = Array.isArray(db.places) ? db.places : [];
  let added = 0;
  for (const p of found) {
    const b = bot.blockAt(p);
    /*
     * 必须是真正的方块，而且确实是我们关心的那类：
     * `findBlocks` 给的坐标可能已经变了（被挖走 / 区块还没同步），
     * 那一格现在可能是个土块 —— 不筛的话会把"土块"记成设施。
     */
    if (!b || !b.name || b.boundingBox !== 'block' || !FACILITY_BLOCK.test(b.name)) continue;
    const key = `${b.name}@${Math.round(p.x / 8)},${Math.round(p.y / 8)},${Math.round(p.z / 8)}`;
    if (list.some((x) => x && x.key === key)) continue;
    list.push({ key, name: b.name, x: p.x, y: p.y, z: p.z, at: Date.now() });
    added++;
  }
  if (added > 0) {
    db.places = list.slice(-60);
    writeJsonFile(placesPath(), db);
    diag(`facilities: 新记下 ${added} 个设施`);
  }
}

/** 提示词里的"你记得的设施"，最多 4 条。 */
function facilitiesBlock() {
  const db = readJsonFile(placesPath(), { places: [] }) || {};
  const list = (db.places || []).slice(-4);
  if (list.length === 0) return '';
  const lines = list.map((x) => `· ${x.name} (${Math.round(x.x)}, ${Math.round(x.y)}, ${Math.round(x.z)})`);
  return `【你记得的设施】\n${lines.join('\n')}\n（走过路过记下的，要用就走过去。）`;
}

// ---------------- 区域原语（Baritone 借鉴，2026-11-05） ----------------

/*
 * Baritone 最值钱的不是"会挖矿"，而是这几个**区域级动作**：
 * `cleararea` / `walls` / `pillar` / `tunnel` / `farm`。
 *
 * <p>它们的共同点是"一次操作覆盖一片空间"—— 用坐标循环就能实现，
 * 但少了它们，模型只能用 `[放]` 一格一格堆，计划会碎成 40 步。</p>
 *
 * <p><b>黑名单</b>（{@link isProtected}）是所有破坏类动作的前置：
 * 没有它，`[清空]` 会把你的箱子、末影箱一起清掉。</p>
 */

/** 名字是否在"永远别碰"的清单里（支持 `前缀*`）。 */
function isProtected(name) {
  const n = String(name || '');
  if (!n) return true;
  return String(cfg.noTouchBlocks || '')
    .split(/[,，\s]+/)
    .filter(Boolean)
    .some((p) => (p.endsWith('*') ? n.startsWith(p.slice(0, -1)) : n === p));
}

/** 她朝向的水平单位向量。 */
function facingDir() {
  const yaw = Number(bot.entity.yaw) || 0;
  return { x: -Math.sin(yaw), z: -Math.cos(yaw) };
}

/**
 * 清空一块区域：`[清空 4]`（脚前 4×3×4）或 `[清空 x y z 长 高 宽]`
 *
 * <p>盖房前清场、挖地下室、平一小块地都用它。受 `allowBreakBlocks`、
 * 黑名单和 `clearMaxBlocks` 三重限制。</p>
 */
async function actClear(args) {
  if (!cfg.allowBreakBlocks) return '配置里关了「允许挖方块」';
  if (!bot || !bot.entity) return '不在游戏里';
  const nums = (args || []).filter((x) => /^-?\d+$/.test(String(x))).map(Number);
  let base = null;
  let w = 4;
  let h = 3;
  let d = 4;
  if (nums.length >= 6) {
    base = vecOf({ x: nums[0], y: nums[1], z: nums[2] });
    w = clamp(nums[3], 1, 16);
    h = clamp(nums[4], 1, 8);
    d = clamp(nums[5], 1, 16);
  } else {
    const n = clamp(nums[0] || 4, 1, 8);
    w = n;
    d = n;
    h = 3;
    const f = facingDir();
    /*
     * 从**脚下一层**开始清（y-1），否则 `[清空 4]` 清的是空气 ——
     * 玩家脚下那格是空气，真正要平的是脚下和膝盖那两层。
     */
    base = bot.entity.position.floored()
      .offset(Math.round(f.x * 2), -1, Math.round(f.z * 2));
  }

  const max = clamp(cfg.clearMaxBlocks, 10, 500);
  let dug = 0;
  let skipped = 0;
  for (let y = 0; y < h; y++) {
    for (let z = 0; z < d; z++) {
      for (let x = 0; x < w; x++) {
        const pos = base.offset(x, y, z);
        const b = bot.blockAt(pos);
        if (!b || b.boundingBox === 'empty') continue;
        if (isProtected(b.name)) {
          skipped++;
          continue;
        }
        if (dug >= max) {
          return `清了 ${dug} 块就停手（上限 ${max}，剩下的下次再说）`;
        }
        try {
          await bot.dig(b);
          dug++;
        } catch {
          skipped++;
        }
      }
    }
  }
  note(`清空了一块区域：${dug} 块`);
  return `清了 ${dug} 块${skipped ? `（跳过 ${skipped} 块空位/受保护的）` : ''}`;
}

/** 砌一圈墙：`[围栏 5 5]`（长 宽，用背包里的木板/圆石）。 */
async function actWalls(args) {
  if (!cfg.allowPlaceBlocks) return '配置里关了「允许放方块」';
  if (!bot || !bot.entity) return '不在游戏里';
  const nums = (args || []).filter((x) => /^\d+$/.test(String(x))).map(Number);
  const w = clamp(nums[0] || 5, 3, 32);
  const d = clamp(nums[1] || 5, 3, 32);
  const item = invItems().find((i) => /planks|cobblestone|stone|bricks|dirt/.test(i.name));
  if (!item) return '背包里没有能砌墙的方块（木板/圆石都行）';

  const f = facingDir();
  const base = bot.entity.position.floored().offset(Math.round(f.x * 2), 0, Math.round(f.z * 2));
  const ring = [];
  for (let x = 0; x < w; x++) {
    ring.push([x, 0]);
    ring.push([x, d - 1]);
  }
  for (let z = 1; z < d - 1; z++) {
    ring.push([0, z]);
    ring.push([w - 1, z]);
  }
  let placed = 0;
  for (const [x, z] of ring) {
    const r = await placeOneBlock(base.offset(x, 0, z), item);
    if (r === 'ok') placed++;
  }
  note(`围了一圈墙：${placed} 块`);
  return `围了一圈：放了 ${placed} 块（${w}×${d}）`;
}

/**
 * 垫柱：`[垫柱 5]`
 *
 * <p>用 pathfinder 的 1×1 塔模式（Baritone 的 `pillar` 也是这个思路），
 * 比自己写"跳一下放一块"稳得多。</p>
 */
async function actPillar(args) {
  if (!cfg.allowPlaceBlocks) return '配置里关了「允许放方块」';
  if (!bot || !bot.entity) return '不在游戏里';
  const n = clamp(Number(args[0]) || 3, 1, 20);
  let Movements;
  let goals;
  try {
    // eslint-disable-next-line global-require
    ({ Movements, goals } = require('mineflayer-pathfinder'));
    // Movements 构造时会读 bot.registry（方块表）—— 表没准备好就会炸，所以要单独兜住
    if (typeof Movements !== 'function') throw new Error('pathfinder 里没有 Movements');
  } catch (e) {
    return `垫柱需要 pathfinder 的 Movements：${e.message}`;
  }
  try {
    const m = new Movements(bot);
    m.canDig = false;
    m.canPlaceBlocks = true;
    m.allow1by1towers = true;
    bot.pathfinder.setMovements(m);
    const p = bot.entity.position.floored();
    bot.pathfinder.setGoal(new goals.GoalNear(p.x, p.y + n, p.z, 1));
    const t0 = Date.now();
    while (pfMoving() && Date.now() - t0 < 20_000) {
      await sleep(300);
    }
    return `往上垫到大约 ${p.y + n} 高（手里有方块才垫得上去）`;
  } catch (e) {
    return `垫柱失败：${e.message}`;
  } finally {
    setupMovements();   // 恢复"不乱挖不乱放"的默认设置
  }
}

/** 挖一条隧道：`[隧道 8]`（朝前，2 格高）。 */
async function actTunnel(args) {
  if (!cfg.allowBreakBlocks) return '配置里关了「允许挖方块」';
  if (!bot || !bot.entity) return '不在游戏里';
  const n = clamp(Number(args[0]) || 6, 1, 32);
  const f = facingDir();
  let dug = 0;
  const start = bot.entity.position.floored();
  for (let i = 1; i <= n; i++) {
    const pos = start.offset(Math.round(f.x * i), 0, Math.round(f.z * i));
    for (const dy of [0, 1]) {
      const b = bot.blockAt(pos.offset(0, dy, 0));
      if (!b || b.boundingBox === 'empty' || isProtected(b.name)) continue;
      try {
        await bot.dig(b);
        dug++;
      } catch {
        /* 这一块挖不动，继续下一格 */
      }
    }
  }
  walkNear(start.offset(Math.round(f.x * n), 0, Math.round(f.z * n)), 1, n + 6);
  note(`挖了条隧道：${dug} 块`);
  return `挖了 ${dug} 块，隧道大概 ${n} 格深`;
}

/**
 * 开荒种地：`[开荒]` / `[种地]`
 *
 * <p>这是 Baritone `farm` 的布局：**围着水源锄一圈**（水周围 1 格留空），
 * 有种子就顺手种下。没有水就直接在脚下锄 —— 长不长是另一回事。</p>
 */
async function actFarm() {
  if (!bot || !bot.entity) return '不在游戏里';
  const hoe = invItems().find((i) => /_hoe$/.test(i.name));
  if (!hoe) return '没有锄头（先 [合成 wooden_hoe 1]，需要木板+木棍）';

  const reg = (bot.registry && bot.registry.blocksByName) || {};
  const waterId = reg.water ? reg.water.id : null;
  const water = waterId != null ? bot.findBlock({ matching: waterId, maxDistance: 16 }) : null;
  const center = water ? water.position : bot.entity.position.floored();

  await bot.equip(hoe, 'hand');
  let tilled = 0;
  const cells = [];
  for (let dx = -2; dx <= 2; dx++) {
    for (let dz = -2; dz <= 2; dz++) {
      // 水源正上方 + 紧贴的一圈留出来（水会流、也免得踩坏）
      if (water && Math.abs(dx) <= 1 && Math.abs(dz) <= 1) continue;
      const pos = center.offset(dx, 0, dz);
      const b = bot.blockAt(pos);
      if (!b) continue;
      const isFarmland = b.name === 'farmland';
      const isSoil = /^(grass_block|dirt|coarse_dirt|rooted_dirt)$/.test(b.name);
      if (!isFarmland && !isSoil) continue;

      /*
       * 已经是耕地也要收进 cells（2026-11-05）。
       * 否则"先锄一遍、回头补种"这种操作会因为 tilled 已经是 farmland
       * 而跳过它 —— 表现是她站在一块空耕地前说"没地可种"。
       */
      cells.push(pos);
      if (isFarmland) continue;

      try {
        bot.activateBlock(b);
        tilled++;
        await sleep(150);
      } catch {
        /* 这一格锄不动 */
      }
    }
  }

  const seeds = invItems().find((i) => /seeds$/.test(i.name));
  if (!seeds) {
    return `锄了 ${tilled} 块地${water ? '（挨着水）' : ''}，但身上没种子 —— 挖点草方块捡种子`;
  }
  await bot.equip(seeds, 'hand');
  let planted = 0;
  for (const pos of cells) {
    const b = bot.blockAt(pos);
    if (!b || b.name !== 'farmland') continue;
    try {
      bot.activateBlock(b);
      planted++;
      await sleep(120);
    } catch {
      /* 这一格种不下 */
    }
  }
  note(`开了块地：锄 ${tilled}、种 ${planted}`);
  return `锄了 ${tilled} 块，种下 ${planted} 块${water ? '（在水边）' : '（附近没水，可能长不好）'}`;
}

/**
 * 目标链（2026-11-05）：需要工作台但附近没有 → **自己搞定**。
 *
 * <p>顺序：附近找 → 背包里有就放下 → 有木板就做一个再放下。
 * 以前这三步要靠玩家催三轮（"做个工作台" → "放下啊" → "现在用它做镐"），
 * 现在一步到位 —— 这是同类项目里最影响"像个人"的地方：**别让人重复催同一件事**。</p>
 */
async function ensureCraftingTable() {
  const def = findBlockByName('crafting_table');
  if (!def) return null;
  const near = bot.findBlock({ matching: def.id, maxDistance: 16 });
  if (near) return near;

  let item = findItemByName('crafting_table');
  if (!item) {
    const plank = findItemByName('oak_planks') || findItemByName('planks');
    const rec = plank ? bot.recipesFor(def.id, null, 1, null) : null;
    if (rec && rec.length > 0) {
      try {
        await withTimeout(bot.craft(rec[0], 1, null), 8000, '做工作台超时');
        diag('chain: 自己做了一个工作台');
        item = findItemByName('crafting_table');
      } catch (e) {
        diag(`chain: 做工作台失败 ${e.message}`);
      }
    }
  }
  if (!item) return null;

  const spot = findPlaceSpot();
  if (!spot) return null;
  await placeItemAt(item, spot.pos, 'crafting_table');
  diag('chain: 工作台已放下');
  return bot.findBlock({ matching: def.id, maxDistance: 16 });
}

async function actPlace(args) {
  if (!cfg.allowPlaceBlocks) return '配置里关了「允许放方块」';
  if (!bot || !bot.entity) return '不在游戏里';
  const name = String(args[0] || '').trim();
  if (!name) return '要放什么？（例如 [放 crafting_table] 或 [放 dirt 128 65 -302]）';

  const item = findItemByName(name);
  if (!item) return `背包里没有 ${name}`;

  // 不给坐标 = 放在她旁边（模型最常用的写法，也是"做好就该放下"的落点）
  if (args.length < 4) {
    const spot = findPlaceSpot();
    if (!spot) return '身边没有能放的空位，先走开一点';
    const r = await placeItemAt(item, spot.pos, name);
    return r.startsWith('放好了') ? `${r}（就在她旁边）` : r;
  }

  const pos = { x: Math.floor(Number(args[1])), y: Math.floor(Number(args[2])), z: Math.floor(Number(args[3])) };
  if (!Number.isFinite(pos.x) || !Number.isFinite(pos.y) || !Number.isFinite(pos.z)) {
    return '坐标不对（要三个整数）';
  }

  const target = vecOf(pos);
  const at = bot.blockAt(target);
  if (at && at.name !== 'air' && at.name !== 'cave_air') return '那一格已经有东西了';
  return placeItemAt(item, target, name);
}

async function actCraft(args) {
  if (!bot || !bot.entity) return '不在游戏里';
  const name = String(args[0] || '').trim();
  const count = clamp(Number(args[1]) || 1, 1, 16);
  if (!name) return '要合成什么？（例如 [合成 oak_planks 4]）';
  const item = bot.registry && bot.registry.itemsByName && bot.registry.itemsByName[name];
  if (!item) return `不认识物品「${name}」`;

  let recipes = bot.recipesFor(item.id, null, 1, null);
  let table = null;
  if (!recipes || recipes.length === 0) {
    // 目标链：附近没工作台就自己搞定（有就放下 / 有木板就做一个再放下）
    table = await ensureCraftingTable();
    if (table) {
      recipes = bot.recipesFor(item.id, null, 1, table);
    }
  }
  if (!recipes || recipes.length === 0) return `做不了 ${name}（缺材料，或附近没有工作台）`;

  try {
    await withTimeout(
      bot.craft(recipes[0], count, table),
      clamp(cfg.actionTimeoutSec, 5, 120) * 1000,
      '合成超时',
    );
  } catch (e) {
    return `合成失败：${e.message}`;
  }

  /*
   * 合成完**顺手放下**（2026-11-05）。
   *
   * <p>实测问题：让她做工作台，她只写了 `[合成 crafting_table 1]`，
   * 做完就报告"做好了"然后站着 —— 因为"放下"需要坐标，而它并不知道哪格是空的。
   * 对"放下才有用"的东西（工作台/熔炉/箱子/火把…），这里直接替她放到旁边，
   * 并在结果里带坐标，她下一轮就能说"工作台放你脚边了"。</p>
   */
  if (cfg.autoPlaceCrafted !== false && cfg.allowPlaceBlocks && AUTO_PLACE.test(name)) {
    const item = findItemByName(name);
    const spot = item ? findPlaceSpot() : null;
    if (spot) {
      const r = await placeItemAt(item, spot.pos, name);
      if (r.startsWith('放好了')) {
        return `做了 ${count} 个 ${name}，并把一个放在 ${r.replace('放好了 ', '')}`;
      }
      return `做了 ${count} 个 ${name}（想放下但没成功：${r}）`;
    }
    return `做了 ${count} 个 ${name}（身边没有空位，暂时拿在手上；要给他写 [给你 ${name}]）`;
  }
  // 提醒下一步：这是"做好了但给不出去"最直接的解药
  return `做了 ${count} 个 ${name}（要给他就写 [给你 ${name}]）`;
}

// ---------------- 创造模式取物（2026-11-05） ----------------

/*
 * <p>创造模式里物品栏是**空的** —— 东西在客户端的创意菜单里，`inventory.items()`
 * 永远看不到。所以"给我拿朵花"在她那儿会变成"背包里没有花"，然后就没有下文了。</p>
 *
 * <p>mineflayer 的 creative 插件能直接往快捷栏塞一个物品栈
 * （`bot.creative.setInventorySlot`），等于"从创意物品栏里拖出来"。
 * 这是创造模式下唯一可行的取物方式。</p>
 */

function isCreative() {
  return !!(bot && bot.game && String(bot.game.gameMode || '') === 'creative');
}

/**
 * 创造模式：变一个物品到手上。
 *
 * @returns {Promise<object|null>} 物品栈；非创造模式 / 没有这个物品时返回 null
 */
async function creativeItem(name, count = 1) {
  if (!isCreative()) return null;
  if (!bot.creative || typeof bot.creative.setInventorySlot !== 'function') {
    diag('creative: 这个 mineflayer 版本没有 creative 插件');
    return null;
  }
  const key = normalizeName(String(name || '').trim()).toLowerCase();
  if (!key) return null;
  const reg = (bot.registry && bot.registry.itemsByName) || {};
  let def = reg[key];
  if (!def) {
    // 模糊一次：「花」→ poppy / dandelion 之类
    const hit = Object.entries(reg).find(([n]) => n.includes(key));
    if (hit) def = hit[1];
  }
  if (!def) return null;

  try {
    // eslint-disable-next-line global-require
    const Item = require('prismarine-item')(bot.version);
    const n = Math.max(1, Math.min(64, Number(count) || 1));
    const stack = new Item(def.id, n, null);
    const slot = 36 + (Number(bot.quickBarSlot) || 0);
    await bot.creative.setInventorySlot(slot, stack);
    try {
      await bot.equip(stack, 'hand');
    } catch {
      /* 已经在快捷栏了，拿不到手上也无所谓 */
    }
    diag(`creative: 取出 ${def.name} ×${n}`);
    return stack;
  } catch (e) {
    diag(`creative 取物失败（${name}）：${e.message}`);
    return null;
  }
}

async function actEquip(args) {
  if (!bot || !bot.entity) return '不在游戏里';
  /*
   * 数量不能混进名字（2026-11-05 修的坑）。
   *
   * <p>`[拿 poppy 1]` 原来被拼成 name="poppy 1"，于是 `findItemByName` 查不到，
   * 回一句"背包里没有 poppy 1"，然后整个计划卡在第二步 —— 玩家看到的就是
   * "她说要给我花，然后什么也没发生"。</p>
   */
  const words = (args || []).map((x) => String(x)).filter((x) => x && !/^\d+$/.test(x));
  const name = words.join(' ').replace(/^[几\d]+[个只把支张块]*$/, '').trim();
  if (!name) return '要拿什么？';

  let item = findItemByName(name);
  if (!item) {
    // 创造模式：直接从创意物品栏取（这是"背包里没有"的真相）
    const made = await creativeItem(name, 1);
    if (made) return `拿出来了：${made.name}`;
    return `背包里没有 ${name}`;
  }
  try {
    await bot.equip(item, 'hand');
    return `拿起了 ${item.name}`;
  } catch (e) {
    return `拿不起来：${e.message}`;
  }
}

async function actEat() {
  if (!bot || !bot.entity) return '不在游戏里';
  const foods = (bot.inventory.items() || []).filter(
    (i) => (i.foodPoints || 0) > 0
      || /bread|apple|cooked_|carrot|potato|beef|porkchop|chicken|mutton|fish|stew|berries|cookie|melon/.test(i.name),
  );
  if (foods.length === 0) return '背包里没有吃的';
  try {
    await bot.equip(foods[0], 'hand');
    await withTimeout(bot.consume(), 20_000, '吃超时');
    return `吃了 ${foods[0].name}`;
  } catch (e) {
    return `吃不了：${e.message}`;
  }
}

async function actAttack(args) {
  if (!cfg.allowCombat) return '配置里关了「允许攻击」';
  if (!bot || !bot.entity) return '不在游戏里';
  const name = (args || []).join(' ').trim().toLowerCase();
  if (!name) return '要打谁？';
  const me = bot.entity.position;
  const target = Object.values(bot.entities || {})
    .filter((e) => e && e !== bot.entity && e.name && String(e.name).toLowerCase().includes(name))
    .filter((e) => e.position.distanceTo(me) < 6)
    .sort((a, b) => a.position.distanceTo(me) - b.position.distanceTo(me))[0];
  if (!target) return `6 格内没有 ${name}`;
  try {
    await bot.attack(target);
    return `打了 ${target.name}`;
  } catch (e) {
    return `打不了：${e.message}`;
  }
}

/**
 * 把东西给玩家：`[给你 stone_axe]` / `[给 Goldenrice56 stone_axe 2]`
 *
 * <p><b>补的是一个致命缺口</b>（2026-11-05）：原来只有 `[丢]` 和 `[放]`，
 * 没有"给"这个动作。于是玩家说"做好了给我"，她只能 `[放 crafting_table]`
 * （放错东西）或者 `[过来]`（只是走过来），然后**口头说"给了啊"** ——
 * 日志里 `[合成 stone_axe 1] -> 做了 1 个` 明明成功了，玩家却永远拿不到。</p>
 *
 * <p>Minecraft 里玩家之间没有"交易式给予"，唯一做法就是**丢在他脚边**。
 * 所以这里会先走近，再 toss。</p>
 */
async function actGive(args, ctx) {
  if (!bot || !bot.entity) return '不在游戏里';
  const a = (args || []).map((x) => String(x)).filter(Boolean);
  if (a.length === 0) return '要给什么？（例如 [给你 stone_axe]）';

  // ① 目标：显式玩家名 / "你" / 默认当前说话的人
  let who = '';
  let rest = a.slice();
  const first = String(a[0] || '').trim();
  if (/^(你|您|you)/i.test(first)) {
    who = (ctx && ctx.from) || '';
    rest = a.slice(1);
  } else {
    const p = Object.values(bot.players || {}).find(
      (x) => x && x.username && x.username.toLowerCase() === first.toLowerCase(),
    );
    if (p) {
      who = p.username;
      rest = a.slice(1);
    } else {
      who = (ctx && ctx.from) || '';
    }
  }
  // 计划里执行时没有"当前说话的人"，退到最近的白名单玩家（别丢给自己）
  if (!who) {
    const near = nearestAllowedPlayer(16);
    if (near) who = near.username;
  }
  if (who && who === stats.username) who = '';

  // ② 物品 + 数量
  const name = normalizeName(rest.find((x) => /^[a-z0-9_]+$/i.test(x)) || '');
  if (!name) return '要给什么？（例如 [给你 stone_axe]）';
  const numArg = rest.find((x) => /^\d+$/.test(x));
  const want = clamp(Number(numArg) || 1, 1, 64);

  let item = findItemByName(name);
  if (!item) {
    // 创造模式：背包是空的，但她能从创意物品栏里直接取
    const made = await creativeItem(name, want);
    if (made) item = made;
  }
  if (!item) return `背包里没有 ${name}，给不了${who ? ` ${who}` : ''}`;

  // ③ 先走近：丢在自己脚下，他两格外是捡不到的
  const target = who ? (bot.players || {})[who] : null;
  if (target && target.entity) {
    try {
      const d = bot.entity.position.distanceTo(target.entity.position);
      if (d > 3) {
        walkNear(target.entity.position, 2, 12);
        await waitNear(target.entity.position, 5000);
      }
    } catch {
      /* 走不过去就直接丢，总比不给强 */
    }
  }

  const n = Math.min(want, item.count);
  try {
    await bot.toss(item.type, null, n);
    note(`给了 ${who || '他'} ${n} 个 ${item.name}`);
    return `给了 ${who || '他'} ${n} 个 ${item.name}（丢在他脚边，让他捡）`;
  } catch (e) {
    return `给不了：${e.message}`;
  }
}

async function actToss(args) {
  if (!bot || !bot.entity) return '不在游戏里';
  const name = String(args[0] || '').trim();
  const n = clamp(Number(args[1]) || 1, 1, 64);
  const item = findItemByName(name);
  if (!item) return `背包里没有 ${name}`;
  try {
    await bot.toss(item.type, null, Math.min(n, item.count));
    return `丢了 ${Math.min(n, item.count)} 个 ${item.name}`;
  } catch (e) {
    return `丢不了：${e.message}`;
  }
}

/**
 * 换皮肤（2026-11-04）。
 *
 * <p><b>插件改不了皮肤</b>：皮肤是账号档案上的东西，离线账号根本没有档案。
 * 唯一可行的路是**服务器端皮肤插件**（最常见是 SkinsRestorer）：
 * 她自己在游戏里发一条 `/skin url <png>` 或 `/skin set <正版名>`，
 * 服务器就会把皮肤同步给所有装了该插件的客户端。</p>
 *
 * <p>所以这个动作只做一件事：**替她把命令发出去**。发完成不成，取决于服务端有没有插件、她有没有权限。</p>
 */
async function actSkin(args) {
  if (!bot || !bot.entity) return '不在游戏里';
  const v = (args || []).join(' ').trim();
  if (!v) {
    return '要换成什么？（[换肤 https://…/her.png] 或 [换肤 某个正版玩家名]）';
  }
  const cmd = /^https?:\/\//i.test(v) ? `skin url ${v}` : `skin set ${v}`;
  try {
    bot.chat(`/${cmd}`);
    note(`换肤：/${cmd}`);
    return `发了 /${cmd}（服务器装了皮肤插件才生效）`;
  } catch (e) {
    return `发不出去：${e.message}`;
  }
}

async function actSleep() {
  if (!bot || !bot.entity) return '不在游戏里';
  const bedBlock = findBlockByName('bed') || findBlockByName('white_bed');
  const bed = bedBlock ? bot.findBlock({ matching: bedBlock.id, maxDistance: 16 }) : null;
  if (!bed) return '附近没有床';
  try {
    await withTimeout(bot.sleep(bed), 15_000, '睡觉超时');
    return '睡了';
  } catch (e) {
    return `睡不了：${e.message}`;
  }
}

/**
 * 她自己决定记下来的一句话（`[记 …]`）。
 *
 * <p>既进流水（QQ 读得到细节），也进本次总结的一句话（索引里能看到）——
 * 她主动选择"这个值得记"的东西，本来就应该比"挖了多少个"更靠前。</p>
 */
function rememberNote(text) {
  const t = String(text || '').replace(/\s+/g, ' ').trim().slice(0, 60);
  if (!t) return '想记什么？';
  note(`[记] ${t}`);
  highlight(t);
  return '记下了';
}

function actMark(args) {
  const name = (args || []).join(' ').trim();
  if (!name) return '要给这个点起个名字：[坐标 家]';
  if (!bot || !bot.entity) return '不在游戏里，存不了坐标';
  const p = bot.entity.position;
  const world = readWorld();
  world[name] = {
    x: Math.round(p.x),
    y: Math.round(p.y),
    z: Math.round(p.z),
    dimension: String((bot.game && bot.game.dimension) || ''),
    at: Date.now(),
  };
  writeJsonFile(worldPath(), world);
  note(`把 (${Math.round(p.x)}, ${Math.round(p.y)}, ${Math.round(p.z)}) 记作「${name}」`);
  highlight(`记住了「${name}」`);
  return `记住了「${name}」在 (${Math.round(p.x)}, ${Math.round(p.y)}, ${Math.round(p.z)})`;
}

const LOOK_CATEGORIES = [
  ['树/木头', /_log$|_wood$/],
  ['石头', /^(stone|deepslate|cobblestone)$/],
  ['矿石', /_ore$/],
  ['水', /^water$/],
  ['工作台', /^crafting_table$/],
  ['箱子', /chest$/],
];

/**
 * 每一类**最近的一个**目标（带坐标）。
 *
 * <p>原来的 `[看周围]` 只会说"石头≈398 格、矿石≈2 格" —— 那是**噪声**：
 * 模型拿不到坐标，只能自己编一个 `[去 80 79 -141]`，走十秒过去发现什么都没有，
 * 然后原地打转。现在每类给一个真实坐标，它照着走就行。</p>
 */
function categoryTargets(maxDistance = 24) {
  if (!bot || !bot.entity) return [];
  const reg = (bot.registry && bot.registry.blocksByName) || {};
  const me = bot.entity.position;
  const out = [];
  for (const [label, re] of LOOK_CATEGORIES) {
    const ids = Object.entries(reg).filter(([n]) => re.test(n)).map(([, d]) => d.id);
    if (ids.length === 0) continue;
    const found = bot.findBlocks({ matching: ids, maxDistance, count: 64 }) || [];
    let best = null;
    let bd = Infinity;
    for (const p of found) {
      let d = 0;
      try {
        d = p.distanceTo(me);
      } catch {
        continue;
      }
      if (d < bd) {
        bd = d;
        best = p;
      }
    }
    if (best) {
      out.push({
        label, x: Math.round(best.x), y: Math.round(best.y), z: Math.round(best.z), dist: bd, count: found.length,
      });
    }
  }
  return out.sort((a, b) => a.dist - b.dist);
}

/** `[看周围]`：给**能直接走过去的坐标**，不给"≈398 格"这种没用的统计。 */
function actLookAround() {
  if (!bot || !bot.entity) return '不在游戏里';
  const list = categoryTargets(24);
  if (list.length === 0) return '周围 24 格没什么值得去的地方（往远处走一点再看）';
  const lines = list.slice(0, 4).map(
    (t) => `${t.label}（${t.x}, ${t.y}, ${t.z}）${Math.round(t.dist)} 格`,
  );
  return `周围 24 格，最近的一个：\n${lines.join('\n')}\n（坐标直接写 [去 x y z]，别自己编）`;
}

async function runAction(a, ctx) {
  const t0 = Date.now();
  let result;
  try {
    switch (a.verb) {
      case 'observe':
        result = '（已更新观察）';
        break;
      case 'lookAround':
        result = actLookAround();
        break;
      case 'goto':
        result = await actGoto(derefPlayer(a.args, ctx));
        break;
      case 'gotoHome':
        result = await actGoto(['家']);
        break;
      case 'come':
        result = await actCome(ctx);
        break;
      case 'follow':
        result = await actFollow(derefPlayer(a.args, ctx));
        break;
      case 'stop':
        result = actStop();
        break;
      case 'mine':
        result = await actMine(a.args);
        break;
      case 'place':
        result = await actPlace(a.args);
        break;
      case 'craft':
        result = await actCraft(a.args);
        break;
      case 'equip':
        result = await actEquip(a.args);
        break;
      case 'eat':
        result = await actEat();
        break;
      case 'attack':
        result = await actAttack(a.args);
        break;
      case 'toss':
        result = await actToss(a.args);
        break;
      case 'give':
        result = await actGive(a.args, ctx);
        break;
      case 'sleep':
        result = await actSleep();
        break;
      case 'say':
        result = (await say(a.args.join(' '))) ? '说了' : '没说出来';
        break;
      case 'remember':
        result = rememberNote(a.args.join(' '));
        break;
      case 'mark':
        result = actMark(a.args);
        break;
      case 'pickup':
        result = await actPickup(a.args);
        break;
      case 'use':
        result = await actUse(a.args);
        break;
      case 'container':
        result = await actContainer(a.args);
        break;
      case 'build':
        result = await actBuild(a.args);
        break;
      case 'portal':
        result = await actPortal();
        break;
      case 'skill':
        result = await actSkill(a.args);
        break;
      case 'find':
        result = await actFind(a.args);
        break;
      case 'cleararea':
        result = await actClear(a.args);
        break;
      case 'walls':
        result = await actWalls(a.args);
        break;
      case 'pillar':
        result = await actPillar(a.args);
        break;
      case 'tunnel':
        result = await actTunnel(a.args);
        break;
      case 'farm':
        result = await actFarm();
        break;
      case 'skin':
        result = await actSkin(a.args);
        break;
      case 'wait':
        await sleep(clamp(Number(a.args[0]) || 2, 1, 30) * 1000);
        result = '等了一会';
        break;
      case 'intent':
        result = addIntent(a.args.join(' '));
        break;
      case 'clearIntent':
        result = clearIntents();
        break;
      default:
        result = `不认识的动作 ${a.raw}`;
    }
  } catch (e) {
    result = `失败：${e.message}`;
  }
  stats.actions++;
  stats.lastAction = `${a.raw} → ${String(result).slice(0, 60)}`;
  diag(`action ${a.raw} -> ${result} (${Date.now() - t0}ms)`);
  /*
   * 动作与结果是**全量流水里最有用的部分**：QQ 那边问"你们刚才干嘛了"，
   * 「21:33 [挖 oak_log 8] → 捡到 8 个」比「挖了 8 个方块」具体得多。
   */
  note(`${a.raw} → ${String(result).slice(0, 80)}`);
  return String(result || '');
}

// ------------------------------------------------------------------ 调平台

function resolveAgentId() {
  const own = String(cfg.agentId || '').trim();
  if (own) return own;
  return String(qqAgentConfig().agentId || '').trim();
}

function sessionId() {
  return `mc:game:${stats.username || String(cfg.username || 'bot')}`;
}

/** 拼这一轮她看到的东西。**注入走 metadata，不落库** —— 和 QQ 助手同一套做法。 */
function buildInject(ctx = {}) {
  const lines = [];
  lines.push('【你在 Minecraft 里】');
  lines.push(observeLine());

  /*
   * 失败复盘（2026-11-05）：只带一次，说完就清。
   * 不写成"系统提示：你死了" —— 那样她会念出来；写成"教训"让她用自己的话说。
   */
  if (pendingLesson) {
    lines.push(`【刚才的教训】${pendingLesson}（用你自己的话说，别像在念笔记）`);
    pendingLesson = '';
  }

  /*
   * 反射打断了模型的动作时必须告诉它（2026-11-05）。
   *
   * <p>这就是 Mindcraft 里那条 `(AUTO MESSAGE)`：不说的话，模型会以为自己
   * 还在挖矿，下一轮继续写 `[挖 oak_log 8]` —— 而她其实已经被岩浆赶到十格开外了。</p>
   */
  if (pendingInterrupt) {
    lines.push(`【刚才】${pendingInterrupt} —— 这是自动反应（躲危险/脱困），不是你改主意；`
      + '按你原来的打算继续，不用重复刚才的动作。');
    pendingInterrupt = '';
  }

  /*
   * 正在做的行为链（2026-11-05）：让她知道自己手上还有件事没做完，
   * 而不是每次聊天都从"我该干点什么"重新开始。
   */
  const planNow = planBlock();
  if (planNow) lines.push(planNow);

  /*
   * 好奇心（2026-11-04）：闲聊时**顺口提一句刚看到的东西**。
   *
   * <p>只在好奇心偏高（>= 0.5）时带 —— 否则她会在你聊正事时插一句"那边有只猫"。
   * 用 {@code peek}（不消耗新奇度）：真正"去看过"由自主那一轮负责。</p>
   */
  if (cfg.curiosityEnabled) {
    const cur = readMind().curiosity;
    /*
     * 「缺什么」在闲聊里也要带上（2026-11-04）：她饿了、被怪堵住时，
     * 你随口跟她说话，她应该能顺口提一句"有吃的吗"，而不是等下一次自主醒来。
     */
    const asks = (peekAttentions() || []).filter((a) => a.ask);
    if (asks.length > 0 && cfg.askForHelp !== false) {
      lines.push(attentionLines(asks, '【你现在缺的】'));
    }
    if (cur >= 0.5) {
      const att = attentionLines(peekAttentions());
      if (att) lines.push(att);
      const cl = curiosityLine();
      if (cl) lines.push(cl);
    }
    const plans = intentionsBlock();
    if (plans) lines.push(plans);
  }

  /*
   * 知识库查到的（2026-11-04）：紧跟在"注意到"后面 ——
   * 她在同一屏里同时看到"那边有个僵尸"和"僵尸会追人"，才可能得出"先跑"。
   */
  if (ctx.kb) lines.push(ctx.kb);

  // 只给她看"做过什么"，聊天行剔掉 —— 那部分本来就在对话历史里
  const mem = readMemoryTail(clamp(cfg.maxMemoryChars, 0, 3000), '', { dropChat: true });
  if (mem) {
    lines.push('【你和他一起玩过的事】\n' + mem);
  }

  const fb = factsBlock();
  if (fb) lines.push(fb);

  if (cfg.useDiary) {
    const d = diaryLine();
    if (d) lines.push(d);
  }

  if (ctx.from) {
    lines.push(`【正在跟你说话的人】${ctx.from}`);
  }

  const maxActions = clamp(cfg.maxActionsPerTurn, 1, 8);
  lines.push(
    '【怎么玩】你是这个服务器里的一个玩家，不是助手。'
    + '说话就直接说（一次一句，短，别用括号写动作）；想做动作就写方括号，按顺序执行，最多 '
    + maxActions + ' 个：\n'
    + '[去 家] [去 128 64 -302] [过来] [跟着 名字] [挖 oak_log 8] [合成 oak_planks 4] [吃] '
    + '[放 crafting_table]（不给坐标就放你旁边） [放 dirt 128 65 -302] [拿 stone_sword] '
    + '[捡] [捡 oak_log] [锄地] [播种] [浇水] [用 oak_door] '
    + '[给你 stone_axe] [给 名字 stone_axe 2] '
    + '[存 箱子 oak_log 8] [取 箱子 oak_log 8] [看箱子] [盖 hut] [传送门] [技能 名字] '
    + '[清空 4] [围栏 5 5] [垫柱 3] [隧道 8] [开荒] [找 树] '
    + '[看周围] [坐标 家] [记 一句话] [想做 下去看看那个洞] '
    + '[换肤 https://…/her.png] [停]\n'
    + '看到什么有意思的，可以**先说**出来再去 —— "那边好像有个洞" 然后 [去 那个坐标]，'
    + '比闷头走过去更像人。不想说话可以只写动作；什么都不想做就只回 [SILENT]。\n'
    + '**动作要以动词开头**：[去 树] [挖 木头 4] [跟着 我]；写成 [去附近有树的地方] 这种'
    + '带句子的写法容易失败，目标尽量用名字或坐标。\n'
    + '**要把东西给他，必须写 [给你 物品名]** —— 只写 [过来] 或 [放] 他不会拿到东西，'
    + '说"给你了"也没用。给东西**不用先拿**，直接 [给你 xxx]。\n'
    + '**别自己编坐标**：要去哪就先 [看周围] 或 [找 树]，用结果里给的坐标；'
    + '你凭空写的 x y z 多半是空气，走过去只会白跑一趟。\n'
    + '**【重要】他让你做事时，需要两步以上就别只回一句"好"** —— 直接写计划块，'
    + '每行一个 [动作]，中间插 1~2 句 [说 …] 当播报（"我去那边找找"「拿出来了」），'
    + '最后一步给东西就写 [给你 xxx]。计划会自动按顺序做完，中途不用等他催；'
    + '哪步做不下去就说清楚缺什么。格式：\n'
    + '[计划 给他做把石斧] 1. [说 得先弄点木头] 2. [找 树] 3. [挖 oak_log 4] '
    + '4. [合成 stone_axe 1] 5. [说 好了] 6. [给你 stone_axe] [/计划]',
  );

  return lines.join('\n\n');
}

async function askPlatform(userText, injectText) {
  const agentId = resolveAgentId();
  if (!agentId) {
    throw new Error('没有可用的智能体：请在插件配置里填 agentId，或先配好 QQ 助手');
  }
  const body = {
    agentId,
    sessionId: sessionId(),
    mode: 'agent',
    messages: [{ role: 'user', content: userText }],
    metadata: {
      tenant_id: 'default',
      user_id: `mc-${stats.username || 'bot'}`,
      injectContext: injectText,
    },
    context: {
      maxHistoryTurns: clamp(cfg.maxHistoryTurns, 1, 40),
      /*
       * 知识库自动检索（2026-11-04 打开）。
       *
       * <p>之前这里是 `useRag: false`，注释写着"她在这里没有知识库，开着只是
       * 让人误以为 RAG 在工作"。现在正好反过来：玩家问"钻石矿怎么挖"，
       * 这句话本身就是检索词，平台从**智能体绑定的**知识库捞片段拼进系统提示词。</p>
       *
       * <p>没挂知识库时平台解析不到 kbIds 直接返回 null —— 零成本、不报错，
       * 所以这个开关默认开着是安全的。</p>
       */
      useRag: cfg.ragEnabled !== false,
      rag: {
        topK: clamp(cfg.ragTopK, 1, 10),
        scoreThreshold: Number(cfg.ragScoreThreshold) || 0,
      },
    },
    /*
     * 工具全关：游戏里她需要的是"动"，不是查网页/生图。
     * 开着会让她把动作写成工具调用（然后什么也没发生），也白烧 token。
     */
    tools: { enabled: false },
    renderGuide: false,
  };
  const resp = await api.platform.request({
    path: '/api/v1/agent/run',
    method: 'POST',
    body,
  });
  const out = resp?.output ?? resp?.data?.output;
  return String((out && out.content) || '').trim();
}

// ------------------------------------------------------------------ 一轮对话

const AUTO_PROMPT = '【系统提示 · 不是玩家说的】现在没人跟你说话。'
  + '你可以自己做点事（挖点东西、四处看看、整理背包），也可以什么都不做。'
  + '不想动就只回 [SILENT]；想说话就直接说。';

async function handleTurn(userText, ctx = {}) {
  if (busy) {
    diag('busy：上一轮还没结束，这条丢弃');
    return;
  }
  if (!cfg.enabled) return;
  if (!stats.connected || !bot || !bot.entity) {
    diag('turn 跳过：不在游戏里');
    return;
  }
  const text = String(userText || '').trim();
  if (!text) return;

  busy = true;
  try {
    /*
     * 看到不认识的东西 → **先去知识库查一下**（2026-11-04）。
     *
     * 放在 buildInject 之前：她这一轮就该"知道那是什么"，
     * 而不是先瞎答一句、下一轮才补。查过的会缓存，不会每轮都调工具。
     */
    const kb = await knowledgeFor(ctx.attentions);
    const inject = buildInject({ ...ctx, kb });
    lastInject = inject;
    const answer = await askPlatform(text, inject);
    diag(`answer(${answer.length}): ${answer.slice(0, 80).replace(/\n/g, ' / ')}`);
    if (!answer) return;

    /*
     * 行为链（2026-11-05）：先抠出计划块，再从剩下的文本里解析"这一轮立刻做的动作"。
     * 顺序不能反 —— 计划块里的动作是**之后按顺序执行**的，不该被当成本轮动作。
     */
    const plan = parsePlanBlock(answer);
    const forThisTurn = plan ? stripPlanBlock(answer) : answer;
    const { actions, lines, dropped } = parseActions(forThisTurn);
    const canAct = ctx.canAct !== false;
    /*
     * 解析结果必须落盘（2026-11-04）。
     *
     * <p>「她只说话不动」的排查第一步就是看这行：`actions=0` 说明模型没按格式写，
     * `dropped` 非空说明写了但动词没认出来 —— 两者要修的地方完全不同。</p>
     */
    diag(`parse: actions=${actions.length} dropped=${dropped.length} lines=${lines.length}`
      + `${dropped.length ? ` droppedList=${dropped.join(' ')}` : ''}`);

    for (const line of lines) {
      await say(line);
    }

    const results = [];
    if (dropped.length > 0) {
      // 让她下一轮知道"刚才那个动作没被执行"，而不是以为自己做了
      results.push(`没看懂的动作：${dropped.join(' ')}（要写成 [动词 参数]，例如 [去 树]）`);
    }
    if (canAct) {
      for (const a of actions.slice(0, clamp(cfg.maxActionsPerTurn, 1, 8))) {
        results.push(await runAction(a, ctx));
      }
    } else if (actions.length > 0) {
      results.push('（对方不在名单里，只说不动）');
    }
    const kept = results.filter(Boolean);
    if (kept.length > 0) {
      session.lastResults = kept.slice(-4);
    }

    // 计划要等这一轮说完、动作做完再开跑，否则会和本轮动作抢 pathfinder
    if (plan && cfg.planEnabled !== false) {
      startPlanFromModel(plan, userText, ctx);
    }
  } catch (e) {
    stats.lastError = e.message;
    diag(`turn FAILED: ${e.message}`);
    log('warn', `这一轮失败：${e.message}`);
  } finally {
    busy = false;
  }
}

// ------------------------------------------------------------------ 游戏内聊天

/** 每个玩家一个窗口期桶：连发几句合并成一句，避免抢答。 */
const buckets = new Map();

function onChat(username, message, isWhisper) {
  if (!bot || !bot.entity) return;
  if (!username || username === stats.username) return;   // 自己的发言
  const text = String(message || '').trim();
  if (!text) return;

  stats.received++;
  session.win.chatIn++;
  session.tot.chatIn++;
  lastActivityAt = Date.now();

  const allowed = parseNames(cfg.allowPlayers);
  const isAllowed = allowed.some((n) => n.toLowerCase() === username.toLowerCase());
  const strangerReply = !isAllowed && !!cfg.respondToStrangers;

  diag(`chat ${username}${isWhisper ? '(私聊)' : ''}: ${text.slice(0, 60)} allowed=${isAllowed}`);

  /*
   * 全量记录（2026-11-04）：**谁说的都记**，包括名单外的人。
   *
   * <p>只记"通过了闸门的话"是不够的 —— QQ 那边问"今天服里热闹吗"，
   * 她需要知道刚才有人来过、说了什么。`recordStrangers` 关掉就只记白名单玩家。</p>
   */
  if (cfg.recordChat !== false && (isAllowed || cfg.recordStrangers !== false)) {
    note(`${username}${isWhisper ? '（私聊）' : ''}：${text.slice(0, 80)}`);
  }

  // 他说话了 = 求助有着落；等着的计划接着做（2026-11-05）
  if (isAllowed) {
    resumeWaitingPlan();
  }

  if (!isAllowed && !strangerReply) {
    /*
     * 名单外的人：不回复，但已经在上面的流水里留了一笔。
     * 同时进 notes，下一次落盘时她会"想起来有人来过"。
     */
    if (session.notes.length < 6) {
      session.notes.push(`${username} 来找过你：${text.slice(0, 40)}`);
    }
    return;
  }

  if (!isAllowed && strangerReply && /\[[^\]\n]{1,40}\]/.test(text)) {
    // 陌生人试图塞动作标记 —— 直接丢掉，只当聊天
    diag('drop action markers from stranger');
  }

  enqueue(username, text, { canAct: isAllowed, from: username });
}

function enqueue(username, text, ctx) {
  const key = String(username).toLowerCase();
  const old = buckets.get(key);
  const windowMs = clamp(cfg.debounceSeconds, 0, 30) * 1000;

  const bucket = old || { items: [], timer: null, ctx };
  bucket.items.push(text);
  bucket.ctx = ctx;
  if (bucket.timer) clearTimeout(bucket.timer);

  if (windowMs <= 0) {
    buckets.delete(key);
    void flushBucket(key, bucket);
    return;
  }
  bucket.timer = setTimeout(() => {
    buckets.delete(key);
    void flushBucket(key, bucket);
  }, windowMs);
  buckets.set(key, bucket);
}

async function flushBucket(key, bucket) {
  if (bucket.timer) clearTimeout(bucket.timer);
  const merged = joinLines(bucket.items);
  if (!merged) return;
  await handleTurn(merged, { ...bucket.ctx, from: bucket.ctx.from || key });
}

/** 连发几句拼成一段（换行最稳：模型能看出是几句，又不会被当成多个请求）。 */
function joinLines(items) {
  const list = (items || []).map((s) => String(s || '').trim()).filter(Boolean);
  if (list.length === 0) return '';
  if (list.length === 1) return list[0];
  return list.join('\n');
}

// ------------------------------------------------------------------ 自主

function inQuietHours() {
  const h = new Date().getHours();
  const s = clamp(cfg.autonomyQuietStart, 0, 23);
  const e = clamp(cfg.autonomyQuietEnd, 0, 23);
  if (s === e) return false;   // 填一样 = 关闭这个功能
  return s < e ? h >= s && h < e : h >= s || h < e;
}

/**
 * 「看到了 → 想 → 说出来 → 决定做」这一轮的系统提示。
 *
 * <p>措辞刻意留了**不去的权利**：只写"去看看"会让她每次都去，
 * 而好奇心的另一半是"看了一眼，没兴趣，算了"。</p>
 */
function curiosityPrompt({
  attentions = [], intents = [], restless = false, urgent = false, flash = null,
} = {}) {
  const parts = ['【系统提示 · 不是玩家说的】现在没人跟你说话。'];

  /*
   * 即时事件（2026-11-05）：这一轮是**被打断**叫醒的，不是定时醒来。
   * 明确要求她先对它反应 —— 否则模型会当成"又一次独自待着"，
   * 慢悠悠地说"我再看看"，那一分钟就白过了。
   */
  if (flash && flash.label) {
    parts.push(`【刚刚】${flash.label} —— 这是**刚刚发生**的，先对它反应（一句），再说下一步。`);
  }
  /*
   * 需求分两类摆出来（2026-11-04）：
   * 一类她自己能解决，一类**只能开口跟他要**。混在一起时模型会一律自己动手，
   * 于是你看到她饿着肚子绕圈，而不是说一句"有吃的吗"。
   */
  const asks = attentions.filter((a) => a.ask);
  const selves = attentions.filter((a) => !a.ask);
  const askBlock = attentionLines(asks, '【你需要开口跟他要的】');
  const selfBlock = attentionLines(selves, '【你自己能处理的】');
  if (askBlock) parts.push(askBlock);
  if (selfBlock) parts.push(selfBlock);
  if (urgent) parts.push('【刚刚】你被打了，身上有点疼。');

  if (intents.length > 0) {
    const b = intentionsBlock();
    if (b) parts.push(b);
  }
  const cl = curiosityLine();
  if (cl) parts.push(cl);

  if (askBlock) {
    parts.push(
      '上面这些是你自己解决不了的事 —— **直接对他说**，别自己憋着、也别假装没这回事。\n'
      + '比如"你有吃的吗""那边有只僵尸，我不敢过去，你来一下"。要到了就道谢；他说没有，就别一直磨。',
    );
  }

  if (askBlock || selfBlock || intents.length > 0) {
    parts.push(
      '想说就先把**你看到什么、打算怎么办**说出来（一句），然后写动作去做 —— 别只在心里想。\n'
      + '想去就直接 [去 x y z]（上面注意点后面给的坐标），走到附近再看。\n'
      + '只是有个念头、现在还不想动，就写 [想做 一句话]，以后还记着。\n'
      + '不想去就当没看见，回 [SILENT] 也正常。',
    );
  } else if (restless) {
    parts.push('坐不太住，但也没什么明确想干的。想干点什么就说 + 写动作；不然就 [SILENT]。');
  } else {
    parts.push('没什么特别想做的就回 [SILENT]；真想干点什么就直接说 + 写动作。');
  }
  return parts.join('\n\n');
}

/**
 * 两次"动脑"之间的间隔（秒 → 毫秒，±30% 抖动）。
 *
 * <p>原来这里有两套闸：`autonomyMinutes`（15 分钟）和硬编码 2 分钟，
 * 后来又加了 `decisionSeconds`（75 秒）—— 三个数字在不同分支里生效，
 * 配置面板上看着就是互相打架。现在只剩 `decisionSeconds` 一个。</p>
 */
function decisionGapMs() {
  const base = clamp(cfg.decisionSeconds, 20, 600) * 1000 * (0.7 + Math.random() * 0.6);
  let factor = 1;
  // 活跃期想得更勤（对应"一阵一阵"的节奏，而不是恒定节拍）
  if (inBurst()) {
    factor *= 0.55;
  }
  // 附近没人的时候更慢：一个人待着还高频"思考"本来就不像人，也费 token
  if (!nearestAllowedPlayer(48)) {
    factor *= 1.6;
  }
  return base * factor;
}

/** 距离上次动脑够久了吗。 */
function canThink() {
  return Date.now() - lastAutonomyAt >= decisionGapMs();
}

async function tickAutonomy() {
  if (!cfg.enabled || !cfg.autonomyEnabled || !stats.connected || busy) return;
  if (!bot || !bot.entity) return;

  const urgentNow = !!(senseCache.urgent && Date.now() - senseCache.urgent.at < 40_000);
  // 静默时段不主动动脑 —— 除非刚挨打（那不能等天亮再说）
  if (inQuietHours() && !urgentNow) return;

  // 先让好奇心自然回落（10 分钟一次，与是否在聊天无关）——
  // 不然忙着聊一下午，她的"闷"会一直停在进场时的值
  settleCuriosity();

  if (Date.now() - lastActivityAt < clamp(cfg.idleMinutes, 1, 120) * 60_000) return;

  /*
   * 好奇心驱动（2026-11-04）。
   *
   * <p><b>顺序很关键</b>：先扫"她看到了什么"，再决定要不要叫醒她。
   * 反过来就又变回定时盲问了 —— 那种"每 15 分钟问一次你想干嘛"的行为，
   * 她只能凭空编，于是永远在重复同一类事。</p>
   */
  if (cfg.curiosityEnabled) {
    const attentions = takeAttentions();
    const intents = readMind().intentions;
    const cur = readMind().curiosity;
    // 滞回：进入/退出用不同阈值，避免在边界上反复横跳
    const restless = updateRestless(cur, clamp(cfg.curiosityThreshold, 0.1, 1));
    /*
     * **跳过思考间隔**的两类（2026-11-04 / 11-05）：
     * ① 挨打（`urgent`）：75 秒的冷静期对"被僵尸追"来说太长，等想明白已经死了；
     * ② 即时事件（`flash`）：稀有矿、有人上线、血见底 —— 这类东西错过就没了，
     *    而且要的就是"看到什么就说"，不该等下一次定时思考。
     */
    const hurt = !!(senseCache.urgent && Date.now() - senseCache.urgent.at < 40_000);
    if (hurt) senseCache.urgent = null;
    const fl = freshFlash();
    const urgent = !!fl || hurt;
    const driven = urgent || attentions.length > 0 || intents.length > 0 || restless;

    if (!driven) {
      /*
       * 什么都没看到、没打算、也没闷到想动。
       *
       * <p>两种情况：</p>
       * <ul>
       *   <li>`idleWander` 开着 → 旧行为（凭空问一次）；</li>
       *   <li>否则 → **有可能冒出一个念头**（灵感涌现，2026-11-05）。
       *       注意它不是每次都会发生：{@link maybeInspire} 里还有冷却和概率两道闸，
       *       所以她的"突然想干点什么"是不规则的，而不是定时任务。</li>
       * </ul>
       */
      if (cfg.idleWander) {
        if (!canThink()) return;
        lastAutonomyAt = Date.now();
        diag('autonomy: idle wander');
        await handleTurn(AUTO_PROMPT, { autonomy: true, canAct: true });
        return;
      }
      await maybeInspire();
      return;
    }

    // 两次动脑的间隔（有紧急事件时跳过，见上）
    if (!urgent && !canThink()) return;
    lastAutonomyAt = Date.now();
    diag(`autonomy: curiosity att=${attentions.length} intents=${intents.length} `
      + `restless=${restless} urgent=${urgent}${fl ? ` flash=${fl.kind}` : ''} c=${cur.toFixed(2)}`);

    await handleTurn(curiosityPrompt({
      attentions, intents, restless, urgent, flash: fl,
    }), {
      autonomy: true,
      canAct: true,
      attentions,
    });

    /*
     * 行动即满足：醒来过一次就把这次的"痒"消化掉，
     * 否则同一个念头会每两分钟把她叫醒一次（即使已经被标记成"见过"）。
     */
    bumpCuriosity(attentions.length > 0 ? -0.05 : -0.2);
    // 清缓存：下一轮重新扫，别复用同一批注意点
    senseCache.attentions = null;
    senseCache.at = 0;
    return;
  }

  // 旧行为：定时盲问（curiosityEnabled 关掉时）
  if (!canThink()) return;
  lastAutonomyAt = Date.now();
  diag('autonomy: blind tick');
  await handleTurn(AUTO_PROMPT, { autonomy: true, canAct: true });
}

// ------------------------------------------------------------------ 心跳

function startTimers() {
  stopTimers();

  // 慢心跳：落盘 / 思考 / 探活（30 秒一次就够）
  const tick = () => {
    try {
      touchLock();     // 告诉别的实例"我还活着"（拿锁的那个）
      recordFacilities();   // 顺手记下附近的箱子/工作台（不花 token）
      /*
       * 配置开关兜底：手改 config.json、或界面保存没走 saveConfig 的情况下，
       * **已连接但配置已关闭**就是明确的矛盾，直接断开（别等她玩到天亮）。
       */
      if (!cfg.enabled && stats.connected) {
        log('warn', '配置里「启用接管」已关闭 —— 主动断开游戏连接');
        disconnect();
      }
      tickDigest();
      void tickAutonomy();
      healthCheck();
    } catch (e) {
      diag(`tick failed: ${e.message}`);
    }
  };
  heartbeatTimer = setInterval(tick, 30_000);
  setTimeout(tick, 15_000);

  /*
   * 快心跳：只做**本地小动作**（2026-11-04）。
   *
   * <p>4 秒一次、不调模型。这是"她一直活着"的观感来源：
   * 转身看你、挪两步、跟过来、跳一下。真正移动仍然按 `idleWalkSeconds` 节流。</p>
   */
  ambientTimer = setInterval(() => {
    try {
      tickAmbient();
    } catch (e) {
      diag(`ambient failed: ${e.message}`);
    }
  }, 4000);

  /*
   * 平台启用状态自检：10 秒一次，连续两次判定为"已禁用"就自我下线。
   *
   * <p>为什么不放在 30 秒心跳里：用户关掉插件后，她要在一分钟内还杵在游戏里，
   * 观感就是"关了也没用"。10 秒 ×2 ≈ 20 秒内下线，代价只是一个本地 GET。</p>
   */
  enabledTimer = setInterval(() => {
    void checkPlatformEnabled();
  }, 10_000);
  void checkPlatformEnabled();

  /*
   * 反射层（2026-11-05）：1.5 秒一次。
   *
   * <p>为什么要比心跳快这么多：岩浆、掉沙、溺水都是"几秒内决定生死"的事。
   * 它不调模型，开销只是几次 `bot.blockAt`。</p>
   */
  reflexTimer = setInterval(() => {
    reflexTick();
  }, 1500);
}

function stopTimers() {
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
  if (ambientTimer) {
    clearInterval(ambientTimer);
    ambientTimer = null;
  }
  if (enabledTimer) {
    clearInterval(enabledTimer);
    enabledTimer = null;
  }
  if (reflexTimer) {
    clearInterval(reflexTimer);
    reflexTimer = null;
  }
}

function tickDigest() {
  if (!stats.connected) return;
  const gapMs = clamp(cfg.digestMinutes, 2, 120) * 60_000;
  if (Date.now() - lastDigestAt < gapMs) return;
  lastDigestAt = Date.now();
  flushDigest();
}

/**
 * 连接探活：`end` 事件**不总是会来**（休眠、网络切换、中间设备掐长连接），
 * 留下"半开连接"时 `stats.connected` 还是 true 而实际什么都收不到。
 * 用户看到的现象是"她站在那儿一整天不动"。这里的做法和 QQ 助手一致：发现不对就主动重连。
 */
function healthCheck() {
  if (!cfg.enabled) return;
  if (!bot) {
    if (!reconnectTimer) scheduleReconnect();
    return;
  }
  /*
   * `connected && !entity` 才重连，而且要等进服满 15 秒（2026-11-04）。
   *
   * <p>没有这 15 秒缓冲时，登录握手那几百毫秒里 entity 还没建好，
   * 探活就可能把自己掐断 → 重连 → 又被掐 → 表现为"反复进出"。</p>
   */
  if (stats.connected && !bot.entity && Date.now() - (stats.sessionStart || 0) > 15_000) {
    diag('health: 已连接但 15 秒都没有 entity -> 主动重连');
    try {
      bot.quit();
    } catch {
      /* 已断 */
    }
  }
}

// ------------------------------------------------------------------ 生命周期

module.exports = {
  start(a) {
    api = a;
    cfg = loadConfig();
    stats.enabled = !!cfg.enabled;
    /*
     * 让 `mind.json` 在第一次启动时就存在（2026-11-04）。
     *
     * 它是"她的心里状态"：好奇心、见过什么、打算做什么。提前落盘有两个好处：
     * ① 用户能直接打开看/改（和 facts.json 同一套习惯）；
     * ② 出问题时能回答"她为什么不理人" —— 是不是什么都见过了、好奇心底。
     */
    saveMind();
    log('info', `MC 助手已加载，配置：${configPath()}`);
    log('info', `心里状态：${mindPath()}（好奇心 ${readMind().curiosity.toFixed(2)}）`);
    log('info', `启用状态：${cfg.enabled ? '开' : '关'}；服务器：${serverText()}；`
      + `自主：${cfg.autonomyEnabled ? '开' : '关'}`);
    // pid 一定要记：出现"反复进出游戏"时，第一步就是确认是不是有两个进程在抢号
    diag(`start enabled=${cfg.enabled} pid=${process.pid} server=${serverText()} shared=${qqAgentDir()}`);

    /*
     * 进程被**优雅**终止时尽量发一次断开包（2026-11-04）。
     * Windows 的强杀不给机会，所以这只是"能救就救" —— 真正兜底的是
     * {@link checkPlatformEnabled} 的自我下线。
     */
    try {
      const bye = () => {
        try {
          if (bot) disconnect();
        } catch {
          /* ignore */
        }
      };
      process.once('SIGTERM', bye);
      process.once('SIGINT', bye);
    } catch {
      /* 极旧运行时没有 process.once */
    }

    /*
     * 上次异常退出留下的 `online: true` 会骗到 QQ 那边（她明明没在玩），
     * 也会让面板显示"在游戏里"。启动时如果没别的实例占着号，就改回 false。
     */
    const st = readJsonFile(statePath(), {});
    if (st.online) {
      const lk = readLock();
      const otherAlive = lk && Number(lk.pid) !== process.pid && pidAlive(lk.pid);
      if (!otherAlive) {
        writeState({ online: false, endedAt: Date.now() });
        diag('启动时修正残留状态：online -> false（上次异常退出）');
      }
    }

    // 依赖自检放在连接之前：坏在这就让日志一眼看出是"装了一半"，而不是"连不上"
    checkDependencies();

    if (cfg.enabled) {
      connect();
      startTimers();
    }
  },

  stop() {
    stopping = true;
    stopTimers();
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
    disconnect();
    releaseLock();
    writeState({ online: false, endedAt: Date.now() });
    log('info', 'MC 助手已停止');
  },

  methods: {
    /** 宿主热重载前会问：忙就等几秒，别把正在生成的那条掐断。 */
    isBusy() {
      return busy;
    },

    status() {
      const m = readMind();
      let sessions = 0;
      try {
        sessions = fs.readdirSync(sessionsDir())
          .filter((f) => f.endsWith('.md') && f !== 'index.md').length;
      } catch {
        /* 还没玩过 */
      }
      return {
        ...stats,
        enabled: !!cfg?.enabled,
        server: serverText(),
        configPath: configPath(),
        memoryPath: memoryPath(),
        // 记忆是按次分文件的（2026-11-04）：面板上要知道"这是第几次"、当前文件叫什么
        sessionFile: session.file ? path.basename(session.file) : '',
        sessions,
        mindPath: mindPath(),
        agentId: resolveAgentId(),
        sharedDir: qqAgentDir(),
        since: session.started || 0,
        // 好奇心（2026-11-04）：面板上能直接看出"她此刻想不想动"
        curiosity: Number(m.curiosity.toFixed(2)),
        intentions: m.intentions.map((i) => i.text),
        seenCount: m.seen.length,
        noticed: (senseCache.attentions || []).map((a) => a.label),
        // 知识库（2026-11-04）：查过几条、缓存在哪 —— 面板和排查都用得上
        kbCached: Object.keys(readKbCache()).length,
        ragEnabled: cfg.ragEnabled !== false,
      };
    },

    getConfig() {
      return { ...cfg };
    },

    /** 保存并热重连（改完不用重启应用）。 */
    saveConfig(patch) {
      saveConfigFile(patch || {});
      stats.enabled = !!cfg.enabled;
      stopping = false;
      if (reconnectTimer) {
        clearTimeout(reconnectTimer);
        reconnectTimer = null;
      }
      disconnect();
      reconnectDelay = 2000;
      if (cfg.enabled) {
        connect();
        startTimers();
      } else {
        stopTimers();
      }
      log('info', `配置已保存，按新配置重连（enabled=${cfg.enabled}）`);
      return { ...cfg };
    },

    /** 手改 config.json 后调这个重新读盘。 */
    reload() {
      cfg = loadConfig();
      return { ...cfg };
    },

    /**
     * 给面板看：最近一次联机的流水 + 索引。
     *
     * <p>2026-11-04：一次联机一个文件，所以这里要额外告诉面板
     * "总共有几次"和"更早那几次分别干了什么"（索引）。</p>
     */
    memory(limit) {
      const n = clamp(Number(limit) || 20, 1, 200);
      const p = memoryPath();
      const out = {
        ok: true,
        path: p,
        file: p ? path.basename(p) : '',
        total: 0,
        lines: [],
        sessions: 0,
        index: [],
      };
      try {
        out.sessions = fs.readdirSync(sessionsDir())
          .filter((f) => f.endsWith('.md') && f !== 'index.md').length;
      } catch {
        /* 还没玩过 */
      }
      try {
        out.index = fs.readFileSync(indexFile(), 'utf8')
          .split('\n')
          .filter((l) => l.trim().startsWith('- '))
          .slice(0, 6);
      } catch {
        /* 同上 */
      }
      try {
        const raw = fs.readFileSync(p, 'utf8');
        const lines = raw.split('\n').filter((l) => l.trim());
        out.total = lines.length;
        out.lines = lines.slice(-n);
        return out;
      } catch (e) {
        /*
         * 文件不存在是**正常状态**（还没玩过），不该在面板上显示成"读取失败"。
         * 只有真正的权限/IO 错误才当失败。
         */
        if (e && e.code === 'ENOENT') {
          return out;
        }
        return { ok: false, path: p, error: e.message };
      }
    },

    /**
     * 手动测知识库通不通（面板上的「查知识库」按钮用它）。
     *
     * <p>这一步**不经过模型**：直接调平台 `search` 工具，命中就说明
     * 知识库已挂到智能体、文档已导入、当前账号有 `tool:invoke` 权限。
     * 三段里缺任何一段都会返回空 —— 错误信息里把三种可能都列出来了。</p>
     */
    async testKnowledge(query) {
      const q = String(query || '').trim() || '我的世界 钻石矿 怎么获得';
      const text = await searchKb(q);
      return {
        ok: !!text,
        query: q,
        text,
        error: text
          ? ''
          : '没有命中：① 知识库没挂到这个智能体 ② 文档还没导入/索引完 ③ 当前账号没有 tool:invoke 权限',
        cached: Object.keys(readKbCache()).length,
      };
    },

    /** 调试：这一轮她实际会看到的上下文（原样吐出，缺什么一眼能看见）。 */
    debugContext() {
      try {
        return { ok: true, text: buildInject({ from: (parseNames(cfg.allowPlayers)[0] || '') }) };
      } catch (e) {
        return { ok: false, error: e.message };
      }
    },

    /**
     * 调试：她现在"看到了什么、想不想动"。
     *
     * <p>用户最常问的是"她怎么站着不动" —— 有了这个就能回答：
     * 什么都没新东西可看（attentions 空）、好奇心也低，那不动才是对的；
     * 反过来如果 attentions 有东西而她不说话，才需要看 diag 里的模型调用。</p>
     */
    debugAttention() {
      try {
        const raw = rawAttentions();
        const m = readMind();
        return {
          ok: true,
          curiosity: Number(m.curiosity.toFixed(2)),
          threshold: clamp(cfg.curiosityThreshold, 0.1, 1),
          rawCount: raw.length,
          novel: classifyAttentions(raw, m.seen, Date.now()).map((a) => ({
            id: a.id, label: a.label, dist: Math.round(a.dist), score: Number(a.score.toFixed(2)),
          })),
          intentions: m.intentions,
          seenCount: m.seen.length,
          idleMinutes: Math.round((Date.now() - lastActivityAt) / 60000),
        };
      } catch (e) {
        return { ok: false, error: e.message };
      }
    },

    /** 冒烟测试：解析器 + 好奇心的新奇度/排序（不连服务器也能跑）。 */
    selftest() {
      const sample = '等我一下\n[挖 oak_log 4]\n[去 家]\n这个 [不是动作] 留着\n[想做 去那个洞看看]';
      const parsed = parseActions(sample);

      /*
       * 好奇心用**合成数据**跑一遍（2026-11-04）：
       * ① 4 个注意点只取前 3；② 把取到的标记成"见过"之后，
       * 第 4 个才会浮上来 —— 这正是"同一棵树不会反复惊叹"的机制。
       */
      const demoRaw = [
        { kind: 'block', key: 'iron_ore', label: '铁矿', dist: 10, weight: 2.2 },
        { kind: 'block', key: 'diamond_ore', label: '钻石矿', dist: 14, weight: 3.0 },
        { kind: 'entity', key: 'cat', label: '猫', dist: 4, weight: 1.6 },
        { kind: 'block', key: 'poppy', label: '虞美人', dist: 3, weight: 1.2 },
      ];
      const now = Date.now();
      const first = classifyAttentions(demoRaw, [], now);
      const second = classifyAttentions(
        demoRaw,
        first.map((a) => ({ id: a.id, at: now })),
        now,
      );

      return {
        ok: true,
        parsed,
        curiosity: {
          first: first.map((a) => a.id),
          afterSeen: second.map((a) => a.id),
          value: Number(readMind().curiosity.toFixed(2)),
          intentions: readMind().intentions.map((i) => i.text),
        },
        injectLength: lastInject.length,
        memoryPath: memoryPath(),
        mindPath: mindPath(),
        agentId: resolveAgentId(),
      };
    },
  },
};
