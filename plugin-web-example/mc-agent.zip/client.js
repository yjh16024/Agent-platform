/*
 * MC 助手 · 前端面板（2026-11-04）
 *
 * 三件事：**看状态**、**开关总闸**、**翻一眼她记下的游戏记忆**。
 * 复杂配置（服务器 / 白名单 / 自主参数）走卡片上的「设置」表单（平台按 manifest.config 渲染）。
 */
window.__apPlugin__.register('mc_agent', {
  apply(ctx) {
    const h = ctx.react.createElement;
    const ui = { open: false, st: null, busy: false, mem: null, tip: '' };

    const BALL_W = 62;
    const BALL_H = 34;
    const EDGE = 30;
    const DRAG_THRESHOLD = 4;
    const POS_KEY = 'ap.mc.ball';

    let alive = true;
    let pos = loadPos();
    let drag = null;

    function defaultPos() {
      return {
        x: window.innerWidth - BALL_W - 24,
        // 放在 QQ 球（右下偏上 130）下面一点，两个球不叠
        y: window.innerHeight - BALL_H - 180,
      };
    }

    function clampIntoView(p) {
      return {
        x: Math.min(Math.max(p.x, -BALL_W / 2), window.innerWidth - BALL_W / 2),
        y: Math.min(Math.max(p.y, 0), window.innerHeight - BALL_H),
      };
    }

    function loadPos() {
      try {
        const raw = localStorage.getItem(POS_KEY);
        if (!raw) return null;
        const p = JSON.parse(raw);
        if (typeof p?.x !== 'number' || typeof p?.y !== 'number') return null;
        const safe = clampIntoView(p);
        if (Math.abs(safe.x - p.x) > 1 || Math.abs(safe.y - p.y) > 1) savePos(safe);
        return safe;
      } catch {
        return null;
      }
    }

    function savePos(p) {
      try {
        localStorage.setItem(POS_KEY, JSON.stringify(p));
      } catch {
        /* 隐私模式：位置只在本次会话有效 */
      }
    }

    /** 靠边半隐藏（与 QQ 球同一套手感）。 */
    function snap(p) {
      const halfW = BALL_W / 2;
      const halfH = BALL_H / 2;
      let { x, y } = p;
      if (x < EDGE) {
        x = -halfW;
      } else if (x > window.innerWidth - BALL_W - EDGE) {
        x = window.innerWidth - BALL_W + halfW;
      }
      if (y < EDGE) {
        y = -halfH;
      } else if (y > window.innerHeight - BALL_H - EDGE) {
        y = window.innerHeight - BALL_H + halfH;
      }
      return { x, y };
    }

    const draw = () => {
      if (!alive) return;
      ctx.render(h(View));
    };

    const refresh = async () => {
      try {
        ui.st = await ctx.host.invoke('status');
      } catch (e) {
        ui.st = { connected: false, lastError: e.message };
      }
      draw();
    };

    const toggle = async () => {
      ui.busy = true;
      draw();
      try {
        await ctx.host.invoke('saveConfig', { enabled: !(ui.st && ui.st.enabled) });
        await refresh();
      } catch (e) {
        ui.st = { ...(ui.st || {}), lastError: e.message };
      } finally {
        ui.busy = false;
        draw();
      }
    };

    /**
     * 查知识库（2026-11-04）：不经过模型，直接调平台的 `search` 工具。
     * 命中就说明"知识库已挂 + 文档已索引 + 有 tool:invoke 权限"三件事都成立。
     */
    const testKb = async () => {
      ui.busy = true;
      ui.tip = '查知识库中…';
      draw();
      try {
        const r = await ctx.host.invoke('testKnowledge', '我的世界 钻石矿 怎么获得');
        ui.tip = r && r.ok
          ? `✅ ${String(r.text).slice(0, 90)}`
          : `❌ ${(r && r.error) || '未知错误'}`;
      } catch (e) {
        ui.tip = `❌ ${e.message}`;
      } finally {
        ui.busy = false;
        draw();
      }
    };

    const showMemory = async () => {
      ui.busy = true;
      ui.tip = '读取中…';
      draw();
      try {
        const r = await ctx.host.invoke('memory', 12);
        ui.mem = r;
        ui.tip = r && r.ok ? '' : `读取失败：${(r && r.error) || '未知'}`;
      } catch (e) {
        ui.tip = `读取失败：${e.message}`;
      } finally {
        ui.busy = false;
        draw();
      }
    };

    // ---------------------------------------------------------------- 拖动

    function onPointerDown(e) {
      if (e.button !== undefined && e.button !== 0) return;
      const cur = pos || defaultPos();
      drag = {
        startX: e.clientX,
        startY: e.clientY,
        originX: cur.x,
        originY: cur.y,
        moved: false,
      };
      pos = cur;
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        /* 老浏览器没有指针捕获 */
      }
      draw();
    }

    function onPointerMove(e) {
      if (!drag) return;
      const dx = e.clientX - drag.startX;
      const dy = e.clientY - drag.startY;
      if (!drag.moved && Math.abs(dx) + Math.abs(dy) < DRAG_THRESHOLD) return;
      drag.moved = true;
      pos = clampIntoView({ x: drag.originX + dx, y: drag.originY + dy });
      draw();
    }

    function onPointerUp(e) {
      if (!drag) return;
      const moved = drag.moved;
      drag = null;
      try {
        e.currentTarget.releasePointerCapture(e.pointerId);
      } catch {
        /* 同上 */
      }
      if (moved) {
        pos = snap(pos || defaultPos());
        savePos(pos);
      } else {
        ui.open = !ui.open;
        if (ui.open) void refresh();
      }
      draw();
    }

    // ---------------------------------------------------------------- 视图

    const Ball = () => {
      const on = !!(ui.st && ui.st.connected);
      const p = pos || defaultPos();
      return h(
        'div',
        {
          className: 'ap-mc-ball' + (on ? ' on' : '') + (drag ? ' dragging' : ''),
          style: { left: p.x + 'px', top: p.y + 'px' },
          title: on ? `已在 ${ui.st.server}（可拖动）` : '未进游戏（可拖动）',
          onPointerDown,
          onPointerMove,
          onPointerUp,
          onPointerCancel: onPointerUp,
        },
        h('span', { className: 'ap-mc-dot' }),
        h('span', { className: 'ap-mc-label' }, 'MC'),
      );
    };

    const Row = (k, v) => h('div', { className: 'ap-mc-row' }, h('span', {}, k), h('b', {}, String(v)));

    const Panel = () => {
      const st = ui.st || {};
      const p = pos || defaultPos();
      const up = p.y > window.innerHeight / 2;
      const style = {
        left: Math.min(Math.max(p.x - 90, 8), window.innerWidth - 280) + 'px',
        top: up ? undefined : p.y + BALL_H + 8 + 'px',
        bottom: up ? window.innerHeight - p.y + 8 + 'px' : undefined,
      };
      return h(
        'div',
        { className: 'ap-mc-panel', style },
        h('div', { className: 'ap-mc-title' }, 'MC 助手'),
        Row('状态', st.connected ? '在游戏里' : '没进游戏'),
        st.connected ? Row('身份', st.username || st.server) : null,
        Row('收到 / 回话', `${st.received || 0} / ${st.replied || 0}`),
        Row('动作', `${st.actions || 0}`),
        // 好奇心（2026-11-04）：让她"此刻想不想动"变成看得见的东西
        st.curiosity !== undefined ? Row('好奇心', Number(st.curiosity).toFixed(2)) : null,
        st.intentions && st.intentions.length
          ? Row('打算', `${st.intentions.length} 件（${st.intentions[0]}）`)
          : null,
        st.noticed && st.noticed.length
          ? h('div', { className: 'ap-mc-hint' }, `刚注意到：${st.noticed.join('、')}`)
          : null,
        st.kbCached !== undefined
          ? Row('知识库缓存', `${st.kbCached} 条${st.ragEnabled ? '' : '（自动检索已关）'}`)
          : null,
        // 记忆按次分文件（2026-11-04）：一眼看出玩过几次、这次记在哪
        st.sessions !== undefined
          ? Row('联机记录', `${st.sessions} 次${st.sessionFile ? `（本次 ${st.sessionFile}）` : ''}`)
          : null,
        st.lastAction ? h('div', { className: 'ap-mc-hint' }, `上次：${st.lastAction}`) : null,
        st.lastError ? h('div', { className: 'ap-mc-err' }, st.lastError) : null,
        h(
          'div',
          { className: 'ap-mc-actions' },
          h('button', { disabled: ui.busy, onClick: () => void toggle() }, st.enabled ? '停用' : '启用'),
          h('button', { disabled: ui.busy, onClick: () => void refresh() }, '刷新'),
          h('button', { disabled: ui.busy, onClick: () => void showMemory() }, '记忆'),
          h('button', { disabled: ui.busy, onClick: () => void testKb() }, '知识库'),
        ),
        ui.tip ? h('div', { className: 'ap-mc-hint' }, ui.tip) : null,
        ui.mem && ui.mem.ok ? h(
          'div',
          { className: 'ap-mc-mem' },
          h('div', { className: 'ap-mc-mem-path' }, ui.mem.path),
          ...(ui.mem.lines || []).map((line, i) => h('div', { key: i }, line)),
        ) : null,
        h(
          'div',
          { className: 'ap-mc-hint' },
          '详细配置在插件卡片的「设置」里',
          h('br'),
          st.memoryPath || '',
        ),
      );
    };

    function View() {
      return h('div', null, h(Ball), ui.open ? h(Panel) : null);
    }

    draw();
    void refresh();

    const timer = setInterval(() => {
      if (ui.open) void refresh();
    }, 5000);

    const onResize = () => {
      if (!pos) return;
      const safe = clampIntoView(pos);
      if (Math.abs(safe.x - pos.x) > 1 || Math.abs(safe.y - pos.y) > 1) savePos(safe);
      pos = safe;
      draw();
    };
    window.addEventListener('resize', onResize);

    ctx.effect(() => () => {
      alive = false;
      clearInterval(timer);
      window.removeEventListener('resize', onResize);
    });
  },
});
